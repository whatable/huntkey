package com.huntkey.rx.sceo.client._util;

import com.huntkey.rx.commons.utils.rest.Result;

/**
 * 一个快捷生成错误结果对象（类型为{@link Result}的工厂类。注意：因为不确定处理Result对象的模块是否会对类型严格要求（如不接受subclass），所以建议严格使用Result类型，也就是调用instance()方法，而不建议调用本类构造方法。本类的多个instance方法返回的是Result对象而非本类对象。
 * 
 * @author jiangshaoh
 *
 */
public class RestErrorResult extends Result {

	/**
	 * 构造方法。不建议调用该方法，因为不确定处理Result对象的模块是否会对类型严格要求（如不接受subclass），所以建议严格使用Result类型，也就是调用instance()方法
	 */
	public RestErrorResult() {
		setRetCode(Result.RECODE_ERROR);
		setErrMsg("调用服务降级处理逻辑！");
	}

	/**
	 * 获得一个表示错误的结果对象，result.retCode默认值为{@link Result.RECODE_ERROR}，result.errMsg默认值为"unkown"
	 * 
	 * @return 错误结果对象
	 */
	public static Result instance() {
		Result result = new Result();
		result.setRetCode(Result.RECODE_ERROR);
		result.setErrMsg("unkown");
		return result;
	}

	/**
	 * 获得一个表示错误的结果对象，result.retCode默认值为{@link Result.RECODE_ERROR}，result.errMsg的值可以设定
	 * 
	 * @param message
	 *            result.errMsg属性的值，错误消息
	 * @return 错误结果对象
	 */
	public static Result instance(String message) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_ERROR);
		result.setErrMsg(message);
		return result;
	}

	/**
	 * 获得一个表示发生熔断的结果对象，result.retCode默认值为{@link Result.RECODE_ERROR}，result.errMsg默认值为"调用服务降级处理逻辑！"
	 * 
	 * @return 错误结果对象
	 */
	public static Result hystrix() {
		Result result = new Result();
		result.setRetCode(Result.RECODE_ERROR);
		result.setErrMsg("调用服务降级处理逻辑！");
		return result;
	}

}
