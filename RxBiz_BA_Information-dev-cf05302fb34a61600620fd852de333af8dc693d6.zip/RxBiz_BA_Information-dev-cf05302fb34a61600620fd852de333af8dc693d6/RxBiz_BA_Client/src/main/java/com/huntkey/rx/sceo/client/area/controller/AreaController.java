package com.huntkey.rx.sceo.client.area.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.sceo.client.area.feign.AreaService;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 区域
 * @author liucs
 * @date 2018-4-2 10:11:27
 */
@RestController
@RequestMapping("/area")
public class AreaController {
    @Autowired
    private AreaService areaService;
    /**
     * 新增
     * @param areaVO 区域对象集合
     * @return 返回对象id
     */
    @RequestMapping(value = "/v1/insert",method = RequestMethod.POST)
    public Result insert(HttpServletRequest request, @RequestBody AreaVO areaVO){
        String authorization = request.getHeader("Authorization");
        return areaService.insert(authorization,areaVO);
    }

    /**
     * 删除
     * @param id 对象id
     * @return 返回删除数量
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@RequestParam("id")String id){
        String authorization = request.getHeader("Authorization");
        return areaService.delete(authorization,id);
    }

    /**
     * 修改
     * @param areaVO 统计对象
     * @return 返回修改记录条数
     */
    @RequestMapping(value = "/v1/update", method = RequestMethod.PUT)
    public Result update(HttpServletRequest request,@RequestBody AreaVO areaVO){
        String authorization = request.getHeader("Authorization");
        return areaService.update(authorization,areaVO);
    }

    @RequestMapping(value = "/v1/qeuryObjectById/{id}",method = RequestMethod.GET)
    public Result qeuryObjectById(@PathVariable(value = "id")String id){
        return areaService.qeuryObjectById(id);
    }
    /**
     * 分页、模糊查询税率列表
     * @return
     */
    @RequestMapping(value = "/v1/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "countryId")String countryId){
        return areaService.list(countryId);
    }

    @RequestMapping(value = "/v1/childList",method = RequestMethod.GET)
    public Result childList(@RequestParam(required = false,value = "areaParentArea")String areaParentArea,
                            @RequestParam(required = false,value = "areaEnable")String areaEnable){
        return areaService.childList(areaParentArea,areaEnable);
    }

    /**
     * 查询省市级联数据
     * @return
     */
    @RequestMapping(value = "/v1/loadOptions", method = RequestMethod.GET)
    public Result loadOptions(){
        return areaService.loadOptions();
    }
    /**
     * 区域中文排序
     * @param areaParentArea
     * @return
     */
    @RequestMapping(value = "/v1/sortList/{areaParentArea}",method = RequestMethod.GET)
    public Result sortList(@PathVariable(value = "areaParentArea",required = false)String areaParentArea){
        return areaService.sortList(areaParentArea);
    }

    /**
     * 上下移
     * @param entityList
     * @return
     */
    @RequestMapping(value = "/updateList",method = RequestMethod.PUT)
    public Result sortArea(@RequestBody List<AreaVO> entityList){
        return areaService.sortArea(entityList);
    }

    /**
     * 查询国家列表
     */
    @RequestMapping(value = "/countryList", method = RequestMethod.GET)
    public Result countryList(){
        return areaService.countryList();
    }
}
