package com.huntkey.rx.sceo.client.area.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.sceo.client.area.feign.hystrix.AreaHystrix;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 10:18:20
 */
@Service
@FeignClient(value = "information-provider",fallback = AreaHystrix.class)
public interface AreaService {

    @RequestMapping(value = "/area/v1/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authorization")String authorization, @RequestBody AreaVO areaVO);

    @RequestMapping(value = "/area/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id);

    @RequestMapping(value = "/area/v1/update", method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody AreaVO areaVO);

    @RequestMapping(value = "/area/v1/qeuryObjectById/{id}",method = RequestMethod.GET)
    Result qeuryObjectById(@PathVariable(value = "id")String id);

    @RequestMapping(value = "/area/v1/list",method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "countryId")String countryId);

    @RequestMapping(value = "/area/v1/childList",method = RequestMethod.GET)
    Result childList(@RequestParam(required = false,value = "areaParentArea")String areaParentArea,
                            @RequestParam(required = false,value = "areaEnable")String areaEnable);

    @RequestMapping(value = "/area/v1/loadOptions", method = RequestMethod.GET)
    Result loadOptions();

    @RequestMapping(value = "/area/v1/sortList/{areaParentArea}",method = RequestMethod.GET)
    Result sortList(@PathVariable(value = "areaParentArea")String areaParentArea);

    @RequestMapping(value = "/area/updateList",method = RequestMethod.PUT)
    Result sortArea(@RequestBody List<AreaVO> entityList);

    @RequestMapping(value = "/area/countryList", method = RequestMethod.GET)
    Result countryList();
}
