package com.huntkey.rx.sceo.client.area.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.area.feign.AreaService;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AreaHystrix implements AreaService {
    @Override
    public Result insert(String authorization, AreaVO areaVO) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, AreaVO areaVO) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result qeuryObjectById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String countryId) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result childList(String areaParentArea, String areaEnable) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result loadOptions() {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result sortList(String areaParentArea) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result sortArea(List<AreaVO> entityList) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result countryList() {
        return RestErrorResult.hystrix();
    }
}
