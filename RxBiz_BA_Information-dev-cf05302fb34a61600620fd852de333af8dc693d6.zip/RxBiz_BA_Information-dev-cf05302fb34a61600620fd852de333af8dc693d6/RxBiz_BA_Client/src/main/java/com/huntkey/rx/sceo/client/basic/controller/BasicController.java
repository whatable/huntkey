package com.huntkey.rx.sceo.client.basic.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.basic.feign.BasicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * @author liucs
 * @date 2018-5-24 13:52:17
 */
@RestController
@RequestMapping(value = "/basic")
public class BasicController {
    @Autowired
    private BasicService basicService;

    public Result enable(HttpServletRequest request, @RequestParam(value = "id")String id){
        String authorization = request.getHeader("Authorization");
        return basicService.enable(authorization,id);
    }
}
