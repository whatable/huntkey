package com.huntkey.rx.sceo.client.basic.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.basic.feign.hystrix.BasicHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author liucs
 * @date 2018-5-24 13:51:57
 */
@FeignClient(value = "information-provider",fallback = BasicHystrix.class)
@Service
public interface BasicService {

    @RequestMapping(value = "/basic/enable",method = RequestMethod.PUT)
    Result enable(@RequestParam(value = "authorization")String authorization,@RequestParam(value = "id") String id);
}
