package com.huntkey.rx.sceo.client.basic.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.basic.feign.BasicService;
import org.springframework.stereotype.Component;

@Component
public class BasicHystrix implements BasicService{
    @Override
    public Result enable(String authorization, String id) {
        return RestErrorResult.hystrix();
    }
}
