package com.huntkey.rx.sceo.client.code.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NbrlNbrlManualNumberSetbEntity;
import com.huntkey.rx.sceo.client.code.feign.NbrlManualNumberSetService;
import com.huntkey.rx.sceo.client.tip.controller.TipMessageController;
import com.huntkey.rx.sceo.common.model.code.AddManualNumberByExcelDto;
import com.huntkey.rx.sceo.common.model.code.QryNumberRulesDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @author zoulj
 * @create 2017/11/27 11:02
 **/
@RestController
@RequestMapping(value = "/manualNumberSet")
public class NbrlManualNumberSetController {

    private static Logger log = LoggerFactory.getLogger(TipMessageController.class);

    @Autowired
    private NbrlManualNumberSetService nbrlManualNumberSetService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    Result list(HttpServletRequest request,@RequestParam(required = false, value = "nbrl_manual_number") String nbrl_manual_number,
                @RequestParam(required = false, value = "nbrl_is_use") String nbrl_is_use,
                @RequestParam(required = false, value = "pid", defaultValue = "0") String pid,
                @RequestParam(required = false, value = "token") String token,
                @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                @RequestParam(required = false, value = "pageSize", defaultValue = "10") int pageSize) {
        log.debug("Client::NbrlManualNumberSetController::list");
        String authorization = request.getHeader("Authorization");
        return nbrlManualNumberSetService.list(nbrl_manual_number, nbrl_is_use,pid,authorization,token, pageNum, pageSize);
    }

    /**
     * 批量上传手工编号
     *
     * @param file
     * @return
     */
    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
    public Result uploadFile(@RequestParam("file") MultipartFile file,
                             @RequestParam(required = false, value = "pid") String pid,
                             @RequestParam(required = false, value = "token") String token) throws Exception {
        if (file.isEmpty()) {
            Result ret = new Result();
            ret.setRetCode(Result.RECODE_ERROR);
            ret.setErrMsg("文件为空");
            return ret;
        }
        AddManualNumberByExcelDto dto = new AddManualNumberByExcelDto();
        dto.setBytes(file.getBytes());
        dto.setPid(pid);
        dto.setFileName(file.getOriginalFilename());
        dto.setToken(token);
        return nbrlManualNumberSetService.addToExcel(dto);

    }

    /**
     * 批量删除手工编码集
     *
     * @param manualNumberCodes
     * @return
     */
    @RequestMapping(value ="/delete", method = RequestMethod.DELETE)
    public Result delete(@RequestParam(required = false, value = "manualNumberCodes") String manualNumberCodes,
                         @RequestParam(required = false, value = "token") String token,
                         @RequestParam(required = false, value = "pid") String pid) throws Exception {
        return nbrlManualNumberSetService.delete(manualNumberCodes,token,pid);
    }

    /**
     * 列表排序修改
     *
     * @param nbs
     * @return
     */
    @RequestMapping(value = "/updateList", method = RequestMethod.PUT)
    public Result updateList(@RequestBody List<NbrlNbrlManualNumberSetbEntity> nbs) throws Exception {
        return nbrlManualNumberSetService.updateList(nbs);
    }

    /**
     * 单条插入手工编码
     *
     * @param nbrlManualNumberSet
     * @return
     */
    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public Result insert(@RequestBody NbrlNbrlManualNumberSetbEntity nbrlManualNumberSet,
                         @RequestParam(required = false, value = "token") String token) throws Exception {
        return nbrlManualNumberSetService.insert(nbrlManualNumberSet,token);
    }

    /**
     * 编码规则列表
     *
     * @param dto
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/qryNumberRules", method = RequestMethod.POST)
    public Result qryNumberRules(HttpServletRequest request,@RequestBody QryNumberRulesDto dto) throws Exception{
        String authorization = request.getHeader("Authorization");
        dto.setAuthorization(authorization);
        return nbrlManualNumberSetService.qryNumberRules(dto);
    }

    /**
     * 检验手动编号可存在
     *
     * @param nbrl_manual_number
     * @return
     */
    @RequestMapping(value = "/qryManualNumberCount", method = RequestMethod.GET)
    public Result qryManualNumberCount(@RequestParam(required = false, value = "nbrl_manual_number") String nbrl_manual_number,
                                       @RequestParam(required = false, value = "pid") String pid,
                                       @RequestParam(required = false, value = "token",defaultValue = "") String token) throws Exception {
        return nbrlManualNumberSetService.qryManualNumberCount(nbrl_manual_number,pid,token);
    }

    /**
     * 删除编码规则
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/deleteNumberRule", method = RequestMethod.DELETE)
    public Result deleteNumberRule(@RequestParam(required = false, value = "id") String id) throws Exception {
        return nbrlManualNumberSetService.deleteNumberRule(id);
    }


}
