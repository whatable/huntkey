package com.huntkey.rx.sceo.client.code.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NumberrulesEntity;
import com.huntkey.rx.sceo.client.code.feign.NumberRulesService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @author liucs
 * @date 2017-11-24 13:44:10
 */
@RestController
@RequestMapping("/numberRules")
public class NumberRulesController {
    private static Logger logger = LoggerFactory.getLogger(NumberRulesController.class);
    @Autowired
    private NumberRulesService numberRuleService;

    /**
     * 新增规则
     * @param numberrulesEntity
     * @return
     */
    @RequestMapping(value = "/addNumberRules",method = RequestMethod.POST)
    public Result addNumberRules(HttpServletRequest request,
                                 @RequestParam(required = false, value = "token", defaultValue = "") String token,
                                 @RequestBody NumberrulesEntity numberrulesEntity){
        String authorization = request.getHeader("Authorization");
        return numberRuleService.addNumberRules(authorization,numberrulesEntity,token);
    }

    /**
     * 根据id查询规则编号信息
     * @param id
     * @return
     */
    @RequestMapping(value = "/getNumberRule/{id}",method = RequestMethod.GET)
    public Result getNumberRule(@PathVariable("id") String id){
        return numberRuleService.getNumberRule(id);
    }

    /**
     * 启用、禁用
     * @param id
     * @return
     */
    @RequestMapping(value = "/enableOrNot/{id}",method = RequestMethod.POST)
    public Result enableOrNot(@PathVariable("id") String id,HttpServletRequest request){
      String authorization = request.getHeader("Authorization");
      return  numberRuleService.enableOrNot(id, authorization);
    }

    /**
     * 获取32位UUID
     * @return
     */
    @RequestMapping(value = "/generateUUID",method = RequestMethod.GET)
    public Result generateUUID(){
        return numberRuleService.generateUUID();
    }

    /**
     * 编号使用情况
     * @param nbrl_code 规则代码
     * @param nbrl_cu_code  已使用编号
     * @param pageNum
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/queryCodeUsed",method = RequestMethod.GET)
    public Result queryCodeUsed(@RequestParam(required = true, value = "nbrl_code")String nbrl_code,
                                @RequestParam(required = false, value = "nbrl_cu_code")String nbrl_cu_code,
                                @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                                @RequestParam(required = false, value = "pageSize", defaultValue = "10") int pageSize){
        return numberRuleService.queryCodeUsed(nbrl_code,nbrl_cu_code,pageNum,pageSize);
    }

    /**
     * 编号规则修改
     * @param numberrulesEntity
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public Result update(HttpServletRequest request,
                         @RequestParam(required = false, value = "token", defaultValue = "") String token,
                         @RequestBody NumberrulesEntity numberrulesEntity){
        String authorization = request.getHeader("Authorization");
        return numberRuleService.update(authorization ,numberrulesEntity,token);
    }

    @RequestMapping(value = "/isCodeExisted/{nbrl_code}",method = RequestMethod.GET)
    public Result isCodeExisted(@PathVariable("nbrl_code") String nbrl_code){
       return numberRuleService.isCodeExisted(nbrl_code);
    }

    @RequestMapping(value="/isNameExisted/{nbrl_name}",method = RequestMethod.GET)
    public Result isNameExisted(@PathVariable("nbrl_name") String nbrl_name){
        return numberRuleService.isNameExisted(nbrl_name);
    }

    @RequestMapping(value = "/getDefaultItems" ,method = RequestMethod.GET)
    public Result getDefaultItems(){
        return numberRuleService.getDefaultItems();
    }
}
