package com.huntkey.rx.sceo.client.code.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NbrlNbrlManualNumberSetbEntity;
import com.huntkey.rx.sceo.client.code.feign.hystrix.NbrlManualNumberSetHystrix;
import com.huntkey.rx.sceo.common.model.code.AddManualNumberByExcelDto;
import com.huntkey.rx.sceo.common.model.code.QryNumberRulesDto;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author zoulj
 * @create 2017/11/27 11:03
 **/
@FeignClient(value = "information-provider", fallback = NbrlManualNumberSetHystrix.class)
@Service
public interface NbrlManualNumberSetService {

    @RequestMapping(value = "/manualNumberSet/list", method = RequestMethod.GET)
    Result list(@RequestParam(required = false, value = "nbrl_manual_number") String nbrl_manual_number,
                @RequestParam(required = false, value = "nbrl_is_use") String nbrl_is_use,
                @RequestParam(required = false, value = "pid") String pid,
                @RequestParam(required = false, value = "authorization") String authorization,
                @RequestParam(required = false, value = "token") String token,
                @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                @RequestParam(required = false, value = "pageSize", defaultValue = "10") int pageSize);


    @RequestMapping(value = "/manualNumberSet/insertListByIo", method = RequestMethod.POST)
    Result addToExcel(@RequestBody AddManualNumberByExcelDto dto);

    @RequestMapping(value = "/manualNumberSet/delete", method = RequestMethod.DELETE)
    Result delete(@RequestParam(required = false, value = "manualNumberCodes") String manualNumberCodes,
                  @RequestParam(required = false, value = "token") String token,
                  @RequestParam(required = false, value = "pid") String pid) throws Exception;

    @RequestMapping(value = "/manualNumberSet/updateList", method = RequestMethod.PUT)
    Result updateList(@RequestBody List<NbrlNbrlManualNumberSetbEntity> nbs) throws Exception;

    @RequestMapping(value = "/manualNumberSet/insert", method = RequestMethod.POST)
    Result insert(@RequestBody NbrlNbrlManualNumberSetbEntity nbrlManualNumberSet,
                  @RequestParam(required = false, value = "token") String token) throws Exception;

    @RequestMapping(value = "/manualNumberSet/qryNumberRules", method = RequestMethod.POST)
    Result qryNumberRules(QryNumberRulesDto dto);

    @RequestMapping(value = "/manualNumberSet/qryManualNumberCount", method = RequestMethod.GET)
    Result qryManualNumberCount(@RequestParam(required = false, value = "nbrl_manual_number") String nbrl_manual_number,
                                @RequestParam(required = false, value = "pid") String pid,
                                @RequestParam(required = false, value = "token") String token);

    @RequestMapping(value = "/manualNumberSet/deleteNumberRule", method = RequestMethod.DELETE)
    Result deleteNumberRule(@RequestParam(required = false, value = "id")String id);

}

