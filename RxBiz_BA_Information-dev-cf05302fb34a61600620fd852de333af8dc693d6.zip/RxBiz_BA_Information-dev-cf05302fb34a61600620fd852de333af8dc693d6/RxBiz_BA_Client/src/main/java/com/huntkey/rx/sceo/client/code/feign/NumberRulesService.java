package com.huntkey.rx.sceo.client.code.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NumberrulesEntity;
import com.huntkey.rx.sceo.client.code.feign.hystrix.NumberRulesHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

@FeignClient(value = "information-provider", fallback = NumberRulesHystrix.class)
@Service
public interface NumberRulesService {
    /**
     * 插入
     * @param numberrulesEntity
     * @param token
     * @return
     */
    @RequestMapping(value="/numberRules/addNumberRules", method = RequestMethod.POST)
    Result addNumberRules(@RequestParam("authorization") String authorization,
                          @RequestBody NumberrulesEntity numberrulesEntity,
                          @RequestParam("token")String token);

    /**
     * 查询numberRule详细信息
     * @param id
     * @return
     */
    @RequestMapping(value="/numberRules/getNumberRule/{id}", method = RequestMethod.GET)
    Result getNumberRule(@PathVariable("id") String id);

    /**
     * 修改状态
     * @param id
     * @return
     */
    @RequestMapping(value="/numberRules/enableOrNot/{id}", method = RequestMethod.POST)
    Result enableOrNot(@PathVariable("id")  String id, @RequestParam("authorization") String authorization);

    /**
     * 生成32位UUID
     * @return
     */
    @RequestMapping(value = "/numberRules/generateUUID",method = RequestMethod.GET)
    Result generateUUID();

    /**
     * 编号使用情况
     * @param nbrl_code  规则代码
     * @param nbrl_cu_code  已使用编号
     * @param pageNum
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/numberRules/queryCodeUsed", method = RequestMethod.GET)
    Result queryCodeUsed(@RequestParam(required = true, value = "nbrl_code")String nbrl_code,
                         @RequestParam(required = false, value = "nbrl_cu_code")String nbrl_cu_code,
                         @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                         @RequestParam(required = false, value = "pageSize", defaultValue = "10") int pageSize);

    /**
     * 编号规则修改
     * @param numberrulesEntity
     * @param token
     * @return
     */
    @RequestMapping(value = "/numberRules/update", method = RequestMethod.POST)
    Result update(@RequestParam("authorization") String authorization,
                  @RequestBody NumberrulesEntity numberrulesEntity,
                  @RequestParam("token")String token);

    @RequestMapping(value = "/numberRules/isCodeExisted/{nbrl_code}",method = RequestMethod.GET)
    Result isCodeExisted(@PathVariable("nbrl_code") String nbrl_code);

    @RequestMapping(value="/numberRules/isNameExisted/{nbrl_name}",method = RequestMethod.GET)
    Result isNameExisted(@PathVariable("nbrl_name") String nbrl_name);

    @RequestMapping(value = "/numberRules/getDefaultItems", method = RequestMethod.GET)
    Result getDefaultItems();
}
