package com.huntkey.rx.sceo.client.code.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NbrlNbrlManualNumberSetbEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.code.feign.NbrlManualNumberSetService;
import com.huntkey.rx.sceo.common.model.code.AddManualNumberByExcelDto;
import com.huntkey.rx.sceo.common.model.code.QryNumberRulesDto;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author zoulj
 * @create 2017/11/27 11:04
 **/
@Component
public class NbrlManualNumberSetHystrix implements NbrlManualNumberSetService {

    @Override
    public Result list(String nbrlManualNumber, String nbrlIsUse,String pid, String authorization,String token, int pageNum, int pageSize) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result addToExcel(AddManualNumberByExcelDto dto) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String manualNumberCodes,String token, String pid) throws Exception {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result updateList(List<NbrlNbrlManualNumberSetbEntity> nbs) throws Exception {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result insert(NbrlNbrlManualNumberSetbEntity nbrlManualNumberSet, String token) throws Exception {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result qryNumberRules(QryNumberRulesDto dto) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result qryManualNumberCount(String nbrl_manualNumber, String pid, String token) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result deleteNumberRule(String id) {
        return RestErrorResult.hystrix();
    }
}
