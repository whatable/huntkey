package com.huntkey.rx.sceo.client.code.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NumberrulesEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.code.feign.NumberRulesService;
import org.springframework.stereotype.Component;

/**
 * @author liucs
 * @date 2017-11-30 17:51:02
 */
@Component
public class NumberRulesHystrix implements NumberRulesService {

    @Override
    public Result addNumberRules(String authorization, NumberrulesEntity numberrulesEntity, String token) {
        return RestErrorResult.hystrix();
    }
    @Override
    public Result getNumberRule(String id) {
        return RestErrorResult.hystrix();
    }
    @Override
    public Result enableOrNot(String id,String authorization) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result generateUUID(){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryCodeUsed(String nbrlCode, String nbrlCuCode, int pageNum, int pageSize){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, NumberrulesEntity numberrulesEntity, String token){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result isCodeExisted(String nbrl_code){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result isNameExisted(String nbrl_name){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result getDefaultItems(){
        return RestErrorResult.hystrix();
    }
}
