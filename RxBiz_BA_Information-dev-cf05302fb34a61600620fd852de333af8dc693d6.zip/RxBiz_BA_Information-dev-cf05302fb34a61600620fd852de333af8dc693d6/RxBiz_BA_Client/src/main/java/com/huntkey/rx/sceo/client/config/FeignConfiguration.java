package com.huntkey.rx.sceo.client.config;

import com.huntkey.rx.sceo.client.filter.MyRequestInterceptor;
import feign.Request;
import feign.Retryer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 *
 * @author xuyf
 * @date 2017/7/27
 */
@Configuration
public class FeignConfiguration {

    @Bean
    Retryer retryer(){
        return Retryer.NEVER_RETRY;
    }

    @Bean
    Request.Options feignOptions() {
        return new Request.Options(1 * 1000,50 * 1000);
    }

    // @Bean
    // public MyRequestInterceptor requestInterceptor(){
    //     return new MyRequestInterceptor();
    // }
}
