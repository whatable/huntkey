package com.huntkey.rx.sceo.client.currency.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;
import com.huntkey.rx.sceo.client.currency.feign.CurrRateService;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrRateVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

/**
 * @author liucs
 * @date 2018-4-3 11:20:38
 */
@RestController
@RequestMapping("/currRate")
public class CurrRateController {
    @Autowired
    private CurrRateService currRateService;

//    /**
//     * 新增
//     * @param entity 对象
//     * @return 返回对象id
//     */
//    @RequestMapping(value = "/creCurrRateOrder",method = RequestMethod.GET)
//    public Result creCurrRateOrder(HttpServletRequest request, @RequestBody CurrRateVO entity){
//        String authorization = request.getHeader("Authorization");
//        return currRateService.creCurrRateOrder(authorization,entity);
//    }

    /**
     * 删除
     * @param id 对象id
     * @return 返回删除数量
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@RequestParam("id")String id){
        String authorization = request.getHeader("Authorization");
        return currRateService.delete(authorization,id);
    }

    /**
     * 修改
     * @param entity 对象
     * @return 返回修改记录条数
     */
//    @RequestMapping(value = "/update", method = RequestMethod.PUT)
//    public Result update(HttpServletRequest request,@RequestBody CurrRateVO entity){
//        String authorization = request.getHeader("Authorization");
//        return currRateService.update(authorization,entity);
//    }

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     */
    @RequestMapping(value = "/queryById/{id}",method = RequestMethod.GET)
    public Result queryById(@PathVariable("id")String id){
        return currRateService.queryById(id);
    }

    /**
     * 分页、模糊查询币别列表
     * @param currConvCurr 查询币别
     * @param pageSize 每页数据量
     * @param pageNum 当前页数
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "currConvCurr")String currConvCurr,
                       @RequestParam(required = false,value = "pid")String pid,
                       @RequestParam(required = false,value = "currRateEnable")String currRateEnable,
                       @RequestParam(required = false,value = "currBeg")String currBeg,
                       @RequestParam(required = false,value = "currEnd")String currEnd,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum) {
        return currRateService.list(currConvCurr,pid,currRateEnable,currBeg,currEnd,pageSize,pageNum);
    }

    @RequestMapping(value = "/loadOrder/{orderId}", method = RequestMethod.GET)
    public Result loadOrder(@PathVariable(value = "orderId")String orderId){
        return currRateService.loadOrder(orderId);
    }

    @RequestMapping(value = "/currRateAuditList")
    public Result currRateAuditList(@RequestParam(value = "ordeStatus")String ordeStatus,
                                    @RequestParam(required = false, defaultValue = "50", value = "pageSize")Integer pageSize,
                                    @RequestParam(required = false, defaultValue = "1", value = "pageNum")Integer pageNum){
        return currRateService.currRateAuditList(ordeStatus,pageSize,pageNum);
    }
}
