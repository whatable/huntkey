package com.huntkey.rx.sceo.client.currency.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.CurrencyEntity;
import com.huntkey.rx.sceo.client.currency.feign.CurrencyService;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrencyVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @author liucs
 * @date 2018-4-3 11:02:58
 */
@RestController
@RequestMapping("/currency")
public class CurrencyController {
    @Autowired
    private CurrencyService currencyService;

    /**
     * 新增
     * @param entity 对象
     * @return 返回对象id
     */
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(HttpServletRequest request, @RequestBody CurrencyVO entity){
        String authorization = request.getHeader("Authorization");
        return currencyService.insert(authorization,entity);
    }

    /**
     * 删除
     * @param id 对象id
     * @return 返回删除数量
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@RequestParam("id")String id){
        String authorization = request.getHeader("Authorization");
        return currencyService.delete(authorization,id);
    }

    /**
     * 修改
     * @param entity 对象
     * @return 返回修改记录条数
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public Result update(HttpServletRequest request,@RequestBody CurrencyVO entity){
        String authorization = request.getHeader("Authorization");
        return currencyService.update(authorization,entity);
    }

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     */
    @RequestMapping(value = "/queryById/{id}",method = RequestMethod.GET)
    public Result queryById(@PathVariable("id")String id){
        return currencyService.queryById(id);
    }

    /**
     * 分页、模糊查询币别列表
     * @param currCode
     * @param currSysCode
     * @param currName
     * @param currEnable
     * @param pageSize
     * @param pageNum
     * @return
     */
    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "currCode")String currCode,
                       @RequestParam(required = false,value = "currSysCode")String currSysCode,
                       @RequestParam(required = false,value = "currName")String currName,
                       @RequestParam(required = false,value = "currEnable")String currEnable,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum){
        return currencyService.list(currCode,currSysCode,currName,currEnable,pageSize,pageNum);
    }

    /**
     * 查询所有币别
     * @return
     */
    @RequestMapping(value = "/allCurrencies",method = RequestMethod.GET)
    public Result allCurrencies(){
        return currencyService.allCurrencies();
    }
}
