package com.huntkey.rx.sceo.client.currency.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;
import com.huntkey.rx.sceo.client.currency.feign.hystrix.CurrRateHystrix;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrRateVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * @author liucs
 * @date 2018-4-3 11:21:40
 */
@Service
@FeignClient(value = "information-provider",fallback = CurrRateHystrix.class)
public interface CurrRateService {

    @RequestMapping(value = "/currRate/insert",method = RequestMethod.GET)
    Result creCurrRateOrder(@RequestParam("authotization")String authorization, @RequestBody CurrRateVO entity);

    @RequestMapping(value = "/currRate/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id);

    @RequestMapping(value = "/currRate/update", method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody CurrRateVO entity);

    @RequestMapping(value = "/currRate/queryById/{id}",method = RequestMethod.GET)
    Result queryById(@PathVariable("id")String id);

    @RequestMapping(value = "/currRate/list", method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "currConvCurr")String currConvCurr,
               @RequestParam(required = false,value = "pid")String pid,
               @RequestParam(required = false,value = "currRateEnable")String currRateEnable,
               @RequestParam(required = false,value = "currBeg")String currBeg,
               @RequestParam(required = false,value = "currEnd")String currEnd,
               @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
               @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum);

    @RequestMapping(value = "/currRate/loadOrder/{orderId}", method = RequestMethod.GET)
    Result loadOrder(@PathVariable(value = "orderId")String orderId);

    @RequestMapping(value = "/currRate/currRateAuditList", method = RequestMethod.GET)
    Result currRateAuditList(@RequestParam(value = "ordeStatus")String ordeStatus,
                                    @RequestParam(required = false, defaultValue = "50", value = "pageSize")Integer pageSize,
                                    @RequestParam(required = false, defaultValue = "1", value = "pageNum")Integer pageNum);
}
