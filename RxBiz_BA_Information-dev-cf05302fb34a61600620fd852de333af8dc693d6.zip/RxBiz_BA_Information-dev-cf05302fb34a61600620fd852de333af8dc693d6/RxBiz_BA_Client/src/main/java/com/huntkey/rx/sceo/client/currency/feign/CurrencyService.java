package com.huntkey.rx.sceo.client.currency.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.CurrencyEntity;
import com.huntkey.rx.sceo.client.currency.feign.hystrix.CurrencyHystrix;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrencyVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

/**
 * @author liucs
 * @date 2018-4-3 11:05:53
 */
@Service
@FeignClient(value = "information-provider",fallback = CurrencyHystrix.class)
public interface CurrencyService {

    @RequestMapping(value = "/currency/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authotization")String authorization, @RequestBody CurrencyVO entity);

    @RequestMapping(value = "/currency/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id);

    @RequestMapping(value = "/currency/update", method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody CurrencyVO entity);

    @RequestMapping(value = "/currency/queryById/{id}",method = RequestMethod.GET)
    Result queryById(@PathVariable("id")String id);

    @RequestMapping(value = "/currency/list",method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "currCode")String currCode,
                @RequestParam(required = false,value = "currSysCode")String currSysCode,
                @RequestParam(required = false,value = "currName")String currName,
                @RequestParam(required = false,value = "currEnable")String currEnable,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum);

    @RequestMapping(value = "/currency/allCurrencies",method = RequestMethod.GET)
    Result allCurrencies();
}

