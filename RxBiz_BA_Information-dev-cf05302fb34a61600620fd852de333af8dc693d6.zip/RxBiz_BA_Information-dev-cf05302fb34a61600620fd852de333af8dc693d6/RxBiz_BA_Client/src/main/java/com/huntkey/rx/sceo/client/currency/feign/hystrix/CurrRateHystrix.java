package com.huntkey.rx.sceo.client.currency.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.currency.feign.CurrRateService;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrRateVO;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * @author liucs
 * @date 2018-4-3 11:23:23
 */
@Component
public class CurrRateHystrix implements CurrRateService {
    @Override
    public Result creCurrRateOrder(String authorization, CurrRateVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, CurrRateVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String currConvCurr, String pid, String currRateEnable, String currBeg,String currEnd, Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result loadOrder(String orderId) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result currRateAuditList(String ordeStatus, Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }
}
