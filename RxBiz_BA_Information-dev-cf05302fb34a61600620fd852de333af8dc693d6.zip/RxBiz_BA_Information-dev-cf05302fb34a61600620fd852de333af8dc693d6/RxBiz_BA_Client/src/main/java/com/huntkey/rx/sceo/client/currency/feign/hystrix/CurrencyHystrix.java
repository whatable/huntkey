package com.huntkey.rx.sceo.client.currency.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.CurrencyEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.currency.feign.CurrencyService;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrencyVO;
import org.springframework.stereotype.Component;

@Component
public class CurrencyHystrix implements CurrencyService {
    @Override
    public Result insert(String authorization, CurrencyVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, CurrencyVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String currCode,String currSysCode,String currName,String currEnable, Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result allCurrencies() {
        return RestErrorResult.hystrix();
    }
}
