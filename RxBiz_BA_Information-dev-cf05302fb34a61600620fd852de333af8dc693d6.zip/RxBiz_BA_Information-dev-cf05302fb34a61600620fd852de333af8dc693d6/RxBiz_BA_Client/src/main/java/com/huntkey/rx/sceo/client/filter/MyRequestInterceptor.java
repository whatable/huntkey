package com.huntkey.rx.sceo.client.filter;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * @author zhoucj
 */
public class MyRequestInterceptor implements RequestInterceptor {
    @Override
    public void apply(RequestTemplate arg0) {
        RequestContextHolder.getRequestAttributes();
        ServletRequestAttributes servletRequest = (ServletRequestAttributes) RequestContextHolder
                .getRequestAttributes();
        HttpServletRequest req = servletRequest.getRequest();
        String auth = req.getHeader("Authorization");
        arg0.header("Authorization", auth);
    }
}