package com.huntkey.rx.sceo.client.measureunit.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.MeasureunitEntity;
import com.huntkey.rx.sceo.client.measureunit.feign.MeasureunitManageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * Created by zhoucj on 2017/12/5.
 */
@RestController
@RequestMapping(value = "/measureunit")
public class MeasureunitmanageController {
    @Autowired
    private MeasureunitManageService measureunitManageService;

    @RequestMapping(method = RequestMethod.POST)
    public Result save(@RequestBody MeasureunitEntity measureunitEntity) throws Exception {
       return measureunitManageService.save(measureunitEntity);
    }

    /**
     * 删除计量单位
     * @param ids 计量单位id，多个id用逗号隔开
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/unit", method = RequestMethod.DELETE)
    public Result deleteUnit(@RequestParam String ids) throws Exception {
        return measureunitManageService.deleteUnits(ids);
    }

    /**
     * 删除计量对象
     * @param id 计量对象id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/object/{id}", method = RequestMethod.DELETE)
    public Result delete(@PathVariable(value = "id") String id) throws Exception {
        return measureunitManageService.delete(id);
    }

    /**
     * 查询接口
     * @param symbol   单位符号
     * @param objName  计量对象名称
     * @param baseName 基准单位名称
     * @param isStand  是否标准单位
     * @param enable   状态
     * @param pageNum  起始页
         * @param pageSize 每页条数
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET)
    public Result select(@RequestParam(required = false, value = "symbol") String symbol,
                         @RequestParam(required = false, value = "obj_name") String objName,
                         @RequestParam(required = false, value = "base_name") String baseName,
                         @RequestParam(required = false, value = "is_stand") Integer isStand,
                         @RequestParam(required = false, value = "enable") Integer enable,
                         @RequestParam(required = false, value = "page_num", defaultValue = "1") Integer pageNum,
                         @RequestParam(required = false, value = "page_size", defaultValue = "15") Integer pageSize)
            throws Exception {
        return measureunitManageService.select(symbol, objName, baseName, isStand,
                enable, pageNum, pageSize);
    }

    /**
     * 获取计量单位
     * @param id 计量对象id
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/{id}/units", method = RequestMethod.GET)
    public Result getUnits(@PathVariable(value = "id") String id) throws Exception {
        return measureunitManageService.getUnitsById(id);
    }

    @RequestMapping(value = "/check", method = RequestMethod.GET)
    public Result objNameCheck(@RequestParam(value = "meas_name") String measName){
        return measureunitManageService.objNameCheck(measName);
    }

    @RequestMapping(value = "/enable/{groupId}/{status}", method = RequestMethod.PUT)
    public Result changeStatus(@PathVariable(value = "groupId") String groupId,
                        @PathVariable(value = "status") Integer status) {
        return measureunitManageService.changeStatus(groupId, status);
    }
}
