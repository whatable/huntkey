package com.huntkey.rx.sceo.client.measureunit.feign;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.MeasMeasDefineSetaEntity;
import com.huntkey.rx.edm.entity.MeasureunitEntity;
import com.huntkey.rx.sceo.client.measureunit.feign.hystrix.MeasureunitManageServiceHystrix;
import com.huntkey.rx.sceo.common.model.measureunit.MeasureunitInfo;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by zhoucj on 2017/12/5.
 */
@FeignClient(value = "information-provider", fallback = MeasureunitManageServiceHystrix.class)
public interface MeasureunitManageService {
    @RequestMapping(value = "/measureunit/check", method = RequestMethod.GET)
    Result objNameCheck(@RequestParam(value = "meas_name") String measName);
//
//    Result unitCheck(List<MeasMeasDefineSetaEntity> meas_define_set);

    @RequestMapping(value = "/measureunit", method = RequestMethod.POST)
    Result save(@RequestBody MeasureunitEntity measureunitEntity);

    @RequestMapping(value = "/measureunit/unit", method = RequestMethod.DELETE)
    Result deleteUnits(@RequestParam(value = "ids") String ids);

    @RequestMapping(value = "/measureunit/object/{id}", method = RequestMethod.DELETE)
    Result delete(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/measureunit", method = RequestMethod.GET)
    Result select(@RequestParam(required = false, value = "symbol") String symbol,
                  @RequestParam(required = false, value = "obj_name") String objName,
                  @RequestParam(required = false, value = "base_name") String baseName,
                  @RequestParam(required = false, value = "is_stand") Integer isStand,
                  @RequestParam(required = false, value = "enable") Integer enable,
                  @RequestParam(required = false, value = "page_num", defaultValue = "1") Integer pageNum,
                  @RequestParam(required = false, value = "page_size", defaultValue = "15") Integer pageSize);

    @RequestMapping(value = "/measureunit/{id}/units", method = RequestMethod.GET)
    Result getUnitsById(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/measureunit/enable/{groupId}/{status}", method = RequestMethod.PUT)
    Result changeStatus(@PathVariable(value = "groupId") String groupId,
                               @PathVariable(value = "status") Integer status);
}
