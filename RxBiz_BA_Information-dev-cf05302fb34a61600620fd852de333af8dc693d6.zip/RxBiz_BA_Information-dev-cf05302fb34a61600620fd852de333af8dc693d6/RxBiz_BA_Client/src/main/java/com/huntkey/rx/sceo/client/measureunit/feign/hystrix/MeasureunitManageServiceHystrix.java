package com.huntkey.rx.sceo.client.measureunit.feign.hystrix;


import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.MeasMeasDefineSetaEntity;
import com.huntkey.rx.edm.entity.MeasureunitEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.measureunit.feign.MeasureunitManageService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by zhoucj on 2017/12/5.
 */
@Service
public class MeasureunitManageServiceHystrix implements MeasureunitManageService {
    @Override
    public Result objNameCheck(String measName) {
        return RestErrorResult.hystrix();
    }
//
//    @Override
//    public Result unitCheck(List<MeasMeasDefineSetaEntity> meas_define_set) {
//        Result result = new Result();
//        result.setRetCode(Result.RECODE_ERROR);
//        result.setErrMsg("调用服务降级处理逻辑！");
//        return result;
//    }

    @Override
    public Result save(MeasureunitEntity measureunitEntity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result deleteUnits(String ids) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result select(String symbol, String objName, String baseName, Integer isStand, Integer enable, Integer pageNum, Integer pageSize) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result getUnitsById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result changeStatus(String groupId, Integer status) {
        return RestErrorResult.hystrix();
    }
}
