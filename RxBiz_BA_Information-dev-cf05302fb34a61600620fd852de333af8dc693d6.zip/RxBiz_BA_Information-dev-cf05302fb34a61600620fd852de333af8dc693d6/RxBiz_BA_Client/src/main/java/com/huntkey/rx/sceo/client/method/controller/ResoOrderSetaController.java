package com.huntkey.rx.sceo.client.method.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.method.feign.ResoOrderSetaService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liucs
 * @date 2017-11-22 11:52:46
 */
@RestController
@RequestMapping("/resoOrder")
public class ResoOrderSetaController {
    private static Logger log = LoggerFactory.getLogger(ResoOrderSetaController.class);

    @Autowired
    private ResoOrderSetaService resoOrderSetaService;

    @RequestMapping(value = "/addBill/{edmcCode}&{objId}",method = RequestMethod.GET)
    public Result addBill(@PathVariable String edmcCode,@PathVariable String objId){
        return resoOrderSetaService.addBill(edmcCode,objId);
    }
}
