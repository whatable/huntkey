package com.huntkey.rx.sceo.client.method.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.method.feign.hystrix.ResoOrderSetaHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author liucs
 * @date 2017-11-22 17:48:48
 */
@FeignClient(value = "tip-provider", fallback = ResoOrderSetaHystrix.class)
public interface ResoOrderSetaService {
    /**
     *
     * @param edmcCode
     * @param objId
     * @return
     */
    @RequestMapping(value = "/resoOrder/addBill/{edmcCode}&{objId}",method = RequestMethod.GET)
    Result addBill(@PathVariable(value="edmcCode") String edmcCode,
                        @PathVariable(value="objId") String objId);
}
