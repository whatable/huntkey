package com.huntkey.rx.sceo.client.method.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.method.feign.ResoOrderSetaService;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * @author liucs
 * @date 2017-11-22 17:54:07
 */
@Component
public class ResoOrderSetaHystrix implements ResoOrderSetaService{
    @Override
    public Result addBill(String edmcCode, String objId) {
        return RestErrorResult.hystrix();
    }
}
