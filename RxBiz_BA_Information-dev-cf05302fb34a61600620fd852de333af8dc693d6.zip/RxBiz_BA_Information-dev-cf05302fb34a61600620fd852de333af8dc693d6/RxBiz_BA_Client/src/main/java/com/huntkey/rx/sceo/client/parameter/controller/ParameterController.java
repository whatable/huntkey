package com.huntkey.rx.sceo.client.parameter.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.sceo.client.parameter.feign.ParameterService;
import com.huntkey.rx.sceo.common.model.paramter.ParamterDto;
import com.huntkey.rx.sceo.common.model.paramter.VO.TreeVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/parameter")
public class ParameterController {

    @Autowired
    private ParameterService parameterService;

    @RequestMapping(value="/list", method = RequestMethod.GET)
    public Result list(@RequestParam(required = false, value = "parm_no")String parm_no,
                       @RequestParam(required = false, value = "parm_type")String parm_type,
                       @RequestParam(required = false, value = "parm_name")String parm_name,
                       @RequestParam(required = false, value = "parm_form_name")String parm_form_name,
                       @RequestParam(required = false, value = "pageNum",defaultValue = "1")Integer pageNum,
                       @RequestParam(required = false, value = "pageSize",defaultValue = "15")Integer pageSize){
        return parameterService.list(parm_no,parm_type,parm_name,parm_form_name,pageNum,pageSize);
    }

    @RequestMapping(value="/getParameter/{id}", method = RequestMethod.GET)
    public Result getParameter(@PathVariable(value = "id") String id){
        return parameterService.getParameter(id);
    }

    @RequestMapping(value="/delete/{id}", method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@PathVariable(value = "id") String id){
        String authorization = request.getHeader("Authorization");
        return parameterService.delete(authorization,id);
    }

    @RequestMapping(value = "/qryParameValueByParamType", method = RequestMethod.GET)
    public Result qryParameValueByParamType(HttpServletRequest request) throws Exception{
        String pageCode = request.getParameter("pageCode");
        if(StringUtils.isEmpty(pageCode)){
            pageCode = "all";//查询所有
        }
        return parameterService.qryParametersGroupByParamType(pageCode);

    }

    @RequestMapping(value = "/updataParameValues", method = RequestMethod.POST)
    public Result updataParameValues(@RequestBody Map<String, List<ParameterEntity>> map) throws Exception{
        return parameterService.updataParameValues(map);
    }

    @RequestMapping(value = "/updataParameValue", method = RequestMethod.POST)
    public Result updataParameValues(@RequestBody ParameterEntity entity) throws Exception{
        return parameterService.updataParameValue(entity);
    }

    @RequestMapping(value="/insert", method = RequestMethod.POST)
    public Result insert(HttpServletRequest request,@RequestBody ParameterEntity parameterEntity){
        String authorization = request.getHeader("Authorization");
        return parameterService.insert(authorization,parameterEntity);
    }

    @RequestMapping(value="/modify", method = RequestMethod.POST)
    public Result modify(HttpServletRequest request,@RequestBody ParameterEntity parameterEntity){
        String authorization = request.getHeader("Authorization");
        return parameterService.modify(authorization,parameterEntity);
    }

    @RequestMapping(value = "/updateList", method = RequestMethod.PUT)
    public Result updateList(@RequestBody List<ParameterEntity> parameterEntities){
        return parameterService.updateList(parameterEntities);
    }

    /**
     * 查询启用提示
     * @param className
     * @param value
     * @param text
     * @param tip
     * @return
     */
    @RequestMapping(value="/getTips",method=RequestMethod.GET)
    public Result getTips(@RequestParam("className")String className,
                          @RequestParam("value")String value,
                          @RequestParam("text")String text,
                          @RequestParam("tip")String tip){

        return parameterService.getTips(className,value,text,tip);
    }

    @RequestMapping(value="/checkParamNo",method=RequestMethod.GET)
    public Result checkParamNo(@RequestParam("paramNo")String paramMo){
        return parameterService.checkParamNo(paramMo);
    }

    @RequestMapping(value="/checkParamName",method=RequestMethod.GET)
    public Result checkParamName(@RequestParam("paramName")String paramName){
        return parameterService.checkParamName(paramName);
    }

    @RequestMapping(value = "/qryTree", method = RequestMethod.GET)
    public Result qryTree(@RequestParam(value = "classId") String classId,
                          @RequestParam(value = "valueId") String valueId,
                          @RequestParam(value = "textId") String textId,
                          @RequestParam(value = "pId") String pId) throws Exception {
        Result result = new Result();
        result =  this.parameterService.qryTree(classId, valueId, textId, pId);
        return result;
    }

    @RequestMapping(value = "/queryValuesSet/{id}", method = RequestMethod.GET)
    public Result queryValuesSet(@PathVariable(value="id") String id){
        return parameterService.queryValuesSetByPid(id);
    }

    @RequestMapping(value = "/qryParmSetting", method = RequestMethod.GET)
    public Result qryParmSetting(@RequestParam(value = "pageCode")String pageCode,
                                @RequestParam(required = false, value = "parmType")String parmType,
                                @RequestParam(required = false, value = "parmName")String parmName){
        return parameterService.qryParmSetting(pageCode, parmType, parmName);
    }

    @RequestMapping(value = "/loadOrder/{orderId}",method = RequestMethod.GET)
    public Result loadOrder(@PathVariable(value = "orderId")String orderId){
        return parameterService.loadOrder(orderId);
    }
    @RequestMapping(value = "/parameterOrderList", method = RequestMethod.GET)
    public Result parameterOrderList(@RequestParam(value = "ordeStatus")String ordeStatus,
                                     @RequestParam(required = false,defaultValue = "50",value = "pageSize")Integer pageSize,
                                     @RequestParam(required = false,defaultValue = "1", value = "pageNum")Integer pageNum){
        return parameterService.parameterOrderList(ordeStatus, pageSize, pageNum);
    }
}
