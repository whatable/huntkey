package com.huntkey.rx.sceo.client.parameter.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.sceo.client.parameter.feign.hystrix.ParameterHystrix;
import com.huntkey.rx.sceo.common.model.paramter.ParamterDto;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@FeignClient(value = "information-provider", fallback = ParameterHystrix.class)
@Service
public interface ParameterService {
    /**
     * 参数列表查询
     * dto 参数封装
     * @return
     */
    @RequestMapping(value="/parameter/list", method = RequestMethod.GET)
    Result list(@RequestParam(required = false, value = "parm_no")String parm_no,
                @RequestParam(required = false, value = "parm_type")String parm_type,
                @RequestParam(required = false, value = "parm_name")String parm_name,
                @RequestParam(required = false, value = "parm_form_name")String parm_form_name,
                @RequestParam(required = false, value = "pageNum",defaultValue = "1")Integer pageNum,
                @RequestParam(required = false, value = "pageSize",defaultValue = "15")Integer pageSize);

    @RequestMapping(value="/parameter/getParameter/{id}", method = RequestMethod.GET)
    Result getParameter(@RequestParam("id") String id);

    @RequestMapping(value="/parameter/delete/{id}", method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization") String authorization,@PathVariable(value = "id")String id);

    @RequestMapping(value = "/parameterSetting/qryParameValueByParamType", method = RequestMethod.GET)
    Result qryParametersGroupByParamType(@RequestParam("pageCode") String pageCode);

    @RequestMapping(value = "/parameterSetting/updataParameValues", method = RequestMethod.POST)
    Result updataParameValues(Map<String, List<ParameterEntity>> map);

    @RequestMapping(value = "/parameterSetting/updataParameValue", method = RequestMethod.POST)
    Result updataParameValue(ParameterEntity entity);

    @RequestMapping(value="/parameter/insert", method = RequestMethod.POST)
    Result insert(@RequestParam("authorization") String authorization,@RequestBody ParameterEntity parameterEntity);

    @RequestMapping(value="/parameter/modify", method = RequestMethod.POST)
    Result modify(@RequestParam("authorization") String authorization,@RequestBody ParameterEntity parameterEntity);

    @RequestMapping(value = "/parameter/updateList", method = RequestMethod.PUT)
    Result updateList(@RequestBody List<ParameterEntity> parameterEntities);

    /**
     * 获取提示信息
     * @param className
     * @param value
     * @param text
     * @param tip
     * @return
     */
    @RequestMapping(value = "/parameter/getTips", method = RequestMethod.GET)
    Result getTips(@RequestParam("className") String className, @RequestParam("value")String value, @RequestParam("text") String text, @RequestParam("tip") String tip);

    @RequestMapping(value = "/parameter/checkParamNo", method = RequestMethod.GET)
    Result checkParamNo(@RequestParam("paramNo") String paramNo);

    @RequestMapping(value = "/parameter/checkParamName", method = RequestMethod.GET)
    Result checkParamName(@RequestParam("paramName") String paramName);

    @RequestMapping(value = "/parameterSetting/qryTree", method = RequestMethod.GET)
    Result qryTree(@RequestParam("classId") String classId,
                   @RequestParam("valueId") String valueId,
                   @RequestParam("textId") String textId,
                   @RequestParam("pId") String pId);

    @RequestMapping(value = "/parameter/queryValuesSet/{id}", method = RequestMethod.GET)
    Result queryValuesSetByPid(@PathVariable(value="id") String id);

    @RequestMapping(value = "/parameter/qryParmSetting", method = RequestMethod.GET)
    Result qryParmSetting(@RequestParam(value = "pageCode")String pageCode,
                          @RequestParam(required = false, value = "parmType")String parmType,
                          @RequestParam(required = false, value = "parmName")String parmName);

    @RequestMapping(value = "/parameter/loadOrder/{orderId}",method = RequestMethod.GET)
    Result loadOrder(@PathVariable(value = "orderId")String orderId);

    @RequestMapping(value = "/parameter/parameterOrderList", method = RequestMethod.GET)
    Result parameterOrderList(@RequestParam(value = "ordeStatus")String ordeStatus,
                                     @RequestParam(required = false, defaultValue = "50", value = "pageSize")Integer pageSize,
                                     @RequestParam(required = false, defaultValue = "1", value = "pageNum")Integer pageNum);
}
