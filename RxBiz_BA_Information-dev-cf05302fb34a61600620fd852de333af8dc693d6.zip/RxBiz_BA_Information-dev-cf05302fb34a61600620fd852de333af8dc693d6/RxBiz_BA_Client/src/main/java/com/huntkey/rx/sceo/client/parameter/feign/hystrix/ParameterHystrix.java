package com.huntkey.rx.sceo.client.parameter.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.parameter.feign.ParameterService;
import com.huntkey.rx.sceo.common.model.paramter.ParamterDto;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
public class ParameterHystrix implements ParameterService{

    @Override
    public Result list(String parm_no,String parm_type,String parm_name,String parm_form_name,Integer pageNum,Integer pageSize){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result getParameter(String id){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization,String id){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result qryParametersGroupByParamType(String pageCode) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result updataParameValues(Map<String, List<ParameterEntity>> map) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result updataParameValue(ParameterEntity entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result insert(String authorization, ParameterEntity parameterEntity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result modify(String authorization, ParameterEntity parameterEntity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result updateList(List<ParameterEntity> parameterEntities){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result getTips(String className, String value, String text, String tip){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result checkParamNo(String paramNo){
        return RestErrorResult.hystrix();
    }
    @Override
    public Result checkParamName(String paramName){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result qryTree(String classId, String valueId, String textId, String pId) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryValuesSetByPid(String id){
        return RestErrorResult.hystrix();
    }

    @Override
    public Result qryParmSetting(String pageCode, String parmName, String parmType) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result loadOrder(String orderId) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result parameterOrderList(String ordeStatus, Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }
}
