package com.huntkey.rx.sceo.client.park.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.sceo.client.park.feign.ParkService;
import com.huntkey.rx.sceo.common.model.park.vo.ParkVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 14:15:31
 */
@RestController
@RequestMapping("/park")
public class ParkController {
    @Autowired
    private ParkService parkService;

    /**
     * 新增
     * @param request 用户请求
     * @param entity 对象
     * @return 返回对象id
     */
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(HttpServletRequest request, @RequestBody ParkVO entity){
        String authorization = request.getHeader("Authorization");
        return parkService.insert(authorization,entity);

    }

    /**
     * 删除
     * @param request 用户请求
     * @param id 对象id
     * @return 返回删除数量
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@RequestParam("id")String id){
        String authorization = request.getHeader("Authorization");
        return parkService.delete(authorization,id);
    }

    /**
     * 修改
     * @param request 用户请求
     * @param entity 对象
     * @return 返回修改记录条数
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public Result update(HttpServletRequest request,@RequestBody ParkVO entity){
        String authorization = request.getHeader("Authorization");
        return parkService.update(authorization,entity);
    }

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     */
    @RequestMapping(value = "/queryById{id}",method = RequestMethod.GET)
    public Result queryById(@PathVariable("id")String id){
            return parkService.queryById(id);
    }

    /**
     * 分页、模糊查询列表
     * @param rpakName 查询参数
     * @param rpakAddrProv 省——区域id
     * @param rpakAddrCity 市——区域id
     * @param rpakAddrDist 市——区/县——区域id
     * @param rpakEnable 市——区/县——区域id
     * @return
     */
    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "rpakName")String rpakName,
                       @RequestParam(required = false,value = "rpakAddrProv")String rpakAddrProv,
                       @RequestParam(required = false,value = "rpakAddrCity")String rpakAddrCity,
                       @RequestParam(required = false,value = "rpakAddrDist")String rpakAddrDist,
                       @RequestParam(required = false,value = "rpakEnable")String rpakEnable){

        return  parkService.list(rpakName,rpakAddrProv,rpakAddrCity,rpakAddrDist,rpakEnable);

    }

    @RequestMapping(value = "/updateList",method = RequestMethod.PUT)
    public Result updateList(HttpServletRequest request,
                             @RequestBody List<ParkVO> voList){
        String authorization = request.getHeader("Authorization");
        return parkService.updateList(authorization,voList);
    }
}
