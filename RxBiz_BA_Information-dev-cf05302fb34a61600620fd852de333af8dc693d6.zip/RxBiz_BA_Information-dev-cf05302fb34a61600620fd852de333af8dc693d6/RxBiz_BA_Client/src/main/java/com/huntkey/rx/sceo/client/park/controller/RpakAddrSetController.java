package com.huntkey.rx.sceo.client.park.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.park.feign.RpakAddrSetService;
import com.huntkey.rx.sceo.common.model.park.vo.RpakAddrVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * @author liucs
 * @date 2018-4-2 16:04:47
 */
@RestController
@RequestMapping("/addr")
public class RpakAddrSetController {
    @Autowired
    private RpakAddrSetService addrSetService;

    /**
     * 新增
     * @param request request请求
     * @param entity 对象
     * @return 返回对象id
     */
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(HttpServletRequest request, @RequestBody RpakAddrVO entity){
        String authorization = request.getHeader("Authorization");
        return addrSetService.insert(authorization,entity);
    }

    /**
     * 删除
     * @param request 登录用户认证
     * @param id 对象id
     * @return 返回删除数量
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@RequestParam("id")String id){
        String authorization = request.getHeader("Authorization");
        return addrSetService.delete(authorization,id);
    }

    /**
     * 修改
     * @param request 登录用户认证
     * @param entity 对象
     * @return 返回修改记录条数
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public Result update(HttpServletRequest request,@RequestBody RpakAddrVO entity){
        String authorization = request.getHeader("Authorization");
        return addrSetService.update(authorization,entity);
    }

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     */
    @RequestMapping(value = "/queryById/{id}",method = RequestMethod.GET)
    public Result queryById(@PathVariable("id")String id){
        return addrSetService.queryById(id);
    }

    /**
     * 交货地址列表
     * @return
     */
    @RequestMapping(value = "/list/{pid}",method = RequestMethod.GET)
    public Result list(@PathVariable("pid")String pid){
        return addrSetService.list(pid);
    }
}
