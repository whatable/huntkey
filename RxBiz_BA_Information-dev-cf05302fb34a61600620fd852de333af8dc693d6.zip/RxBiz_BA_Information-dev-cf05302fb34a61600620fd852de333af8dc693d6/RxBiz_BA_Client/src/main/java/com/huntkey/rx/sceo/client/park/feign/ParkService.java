package com.huntkey.rx.sceo.client.park.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.sceo.client.park.feign.hystrix.ParkHystrix;
import com.huntkey.rx.sceo.common.model.park.vo.ParkVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 14:15:31
 */
@Service
@FeignClient(value = "information-provider",fallback = ParkHystrix.class)
public interface ParkService {

    @RequestMapping(value = "/park/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authorization")String authorization, @RequestBody ParkVO entity);

    @RequestMapping(value = "/park/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id);

    @RequestMapping(value = "/park/update", method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody ParkVO entity);

    @RequestMapping(value = "/park/queryById{id}",method = RequestMethod.GET)
    Result queryById(@PathVariable("id")String id);

    @RequestMapping(value = "/park/list",method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "rpakName")String rpakName,
                @RequestParam(required = false,value = "rpakAddrProv")String rpakAddrProv,
                @RequestParam(required = false,value = "rpakAddrCity")String rpakAddrCity,
                @RequestParam(required = false,value = "rpakAddrDist")String rpakAddrDist,
                @RequestParam(required = false,value = "rpakEnable")String rpakEnable);

    @RequestMapping(value = "/park/updateList",method = RequestMethod.PUT)
    Result updateList(@RequestParam(value = "authorization")String authorization,
                      @RequestBody List<ParkVO> voList);
}
