package com.huntkey.rx.sceo.client.park.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.sceo.client.park.feign.hystrix.ParkHystrix;
import com.huntkey.rx.sceo.client.park.feign.hystrix.RpakAddrSetHystrix;
import com.huntkey.rx.sceo.common.model.park.vo.ParkVO;
import com.huntkey.rx.sceo.common.model.park.vo.RpakAddrVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

/**
 * @author liucs
 * @date 2018-4-2 14:15:31
 */
@Service
@FeignClient(value = "information-provider",fallback = RpakAddrSetHystrix.class)
public interface RpakAddrSetService {

    @RequestMapping(value = "/addr/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authorization")String authorization, @RequestBody RpakAddrVO entity);

    @RequestMapping(value = "/addr/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id);

    @RequestMapping(value = "/addr/update", method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody RpakAddrVO entity);

    @RequestMapping(value = "/addr/queryById/{id}",method = RequestMethod.GET)
    Result queryById(@PathVariable("id")String id);

    @RequestMapping(value = "/addr/list/{pid}",method = RequestMethod.GET)
    Result list(@PathVariable(value = "pid")String pid);
}
