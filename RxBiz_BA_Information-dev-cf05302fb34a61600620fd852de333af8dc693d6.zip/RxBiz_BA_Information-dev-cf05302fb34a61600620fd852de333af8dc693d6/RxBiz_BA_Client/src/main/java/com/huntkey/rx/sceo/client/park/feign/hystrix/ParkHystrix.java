package com.huntkey.rx.sceo.client.park.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.park.feign.ParkService;
import com.huntkey.rx.sceo.common.model.park.vo.ParkVO;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 14:15:31
 */
@Component
public class ParkHystrix implements ParkService {
    @Override
    public Result insert(String authorization, ParkVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, ParkVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String rpakName,String rpakAddrProv,String rpakAddrCity,String rpakAddrDist,String rpakEnable) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result updateList(String authorization, List<ParkVO> voList) {
        return RestErrorResult.hystrix();
    }
}
