package com.huntkey.rx.sceo.client.park.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.park.feign.RpakAddrSetService;
import com.huntkey.rx.sceo.common.model.park.vo.ParkVO;
import com.huntkey.rx.sceo.common.model.park.vo.RpakAddrVO;
import org.springframework.stereotype.Component;

@Component
public class RpakAddrSetHystrix implements RpakAddrSetService {
    @Override
    public Result insert(String authorization, RpakAddrVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, RpakAddrVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String pid){
        return RestErrorResult.hystrix();
    }
}
