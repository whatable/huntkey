package com.huntkey.rx.sceo.client.period.controller;

import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.sceo.client.period.feign.PeriodService;
import com.huntkey.rx.sceo.common.model.period.vo.PeriodVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.huntkey.rx.commons.utils.rest.Result;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@RestController
@RequestMapping("/period")
public class PeriodController {
    @Autowired
    private PeriodService periodService;

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "peidFyr")String peidFyr,
                       @RequestParam(required = false,value = "peidName")String peidName,
                       @RequestParam(required = false,value = "peidProid")Integer peidProid,
                       @RequestParam(required = false,value = "peidEnable")String peidEnable,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum){

        return periodService.list(peidFyr,peidName,peidProid,peidEnable,pageSize,pageNum);
    }

    @RequestMapping(value="/queryById",method = RequestMethod.GET)
    public Result queryById(@RequestParam("id") String id){
        return periodService.queryById(id);
    }

    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    public Result update(@RequestBody PeriodVO entity){
        return periodService.update(entity);
    }

    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(@RequestParam("id")String id){
        return periodService.delete(id);
    }

    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(HttpServletRequest request, @RequestBody PeriodVO entity){
        String authorization = request.getHeader("Authorization");
        return periodService.insert(authorization,entity);
    }
    @RequestMapping(value = "/queryPeriodEnum",method = RequestMethod.GET)
    public Result queryPeriodEnum(){
        return periodService.queryPeriodEnum();
    }
}
