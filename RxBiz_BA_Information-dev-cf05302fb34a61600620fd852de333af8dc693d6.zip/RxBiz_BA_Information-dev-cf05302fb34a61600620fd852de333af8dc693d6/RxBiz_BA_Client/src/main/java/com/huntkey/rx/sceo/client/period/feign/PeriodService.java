package com.huntkey.rx.sceo.client.period.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.sceo.client.period.feign.hystrix.PeriodHystrix;
import com.huntkey.rx.sceo.common.model.period.vo.PeriodVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;


@FeignClient(value="information-provider", fallback = PeriodHystrix.class)
@Service
public interface PeriodService {

    @RequestMapping(value = "/period/list",method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "peidFyr")String peidFyr,
                @RequestParam(required = false,value = "peidName")String peidName,
                @RequestParam(required = false,value = "peidProid")Integer peidProid,
                @RequestParam(required = false,value = "peidEnable")String peidEnable,
                @RequestParam("pageSize")Integer pageSize,
                @RequestParam("pageNum")Integer pageNum);

    @RequestMapping(value="/period/queryById",method = RequestMethod.GET)
    Result queryById(@RequestParam("id") String id);

    @RequestMapping(value = "/period/update",method = RequestMethod.PUT)
    Result update(@RequestBody PeriodVO entity);

    @RequestMapping(value = "/period/delete", method = RequestMethod.DELETE)
    Result delete(@RequestParam("id")String id);

    @RequestMapping(value="/period/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authorization")String authorization, @RequestBody PeriodVO entity);

    @RequestMapping(value = "period/queryPeriodEnum",method = RequestMethod.GET)
    Result queryPeriodEnum();
}
