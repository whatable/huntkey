package com.huntkey.rx.sceo.client.period.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.period.feign.PeriodService;
import com.huntkey.rx.sceo.common.model.period.vo.PeriodVO;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class PeriodHystrix implements PeriodService {
    @Override
    public Result list(String peidFyr,String peidName,Integer peidProid, String peidEnable,Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(PeriodVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result insert(String authorization, PeriodVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryPeriodEnum() {
        return RestErrorResult.hystrix();
    }
}
