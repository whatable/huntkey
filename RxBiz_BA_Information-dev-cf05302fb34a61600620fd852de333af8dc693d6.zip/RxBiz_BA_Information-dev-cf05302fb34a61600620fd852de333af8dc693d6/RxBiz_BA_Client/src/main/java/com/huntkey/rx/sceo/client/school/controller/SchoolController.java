package com.huntkey.rx.sceo.client.school.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.SchoolEntity;
import com.huntkey.rx.sceo.client.school.feign.SchoolService;
import com.huntkey.rx.sceo.common.model.school.vo.SchoolVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/school")
public class SchoolController {

    @Autowired
    private SchoolService schoolService;

    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public Result insert(HttpServletRequest request,@RequestBody SchoolVO entity){
        String authorization = request.getHeader("Authorization");
        return schoolService.insert(authorization,entity);
    }

    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request, @RequestParam("id") String id){
        String authorization = request.getHeader("Authorization");
        return schoolService.delete(authorization,id);
    }

    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    public Result update(HttpServletRequest request, @RequestBody SchoolVO entity){
        String authorization = request.getHeader("Authorization");
        return schoolService.update(authorization,entity);
    }

    @RequestMapping(value = "/queryById/{id}",method = RequestMethod.GET)
    public Result queryById(@PathVariable("id")String id){
        return schoolService.queryById(id);
    }

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "rschName")String rschName,
                       @RequestParam(required = false,value = "rschCode")String rschCode,
                       @RequestParam(required = false,value = "rschCity")String rschCity,
                       @RequestParam(required = false,value = "rschEnable")String rschEnable,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum){
        return schoolService.list(rschName,rschCode,rschCity,rschEnable,pageSize,pageNum);
    }
}
