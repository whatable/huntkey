package com.huntkey.rx.sceo.client.school.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.SchoolEntity;
import com.huntkey.rx.sceo.client.school.feign.hystrix.SchoolHystrix;
import com.huntkey.rx.sceo.common.model.school.vo.SchoolVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;


@Service
@FeignClient(value = "information-provider",fallback = SchoolHystrix.class)
public interface SchoolService {

    @RequestMapping(value = "/school/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authorization")String authorization, @RequestBody SchoolVO entity);

    @RequestMapping(value = "/school/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization,@RequestParam("id") String id);

    @RequestMapping(value = "/school/update",method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody SchoolVO entity);

    @RequestMapping(value = "/school/queryById/{id}",method = RequestMethod.GET)
    Result queryById(@PathVariable("id")String id);

    @RequestMapping(value = "/school/list",method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "rschName")String rschName,
                @RequestParam(required = false,value = "rschCode")String rschCode,
                @RequestParam(required = false,value = "rschCity")String rschCity,
                @RequestParam(required = false,value = "rschEnable")String rschEnable,
                @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum);
}
