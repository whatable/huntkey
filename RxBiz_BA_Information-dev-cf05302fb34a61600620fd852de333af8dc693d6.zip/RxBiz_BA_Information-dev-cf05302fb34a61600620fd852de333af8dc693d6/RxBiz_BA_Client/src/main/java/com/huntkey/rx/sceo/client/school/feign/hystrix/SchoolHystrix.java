package com.huntkey.rx.sceo.client.school.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.SchoolEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.school.feign.SchoolService;
import com.huntkey.rx.sceo.common.model.school.vo.SchoolVO;
import org.springframework.stereotype.Component;


@Component
public class SchoolHystrix implements SchoolService {
    @Override
    public Result insert(String authorization,SchoolVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, SchoolVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String rschName,String rschCode, String rschCity,String enable, Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }
}
