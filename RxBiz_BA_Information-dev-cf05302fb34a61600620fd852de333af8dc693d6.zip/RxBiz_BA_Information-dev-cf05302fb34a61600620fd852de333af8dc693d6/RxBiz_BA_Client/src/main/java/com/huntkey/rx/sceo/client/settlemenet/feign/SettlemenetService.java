package com.huntkey.rx.sceo.client.settlemenet.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.SettlemenetEntity;
import com.huntkey.rx.sceo.client.settlemenet.feign.hystrix.SettlemenetHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author liucs
 * @date 2018-4-2 13:50:33
 */
@Service
@FeignClient(value = "information-provider",fallback = SettlemenetHystrix.class)
public interface SettlemenetService {
    @RequestMapping(value = "/settlemenet/insert",method = RequestMethod.GET)
    Result insert(@RequestParam("authotization")String authorization, @RequestBody SettlemenetEntity entity);

    @RequestMapping(value = "/settlemenet/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id);

    @RequestMapping(value = "/settlemenet/update", method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody SettlemenetEntity entity);

    @RequestMapping(value = "/settlemenet/queryById",method = RequestMethod.GET)
    Result queryById(@RequestParam("id")String id);

    @RequestMapping(value = "/settlemenet/list",method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "sett_type")String settType,
                @RequestParam(required = false,value = "sett_odays")Integer settOdays,
                @RequestParam(required = false,value = "sett_idays")Integer settIdays,
                @RequestParam(required = false,value = "sett_way")String settWay,
                @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum);
}
