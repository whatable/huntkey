package com.huntkey.rx.sceo.client.settlemenet.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.SettlemenetEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.settlemenet.feign.SettlemenetService;
import org.springframework.stereotype.Component;

/**
 * @author liucs
 * @date 2018-4-2 13:50:33
 */
@Component
public class SettlemenetHystrix implements SettlemenetService {
    @Override
    public Result insert(String authorization, SettlemenetEntity entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, SettlemenetEntity entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String settType, Integer settOdays, Integer settIdays, String settWay, Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }
}
