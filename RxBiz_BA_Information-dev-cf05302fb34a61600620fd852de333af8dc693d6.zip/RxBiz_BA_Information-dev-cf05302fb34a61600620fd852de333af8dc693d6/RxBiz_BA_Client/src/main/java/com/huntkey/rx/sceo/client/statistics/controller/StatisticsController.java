package com.huntkey.rx.sceo.client.statistics.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.StatisticsEntity;
import com.huntkey.rx.sceo.client.statistics.feign.StatisticService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@RestController
@RequestMapping(value = "/statistics")
public class StatisticsController {
    @Autowired
    private StatisticService statisticService;

    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(HttpServletRequest request, @RequestBody StatisticsEntity entity){
        String authorization = request.getHeader("Authorization");
        return statisticService.insert(authorization,entity);
    }

    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@RequestParam("id")String id){
        String authorization = request.getHeader("Authorization");
        return statisticService.delete(authorization,id);
    }

    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    public Result update(HttpServletRequest request,@RequestBody StatisticsEntity entity){
        String authorization = request.getHeader("Authorization");
        return statisticService.update(authorization,entity);
    }

    @RequestMapping(value = "/queryById",method = RequestMethod.GET)
    public Result queryById(@RequestParam("id")String id){
        return statisticService.queryById(id);
    }

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "stat_moniclass")String statMoniclass,
                       @RequestParam(required = false,value = "stat_fyear")String statFyear,
                       @RequestParam(required = false,value = "stat_beg")Date statBeg,
                       @RequestParam(required = false,value = "stat_end")Date statEnd,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum){
        return statisticService.list(statMoniclass,statFyear,statBeg,statEnd,pageSize,pageNum);
    }
}
