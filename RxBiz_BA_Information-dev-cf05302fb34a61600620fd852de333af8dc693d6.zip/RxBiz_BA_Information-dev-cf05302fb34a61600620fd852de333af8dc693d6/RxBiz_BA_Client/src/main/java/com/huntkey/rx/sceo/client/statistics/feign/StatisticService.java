package com.huntkey.rx.sceo.client.statistics.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.StatisticsEntity;
import com.huntkey.rx.sceo.client.statistics.feign.hystrix.StatisticsHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;

@Service
@FeignClient(value = "information-provider",fallback = StatisticsHystrix.class)
public interface StatisticService {

    @RequestMapping(value = "/statistics/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authorization")String authorization, @RequestBody StatisticsEntity entity);

    @RequestMapping(value = "/statistics/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization")String authorization, String id);

    @RequestMapping(value = "/statistics/update",method = RequestMethod.PUT)
    Result update(@RequestParam("authorization")String authorization,@RequestBody StatisticsEntity entity);

    @RequestMapping(value = "/statistics/queryById",method = RequestMethod.GET)
    Result queryById(@RequestParam("id")String id);

    @RequestMapping(value = "/statistics/list", method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "stat_moniclass")String statMoniclass,
                @RequestParam(required = false,value = "stat_fyear")String statFyear,
                @RequestParam(required = false,value = "stat_beg")Date statBeg,
                @RequestParam(required = false,value = "stat_end")Date statEnd,
                @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum);
}
