package com.huntkey.rx.sceo.client.statistics.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.StatisticsEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.statistics.feign.StatisticService;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class StatisticsHystrix implements StatisticService{
    @Override
    public Result insert(String authorization, StatisticsEntity entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, StatisticsEntity entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String statMoniclass, String statFyear, Date statBeg, Date statEnd, Integer pageSize, Integer pageNum) {
        return RestErrorResult.hystrix();
    }
}
