package com.huntkey.rx.sceo.client.taxrate.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.client.taxrate.feign.TaxrateService;
import com.huntkey.rx.sceo.common.model.taxrate.vo.TaxrateVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/taxrate")
public class TaxrateController {
    @Autowired
    private TaxrateService taxrateService;

    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(HttpServletRequest request, @RequestBody TaxrateVO entity){
        String authorization = request.getHeader("Authorization");
        return taxrateService.insert(authorization,entity);
    }

    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(HttpServletRequest request,@RequestParam("id")String id){
        String authorizatoin = request.getHeader("Authorization");
        return taxrateService.delete(authorizatoin,id);
    }

    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    public Result update(HttpServletRequest request,@RequestBody TaxrateVO entity){
        String authorizaion = request.getHeader("Authorization");
        return taxrateService.update(authorizaion,entity);
    }

    @RequestMapping(value = "/queryById/{id}",method = RequestMethod.GET)
    public Result queryById(@PathVariable("id")String id){
        return taxrateService.queryById(id);
    }

    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "taxrName")String taxrName,
                       @RequestParam(required = false,value = "taxrCode")String taxrCode,
                       @RequestParam(required = false,value = "taxrEnable")String taxrEnable,
                       @RequestParam(required = false,value = "taxrIsdeduct")Integer taxrIsdeduct){
        return taxrateService.list(taxrName,taxrCode,taxrEnable,taxrIsdeduct);
    }
}
