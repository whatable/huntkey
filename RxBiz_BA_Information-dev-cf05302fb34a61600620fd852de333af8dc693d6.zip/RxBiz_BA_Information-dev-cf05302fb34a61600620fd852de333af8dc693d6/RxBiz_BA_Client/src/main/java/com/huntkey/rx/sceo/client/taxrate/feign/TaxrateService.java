package com.huntkey.rx.sceo.client.taxrate.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.client.taxrate.feign.hystrix.TaxrateHystrix;
import com.huntkey.rx.sceo.common.model.taxrate.vo.TaxrateVO;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;


@Service
@FeignClient(value = "information-provider",fallback = TaxrateHystrix.class)
public interface TaxrateService {

    @RequestMapping(value = "/taxrate/insert",method = RequestMethod.POST)
    Result insert(@RequestParam("authorization") String authorization, @RequestBody TaxrateVO entity);

    @RequestMapping(value = "/taxrate/delete",method = RequestMethod.DELETE)
    Result delete(@RequestParam("authorization") String authorization,@RequestParam("id")String id);

    @RequestMapping(value = "/taxrate/update",method = RequestMethod.PUT)
    Result update(@RequestParam("authorization") String authorization,@RequestBody TaxrateVO entity);

    @RequestMapping(value = "/taxrate/queryById/{id}",method = RequestMethod.GET)
    Result queryById(@PathVariable("id")String id);

    @RequestMapping(value = "/taxrate/list",method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "taxrName")String taxrName,
                @RequestParam(required = false,value = "taxrCode")String taxrCode,
                @RequestParam(required = false,value = "taxrEnable")String taxrEnable,
                @RequestParam(required = false,value = "taxrIsdeduct")Integer taxrIsdeduct);
}
