package com.huntkey.rx.sceo.client.taxrate.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.taxrate.feign.TaxrateService;
import com.huntkey.rx.sceo.common.model.taxrate.vo.TaxrateVO;
import org.springframework.stereotype.Component;

@Component
public class TaxrateHystrix implements TaxrateService{
    @Override
    public Result insert(String authorization, TaxrateVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String authorization, String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(String authorization, TaxrateVO entity) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryById(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String taxrName,String taxrCode,String taxrEnable,Integer taxrIsdeduct) {
        return RestErrorResult.hystrix();
    }
}
