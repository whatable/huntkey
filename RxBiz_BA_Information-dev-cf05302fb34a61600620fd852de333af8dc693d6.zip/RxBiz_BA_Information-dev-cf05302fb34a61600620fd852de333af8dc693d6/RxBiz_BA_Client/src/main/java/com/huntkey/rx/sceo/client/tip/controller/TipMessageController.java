package com.huntkey.rx.sceo.client.tip.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.tip.feign.TipMessageService;
import com.huntkey.rx.sceo.common.model.tip.TipMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 *
 * @author yexin
 * @date 2017/10/30
 */
@RestController
@RequestMapping(value = "/tipMessage")
public class TipMessageController {

    private static Logger log = LoggerFactory.getLogger(TipMessageController.class);

    @Autowired
    TipMessageService tipMessageService;

    @RequestMapping(value = "/getMessage", method = RequestMethod.POST)
    public Result getMessage(@RequestBody String params){

        return tipMessageService.getMessage(params);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    Result queryTip(@PathVariable(value = "id") String id){
        return tipMessageService.queryTip(id);
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    Result updateMessage(@RequestBody TipMessage tipMessage){
        return tipMessageService.updateMessage(tipMessage);
    }

    @RequestMapping(value = "/{id}/delete", method = RequestMethod.DELETE)
    Result delete(@PathVariable(value = "id") String id){
        return tipMessageService.delete(id);
    }

    @RequestMapping(value = "/{pageCode}/loadMsgs", method = RequestMethod.GET)
    Result loadMsgs(@PathVariable(value = "pageCode") String pageCode){
        return tipMessageService.loadMsgs(pageCode);
    }

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    Result list(@RequestParam(required = false,value = "pageCode") String pageCode,
                @RequestParam(required = false,value = "msgCode") String msgCode,
                @RequestParam(required = false,value = "msgType") String msgType,
                @RequestParam(required = false,value = "pageNum",defaultValue = "1") int pageNum,
                @RequestParam(required = false,value = "pageSize",defaultValue = "15") int pageSize){
        return tipMessageService.list(pageCode ,msgCode, msgType, pageNum, pageSize);
    }


}
