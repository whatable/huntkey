package com.huntkey.rx.sceo.client.tip.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.tip.feign.hystrix.TipMessageHystrix;
import com.huntkey.rx.sceo.common.model.tip.TipMessage;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.*;

/**
 *
 * @author yexin
 * @date 2017/10/30
 */
@FeignClient(value = "information-provider", fallback = TipMessageHystrix.class)
public interface TipMessageService {

    @RequestMapping(value = "/tipMessage/getMessage", method = RequestMethod.POST)
    Result getMessage(@RequestBody String params);

    @RequestMapping(value = "/tipMessage/{id}", method = RequestMethod.GET)
    Result queryTip(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/tipMessage/update", method = RequestMethod.PUT)
    Result updateMessage(@RequestBody TipMessage tipMessage);

    @RequestMapping(value = "/tipMessage/{id}/delete", method = RequestMethod.DELETE)
    Result delete(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/tipMessage/{pageCode}/loadMsgs", method = RequestMethod.GET)
    Result loadMsgs(@PathVariable(value = "pageCode") String pageCode);

    @RequestMapping(value = "/tipMessage/list", method = RequestMethod.GET)
    Result list(@RequestParam(required = false, value = "pageCode") String pageCode,
                @RequestParam(required = false, value = "msgCode") String msgCode,
                @RequestParam(required = false, value = "msgType") String msgType,
                @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                @RequestParam(required = false, value = "pageSize", defaultValue = "10") int pageSize);

}
