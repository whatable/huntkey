package com.huntkey.rx.sceo.client.tip.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.tip.feign.TipMessageService;
import com.huntkey.rx.sceo.common.model.tip.TipMessage;
import org.springframework.stereotype.Component;

/**
 *
 * @author yexin
 * @date 2017/10/30
 */
@Component
public class TipMessageHystrix implements TipMessageService {
    @Override
    public Result getMessage(String params) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result queryTip(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result updateMessage(TipMessage tipMessage) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result loadMsgs(String pageCode) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result list(String pageCode, String msgCode, String msgType, int pageNum, int pageSize) {
        return RestErrorResult.hystrix();
    }

}
