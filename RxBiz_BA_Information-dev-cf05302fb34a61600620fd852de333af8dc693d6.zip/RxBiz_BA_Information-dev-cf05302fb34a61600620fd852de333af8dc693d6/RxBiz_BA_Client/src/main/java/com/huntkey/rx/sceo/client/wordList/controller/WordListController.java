package com.huntkey.rx.sceo.client.wordList.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.wordList.feign.WordListManageService;
import com.huntkey.rx.sceo.common.model.wordlist.WordList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 *
 * @author zhoucj
 * @date 2017/11/23
 */

@RestController
@RequestMapping(value = "/wordList")
public class WordListController {
    @Autowired
    private WordListManageService wordListManageService;

    @RequestMapping(method = RequestMethod.POST)
    public Result insert(@RequestBody WordList wordList) {
        return wordListManageService.insert(wordList);
    }

    @RequestMapping(method = RequestMethod.PUT)
    public Result update(@RequestBody WordList wordList) {
        return wordListManageService.update(wordList);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    public Result delete(@RequestParam(value = "ids") String ids) {
        return wordListManageService.delete(ids);
    }

    @RequestMapping(value = "/wordListTree/{id}", method = RequestMethod.GET)
    public Result getWordListTree(@PathVariable(value = "id") String id) {
        return  wordListManageService.getWordListTree(id);
    }

    @RequestMapping(value = "/wordListTree", method = RequestMethod.GET)
    public Result getWordListTree() {
        return wordListManageService.getWordListTree();
    }

    @RequestMapping(method = RequestMethod.GET)
    public Result select(@RequestParam(required = false, value = "infoCode") String infoCode,
                         @RequestParam(required = false, value = "wordName") String wordName,
                         @RequestParam(required = false, value = "className") String className,
                         @RequestParam(required = false, value = "wordEnable") Integer wordEnable,
                         @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                         @RequestParam(required = false, value = "pageSize", defaultValue = "15") int pageSize) {
        return wordListManageService.select(infoCode, wordName, className, wordEnable, pageNum, pageSize);
    }

    @RequestMapping(value = "/check", method = RequestMethod.GET)
    public Result checkInfoCodeAndName(@RequestParam(value = "infoCode") String infoCode,
                                       @RequestParam(value = "wordName") String wordName,
                                       @RequestParam(value = "wordParent") String wordParent) throws Exception {
        return wordListManageService.checkInfoCodeAndName(infoCode, wordName, wordParent);
    }

    @RequestMapping(value = "/move", method = RequestMethod.PUT)
    public Result move(@RequestParam(value = "ids") String ids) throws Exception {
        return wordListManageService.move(ids);
    }

    /**
     * 根据枚举编码获取子枚举
     * @return
     */
    @RequestMapping(value = "/selectChildByInfoCode",method = RequestMethod.GET)
    public Result selectChildByInfoCode(@RequestParam(value = "infoCode", required = false)String infoCode)
            throws Exception {
        return wordListManageService.selectChildByInfoCode(infoCode);
    }

    /**
     * 根据枚举编码获取子枚举
     * @return
     */
    @RequestMapping(value = "/selectChildByInfoCodes",method = RequestMethod.GET)
    public Result selectChildByInfoCodes(@RequestParam(value = "infoCodes", required = false)List<String> infoCodes) {
        return wordListManageService.selectChildByInfoCodes(infoCodes);
    }
}
