package com.huntkey.rx.sceo.client.wordList.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client.wordList.feign.hystrix.WordListManageServiceImpl;
import com.huntkey.rx.sceo.common.model.wordlist.WordList;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 *
 * @author zhoucj
 * @date 2017/11/23
 */
@FeignClient(value = "information-provider", fallback = WordListManageServiceImpl.class)
public interface WordListManageService {
    @RequestMapping(value = "/wordList", method = RequestMethod.POST)
    Result insert(@RequestBody WordList wordList);

    @RequestMapping(value = "/wordList", method = RequestMethod.PUT)
    Result update(@RequestBody WordList wordList);

    @RequestMapping(value = "/wordList", method = RequestMethod.DELETE)
    Result delete(@RequestParam(value = "ids") String ids);

    @RequestMapping(value = "/wordList/wordListTree/{id}", method = RequestMethod.GET)
    Result getWordListTree(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/wordList/wordListTree", method = RequestMethod.GET)
    Result getWordListTree();

    @RequestMapping(value = "/wordList", method = RequestMethod.GET)
    Result select(@RequestParam(required = false, value = "infoCode") String infoCode,
                  @RequestParam(required = false, value = "wordName") String wordName,
                  @RequestParam(required = false, value = "className") String className,
                  @RequestParam(required = false, value = "wordEnable") Integer wordEnable,
                  @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                  @RequestParam(required = false, value = "pageSize", defaultValue = "15") int pageSize);

    @RequestMapping(value = "/wordList/check", method = RequestMethod.GET)
    Result checkInfoCodeAndName(@RequestParam(value = "infoCode") String infoCode,
                                @RequestParam(value = "wordName") String wordName,
                                @RequestParam(value = "wordParent", required = false) String wordParent);

    @RequestMapping(value = "/wordList/move", method = RequestMethod.PUT)
    Result move(@RequestParam(value = "ids") String ids);

    /**
     * 根据枚举编码获取子枚举
     * @return
     */
    @RequestMapping(value = "/wordList/selectChildByInfoCode",method = RequestMethod.GET)
    Result selectChildByInfoCode(@RequestParam(value = "infoCode", required = false)String infoCode);

    /**
     * 根据枚举编码获取子枚举
     * @return
     */
    @RequestMapping(value = "/wordList/selectChildByInfoCodes",method = RequestMethod.GET)
    public Result selectChildByInfoCodes(@RequestParam(value = "infoCodes", required = false)List<String> infoCodes);
}
