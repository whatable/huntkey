package com.huntkey.rx.sceo.client.wordList.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.client._util.RestErrorResult;
import com.huntkey.rx.sceo.client.wordList.feign.WordListManageService;
import com.huntkey.rx.sceo.common.model.wordlist.WordList;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * @author zhoucj
 * @date 2017/11/23
 */
@Service
public class WordListManageServiceImpl implements WordListManageService {
    @Override
    public Result insert(WordList wordList) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result update(WordList wordList) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result delete(String ids) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result getWordListTree(String id) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result getWordListTree() {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result select(String infoCode, String wordName, String className, Integer wordEnable, int pageNum, int pageSize) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result checkInfoCodeAndName(String infoCode, String wordName, String wordParent) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result move(String ids) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result selectChildByInfoCode(String infoCode) {
        return RestErrorResult.hystrix();
    }

    @Override
    public Result selectChildByInfoCodes(List<String> infoCodes) {
        return RestErrorResult.hystrix();
    }
}
