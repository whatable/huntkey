package com.huntkey.rx.sceo.common.model.area;

public interface AreaConstant {
    String AREA_IDCODE = "area_idcode";
    String AREA_PARENT_AREA = "area_parent_area";
    String AREA_LEVEL = "area_level";
    String AREA_ORDER = "area_order";
    String AREA_DESC = "area_desc";
    String AREA_CODE = "area_code";
    String AREA_NAME = "area_name";
    String AREA_ENABLE = "area_enable";
    String AREA_IS_STANDARD = "area_is_standard";
}
