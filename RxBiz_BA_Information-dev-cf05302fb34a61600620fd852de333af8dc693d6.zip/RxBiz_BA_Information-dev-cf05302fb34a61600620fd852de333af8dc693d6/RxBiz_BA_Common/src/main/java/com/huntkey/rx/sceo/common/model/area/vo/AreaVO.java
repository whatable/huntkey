package com.huntkey.rx.sceo.common.model.area.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;

import java.util.List;

/**
 * @author liucs
 * @date 2018-5-24 14:16:16
 */
public class AreaVO extends BaseEntity{
    List<AreaVO> areaVOS;
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 上级区域名称
     */
    private String parentAreaName;
    /**
     * 区域层级
     */
    private int level;
    /**
     * 区域识别码
     */
    @JSONField(name = "area_idcode")
    private String areaIdcode;
    /**
     * 区域上级
     */
    @JSONField(name = "area_parent_area")
    private String areaParentArea;
    /**
     * 区域层级码
     */
    @JSONField(name = "area_level")
    private String areaLevel;

    /**
     * 区域排序
     */
    @JSONField(name = "area_order")
    private Integer areaOrder;
    /**
     * 区域描述
     */
    @JSONField(name = "area_desc")
    private String areaDesc;
    /**
     * 区域代码
     */
    @JSONField(name = "area_code")
    private String areaCode;
    /**
     * 区域名称
     */
    @JSONField(name = "area_name")
    private String areaName;
    /**
     * 启用/禁用
     */
    @JSONField(name = "area_enable")
    private String areaEnable;
    /**
     * 是否标准：1、标准，0、非标准
     */
    @JSONField(name = "area_is_standard")
    private String areaIsStandard;

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getAreaIsStandard() {
        return areaIsStandard;
    }

    public void setAreaIsStandard(String areaIsStandard) {
        this.areaIsStandard = areaIsStandard;
    }

    public String getAreaIdcode() {
        return areaIdcode;
    }

    public void setAreaIdcode(String areaIdcode) {
        this.areaIdcode = areaIdcode;
    }

    public String getAreaParentArea() {
        return areaParentArea;
    }

    public void setAreaParentArea(String areaParentArea) {
        this.areaParentArea = areaParentArea;
    }

    public String getAreaLevel() {
        return areaLevel;
    }

    public void setAreaLevel(String areaLevel) {
        this.areaLevel = areaLevel;
    }

    public Integer getAreaOrder() {
        return areaOrder;
    }

    public void setAreaOrder(Integer areaOrder) {
        this.areaOrder = areaOrder;
    }

    public String getAreaDesc() {
        return areaDesc;
    }

    public void setAreaDesc(String areaDesc) {
        this.areaDesc = areaDesc;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String area_code) {
        this.areaCode = area_code;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getAreaEnable() {
        return areaEnable;
    }

    public void setAreaEnable(String areaEnable) {
        this.areaEnable = areaEnable;
    }

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getParentAreaName() {
        return parentAreaName;
    }

    public void setParentAreaName(String parentAreaName) {
        this.parentAreaName = parentAreaName;
    }

    public List<AreaVO> getAreaVOS() {
        return areaVOS;
    }

    public void setAreaVOS(List<AreaVO> areaVOS) {
        this.areaVOS = areaVOS;
    }

    @Override
    public String toString() {
        return "AreaVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", parentAreaName='" + parentAreaName + '\'' +
                ", areaIdcode='" + areaIdcode + '\'' +
                ", areaParentArea='" + areaParentArea + '\'' +
                ", areaLevel='" + areaLevel + '\'' +
                ", areaOrder=" + areaOrder +
                ", areaDesc='" + areaDesc + '\'' +
                ", areaCode='" + areaCode + '\'' +
                ", areaName='" + areaName + '\'' +
                ", areaEnable='" + areaEnable + '\'' +
                '}';
    }
}
