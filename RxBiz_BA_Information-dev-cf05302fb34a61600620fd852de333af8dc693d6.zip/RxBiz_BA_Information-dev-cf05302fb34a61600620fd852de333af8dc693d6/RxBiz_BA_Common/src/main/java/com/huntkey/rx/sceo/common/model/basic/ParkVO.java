package com.huntkey.rx.sceo.common.model.basic;


import java.util.Date;
import java.util.List;

public class ParkVO {
    private String id;

    private String edmdClass;

    private String edmdEnte;

    private String edmdSrcobj;

    private String edmdCode;

    private String infoCode;

    private String infoDesc;

    private String infoName;

    private String rpakAddr;

    private String rpakCode;

    private String rpakName;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String modUserName;

    private String edmdSrcClass;

    private Integer rpakIsdefault;

    private Integer rpakSeq;

    private List<RpakRpakAddrSetaVO> rpakAddrSet;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEdmdClass() {
        return edmdClass;
    }

    public void setEdmdClass(String edmdClass) {
        this.edmdClass = edmdClass;
    }

    public String getEdmdEnte() {
        return edmdEnte;
    }

    public void setEdmdEnte(String edmdEnte) {
        this.edmdEnte = edmdEnte;
    }

    public String getEdmdSrcobj() {
        return edmdSrcobj;
    }

    public void setEdmdSrcobj(String edmdSrcobj) {
        this.edmdSrcobj = edmdSrcobj;
    }

    public String getEdmdCode() {
        return edmdCode;
    }

    public void setEdmdCode(String edmdCode) {
        this.edmdCode = edmdCode;
    }

    public String getInfoCode() {
        return infoCode;
    }

    public void setInfoCode(String infoCode) {
        this.infoCode = infoCode;
    }

    public String getInfoDesc() {
        return infoDesc;
    }

    public void setInfoDesc(String infoDesc) {
        this.infoDesc = infoDesc;
    }

    public String getInfoName() {
        return infoName;
    }

    public void setInfoName(String infoName) {
        this.infoName = infoName;
    }

    public String getRpakAddr() {
        return rpakAddr;
    }

    public void setRpakAddr(String rpakAddr) {
        this.rpakAddr = rpakAddr;
    }

    public String getRpakCode() {
        return rpakCode;
    }

    public void setRpakCode(String rpakCode) {
        this.rpakCode = rpakCode;
    }

    public String getRpakName() {
        return rpakName;
    }

    public void setRpakName(String rpakName) {
        this.rpakName = rpakName;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getEdmdSrcClass() {
        return edmdSrcClass;
    }

    public void setEdmdSrcClass(String edmdSrcClass) {
        this.edmdSrcClass = edmdSrcClass;
    }

    public Integer getRpakIsdefault() {
        return rpakIsdefault;
    }

    public void setRpakIsdefault(Integer rpakIsdefault) {
        this.rpakIsdefault = rpakIsdefault;
    }

    public Integer getRpakSeq() {
        return rpakSeq;
    }

    public void setRpakSeq(Integer rpakSeq) {
        this.rpakSeq = rpakSeq;
    }

    public List<RpakRpakAddrSetaVO> getRpakAddrSet() {
        return rpakAddrSet;
    }

    public void setRpakAddrSet(List<RpakRpakAddrSetaVO> rpakAddrSet) {
        this.rpakAddrSet = rpakAddrSet;
    }
}
