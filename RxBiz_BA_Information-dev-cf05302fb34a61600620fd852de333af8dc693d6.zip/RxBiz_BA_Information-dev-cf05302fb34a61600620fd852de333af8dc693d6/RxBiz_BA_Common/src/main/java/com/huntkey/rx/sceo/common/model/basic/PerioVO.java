package com.huntkey.rx.sceo.common.model.basic;


import java.util.Date;

public class PerioVO {
    private String id;

    private String edmdClass;

    private String edmdEnte;

    private String edmdSrcobj;

    private String edmdCode;

    private String infoCode;

    private String infoDesc;

    private String infoName;

    private String edmdSrcClass;

    private Date peidEdate;

    private String peidFyr;

    private String peidName;

    private Integer peidProid;

    private Date peidSdate;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String modUserName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEdmdClass() {
        return edmdClass;
    }

    public void setEdmdClass(String edmdClass) {
        this.edmdClass = edmdClass;
    }

    public String getEdmdEnte() {
        return edmdEnte;
    }

    public void setEdmdEnte(String edmdEnte) {
        this.edmdEnte = edmdEnte;
    }

    public String getEdmdSrcobj() {
        return edmdSrcobj;
    }

    public void setEdmdSrcobj(String edmdSrcobj) {
        this.edmdSrcobj = edmdSrcobj;
    }

    public String getEdmdCode() {
        return edmdCode;
    }

    public void setEdmdCode(String edmdCode) {
        this.edmdCode = edmdCode;
    }

    public String getInfoCode() {
        return infoCode;
    }

    public void setInfoCode(String infoCode) {
        this.infoCode = infoCode;
    }

    public String getInfoDesc() {
        return infoDesc;
    }

    public void setInfoDesc(String infoDesc) {
        this.infoDesc = infoDesc;
    }

    public String getInfoName() {
        return infoName;
    }

    public void setInfoName(String infoName) {
        this.infoName = infoName;
    }


    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getEdmdSrcClass() {
        return edmdSrcClass;
    }

    public void setEdmdSrcClass(String edmdSrcClass) {
        this.edmdSrcClass = edmdSrcClass;
    }

    public Date getPeidEdate() {
        return peidEdate;
    }

    public void setPeidEdate(Date peidEdate) {
        this.peidEdate = peidEdate;
    }

    public String getPeidFyr() {
        return peidFyr;
    }

    public void setPeidFyr(String peidFyr) {
        this.peidFyr = peidFyr;
    }

    public String getPeidName() {
        return peidName;
    }

    public void setPeidName(String peidName) {
        this.peidName = peidName;
    }

    public Integer getPeidProid() {
        return peidProid;
    }

    public void setPeidProid(Integer peidProid) {
        this.peidProid = peidProid;
    }

    public Date getPeidSdate() {
        return peidSdate;
    }

    public void setPeidSdate(Date peidSdate) {
        this.peidSdate = peidSdate;
    }
}
