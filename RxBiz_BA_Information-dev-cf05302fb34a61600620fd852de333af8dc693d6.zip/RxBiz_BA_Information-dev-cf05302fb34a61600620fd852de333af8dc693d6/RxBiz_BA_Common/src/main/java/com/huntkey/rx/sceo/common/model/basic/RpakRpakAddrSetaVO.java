package com.huntkey.rx.sceo.common.model.basic;


import java.util.Date;

public class RpakRpakAddrSetaVO {
    private String id;
    private String pid;
    private String classname;
    private String rpakDaddr;
    private String rpakAddrp;
    private String rpakAddrc;
    private String rpakContact;
    private String rpakCway;
    private String rpakAddrl;
    private String isDel;
    private Date cretime;
    private String creuser;
    private Date modtime;
    private String moduser;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getRpakDaddr() {
        return rpakDaddr;
    }

    public void setRpakDaddr(String rpakDaddr) {
        this.rpakDaddr = rpakDaddr;
    }

    public String getRpakAddrp() {
        return rpakAddrp;
    }

    public void setRpakAddrp(String rpakAddrp) {
        this.rpakAddrp = rpakAddrp;
    }

    public String getRpakAddrc() {
        return rpakAddrc;
    }

    public void setRpakAddrc(String rpakAddrc) {
        this.rpakAddrc = rpakAddrc;
    }

    public String getRpakContact() {
        return rpakContact;
    }

    public void setRpakContact(String rpakContact) {
        this.rpakContact = rpakContact;
    }

    public String getRpakCway() {
        return rpakCway;
    }

    public void setRpakCway(String rpakCway) {
        this.rpakCway = rpakCway;
    }

    public String getRpakAddrl() {
        return rpakAddrl;
    }

    public void setRpakAddrl(String rpakAddrl) {
        this.rpakAddrl = rpakAddrl;
    }

    public String getIsDel() {
        return isDel;
    }

    public void setIsDel(String isDel) {
        this.isDel = isDel;
    }


    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }
}
