package com.huntkey.rx.sceo.common.model.code;

/**
 * @author zoulj
 * @create 2017/12/1 14:44
 **/
public class AddManualNumberByExcelDto {

    private byte[] bytes;

    private String pid;

    private String fileName;

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public byte[] getBytes() {
        return bytes;
    }

    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }
}
