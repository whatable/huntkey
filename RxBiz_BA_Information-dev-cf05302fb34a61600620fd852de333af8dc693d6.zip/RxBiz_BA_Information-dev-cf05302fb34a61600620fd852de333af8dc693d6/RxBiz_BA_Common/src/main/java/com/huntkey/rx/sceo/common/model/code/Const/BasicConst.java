package com.huntkey.rx.sceo.common.model.code.Const;

/**
 * @author liucs
 * @create 2018-1-15 17:26:15
 */
public interface BasicConst {
    String ID = "id";
    String PID = "pid";
    String CREUSER = "creuser";
    String MODUSER = "moduser";
    String CRETIME = "cretime";
    String MODTIME = "modtime";
    String CLASSNAME = "classname";
}
