package com.huntkey.rx.sceo.common.model.code.Const;

/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlConditionFormulaSetConst {
    String TABLENAME = "nbrl_condition_formula_set";
    String NBRL_CONDITION_FORMULA = "nbrl_condition_formula";
    String NBRL_CFORMULA_TYPE = "nbrl_cformula_type";
    String NBRL_CFORMULA_ID = "nbrl_cformula_id";
    String NBRL_CLASS = "nbrl_class";
    String NBRL_NBRL_CFORMULA_ORDER = "nbrl_cformula_order";

    /** 属性名称*/
}
