package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlConditionSetConst {
    String TABLENAME = "nbrl_condition_set";

    String NBRL_CURRENT_SERIAL = "nbrl_current_serial";
    String NBRL_DESC = "nbrl_desc";
    String  NBRL_IS_MANUAL_NUMBER = "nbrl_is_manual_number";
    String  NBRL_CODE_EPSN = "nbrl_code_epsn";
    String  NBRL_TAKENO_DATE = "nbrl_takeno_date";
    String NBRL_CONDITION_ORDER = "nbrl_condition_order";
    String NBRL_IS_USED = "nbrl_is_used";
    /**
     * 属性集
     */
}
