package com.huntkey.rx.sceo.common.model.code.Const;

public interface NbrlFormulacConst {
    String NBRL_BRACKET_LEFT = "nbrl_bracket_left";
    String NBRL_FMLA_PARAM = "nbrl_fmla_param";
    String NBRL_FMLA_OPRT = "nbrl_fmla_oprt";
    String NBRL_FMLA_VALUE = "nbrl_fmla_value";
    String NBRL_BRACKET_RIGHT = "nbrl_bracket_right";
    String NBRL_FMLA_LOGIC = "nbrl_fmla_logic";
    String NBRL_FMLA_ORDER = "nbrl_fmla_order";
}
