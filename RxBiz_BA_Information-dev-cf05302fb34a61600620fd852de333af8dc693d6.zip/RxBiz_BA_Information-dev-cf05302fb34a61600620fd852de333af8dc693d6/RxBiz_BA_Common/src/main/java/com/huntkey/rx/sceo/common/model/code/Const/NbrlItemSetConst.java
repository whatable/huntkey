package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlItemSetConst {
    String TABLENAME = "nbrl_item_set";
    String NBRL_NBRL_ITEM_ORDER = "nbrl_item_order";
    String NBRL_NBRL_ITEM_TYPE = "nbrl_item_type";
    String NBRL_ITEM_DESC = "nbrl_item_desc";
    /**
     *属性集
     */
    String NBRL_TIME_SET_LIST  = "nbrlTimeSetList";
    String NBRL_TEXT_SET_LIST = "nbrlTextSetList";
    String NBRL_PARAM_SET_LIST = "nbrlParamSetList";
    String NBRL_SERIAL_SET_LIST = "nbrlSerialSetList";
    String NBRL_PROPERTY_TYPE_LIST = "nbrlPropertyTypeList";

    /*************属性名称******/
    String NBRL_ITEM_ORDER = "nbrlItemOrder";
    String NBRL_ITEM_TYPE = "nbrlItemType";
}
