package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlManualNumberSetConst {
    String TABLENAME = "nbrl_manual_number_set";
    String NBRL_NBRL_IS_USE = "nbrl_is_use";
    String NBRL_NBRL_MANUAL_NUMBER = "nbrl_manual_number";
    String NBRL_NBRL_MANUAL_NUMBER_ORDER = "nbrl_manual_number_order";

    /****************属性名称***********/
    String NBRL_IS_USE = "nbrlIsUse";

    String NBRL_MANUAL_NUMBER = "nbrlManualNumber";

    String NBRL_MANUAL_NUMBER_ORDER = "nbrlManualNumberOrder";
}
