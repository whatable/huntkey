package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlParamSetConst {
    String TABLENAME = "nbrl_param_set";
    String NBRL_NBRL_PARAM = "nbrl_param";
    String NBRL_NBRL_PARAM_TYPE = "nbrl_param_type";
    String NBRL_NBRL_PARAM_START_POSITION = "nbrl_param_start_position";
    String NBRL_NBRL_PARAM_INTERCEPT_COUNT = "nbrl_param_intercept_count";
    /***********属性名称********/
    String NBRL_PARAM = "nbrlParam";
    String NBRL_PARAM_TYPE = "nbrlParamType";
    String NBRL_PARAM_START_POSITION = "nbrlParamStartPosition";
    String NBRL_PARAM_INTERCEPT_COUNT = "nbrlParamInterceptCount";
}
