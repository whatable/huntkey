package com.huntkey.rx.sceo.common.model.code.Const;

/**
 * @author liucs
 * @date 2017-11-27 11:20:39
 */
public interface NbrlPropertyTypeSetConst {
    String TABLENAME = "nbrl_property_type";
    String NBRL_NBRL_PROPERPY = "nbrl_property";
    String NBRL_NBRL_PROPERTY_INTERCEPT_TYPE = "nbrl_property_intercept_type";
    String  NBRL_NBRL_PROPERTY_INTERCEPT_START = "nbrl_property_intercept_start";
    String  NBRL_NBRL_PROPERTY_INTERCEPT_COUNT = "nbrl_property_intercept_count";

    /*************属性名称**************/
    String NBRL_PROPERPY = "nbrlProperty";
    String NBRL_PROPERTY_INTERCEPT_TYPE = "nbrlPropertyInterceptType";
    String NBRL_PROPERTY_INTERCEPT_START = "nbrlPropertyInterceptStart";
    String NBRL_PROPERTY_INTERCEPT_COUNT = "nbrlPropertyInterceptCount";
}
