package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlSerialSetConst {
    String TABLENAME = "nbrl_serial_set";

    String NBRL_NBRL_SERIAL_LENGTH = "nbrl_serial_length";
    String NBRL_NBRL_SERIAL_RESET_CONDITION = "nbrl_serial_reset_condition";
    String  NBRL_NBRL_SERIAL_STEP = "nbrl_serial_step";
    String NBRL_NBRL_SERIAL_RESET_NUMBER = "nbrl_serial_reset_number";
    String NBRL_NBRL_SERIAL_RULE = "nbrl_serial_rule";

    /*********************属性名称************/
    String NBRL_SERIAL_LENGTH = "nbrlSerialLength";
    String NBRL_SERIAL_RESET_CONDITION = "nbrlSerialResetCondition";
    String NBRL_SERIAL_STEP = "nbrlSerialStep";
    String NBRL_SERIAL_RESET_NUMBER = "nbrlSerialResetNumber";
    String NBRL_SERIAL_RULE = "nbrlSerialRule";
}
