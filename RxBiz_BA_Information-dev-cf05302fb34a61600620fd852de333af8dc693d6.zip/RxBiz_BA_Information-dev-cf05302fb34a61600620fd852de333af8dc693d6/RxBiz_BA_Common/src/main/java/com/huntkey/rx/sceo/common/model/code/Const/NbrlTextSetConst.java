package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlTextSetConst {
    String TABLENAME = "nbrl_text_set";
    String NBRL_NBRL_TEST_CONTENT = "nbrl_test_content";
}
