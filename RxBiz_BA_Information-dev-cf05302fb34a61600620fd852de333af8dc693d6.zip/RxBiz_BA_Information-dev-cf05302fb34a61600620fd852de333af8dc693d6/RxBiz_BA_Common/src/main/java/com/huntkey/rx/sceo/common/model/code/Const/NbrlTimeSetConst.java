package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlTimeSetConst {
    String TABLENAME = "nbrl_time_set";
    String NBRL_NBRL_TIME_TYPE = "nbrl_time_type";
    String NBRL_NBRL_TIME_LENGTH = "nbrl_time_length";
    /**********属性名称*****/
    String NBRL_TIME_TYPE = "nbrlTimeType";
    String NBRL_TIME_LENGTH = "nbrlTimeLength";
}
