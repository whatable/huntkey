package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NbrlUseSetConst {
    String TABLENAME = "nbrl_use_set";
    String NBRL_NBRL_USEPROPERTY = "nbrl_useproperty";

    /**子表属性名*/
    String NBRL_USEPROPERTY = "nbrlUseproperty";
}
