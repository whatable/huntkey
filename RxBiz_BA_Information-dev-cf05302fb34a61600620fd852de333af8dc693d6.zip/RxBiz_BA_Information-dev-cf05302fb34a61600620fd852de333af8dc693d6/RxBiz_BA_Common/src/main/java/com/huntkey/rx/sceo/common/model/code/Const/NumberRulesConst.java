package com.huntkey.rx.sceo.common.model.code.Const;
/**
 * @author liucs
 * @date 2017-11-27 11:21:08
 */
public interface NumberRulesConst {
    String TABLENAME = "numberrules";
    String NBRL_ID = "id";
    String NBRL_NBRL_SERIAL_INCREASE = "nbrl_serial_increase";
    String NBRL_NBRL_NAME = "nbrl_name";
    String NBRL_NBRL_CODE = "nbrl_code";
    String NBRL_NBRL_IS_USED = "nbrl_is_used";
    String NBRL_INFO_NAME = "info_name";
    String NBRL_INFO_DESC = "info_desc";
    String NBRL_INFO_CODE = "info_code";
    String NBRL_EDMD_SRC_CLASS = "edmd_src_class";
    String NBRL_EDMD_SRCOBJ = "edmd_srcobj";
    String NBRL_EDMD_ENTE = "edmd_ente";
    String NBRL_EDMD_CODE = "edmd_code";
    String NBRL_EDMD_CLASS = "edmd_class";
    String NBRL_ISDEL = "is_del";
    String NBRL_CRETIME = "cretime";
    String NBRL_CREUSER = "creuser";
    String NBRL_MODTIME = "modtime";
    String NBRL_MODUSER = "moduser";

/********************属性名称*****************************/
    String ID = "id";
    String NBRL_SERIAL_INCREASE = "nbrlSerialIncrease";
    String NBRL_NAME = "nbrlName";
    String NBRL_CODE = "nbrlCode";
    String NBRL_IS_USED = "nbrlIsUsed";
    String INFO_NAME = "infoName";
    String INFO_DESC = "infoDesc";
    String INFO_CODE = "infoCode";
    String EDMD_SRC_CLASS = "edmdSrcClass";
    String EDMD_SRCOBJ = "edmdSrcobj";
    String EDMD_ENTE = "edmdEnte";
    String EDMD_CODE = "edmdCode";
    String EDMD_CLASS = "edmdClass";
    String ISDEL = "isDel";
    String CRETIME = "cretime";
    String CREUSER = "creuser";
    String MODTIME = "modtime";
    String MODUSER = "moduser";
    /**
     * 属性集
     */
    String NBRL_USE_SET_LIST = "nbrlUseSetList";
    String NBRL_CONDITION_SET_LIST= "nbrlConditionSetList";
}
