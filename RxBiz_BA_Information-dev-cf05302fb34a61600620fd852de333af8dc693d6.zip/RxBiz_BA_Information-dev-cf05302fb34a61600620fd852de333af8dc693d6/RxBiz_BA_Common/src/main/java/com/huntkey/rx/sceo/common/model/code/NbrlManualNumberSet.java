package com.huntkey.rx.sceo.common.model.code;


/**
 * 手工编号集
 * @author liucs
 * @date 2017-11-24 14:39:36
 */
public class NbrlManualNumberSet{

    private String pid;

    private String classname;

    private String nbrlIsUse;

    private String nbrlManualNumber;

    private Integer nbrlManualNumberOrder;

    private String isDel;


    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid == null ? null : pid.trim();
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname == null ? null : classname.trim();
    }

    public String getNbrlIsUse() {
        return nbrlIsUse;
    }

    public void setNbrlIsUse(String nbrlIsUse) {
        this.nbrlIsUse = nbrlIsUse == null ? null : nbrlIsUse.trim();
    }

    public String getNbrlManualNumber() {
        return nbrlManualNumber;
    }

    public void setNbrlManualNumber(String nbrlManualNumber) {
        this.nbrlManualNumber = nbrlManualNumber == null ? null : nbrlManualNumber.trim();
    }

    public Integer getNbrlManualNumberOrder() {
        return nbrlManualNumberOrder;
    }

    public void setNbrlManualNumberOrder(Integer nbrlManualNumberOrder) {
        this.nbrlManualNumberOrder = nbrlManualNumberOrder;
    }

    public String getIsDel() {
        return isDel;
    }

    public void setIsDel(String isDel) {
        this.isDel = isDel;
    }

}