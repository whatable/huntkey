package com.huntkey.rx.sceo.common.model.code;

/**
 * @author zoulj
 * @create 2017/11/27 9:36
 **/
public interface NbrlManualNumberSetConst {

    String TABLENAME = "numberrules.nbrl_condition_set.nbrl_manual_number_set";
    String ID = "id";
    String PID = "pid";
    String IS_DEL = "is_del";
    String CLASSNAME = "classname";
    String MODUSER = "moduser";
    String MODTIME = "modtime";
    String CREUSER = "creuser";
    String CRETIME = "cretime";

    String NBRL_IS_USE_TB = "nbrl_is_use";
    String NBRL_MANUAL_NUMBER_TB = "nbrl_manual_number";
    String NBRL_MANUAL_NUMBER_ORDER_TB = "nbrl_manual_number_order";

    String ISDEL = "isDel";
    String NBRL_IS_USE = "nbrlIsUse";
    String NBRL_MANUAL_NUMBER = "nbrlManualNumber";
    String NBRL_MANUAL_NUMBER_ORDER = "nbrlManualNumberOrder";

}
