package com.huntkey.rx.sceo.common.model.code;

import java.util.Date;
/**
 * 参数集
 * @author liucs
 * @date 2017-11-24 14:37:47
 */
public class NbrlParamSet {
    private String id;

    private String pid;

    private String classname;

    private String nbrlParam;

    private Integer nbrlParamInterceptCount;

    private Integer nbrlParamStartPosition;

    private String nbrlParamType;

    private Byte isDel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid == null ? null : pid.trim();
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname == null ? null : classname.trim();
    }

    public String getNbrlParam() {
        return nbrlParam;
    }

    public void setNbrlParam(String nbrlParam) {
        this.nbrlParam = nbrlParam == null ? null : nbrlParam.trim();
    }

    public Integer getNbrlParamInterceptCount() {
        return nbrlParamInterceptCount;
    }

    public void setNbrlParamInterceptCount(Integer nbrlParamInterceptCount) {
        this.nbrlParamInterceptCount = nbrlParamInterceptCount;
    }

    public Integer getNbrlParamStartPosition() {
        return nbrlParamStartPosition;
    }

    public void setNbrlParamStartPosition(Integer nbrlParamStartPosition) {
        this.nbrlParamStartPosition = nbrlParamStartPosition;
    }

    public String getNbrlParamType() {
        return nbrlParamType;
    }

    public void setNbrlParamType(String nbrlParamType) {
        this.nbrlParamType = nbrlParamType == null ? null : nbrlParamType.trim();
    }

    public Byte getIsDel() {
        return isDel;
    }

    public void setIsDel(Byte isDel) {
        this.isDel = isDel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser == null ? null : creuser.trim();
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser == null ? null : moduser.trim();
    }
}