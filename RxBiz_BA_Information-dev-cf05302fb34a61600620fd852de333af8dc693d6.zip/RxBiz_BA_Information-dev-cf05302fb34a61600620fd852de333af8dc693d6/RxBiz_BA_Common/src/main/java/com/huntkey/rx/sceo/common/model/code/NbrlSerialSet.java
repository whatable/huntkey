package com.huntkey.rx.sceo.common.model.code;

import java.util.Date;
/**
 * 流水号集
 * @author liucs
 * @date 2017-11-24 14:37:08
 */
public class NbrlSerialSet {
    private String id;

    private String pid;

    private String classname;

    private Integer nbrlSerialLength;

    private String nbrlSerialResetCondition;

    private String nbrlSerialResetNumber;

    private String nbrlSerialRule;

    private Integer nbrlSerialStep;

    private Byte isDel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid == null ? null : pid.trim();
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname == null ? null : classname.trim();
    }

    public Integer getNbrlSerialLength() {
        return nbrlSerialLength;
    }

    public void setNbrlSerialLength(Integer nbrlSerialLength) {
        this.nbrlSerialLength = nbrlSerialLength;
    }

    public String getNbrlSerialResetCondition() {
        return nbrlSerialResetCondition;
    }

    public void setNbrlSerialResetCondition(String nbrlSerialResetCondition) {
        this.nbrlSerialResetCondition = nbrlSerialResetCondition == null ? null : nbrlSerialResetCondition.trim();
    }

    public String getNbrlSerialResetNumber() {
        return nbrlSerialResetNumber;
    }

    public void setNbrlSerialResetNumber(String nbrlSerialResetNumber) {
        this.nbrlSerialResetNumber = nbrlSerialResetNumber == null ? null : nbrlSerialResetNumber.trim();
    }

    public String getNbrlSerialRule() {
        return nbrlSerialRule;
    }

    public void setNbrlSerialRule(String nbrlSerialRule) {
        this.nbrlSerialRule = nbrlSerialRule == null ? null : nbrlSerialRule.trim();
    }

    public Integer getNbrlSerialStep() {
        return nbrlSerialStep;
    }

    public void setNbrlSerialStep(Integer nbrlSerialStep) {
        this.nbrlSerialStep = nbrlSerialStep;
    }

    public Byte getIsDel() {
        return isDel;
    }

    public void setIsDel(Byte isDel) {
        this.isDel = isDel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser == null ? null : creuser.trim();
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser == null ? null : moduser.trim();
    }
}