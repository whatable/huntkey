package com.huntkey.rx.sceo.common.model.code;

import java.util.Date;
/**
 * 文本集
 * @author liucs
 * @date 2017-11-24 14:38:06
 */
public class NbrlTextSet {
    private String id;

    private String pid;

    private String classname;

    private String nbrlTestContent;

    private Byte isDel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid == null ? null : pid.trim();
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname == null ? null : classname.trim();
    }

    public String getNbrlTestContent() {
        return nbrlTestContent;
    }

    public void setNbrlTestContent(String nbrlTestContent) {
        this.nbrlTestContent = nbrlTestContent == null ? null : nbrlTestContent.trim();
    }

    public Byte getIsDel() {
        return isDel;
    }

    public void setIsDel(Byte isDel) {
        this.isDel = isDel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser == null ? null : creuser.trim();
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser == null ? null : moduser.trim();
    }
}