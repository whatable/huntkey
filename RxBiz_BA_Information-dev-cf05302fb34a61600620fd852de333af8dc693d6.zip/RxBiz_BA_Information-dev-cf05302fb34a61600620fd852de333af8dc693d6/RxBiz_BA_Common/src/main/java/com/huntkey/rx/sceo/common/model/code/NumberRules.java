package com.huntkey.rx.sceo.common.model.code;

import java.util.Date;
/**
 * 编号规则
 * @author liucs
 * @date 2017-11-24 14:41:47
 */
public class NumberRules {
    private String id;

    private String edmdClass;

    private String edmdCode;

    private String edmdEnte;

    private String edmdSrcobj;

    private String edmdSrcClass;

    private String infoCode;

    private String infoDesc;

    private String infoName;

    private String nbrlCode;

    private String nbrlName;

    private String nbrlSerialIncrease;

    private Byte nbrlIsUsed;

    private Byte isDel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    public Byte getNbrlIsUsed() {
        return nbrlIsUsed;
    }

    public void setNbrlIsUsed(Byte nbrlIsUsed) {
        this.nbrlIsUsed = nbrlIsUsed;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getEdmdClass() {
        return edmdClass;
    }

    public void setEdmdClass(String edmdClass) {
        this.edmdClass = edmdClass == null ? null : edmdClass.trim();
    }

    public String getEdmdCode() {
        return edmdCode;
    }

    public void setEdmdCode(String edmdCode) {
        this.edmdCode = edmdCode == null ? null : edmdCode.trim();
    }

    public String getEdmdEnte() {
        return edmdEnte;
    }

    public void setEdmdEnte(String edmdEnte) {
        this.edmdEnte = edmdEnte == null ? null : edmdEnte.trim();
    }

    public String getEdmdSrcobj() {
        return edmdSrcobj;
    }

    public void setEdmdSrcobj(String edmdSrcobj) {
        this.edmdSrcobj = edmdSrcobj == null ? null : edmdSrcobj.trim();
    }

    public String getEdmdSrcClass() {
        return edmdSrcClass;
    }

    public void setEdmdSrcClass(String edmdSrcClass) {
        this.edmdSrcClass = edmdSrcClass == null ? null : edmdSrcClass.trim();
    }

    public String getInfoCode() {
        return infoCode;
    }

    public void setInfoCode(String infoCode) {
        this.infoCode = infoCode == null ? null : infoCode.trim();
    }

    public String getInfoDesc() {
        return infoDesc;
    }

    public void setInfoDesc(String infoDesc) {
        this.infoDesc = infoDesc == null ? null : infoDesc.trim();
    }

    public String getInfoName() {
        return infoName;
    }

    public void setInfoName(String infoName) {
        this.infoName = infoName == null ? null : infoName.trim();
    }

    public String getNbrlCode() {
        return nbrlCode;
    }

    public void setNbrlCode(String nbrlCode) {
        this.nbrlCode = nbrlCode == null ? null : nbrlCode.trim();
    }

    public String getNbrlName() {
        return nbrlName;
    }

    public void setNbrlName(String nbrlName) {
        this.nbrlName = nbrlName == null ? null : nbrlName.trim();
    }

    public String getNbrlSerialIncrease() {
        return nbrlSerialIncrease;
    }

    public void setNbrlSerialIncrease(String nbrlSerialIncrease) {
        this.nbrlSerialIncrease = nbrlSerialIncrease == null ? null : nbrlSerialIncrease.trim();
    }

    public Byte getIsDel() {
        return isDel;
    }

    public void setIsDel(Byte isDel) {
        this.isDel = isDel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser == null ? null : creuser.trim();
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser == null ? null : moduser.trim();
    }
}