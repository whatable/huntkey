package com.huntkey.rx.sceo.common.model.code;

/**
 * @author zoulj
 * @create 2017/12/5 10:54
 **/
public class QryNumberRulesDto {

    private String nbrl_code;

    private String nbrl_name;

    private String nbrl_useproperty;

    private String nbrl_is_used=""; //"" 全部, "0" 启用, "1" 禁用

    private String authorization;

    private int pageNum = 1;

    private int pageSize = 15;

    public String getAuthorization() {
        return authorization;
    }

    public void setAuthorization(String authorization) {
        this.authorization = authorization;
    }

    public String getNbrl_code() {
        return nbrl_code;
    }

    public void setNbrl_code(String nbrl_code) {
        this.nbrl_code = nbrl_code;
    }

    public String getNbrl_name() {
        return nbrl_name;
    }

    public void setNbrl_name(String nbrl_name) {
        this.nbrl_name = nbrl_name;
    }

    public String getNbrl_useproperty() {
        return nbrl_useproperty;
    }

    public void setNbrl_useproperty(String nbrl_useproperty) {
        this.nbrl_useproperty = nbrl_useproperty;
    }

    public String getNbrl_is_used() {
        return nbrl_is_used;
    }

    public void setNbrl_is_used(String nbrl_is_used) {
        this.nbrl_is_used = nbrl_is_used;
    }

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }
}
