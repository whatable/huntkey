package com.huntkey.rx.sceo.common.model.code.VO;

/**
 * @author zoulj
 * @create 2018/1/15 11:45
 **/
public class ManualNumberAddToRedis {

    private String pid;

    private String manualNumberCodes;

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getManualNumberCodes() {
        return manualNumberCodes;
    }

    public void setManualNumberCodes(String manualNumberCodes) {
        this.manualNumberCodes = manualNumberCodes;
    }
}
