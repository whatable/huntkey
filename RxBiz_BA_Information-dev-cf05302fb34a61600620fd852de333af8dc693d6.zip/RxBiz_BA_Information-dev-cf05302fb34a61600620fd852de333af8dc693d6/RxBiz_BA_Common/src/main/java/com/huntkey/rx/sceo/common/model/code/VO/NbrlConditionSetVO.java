package com.huntkey.rx.sceo.common.model.code.VO;

import java.util.Date;
import java.util.List;

public class NbrlConditionSetVO {
    private String id;

    private String pid;

    private String classname;

    private String nbrl_current_serial;

    private String nbrl_desc;

    private String nbrl_is_manual_number;

    private String nbrl_code_epsn;

    private Date nbrl_takeno_date;

    private String nbrl_is_used;

    private Integer nbrl_condition_order;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String modUserName;
    /*******扩展属性****************/
    /**
     * 规则条件公式集
     */
    private List<NbrlNbrlConditionFormulaSetbVO> nbrl_condition_formula_set;
    /**
     * 手工编号集
     */
    private List<NbrlNbrlManualNumberSetbVO>  nbrl_manual_number_set;
    /**
     * 规则项集
     */
    private List<NbrlItemSetVO> nbrl_item_set;

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getNbrl_current_serial() {
        return nbrl_current_serial;
    }

    public void setNbrl_current_serial(String nbrl_current_serial) {
        this.nbrl_current_serial = nbrl_current_serial;
    }

    public String getNbrl_desc() {
        return nbrl_desc;
    }

    public void setNbrl_desc(String nbrl_desc) {
        this.nbrl_desc = nbrl_desc;
    }

    public String getNbrl_is_manual_number() {
        return nbrl_is_manual_number;
    }

    public void setNbrl_is_manual_number(String nbrl_is_manual_number) {
        this.nbrl_is_manual_number = nbrl_is_manual_number;
    }

    public String getNbrl_code_epsn() {
        return nbrl_code_epsn;
    }

    public void setNbrl_code_epsn(String nbrl_code_epsn) {
        this.nbrl_code_epsn = nbrl_code_epsn;
    }

    public Date getNbrl_takeno_date() {
        return nbrl_takeno_date;
    }

    public void setNbrl_takeno_date(Date nbrl_takeno_date) {
        this.nbrl_takeno_date = nbrl_takeno_date;
    }

    public String getNbrl_is_used() {
        return nbrl_is_used;
    }

    public void setNbrl_is_used(String nbrl_is_used) {
        this.nbrl_is_used = nbrl_is_used;
    }

    public Integer getNbrl_condition_order() {
        return nbrl_condition_order;
    }

    public void setNbrl_condition_order(Integer nbrl_condition_order) {
        this.nbrl_condition_order = nbrl_condition_order;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public List<NbrlNbrlConditionFormulaSetbVO> getNbrl_condition_formula_set() {
        return nbrl_condition_formula_set;
    }

    public void setNbrl_condition_formula_set(List<NbrlNbrlConditionFormulaSetbVO> nbrl_condition_formula_set) {
        this.nbrl_condition_formula_set = nbrl_condition_formula_set;
    }

    public List<NbrlNbrlManualNumberSetbVO> getNbrl_manual_number_set() {
        return nbrl_manual_number_set;
    }

    public void setNbrl_manual_number_set(List<NbrlNbrlManualNumberSetbVO> nbrl_manual_number_set) {
        this.nbrl_manual_number_set = nbrl_manual_number_set;
    }

    public List<NbrlItemSetVO> getNbrl_item_set() {
        return nbrl_item_set;
    }

    public void setNbrl_item_set(List<NbrlItemSetVO> nbrl_item_set) {
        this.nbrl_item_set = nbrl_item_set;
    }

    @Override
    public String toString() {
        return "NbrlConditionSetVO{" +
                "id='" + id + '\'' +
                ", pid='" + pid + '\'' +
                ", classname='" + classname + '\'' +
                ", nbrl_current_serial='" + nbrl_current_serial + '\'' +
                ", nbrl_desc='" + nbrl_desc + '\'' +
                ", nbrl_is_manual_number='" + nbrl_is_manual_number + '\'' +
                ", nbrl_code_epsn='" + nbrl_code_epsn + '\'' +
                ", nbrl_takeno_date='" + nbrl_takeno_date + '\'' +
                ", nbrl_is_used='" + nbrl_is_used + '\'' +
                ", nbrl_condition_order='" + nbrl_condition_order + '\'' +
                ", isDel=" + isdel +
                ", cretime='" + cretime + '\'' +
                ", creuser='" + creuser + '\'' +
                ", modtime='" + modtime + '\'' +
                ", moduser='" + moduser + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", nbrl_condition_formula_set=" + nbrl_condition_formula_set +
                ", nbrl_manual_number_set=" + nbrl_manual_number_set +
                ", nbrl_item_set=" + nbrl_item_set +
                '}';
    }
}
