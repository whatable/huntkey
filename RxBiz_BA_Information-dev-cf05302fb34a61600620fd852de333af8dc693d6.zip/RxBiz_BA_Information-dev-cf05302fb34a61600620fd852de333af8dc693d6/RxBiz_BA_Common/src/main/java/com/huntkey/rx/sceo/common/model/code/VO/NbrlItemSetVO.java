package com.huntkey.rx.sceo.common.model.code.VO;

import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.sceo.common.model.code.*;

import java.util.Date;
import java.util.List;

public class NbrlItemSetVO {
    private String id;

    private String pid;

    private String classname;

    private Integer nbrl_item_order;

    private String nbrl_item_type;

    private String nbrl_item_desc;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;
    /********************扩展字段****************/
    private List<NbrlTimeVO> nbrl_time_set;
    private List<NbrlTextVO> nbrl_text_set;
    private List<NbrlParamVO> nbrl_param_set;
    private List<NbrlSerialVO> nbrl_serial_set;
    private List<NbrlPropertyVO> nbrl_property_type;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Integer getNbrl_item_order() {
        return nbrl_item_order;
    }

    public void setNbrl_item_order(Integer nbrl_item_order) {
        this.nbrl_item_order = nbrl_item_order;
    }

    public String getNbrl_item_type() {
        return nbrl_item_type;
    }

    public void setNbrl_item_type(String nbrl_item_type) {
        this.nbrl_item_type = nbrl_item_type;
    }

    public String getNbrl_item_desc() {
        return nbrl_item_desc;
    }

    public void setNbrl_item_desc(String nbrl_item_desc) {
        this.nbrl_item_desc = nbrl_item_desc;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public List<NbrlTimeVO> getNbrl_time_set() {
        return nbrl_time_set;
    }

    public void setNbrl_time_set(List<NbrlTimeVO> nbrl_time_set) {
        this.nbrl_time_set = nbrl_time_set;
    }

    public List<NbrlTextVO> getNbrl_text_set() {
        return nbrl_text_set;
    }

    public void setNbrl_text_set(List<NbrlTextVO> nbrl_text_set) {
        this.nbrl_text_set = nbrl_text_set;
    }

    public List<NbrlParamVO> getNbrl_param_set() {
        return nbrl_param_set;
    }

    public void setNbrl_param_set(List<NbrlParamVO> nbrl_param_set) {
        this.nbrl_param_set = nbrl_param_set;
    }

    public List<NbrlSerialVO> getNbrl_serial_set() {
        return nbrl_serial_set;
    }

    public void setNbrl_serial_set(List<NbrlSerialVO> nbrl_serial_set) {
        this.nbrl_serial_set = nbrl_serial_set;
    }

    public List<NbrlPropertyVO> getNbrl_property_type() {
        return nbrl_property_type;
    }

    public void setNbrl_property_type(List<NbrlPropertyVO> nbrl_property_type) {
        this.nbrl_property_type = nbrl_property_type;
    }

    @Override
    public String toString() {
        return "NbrlItemSetVO{" +
                "id='" + id + '\'' +
                ", pid='" + pid + '\'' +
                ", classname='" + classname + '\'' +
                ", nbrl_item_order=" + nbrl_item_order +
                ", nbrl_item_type='" + nbrl_item_type + '\'' +
                ", nbrl_item_desc='" + nbrl_item_desc + '\'' +
                ", isdel=" + isdel +
                ", cretime=" + cretime +
                ", creuser='" + creuser + '\'' +
                ", modtime=" + modtime +
                ", moduser='" + moduser + '\'' +
                ", nbrl_time_set=" + nbrl_time_set +
                ", nbrl_text_set=" + nbrl_text_set +
                ", nbrl_param_set=" + nbrl_param_set +
                ", nbrl_serial_set=" + nbrl_serial_set +
                ", nbrl_property_type=" + nbrl_property_type +
                '}';
    }
}
