package com.huntkey.rx.sceo.common.model.code.VO;

/**
 * @author zoulj
 * @create 2017/12/18 15:45
 **/
public class NbrlNbrlCodeUsedbVO {

    private String nbrl_cu_code;

    private String nbrl_cu_desc;

    public String getNbrl_cu_code() {
        return nbrl_cu_code;
    }

    public void setNbrl_cu_code(String nbrl_cu_code) {
        this.nbrl_cu_code = nbrl_cu_code;
    }

    public String getNbrl_cu_desc() {
        return nbrl_cu_desc;
    }

    public void setNbrl_cu_desc(String nbrl_cu_desc) {
        this.nbrl_cu_desc = nbrl_cu_desc;
    }

    @Override
    public String toString() {
        return "NbrlNbrlCodeUsedbVO{" +
                "nbrl_cu_code='" + nbrl_cu_code + '\'' +
                ", nbrl_cu_desc='" + nbrl_cu_desc + '\'' +
                '}';
    }
}
