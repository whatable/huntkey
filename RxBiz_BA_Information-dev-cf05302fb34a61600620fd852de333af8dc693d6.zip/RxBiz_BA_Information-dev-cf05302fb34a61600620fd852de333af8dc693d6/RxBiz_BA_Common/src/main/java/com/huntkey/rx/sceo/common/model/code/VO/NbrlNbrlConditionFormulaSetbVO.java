package com.huntkey.rx.sceo.common.model.code.VO;

import com.huntkey.rx.edm.entity.NbrlNbrlConditionFormulaSetbEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlFormulacEntity;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.util.Date;
import java.util.List;

/**
 * @author zoulj
 * @create 2017/12/18 15:34
 **/
public class NbrlNbrlConditionFormulaSetbVO {
    private String id;

    private String pid;

    private String classname;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String nbrl_condition_formula;

    private String nbrl_cformula_type;

    private Integer nbrl_cformula_order;

    private List<NbrlNbrlFormulacEntity> nbrl_formula;

    private String nbrl_cformula_id;

    private String nbrl_class;

    /** 规则属性集所属类ID **/
    private String classId;

    /** 规则属性所属类属性ID */
    private String propertyId;

    public List<NbrlNbrlFormulacEntity> getNbrl_formula() {
        return nbrl_formula;
    }

    public String getNbrl_class() {
        return nbrl_class;
    }

    public void setNbrl_class(String nbrl_class) {
        this.nbrl_class = nbrl_class;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getPropertyId() {
        return propertyId;
    }

    public void setPropertyId(String propertyId) {
        this.propertyId = propertyId;
    }

    public String getClassId() {
        return classId;
    }

    public void setClassId(String classId) {
        this.classId = classId;
    }

    public String getNbrl_condition_formula() {
        return nbrl_condition_formula;
    }

    public void setNbrl_condition_formula(String nbrl_condition_formula) {
        this.nbrl_condition_formula = nbrl_condition_formula;
    }

    public String getNbrl_cformula_type() {
        return nbrl_cformula_type;
    }

    public void setNbrl_cformula_type(String nbrl_cformula_type) {
        this.nbrl_cformula_type = nbrl_cformula_type;
    }

    public Integer getNbrl_cformula_order() {
        return nbrl_cformula_order;
    }

    public void setNbrl_cformula_order(Integer nbrl_cformula_order) {
        this.nbrl_cformula_order = nbrl_cformula_order;
    }

    public void setNbrl_formula(List<NbrlNbrlFormulacEntity> nbrl_formula) {
        this.nbrl_formula = nbrl_formula;
    }

    public String getNbrl_cformula_id() {
        return nbrl_cformula_id;
    }

    public void setNbrl_cformula_id(String nbrl_cformula_id) {
        this.nbrl_cformula_id = nbrl_cformula_id;
    }

    @Override
    public String toString() {
        return "NbrlNbrlConditionFormulaSetbVO{" +
                "id='" + id + '\'' +
                ", pid='" + pid + '\'' +
                ", classname='" + classname + '\'' +
                ", isDel=" + isdel +
                ", cretime='" + cretime + '\'' +
                ", creuser='" + creuser + '\'' +
                ", modtime='" + modtime + '\'' +
                ", moduser='" + moduser + '\'' +
                ", nbrl_condition_formula='" + nbrl_condition_formula + '\'' +
                ", nbrl_cformula_type='" + nbrl_cformula_type + '\'' +
                ", nbrl_cformula_order=" + nbrl_cformula_order +
                ", nbrl_formula=" + nbrl_formula +
                ", nbrl_cformula_id='" + nbrl_cformula_id + '\'' +
                ", nbrl_class='" + nbrl_class + '\'' +
                ", classId='" + classId + '\'' +
                ", propertyId='" + propertyId + '\'' +
                '}';
    }

    public static NbrlNbrlConditionFormulaSetbVO getIntance(NbrlNbrlConditionFormulaSetbEntity entity) throws Exception{
        NbrlNbrlConditionFormulaSetbVO vo = new NbrlNbrlConditionFormulaSetbVO();

        BeanInfo sourceBean = Introspector.getBeanInfo(entity.getClass(),NbrlNbrlConditionFormulaSetbVO.class);
        PropertyDescriptor[] sourceProperty = sourceBean.getPropertyDescriptors();

        BeanInfo destBean = Introspector.getBeanInfo(vo.getClass(),Object.class);
        PropertyDescriptor[] destProperty = destBean.getPropertyDescriptors();
        try {
            for (int i = 0; i < sourceProperty.length; i++) {
                for (int j = 0; j < destProperty.length; j++) {

                    if (sourceProperty[i].getName().equals(destProperty[j].getName())  && sourceProperty[i].getPropertyType() == destProperty[j].getPropertyType()) {
                        destProperty[j].getWriteMethod().invoke(vo,sourceProperty[i].getReadMethod().invoke(entity));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            throw new Exception("属性复制失败:" + e.getMessage());
        }
        return vo;
    }
}
