package com.huntkey.rx.sceo.common.model.code.VO;

/**
 * @author zoulj
 * @create 2017/12/18 15:37
 **/
public class NbrlNbrlFormulacVO {

    private String nbrl_bracket_left;

    private String nbrl_fmla_param;

    private String nbrl_fmla_oprt;

    private String nbrl_fmla_value;

    private String nbrl_bracket_right;

    private String nbrl_fmla_logic;

    private Integer nbrl_fmla_order;

    public String getNbrl_bracket_left() {
        return nbrl_bracket_left;
    }

    public void setNbrl_bracket_left(String nbrl_bracket_left) {
        this.nbrl_bracket_left = nbrl_bracket_left;
    }

    public String getNbrl_fmla_param() {
        return nbrl_fmla_param;
    }

    public void setNbrl_fmla_param(String nbrl_fmla_param) {
        this.nbrl_fmla_param = nbrl_fmla_param;
    }

    public String getNbrl_fmla_oprt() {
        return nbrl_fmla_oprt;
    }

    public void setNbrl_fmla_oprt(String nbrl_fmla_oprt) {
        this.nbrl_fmla_oprt = nbrl_fmla_oprt;
    }

    public String getNbrl_fmla_value() {
        return nbrl_fmla_value;
    }

    public void setNbrl_fmla_value(String nbrl_fmla_value) {
        this.nbrl_fmla_value = nbrl_fmla_value;
    }

    public String getNbrl_bracket_right() {
        return nbrl_bracket_right;
    }

    public void setNbrl_bracket_right(String nbrl_bracket_right) {
        this.nbrl_bracket_right = nbrl_bracket_right;
    }

    public String getNbrl_fmla_logic() {
        return nbrl_fmla_logic;
    }

    public void setNbrl_fmla_logic(String nbrl_fmla_logic) {
        this.nbrl_fmla_logic = nbrl_fmla_logic;
    }

    public Integer getNbrl_fmla_order() {
        return nbrl_fmla_order;
    }

    public void setNbrl_fmla_order(Integer nbrl_fmla_order) {
        this.nbrl_fmla_order = nbrl_fmla_order;
    }

    @Override
    public String toString() {
        return "NbrlNbrlFormulacVO{" +
                "nbrl_bracket_left='" + nbrl_bracket_left + '\'' +
                ", nbrl_fmla_param='" + nbrl_fmla_param + '\'' +
                ", nbrl_fmla_oprt='" + nbrl_fmla_oprt + '\'' +
                ", nbrl_fmla_value='" + nbrl_fmla_value + '\'' +
                ", nbrl_bracket_right='" + nbrl_bracket_right + '\'' +
                ", nbrl_fmla_logic='" + nbrl_fmla_logic + '\'' +
                ", nbrl_fmla_order=" + nbrl_fmla_order +
                '}';
    }
}
