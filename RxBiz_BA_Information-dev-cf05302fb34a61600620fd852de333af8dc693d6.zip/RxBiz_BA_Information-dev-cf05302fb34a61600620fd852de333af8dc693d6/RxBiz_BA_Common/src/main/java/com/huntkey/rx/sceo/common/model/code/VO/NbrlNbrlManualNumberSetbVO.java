package com.huntkey.rx.sceo.common.model.code.VO;

import java.util.Date;

/**
 * @author zoulj
 * @create 2017/12/18 15:40
 **/
public class NbrlNbrlManualNumberSetbVO {
    private String id;

    private String pid;

    private String classname;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String nbrl_manual_number;

    private Integer nbrl_manual_number_order;

    private String nbrl_is_use;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getNbrl_manual_number() {
        return nbrl_manual_number;
    }

    public void setNbrl_manual_number(String nbrl_manual_number) {
        this.nbrl_manual_number = nbrl_manual_number;
    }

    public Integer getNbrl_manual_number_order() {
        return nbrl_manual_number_order;
    }

    public void setNbrl_manual_number_order(Integer nbrl_manual_number_order) {
        this.nbrl_manual_number_order = nbrl_manual_number_order;
    }

    public String getNbrl_is_use() {
        return nbrl_is_use;
    }

    public void setNbrl_is_use(String nbrl_is_use) {
        this.nbrl_is_use = nbrl_is_use;
    }

    @Override
    public String toString() {
        return "NbrlNbrlManualNumberSetbVO{" +
                "id='" + id + '\'' +
                ", pid='" + pid + '\'' +
                ", classname='" + classname + '\'' +
                ", isDel=" + isdel +
                ", cretime='" + cretime + '\'' +
                ", creuser='" + creuser + '\'' +
                ", modtime='" + modtime + '\'' +
                ", moduser='" + moduser + '\'' +
                ", nbrl_manual_number='" + nbrl_manual_number + '\'' +
                ", nbrl_manual_number_order=" + nbrl_manual_number_order +
                ", nbrl_is_use='" + nbrl_is_use + '\'' +
                '}';
    }
}
