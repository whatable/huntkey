package com.huntkey.rx.sceo.common.model.code.VO;

/**
 * @author zoulj
 * @create 2017/12/18 15:27
 **/
public class NbrlNbrlUseSetaVO {

    private String id;

    private String cretime;

    private String moduser;

    private String creuser;

    private String modtime;

    private String nbrl_useproperty;

    private String nbrl_class_id;

    private String nbrl_class_name;

    private String nbrl_useproperty_name;

    public String getNbrl_useproperty() {
        return nbrl_useproperty;
    }

    public void setNbrl_useproperty(String nbrl_useproperty) {
        this.nbrl_useproperty = nbrl_useproperty;
    }

    public String getNbrl_class_id() {
        return nbrl_class_id;
    }

    public void setNbrl_class_id(String nbrl_class_id) {
        this.nbrl_class_id = nbrl_class_id;
    }

    public String getNbrl_class_name() {
        return nbrl_class_name;
    }

    public void setNbrl_class_name(String nbrl_class_name) {
        this.nbrl_class_name = nbrl_class_name;
    }

    public String getNbrl_useproperty_name() {
        return nbrl_useproperty_name;
    }

    public void setNbrl_useproperty_name(String nbrl_useproperty_name) {
        this.nbrl_useproperty_name = nbrl_useproperty_name;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCretime() {
        return cretime;
    }

    public void setCretime(String cretime) {
        this.cretime = cretime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getModtime() {
        return modtime;
    }

    public void setModtime(String modtime) {
        this.modtime = modtime;
    }

    @Override
    public String toString() {
        return "NbrlNbrlUseSetaVO{" +
                "id='" + id + '\'' +
                ", cretime='" + cretime + '\'' +
                ", moduser='" + moduser + '\'' +
                ", creuser='" + creuser + '\'' +
                ", modtime='" + modtime + '\'' +
                ", nbrl_useproperty='" + nbrl_useproperty + '\'' +
                ", nbrl_class_id='" + nbrl_class_id + '\'' +
                ", nbrl_class_name='" + nbrl_class_name + '\'' +
                ", nbrl_useproperty_name='" + nbrl_useproperty_name + '\'' +
                '}';
    }
}
