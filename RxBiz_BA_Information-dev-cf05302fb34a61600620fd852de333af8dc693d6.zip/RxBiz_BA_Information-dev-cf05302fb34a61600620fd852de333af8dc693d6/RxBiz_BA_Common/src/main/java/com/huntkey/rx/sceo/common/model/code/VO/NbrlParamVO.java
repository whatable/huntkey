package com.huntkey.rx.sceo.common.model.code.VO;

import java.util.Date;

public class NbrlParamVO {
    private String id;

    private String pid;

    private String classname;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String modUserName;

    private String nbrl_param;

    private String nbrl_param_type;

    private Integer nbrl_param_start_position;

    private Integer nbrl_param_intercept_count;

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getNbrl_param() {
        return nbrl_param;
    }

    public void setNbrl_param(String nbrl_param) {
        this.nbrl_param = nbrl_param;
    }

    public String getNbrl_param_type() {
        return nbrl_param_type;
    }

    public void setNbrl_param_type(String nbrl_param_type) {
        this.nbrl_param_type = nbrl_param_type;
    }

    public Integer getNbrl_param_start_position() {
        return nbrl_param_start_position;
    }

    public void setNbrl_param_start_position(Integer nbrl_param_start_position) {
        this.nbrl_param_start_position = nbrl_param_start_position;
    }

    public Integer getNbrl_param_intercept_count() {
        return nbrl_param_intercept_count;
    }

    public void setNbrl_param_intercept_count(Integer nbrl_param_intercept_count) {
        this.nbrl_param_intercept_count = nbrl_param_intercept_count;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    @Override
    public String toString() {
        return "NbrlParamVO{" +
                "id='" + id + '\'' +
                ", pid='" + pid + '\'' +
                ", classname='" + classname + '\'' +
                ", isDel=" + isdel +
                ", cretime='" + cretime + '\'' +
                ", creuser='" + creuser + '\'' +
                ", modtime='" + modtime + '\'' +
                ", moduser='" + moduser + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", nbrl_param='" + nbrl_param + '\'' +
                ", nbrl_param_type='" + nbrl_param_type + '\'' +
                ", nbrl_param_start_position=" + nbrl_param_start_position +
                ", nbrl_param_intercept_count=" + nbrl_param_intercept_count +
                '}';
    }
}
