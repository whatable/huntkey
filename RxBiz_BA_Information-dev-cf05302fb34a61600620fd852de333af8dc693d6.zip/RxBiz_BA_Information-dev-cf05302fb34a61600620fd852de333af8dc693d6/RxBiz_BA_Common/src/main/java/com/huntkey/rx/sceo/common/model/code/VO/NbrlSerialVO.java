package com.huntkey.rx.sceo.common.model.code.VO;

import java.util.Date;

public class NbrlSerialVO {
    private String id;

    private String pid;

    private String classname;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String modUserName;

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    private Integer nbrl_serial_length;

    private String nbrl_serial_reset_condition;

    private Integer nbrl_serial_step;

    private String nbrl_serial_reset_number;

    private String nbrl_serial_rule;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public Integer getNbrl_serial_length() {
        return nbrl_serial_length;
    }

    public void setNbrl_serial_length(Integer nbrl_serial_length) {
        this.nbrl_serial_length = nbrl_serial_length;
    }

    public String getNbrl_serial_reset_condition() {
        return nbrl_serial_reset_condition;
    }

    public void setNbrl_serial_reset_condition(String nbrl_serial_reset_condition) {
        this.nbrl_serial_reset_condition = nbrl_serial_reset_condition;
    }

    public Integer getNbrl_serial_step() {
        return nbrl_serial_step;
    }

    public void setNbrl_serial_step(Integer nbrl_serial_step) {
        this.nbrl_serial_step = nbrl_serial_step;
    }

    public String getNbrl_serial_reset_number() {
        return nbrl_serial_reset_number;
    }

    public void setNbrl_serial_reset_number(String nbrl_serial_reset_number) {
        this.nbrl_serial_reset_number = nbrl_serial_reset_number;
    }

    public String getNbrl_serial_rule() {
        return nbrl_serial_rule;
    }

    public void setNbrl_serial_rule(String nbrl_serial_rule) {
        this.nbrl_serial_rule = nbrl_serial_rule;
    }

    @Override
    public String toString() {
        return "NbrlSerialVO{" +
                "id='" + id + '\'' +
                ", pid='" + pid + '\'' +
                ", classname='" + classname + '\'' +
                ", isDel=" + isdel +
                ", cretime='" + cretime + '\'' +
                ", creuser='" + creuser + '\'' +
                ", modtime='" + modtime + '\'' +
                ", moduser='" + moduser + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", nbrl_serial_length=" + nbrl_serial_length +
                ", nbrl_serial_reset_condition='" + nbrl_serial_reset_condition + '\'' +
                ", nbrl_serial_step=" + nbrl_serial_step +
                ", nbrl_serial_reset_number='" + nbrl_serial_reset_number + '\'' +
                ", nbrl_serial_rule='" + nbrl_serial_rule + '\'' +
                '}';
    }
}
