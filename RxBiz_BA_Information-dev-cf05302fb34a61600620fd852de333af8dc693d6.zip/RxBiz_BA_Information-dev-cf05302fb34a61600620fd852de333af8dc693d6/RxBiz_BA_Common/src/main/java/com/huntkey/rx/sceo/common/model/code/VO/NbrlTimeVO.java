package com.huntkey.rx.sceo.common.model.code.VO;

import java.util.Date;

public class NbrlTimeVO {
    private String id;

    private String pid;

    private String classname;

    private Byte isdel;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;

    private String modUserName;

    private String nbrl_time_type;

    private Integer nbrl_time_length;

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Byte getIsdel() {
        return isdel;
    }

    public void setIsdel(Byte isdel) {
        this.isdel = isdel;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getNbrl_time_type() {
        return nbrl_time_type;
    }

    public void setNbrl_time_type(String nbrl_time_type) {
        this.nbrl_time_type = nbrl_time_type;
    }

    public Integer getNbrl_time_length() {
        return nbrl_time_length;
    }

    public void setNbrl_time_length(Integer nbrl_time_length) {
        this.nbrl_time_length = nbrl_time_length;
    }

    @Override
    public String toString() {
        return "NbrlTimeVO{" +
                "id='" + id + '\'' +
                ", pid='" + pid + '\'' +
                ", classname='" + classname + '\'' +
                ", isDel=" + isdel +
                ", cretime='" + cretime + '\'' +
                ", creuser='" + creuser + '\'' +
                ", modtime='" + modtime + '\'' +
                ", moduser='" + moduser + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", nbrl_time_type='" + nbrl_time_type + '\'' +
                ", nbrl_time_length=" + nbrl_time_length +
                '}';
    }
}
