package com.huntkey.rx.sceo.common.model.code.VO;

import com.huntkey.rx.base.PropertyAnnotation;
import com.huntkey.rx.edm.entity.NbrlNbrlCodeUsedbEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlConditionSetaEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlUseSetaEntity;
import com.huntkey.rx.edm.entity.NumberrulesEntity;
import org.hibernate.validator.constraints.NotBlank;

import java.util.List;

/**
 * @author liucs
 * @date 2017-11-24 15:53:36
 */
public class NumberRulesVO {

    private String id;

    private String nbrl_code;

    private String nbrl_name;

    private String nbrl_serial_increase;

    private String modtime;

    private String creuser;

    private String moduser;

    private List<NbrlNbrlUseSetaVO> nbrl_use_set;

    private List<NbrlNbrlConditionSetaEntity> nbrl_condition_set;

    public String getNbrl_code() {
        return nbrl_code;
    }

    public void setNbrl_code(String nbrl_code) {
        this.nbrl_code = nbrl_code;
    }

    public String getNbrl_name() {
        return nbrl_name;
    }

    public void setNbrl_name(String nbrl_name) {
        this.nbrl_name = nbrl_name;
    }

    public String getNbrl_serial_increase() {
        return nbrl_serial_increase;
    }

    public void setNbrl_serial_increase(String nbrl_serial_increase) {
        this.nbrl_serial_increase = nbrl_serial_increase;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getModtime() {
        return modtime;
    }

    public void setModtime(String modtime) {
        this.modtime = modtime;
    }

    public List<NbrlNbrlUseSetaVO> getNbrl_use_set() {
        return nbrl_use_set;
    }

    public void setNbrl_use_set(List<NbrlNbrlUseSetaVO> nbrl_use_set) {
        this.nbrl_use_set = nbrl_use_set;
    }

    public List<NbrlNbrlConditionSetaEntity> getNbrl_condition_set() {
        return nbrl_condition_set;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setNbrl_condition_set(List<NbrlNbrlConditionSetaEntity> nbrl_condition_set) {
        this.nbrl_condition_set = nbrl_condition_set;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    @Override
    public String toString() {
        return "NumberRulesVO{" +
                "id='" + id + '\'' +
                ", nbrl_code='" + nbrl_code + '\'' +
                ", nbrl_name='" + nbrl_name + '\'' +
                ", nbrl_serial_increase='" + nbrl_serial_increase + '\'' +
                ", modtime='" + modtime + '\'' +
                ", creuser='" + creuser + '\'' +
                ", moduser='" + moduser + '\'' +
                ", nbrl_use_set=" + nbrl_use_set +
                ", nbrl_condition_set=" + nbrl_condition_set +
                '}';
    }
}
