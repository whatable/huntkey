package com.huntkey.rx.sceo.common.model.code.VO;

import java.util.Date;
import java.util.List;

public class NumberVO {
    private String id;

    private String nbrl_code;

    private String nbrl_name;

    private String nbrl_serial_increase;

    private Date modtime;
    
    private Date cretime;

    private String creuser;

    private String moduser;

    private String modUserName;

    private List<NbrlNbrlUseSetaVO> nbrl_use_set;

    private List<NbrlConditionSetVO> nbrl_condition_set;

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getNbrl_code() {
        return nbrl_code;
    }

    public void setNbrl_code(String nbrl_code) {
        this.nbrl_code = nbrl_code;
    }

    public String getNbrl_name() {
        return nbrl_name;
    }

    public void setNbrl_name(String nbrl_name) {
        this.nbrl_name = nbrl_name;
    }

    public String getNbrl_serial_increase() {
        return nbrl_serial_increase;
    }

    public void setNbrl_serial_increase(String nbrl_serial_increase) {
        this.nbrl_serial_increase = nbrl_serial_increase;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public List<NbrlNbrlUseSetaVO> getNbrl_use_set() {
        return nbrl_use_set;
    }

    public List<NbrlConditionSetVO> getNbrl_condition_set() {
        return nbrl_condition_set;
    }

    public void setNbrl_condition_set(List<NbrlConditionSetVO> nbrl_condition_set) {
        this.nbrl_condition_set = nbrl_condition_set;
    }

    public void setNbrl_use_set(List<NbrlNbrlUseSetaVO> nbrl_use_set) {
        this.nbrl_use_set = nbrl_use_set;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    @Override
    public String toString() {
        return "NumberVO{" +
                "id='" + id + '\'' +
                ", nbrl_code='" + nbrl_code + '\'' +
                ", nbrl_name='" + nbrl_name + '\'' +
                ", nbrl_serial_increase='" + nbrl_serial_increase + '\'' +
                ", modtime=" + modtime +
                ", cretime=" + cretime +
                ", creuser='" + creuser + '\'' +
                ", moduser='" + moduser + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", nbrl_use_set=" + nbrl_use_set +
                ", nbrl_condition_set=" + nbrl_condition_set +
                '}';
    }
}
