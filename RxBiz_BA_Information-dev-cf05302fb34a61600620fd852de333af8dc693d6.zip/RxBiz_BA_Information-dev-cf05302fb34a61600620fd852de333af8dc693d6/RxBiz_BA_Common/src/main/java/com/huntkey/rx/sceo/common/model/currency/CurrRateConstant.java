package com.huntkey.rx.sceo.common.model.currency;

public interface CurrRateConstant {
    String CURR_CONV_CURR = "curr_conv_curr";
    String CURR_CONV_UNIT = "curr_conv_unit";
    String CURR_RATE = "curr_rate";
    String CURR_BEG = "curr_beg";
    String CURR_END = "curr_end";
    String CURR_REMARK = "curr_remark";
    String CURR_RATE_ENABLE = "curr_rate_enable";
}
