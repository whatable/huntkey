package com.huntkey.rx.sceo.common.model.currency;

/**
 * @author liucs
 * @date 2018-4-3 10:06:39
 */
public interface CurrencyConstant {
    String CURR_CODE = "curr_code";
    String CURR_NAME = "curr_name";
    String CURR_DESC = "curr_desc";
    String CURR_ENABLE = "curr_enable";
    String CURR_SYMBOL = "curr_symbol";
    String CURR_SYS_CODE = "curr_sys_code";
    String CURR_IS_STANDARD = "curr_is_standard";
}
