package com.huntkey.rx.sceo.common.model.currency.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;

import java.math.BigDecimal;
import java.util.Date;

public class CurrRateVO extends BaseEntity {
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;

    /**
     *  是否待审核, 0、待审，1、审核完成
     */
    private String isAudit;
    /**
     * 币别名称
     */
    private String currName;

    /**
     * 兑换币别名称
     */
    private String currConvName;

    /**
     * 币别id
     */
    @JSONField(name = "pid")
    private String currId;
    /**
     * 换算币别
     */
    @JSONField(name = "curr_conv_curr")
    private String currConvCurr;
    /**
     * 换算单位
     */
    @JSONField(name = "curr_conv_unit")
    private BigDecimal currConvUnit;
    /**
     * 汇率
     */
    @JSONField(name = "curr_rate")
    private BigDecimal currRate;
    /**
     * 生效日期
     */
    @JSONField(name = "curr_beg")
    private Date currBeg;
    /**
     * 失效日期
     */
    @JSONField(name = "curr_end")
    private Date currEnd;
    /**
     * 备注
     */
    @JSONField(name = "curr_remark")
    private String currRemark;
    /**
     * 启用/禁用
     */
    @JSONField(name = "curr_rate_enable")
    private String currRateEnable;

    public String getIsAudit() {
        return isAudit;
    }

    public String getCurrName() {
        return currName;
    }

    public void setCurrName(String currName) {
        this.currName = currName;
    }

    public String getCurrConvName() {
        return currConvName;
    }

    public void setCurrConvName(String currConvName) {
        this.currConvName = currConvName;
    }

    public void setIsAudit(String isAudit) {
        this.isAudit = isAudit;
    }

    public String getCurrConvCurr() {
        return currConvCurr;
    }

    public void setCurrConvCurr(String currConvCurr) {
        this.currConvCurr = currConvCurr;
    }

    public BigDecimal getCurrConvUnit() {
        return currConvUnit;
    }

    public void setCurrConvUnit(BigDecimal currConvUnit) {
        this.currConvUnit = currConvUnit;
    }

    public BigDecimal getCurrRate() {
        return currRate;
    }

    public void setCurrRate(BigDecimal currRate) {
        this.currRate = currRate;
    }

    public Date getCurrBeg() {
        return currBeg;
    }

    public void setCurrBeg(Date currBeg) {
        this.currBeg = currBeg;
    }

    public Date getCurrEnd() {
        return currEnd;
    }

    public void setCurrEnd(Date currEnd) {
        this.currEnd = currEnd;
    }

    public String getCurrRemark() {
        return currRemark;
    }

    public void setCurrRemark(String currRemark) {
        this.currRemark = currRemark;
    }

    public String getCurrRateEnable() {
        return currRateEnable;
    }

    public void setCurrRateEnable(String currRateEnable) {
        this.currRateEnable = currRateEnable;
    }

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getCurrId() {
        return currId;
    }

    public void setCurrId(String currId) {
        this.currId = currId;
    }

    @Override
    public String toString() {
        return "CurrRateVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", currId='" + currId + '\'' +
                ", currConvCurr='" + currConvCurr + '\'' +
                ", currConvUnit=" + currConvUnit +
                ", currRate=" + currRate +
                ", currBeg=" + currBeg +
                ", currEnd=" + currEnd +
                ", currRemark='" + currRemark + '\'' +
                ", currRateEnable='" + currRateEnable + '\'' +
                '}';
    }
}
