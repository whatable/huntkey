package com.huntkey.rx.sceo.common.model.currency.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;
import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;

import java.util.Date;
import java.util.List;

/**
 * @author liucs
 * @date 2018-4-3 09:56:28
 */
public class CurrencyVO extends BaseEntity{
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 图标
     */
    @JSONField(name = "curr_flag_icon")
    private String currFlagIcon;
    /**
     * 币别代码
     */
    @JSONField(name = "curr_code")
    private String currCode;
    /**
     * 币别名称
     */
    @JSONField(name = "curr_name")
    private String currName;
    /**
     * 币别描述
     */
    @JSONField(name = "curr_desc")
    private String currDesc;
    /**
     * 汇率集
     */
    @JSONField(name = "curr_rate_set")
    private List<CurrCurrRateSetaEntity> currRateSet;
    /**
     * 币别符号
     */
    @JSONField(name = "curr_symbol")
    private String currSymbol;
    /**
     * 启用禁用
     */
    @JSONField(name = "curr_enable")
    private String currEnable;

    /**
     * 是否标准
     */
    @JSONField(name = "curr_is_standard")
    private String currIsStandard;

    /**
     * 系统编码
     */
    @JSONField(name = "curr_sys_code")
    private String currSysCode;

    public String getCurrIsStandard() {
        return currIsStandard;
    }

    public void setCurrIsStandard(String currIsStandard) {
        this.currIsStandard = currIsStandard;
    }

    public String getCurrSysCode() {
        return currSysCode;
    }

    public void setCurrSysCode(String currSysCode) {
        this.currSysCode = currSysCode;
    }

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getCurrCode() {
        return currCode;
    }

    public void setCurrCode(String currCode) {
        this.currCode = currCode;
    }

    public String getCurrName() {
        return currName;
    }

    public void setCurrName(String currName) {
        this.currName = currName;
    }

    public String getCurrDesc() {
        return currDesc;
    }

    public void setCurrDesc(String currDesc) {
        this.currDesc = currDesc;
    }

    public List<CurrCurrRateSetaEntity> getCurrRateSet() {
        return currRateSet;
    }

    public void setCurrRateSet(List<CurrCurrRateSetaEntity> currRateSet) {
        this.currRateSet = currRateSet;
    }

    public String getCurrSymbol() {
        return currSymbol;
    }

    public void setCurrSymbol(String currSymbol) {
        this.currSymbol = currSymbol;
    }

    public String getCurrEnable() {
        return currEnable;
    }

    public void setCurrEnable(String currEnable) {
        this.currEnable = currEnable;
    }

    @Override
    public String toString() {
        return "CurrencyVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", currFlagIcon='" + currFlagIcon + '\'' +
                ", currCode='" + currCode + '\'' +
                ", currName='" + currName + '\'' +
                ", currDesc='" + currDesc + '\'' +
                ", currRateSet=" + currRateSet +
                ", currSymbol='" + currSymbol + '\'' +
                ", currEnable='" + currEnable + '\'' +
                ", currIsStandard='" + currIsStandard + '\'' +
                ", currSysCode='" + currSysCode + '\'' +
                '}';
    }

    public String getCurrFlagIcon() {
        return currFlagIcon;
    }

    public void setCurrFlagIcon(String currFlagIcon) {
        this.currFlagIcon = currFlagIcon;
    }

}
