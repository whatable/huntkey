package com.huntkey.rx.sceo.common.model.measureunit;

import com.huntkey.rx.edm.entity.MeasMeasDefineSetaEntity;

/**
 *
 * @author zhoucj
 * @date 2017/12/8
 */
public class MeasMeasDefineSetaInfo extends MeasMeasDefineSetaEntity {
    //制式
    private String meas_dtype_name;

    public String getMeas_dtype_name() {
        return meas_dtype_name;
    }

    public void setMeas_dtype_name(String meas_dtype_name) {
        this.meas_dtype_name = meas_dtype_name;
    }
}
