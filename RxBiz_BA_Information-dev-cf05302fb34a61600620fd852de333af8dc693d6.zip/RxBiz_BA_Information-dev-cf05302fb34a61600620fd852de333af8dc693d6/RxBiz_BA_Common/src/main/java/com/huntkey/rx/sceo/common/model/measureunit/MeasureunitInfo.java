package com.huntkey.rx.sceo.common.model.measureunit;

import com.huntkey.rx.edm.entity.MeasureunitEntity;

/**
 *
 * @author zhoucj
 * @date 2017/12/6
 */
public class MeasureunitInfo extends MeasureunitEntity {
    //基准计量单位符号
    private String symbol;
    //计量单位组
    private String group;

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }
}
