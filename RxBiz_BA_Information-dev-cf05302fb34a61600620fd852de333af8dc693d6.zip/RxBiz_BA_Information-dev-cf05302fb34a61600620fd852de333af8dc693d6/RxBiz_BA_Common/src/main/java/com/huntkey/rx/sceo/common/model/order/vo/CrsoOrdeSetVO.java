package com.huntkey.rx.sceo.common.model.order.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 汇率维护属性集
 * @author liucs
 * @date 2018-6-12 11:33:55
 */
public class CrsoOrdeSetVO extends BaseEntity{
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 兑换币别名称
     */
    private String crsoConvName;
    /**
     * 币别名称
     */
    private String crsoName;

    /**
     * 单据操作状态： 0、拒绝，1、通过
     */
    @JSONField(name="crso_oper_status")
    private String crsoStatus;
    /**
     * 是否标准
     */
    @JSONField(name = "crsoo_is_standard")
    private int crsooIsStandard;
    /**
     * 换算币别
     */
    @JSONField(name = "crsoo_conv_curr")
    private String crsoConvCurr;
    /**
     * 换算单位
     */
    @JSONField(name = "crsoo_conv_unit")
    private BigDecimal crsoConvUnit;
    /**
     * 汇率
     */
    @JSONField(name = "crsoo_rate")
    private BigDecimal crsoRate;
    /**
     * 生效日期
     */
    @JSONField(name = "crsoo_beg")
    private Date crsoBeg;
    /**
     * 失效日期
     */
    @JSONField(name = "crsoo_end")
    private Date crsoEnd;
    /**
     * 备注
     */
    @JSONField(name = "crsoo_remark")
    private String crsoRemark;
    /**
     * 启用/禁用
     */
    @JSONField(name = "crsoo_rate_enable")
    private String crsoRateEnable;
    /**
     * 币别
     */
    @JSONField(name = "crsoo_curr_id")
    private String crsoCurrId;

    public String getCrsoStatus() {
        return crsoStatus;
    }

    public void setCrsoStatus(String crsoStatus) {
        this.crsoStatus = crsoStatus;
    }

    public String getCrsoConvName() {
        return crsoConvName;
    }

    public void setCrsoConvName(String crsoConvName) {
        this.crsoConvName = crsoConvName;
    }

    public String getCrsoName() {
        return crsoName;
    }

    public void setCrsoName(String crsoName) {
        this.crsoName = crsoName;
    }

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public int getCrsooIsStandard() {
        return crsooIsStandard;
    }

    public void setCrsooIsStandard(int crsooIsStandard) {
        this.crsooIsStandard = crsooIsStandard;
    }

    public String getCrsoConvCurr() {
        return crsoConvCurr;
    }

    public void setCrsoConvCurr(String crsoConvCurr) {
        this.crsoConvCurr = crsoConvCurr;
    }

    public BigDecimal getCrsoConvUnit() {
        return crsoConvUnit;
    }

    public void setCrsoConvUnit(BigDecimal crsoConvUnit) {
        this.crsoConvUnit = crsoConvUnit;
    }

    public BigDecimal getCrsoRate() {
        return crsoRate;
    }

    public void setCrsoRate(BigDecimal crsoRate) {
        this.crsoRate = crsoRate;
    }

    public Date getCrsoBeg() {
        return crsoBeg;
    }

    public void setCrsoBeg(Date crsoBeg) {
        this.crsoBeg = crsoBeg;
    }

    public Date getCrsoEnd() {
        return crsoEnd;
    }

    public void setCrsoEnd(Date crsoEnd) {
        this.crsoEnd = crsoEnd;
    }

    public String getCrsoRemark() {
        return crsoRemark;
    }

    public void setCrsoRemark(String crsoRemark) {
        this.crsoRemark = crsoRemark;
    }

    public String getCrsoRateEnable() {
        return crsoRateEnable;
    }

    public void setCrsoRateEnable(String crsoRateEnable) {
        this.crsoRateEnable = crsoRateEnable;
    }

    public String getCrsoCurrId() {
        return crsoCurrId;
    }

    public void setCrsoCurrId(String crsoCurrId) {
        this.crsoCurrId = crsoCurrId;
    }

    @Override
    public String toString() {
        return "CrsoOrdeSetVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", crsooIsStandard=" + crsooIsStandard +
                ", crsoConvCurr='" + crsoConvCurr + '\'' +
                ", crsoConvUnit=" + crsoConvUnit +
                ", crsoRate=" + crsoRate +
                ", crsoBeg=" + crsoBeg +
                ", crsoEnd=" + crsoEnd +
                ", crsoRemark='" + crsoRemark + '\'' +
                ", crsoRateEnable='" + crsoRateEnable + '\'' +
                ", crsoCurrId='" + crsoCurrId + '\'' +
                '}';
    }
}
