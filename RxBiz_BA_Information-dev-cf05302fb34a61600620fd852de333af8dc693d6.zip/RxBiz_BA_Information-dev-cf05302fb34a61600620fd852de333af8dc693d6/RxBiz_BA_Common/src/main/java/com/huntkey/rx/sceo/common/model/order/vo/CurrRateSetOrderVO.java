package com.huntkey.rx.sceo.common.model.order.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;
import com.huntkey.rx.edm.constant.OrderProperty;
import com.huntkey.rx.edm.entity.OrderEntity;
import org.hibernate.validator.constraints.NotBlank;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class CurrRateSetOrderVO extends BaseEntity {
    /**
     * 操作類型 0,新增、1,修改、2,删除
     */
    @JSONField(name = "crso_orde_type")
    private String operaOrderType;
    /**
     * 新增汇率集合
     */
    private List<CrsoOrdeSetVO> crsoOrdeSetVOS;
    /**
     * 製單人部門
     */
    @JSONField(name = "orde_dept")
    private String ordeDept;

    /**
     * 制单人部门名称
     */
    private String ordeDeptName;
    /**
     * 製單人崗位
     */
    @JSONField(name = "orde_duty")
    private String ordeDuty;
    /**
     * 制单人岗位名称
     */
    private String ordeDutyName;
    /**
     * 制單人
     */
    @JSONField(name = "orde_adduser")
    private String ordeAdduser;
    /**
     * 制单人姓名
     */
    private String ordeAdduserName;
    /**
     * 申請人
     */
    @JSONField(name = "orde_applicant")
    private String ordeApplicant;
    /**
     * 申請人崗位
     */
    @JSONField(name = "orde_applicant_post")
    private String ordeApplicantPost;
    /**
     * 制單時間
     */
    @JSONField(name = "Orde_date")
    private String ordeDate;
    /**
     * 單據狀態
     */
    @JSONField(name = "orde_status")
    private String ordeStatus;
    /**
     * 單據單號
     */
    @JSONField(name = "orde_nbr")
    private String ordeNbr;

    /**
     * 单据定义类
     */
    @JSONField(name = OrderProperty.ORDE_RODE_OBJ)
    private String ordeRodeObj;
    /**
     * 更新员工
     */
    @JSONField(name = OrderProperty.ORDE_EMP)
    private String ordeEmp;

    public String getOrdeEmp() {
        return ordeEmp;
    }

    public void setOrdeEmp(String ordeEmp) {
        this.ordeEmp = ordeEmp;
    }

    public String getOrdeDept() {
        return ordeDept;
    }

    public void setOrdeDept(String ordeDept) {
        this.ordeDept = ordeDept;
    }

    public String getOrdeDuty() {
        return ordeDuty;
    }

    public void setOrdeDuty(String ordeDuty) {
        this.ordeDuty = ordeDuty;
    }

    public String getOrdeAdduser() {
        return ordeAdduser;
    }

    public void setOrdeAdduser(String ordeAdduser) {
        this.ordeAdduser = ordeAdduser;
    }

    public String getOrdeApplicant() {
        return ordeApplicant;
    }

    public void setOrdeApplicant(String ordeApplicant) {
        this.ordeApplicant = ordeApplicant;
    }

    public String getOrdeApplicantPost() {
        return ordeApplicantPost;
    }

    public void setOrdeApplicantPost(String ordeApplicantPost) {
        this.ordeApplicantPost = ordeApplicantPost;
    }

    public String getOrdeDate() {
        return ordeDate;
    }

    public void setOrdeDate(String ordeDate) {
        this.ordeDate = ordeDate;
    }

    public String getOrdeStatus() {
        return ordeStatus;
    }

    public void setOrdeStatus(String ordeStatus) {
        this.ordeStatus = ordeStatus;
    }

    public String getOrdeNbr() {
        return ordeNbr;
    }

    public void setOrdeNbr(String ordeNbr) {
        this.ordeNbr = ordeNbr;
    }

    public String getOperaOrderType() {
        return operaOrderType;
    }

    public void setOperaOrderType(String operaOrderType) {
        this.operaOrderType = operaOrderType;
    }

    public String getOrdeRodeObj() {
        return ordeRodeObj;
    }

    public void setOrdeRodeObj(String ordeRodeObj) {
        this.ordeRodeObj = ordeRodeObj;
    }

    public List<CrsoOrdeSetVO> getCrsoOrdeSetVOS() {
        return crsoOrdeSetVOS;
    }

    public void setCrsoOrdeSetVOS(List<CrsoOrdeSetVO> crsoOrdeSetVOS) {
        this.crsoOrdeSetVOS = crsoOrdeSetVOS;
    }

    public String getOrdeDeptName() {
        return ordeDeptName;
    }

    public void setOrdeDeptName(String ordeDeptName) {
        this.ordeDeptName = ordeDeptName;
    }

    public String getOrdeDutyName() {
        return ordeDutyName;
    }

    public void setOrdeDutyName(String ordeDutyName) {
        this.ordeDutyName = ordeDutyName;
    }

    public String getOrdeAdduserName() {
        return ordeAdduserName;
    }

    public void setOrdeAdduserName(String ordeAdduserName) {
        this.ordeAdduserName = ordeAdduserName;
    }

    @Override
    public String toString() {
        return "CurrRateSetOrderVO{" +
                "operaOrderType='" + operaOrderType + '\'' +
                ", crsoOrdeSetVOS=" + crsoOrdeSetVOS +
                ", ordeDept='" + ordeDept + '\'' +
                ", ordeDuty='" + ordeDuty + '\'' +
                ", ordeAdduser='" + ordeAdduser + '\'' +
                ", ordeApplicant='" + ordeApplicant + '\'' +
                ", ordeApplicantPost='" + ordeApplicantPost + '\'' +
                ", ordeDate='" + ordeDate + '\'' +
                ", ordeStatus='" + ordeStatus + '\'' +
                ", ordeNbr='" + ordeNbr + '\'' +
                ", ordeRodeObj='" + ordeRodeObj + '\'' +
                ", ordeEmp='" + ordeEmp + '\'' +
                '}';
    }
}
