package com.huntkey.rx.sceo.common.model.order.vo.parameter;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;

public class ParoFormSetOrdeVO extends BaseEntity {
    /**
     * 表单页面编号
     */
    @JSONField(name = "paroof_from_code")
    private String paroFromCode;
    /**
     * 表单页面名称
     */
    @JSONField(name = "paroof_from_name")
    private String paroFromName;

    public String getParoFromCode() {
        return paroFromCode;
    }

    public void setParoFromCode(String paroFromCode) {
        this.paroFromCode = paroFromCode;
    }

    public String getParoFromName() {
        return paroFromName;
    }

    public void setParoFromName(String paroFromName) {
        this.paroFromName = paroFromName;
    }

    @Override
    public String toString() {
        return "ParoFormSetOrdeVO{" +
                "paroFromCode='" + paroFromCode + '\'' +
                ", paroFromName='" + paroFromName + '\'' +
                '}';
    }
}
