package com.huntkey.rx.sceo.common.model.order.vo.parameter;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;

import java.util.List;

public class ParoOrdeVO extends BaseEntity {
    /**
     * 待审核
     */
    private String isAudit;
    /**
     * 修改前的参数值
     */
    @JSONField(name = "paroo_values_old")
    private String old_parm_values;

    @JSONField(name = "paroo_oper_status")
    private String parm_oper_status;

    /**
     * 参数表单页面集
     */
    private List<ParoFormSetOrdeVO> paroFormVOS;
    /**
     * 参数值集
     */
    private List<ParoValueSetOrdeVO> parm_value_set;

    /**
     * 是否标准数据
     * 1、标准；0、非标准
     */
    private Integer parm_is_standard;
    /**
     * 参数编号
     */
    @JSONField(name = "paroo_no")
    private String parm_no;
    /**
     * 参数名称
     */
    @JSONField(name = "paroo_name")
    private String parm_name;

    /**
     * 参数值
     */
    @JSONField(name = "paroo_values")
    private String parm_values;

    /**
     * 参数描述
     */
    @JSONField(name = "paroo_desc")
    private String parm_desc;

    /**
     * 参数排序
     */
    @JSONField(name = "paroo_seq")
    private String parm_seq;

    /**
     * 是否可见
     */
    @JSONField(name = "paroo_is_visible")
    private Integer parm_is_visible;

    /**
     * 是否可改
     */
    @JSONField(name = "paroo_is_modify")
    private Integer parm_is_modify;

    /**
     * 控件类型
     */
    @JSONField(name = "paroo_control_type")
    private Integer parm_control_type;

    /**
     * 控件值
     */
    @JSONField(name = "paroo_control_value")
    private String parm_control_value;

    /**
     * 参数类别
     */
    @JSONField(name = "paroo_type")
    private String parm_type;

    /**
     * 启用、禁用
     * 1、启用；0、禁用
     */
    @JSONField(name = "paroo_enable")
    private Integer parm_enable;

    public List<ParoFormSetOrdeVO> getParoFormVOS() {
        return paroFormVOS;
    }

    public void setParoFormVOS(List<ParoFormSetOrdeVO> paroFormVOS) {
        this.paroFormVOS = paroFormVOS;
    }

    public List<ParoValueSetOrdeVO> getParm_value_set() {
        return parm_value_set;
    }

    public void setParm_value_set(List<ParoValueSetOrdeVO> parm_value_set) {
        this.parm_value_set = parm_value_set;
    }

    public String getOld_parm_values() {
        return old_parm_values;
    }

    public void setOld_parm_values(String old_parm_values) {
        this.old_parm_values = old_parm_values;
    }

    public Integer getParm_is_standard() {
        return parm_is_standard;
    }

    public void setParm_is_standard(Integer parm_is_standard) {
        this.parm_is_standard = parm_is_standard;
    }

    public String getParm_no() {
        return parm_no;
    }

    public void setParm_no(String parm_no) {
        this.parm_no = parm_no;
    }

    public String getParm_name() {
        return parm_name;
    }

    public void setParm_name(String parm_name) {
        this.parm_name = parm_name;
    }

    public String getParm_values() {
        return parm_values;
    }

    public void setParm_values(String parm_values) {
        this.parm_values = parm_values;
    }

    public String getParm_desc() {
        return parm_desc;
    }

    public void setParm_desc(String parm_desc) {
        this.parm_desc = parm_desc;
    }

    public String getParm_seq() {
        return parm_seq;
    }

    public void setParm_seq(String parm_seq) {
        this.parm_seq = parm_seq;
    }

    public Integer getParm_is_visible() {
        return parm_is_visible;
    }

    public void setParm_is_visible(Integer parm_is_visible) {
        this.parm_is_visible = parm_is_visible;
    }

    public Integer getParm_is_modify() {
        return parm_is_modify;
    }

    public void setParm_is_modify(Integer parm_is_modify) {
        this.parm_is_modify = parm_is_modify;
    }

    public Integer getParm_control_type() {
        return parm_control_type;
    }

    public void setParm_control_type(Integer parm_control_type) {
        this.parm_control_type = parm_control_type;
    }

    public String getParm_control_value() {
        return parm_control_value;
    }

    public void setParm_control_value(String parm_control_value) {
        this.parm_control_value = parm_control_value;
    }

    public String getParm_type() {
        return parm_type;
    }

    public void setParm_type(String parm_type) {
        this.parm_type = parm_type;
    }

    public Integer getParm_enable() {
        return parm_enable;
    }

    public void setParm_enable(Integer parm_enable) {
        this.parm_enable = parm_enable;
    }

    public String getParm_oper_status() {
        return parm_oper_status;
    }

    public void setParm_oper_status(String parm_oper_status) {
        this.parm_oper_status = parm_oper_status;
    }

    public String getIsAudit() {
        return isAudit;
    }

    public void setIsAudit(String isAudit) {
        this.isAudit = isAudit;
    }

    @Override
    public String toString() {
        return "ParoOrdeVO{" +
                "old_parm_values='" + old_parm_values + '\'' +
                ", paroFormVOS=" + paroFormVOS +
                ", parm_is_standard=" + parm_is_standard +
                ", parm_no='" + parm_no + '\'' +
                ", parm_name='" + parm_name + '\'' +
                ", parm_values='" + parm_values + '\'' +
                ", parm_desc='" + parm_desc + '\'' +
                ", parm_seq='" + parm_seq + '\'' +
                ", parm_is_visible=" + parm_is_visible +
                ", parm_is_modify=" + parm_is_modify +
                ", parm_control_type=" + parm_control_type +
                ", parm_control_value='" + parm_control_value + '\'' +
                ", parm_type='" + parm_type + '\'' +
                ", parm_enable=" + parm_enable +
                '}';
    }
}
