package com.huntkey.rx.sceo.common.model.order.vo.parameter;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.huntkey.rx.base.BaseEntity;

public class ParoValueSetOrdeVO extends BaseEntity {
    /**
     * 参数一值
     */
    @JSONField(name = "paroov_one")
    private String parm_one;
    /**
     * 参数二值
     */
    @JSONField(name = "paroov_two")
    private String parm_two;
    /**
     * 参数三值
     */
    @JSONField(name = "paroov_three")
    private String parm_three;
    /**
     * 参数四 值
     */
    @JSONField(name = "paroov_four")
    private String parm_four;
    /**
     * 参数五值
     */
    @JSONField(name = "paroov_five")
    private String parm_five;
    /**
     * 排序值
     */
    @JSONField(name = "paroov_value_seq")
    private Integer parm_value_seq;
    /**
     * 参数一显示值
     */
    @JSONField(name = "paroov_one_view")
    private String parm_one_view;
    /**
     * 参数二显示值
     */
    @JSONField(name = "paroov_two_view")
    private String parm_two_view;
    /**
     * 参数三显示值
     */
    @JSONField(name = "paroov_three_view")
    private String parm_three_view;
    /**
     * 参数四显示值
     */
    @JSONField(name = "paroov_four_view")
    private String parm_four_view;
    /**
     * 参数五显示值
     */
    @JSONField(name = "paroov_five_view")
    private String parm_five_view;

    public String getParm_one() {
        return parm_one;
    }

    public void setParm_one(String parm_one) {
        this.parm_one = parm_one;
    }

    public String getParm_two() {
        return parm_two;
    }

    public void setParm_two(String parm_two) {
        this.parm_two = parm_two;
    }

    public String getParm_three() {
        return parm_three;
    }

    public void setParm_three(String parm_three) {
        this.parm_three = parm_three;
    }

    public String getParm_four() {
        return parm_four;
    }

    public void setParm_four(String parm_four) {
        this.parm_four = parm_four;
    }

    public String getParm_five() {
        return parm_five;
    }

    public void setParm_five(String parm_five) {
        this.parm_five = parm_five;
    }

    public Integer getParm_value_seq() {
        return parm_value_seq;
    }

    public void setParm_value_seq(Integer parm_value_seq) {
        this.parm_value_seq = parm_value_seq;
    }

    public String getParm_one_view() {
        return parm_one_view;
    }

    public void setParm_one_view(String parm_one_view) {
        this.parm_one_view = parm_one_view;
    }

    public String getParm_two_view() {
        return parm_two_view;
    }

    public void setParm_two_view(String parm_two_view) {
        this.parm_two_view = parm_two_view;
    }

    public String getParm_three_view() {
        return parm_three_view;
    }

    public void setParm_three_view(String parm_three_view) {
        this.parm_three_view = parm_three_view;
    }

    public String getParm_four_view() {
        return parm_four_view;
    }

    public void setParm_four_view(String parm_four_view) {
        this.parm_four_view = parm_four_view;
    }

    public String getParm_five_view() {
        return parm_five_view;
    }

    public void setParm_five_view(String parm_five_view) {
        this.parm_five_view = parm_five_view;
    }
}
