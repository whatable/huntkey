package com.huntkey.rx.sceo.common.model.paramter;

import javafx.beans.DefaultProperty;

public class ParamterDto {
    private String parm_type;
    private String parm_no;
    private String parm_name;
    private String parm_form_name;
    private Integer pageNum;
    private Integer pageSize;

    @Override
    public String toString() {
        return "ParamterDto{" +
                "parm_type='" + parm_type + '\'' +
                ", parm_no='" + parm_no + '\'' +
                ", parm_name='" + parm_name + '\'' +
                ", parm_form_name='" + parm_form_name + '\'' +
                ", pageNum=" + pageNum +
                ", pageSize=" + pageSize +
                '}';
    }

    public String getParm_type() {
        return parm_type;
    }

    public void setParm_type(String parm_type) {
        this.parm_type = parm_type;
    }

    public String getParm_no() {
        return parm_no;
    }

    public void setParm_no(String parm_no) {
        this.parm_no = parm_no;
    }

    public String getParm_name() {
        return parm_name;
    }

    public void setParm_name(String parm_name) {
        this.parm_name = parm_name;
    }

    public String getParm_form_name() {
        return parm_form_name;
    }

    public void setParm_form_name(String parm_form_name) {
        this.parm_form_name = parm_form_name;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }
}
