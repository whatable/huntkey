package com.huntkey.rx.sceo.common.model.paramter.VO;

import com.huntkey.rx.edm.entity.ParmParmFormSetaEntity;
import com.huntkey.rx.edm.entity.ParmParmValueSetaEntity;

import java.util.Date;
import java.util.List;

/**
 * @author liucs
 * @date 2018-1-8 13:59:06
 */
public class ParameterVO {
    private String id;

    private String classname;

    private Date cretime;

    private String creuser;

    private Date modtime;

    private String moduser;
    /**
     * 参数使用页面
     */
    private String usePageName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 参数值
     */
    private String parm_values;
    /**
     * 拼接参数值
     */
    private String parm_values_string;

    private String parm_type;

    private String parm_desc;

    private String parm_is_visible;

    private List<ParmParmFormSetaEntity> parm_form_set;

    private Integer parm_seq;

    private String parm_control_value;

    private String parm_name;

    private String parm_is_modify;

    private String parm_no;

    private List<ParmParmValueSetaEntity> parm_value_set;

    private String parm_control_type;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public Date getCretime() {
        return cretime;
    }

    public void setCretime(Date cretime) {
        this.cretime = cretime;
    }

    public String getCreuser() {
        return creuser;
    }

    public void setCreuser(String creuser) {
        this.creuser = creuser;
    }

    public Date getModtime() {
        return modtime;
    }

    public void setModtime(Date modtime) {
        this.modtime = modtime;
    }

    public String getModuser() {
        return moduser;
    }

    public void setModuser(String moduser) {
        this.moduser = moduser;
    }

    public String getUsePageName() {
        return usePageName;
    }

    public void setUsePageName(String usePageName) {
        this.usePageName = usePageName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getParm_values() {
        return parm_values;
    }

    public void setParm_values(String parm_values) {
        this.parm_values = parm_values;
    }

    public String getParm_values_string() {
        return parm_values_string;
    }

    public void setParm_values_string(String parm_values_string) {
        this.parm_values_string = parm_values_string;
    }

    public String getParm_type() {
        return parm_type;
    }

    public void setParm_type(String parm_type) {
        this.parm_type = parm_type;
    }

    public String getParm_desc() {
        return parm_desc;
    }

    public void setParm_desc(String parm_desc) {
        this.parm_desc = parm_desc;
    }

    public String getParm_is_visible() {
        return parm_is_visible;
    }

    public void setParm_is_visible(String parm_is_visible) {
        this.parm_is_visible = parm_is_visible;
    }

    public List<ParmParmFormSetaEntity> getParm_form_set() {
        return parm_form_set;
    }

    public void setParm_form_set(List<ParmParmFormSetaEntity> parm_form_set) {
        this.parm_form_set = parm_form_set;
    }

    public Integer getParm_seq() {
        return parm_seq;
    }

    public void setParm_seq(Integer parm_seq) {
        this.parm_seq = parm_seq;
    }

    public String getParm_control_value() {
        return parm_control_value;
    }

    public void setParm_control_value(String parm_control_value) {
        this.parm_control_value = parm_control_value;
    }

    public String getParm_name() {
        return parm_name;
    }

    public void setParm_name(String parm_name) {
        this.parm_name = parm_name;
    }

    public String getParm_is_modify() {
        return parm_is_modify;
    }

    public void setParm_is_modify(String parm_is_modify) {
        this.parm_is_modify = parm_is_modify;
    }

    public String getParm_no() {
        return parm_no;
    }

    public void setParm_no(String parm_no) {
        this.parm_no = parm_no;
    }

    public List<ParmParmValueSetaEntity> getParm_value_set() {
        return parm_value_set;
    }

    public void setParm_value_set(List<ParmParmValueSetaEntity> parm_value_set) {
        this.parm_value_set = parm_value_set;
    }

    public String getParm_control_type() {
        return parm_control_type;
    }

    public void setParm_control_type(String parm_control_type) {
        this.parm_control_type = parm_control_type;
    }

    @Override
    public String toString() {
        return "ParameterVO{" +
                "id='" + id + '\'' +
                ", classname='" + classname + '\'' +
                ", cretime=" + cretime +
                ", creuser='" + creuser + '\'' +
                ", modtime=" + modtime +
                ", moduser='" + moduser + '\'' +
                ", usePageName='" + usePageName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", parm_values='" + parm_values + '\'' +
                ", parm_values_string='" + parm_values_string + '\'' +
                ", parm_type='" + parm_type + '\'' +
                ", parm_desc='" + parm_desc + '\'' +
                ", parm_is_visible='" + parm_is_visible + '\'' +
                ", parm_form_set=" + parm_form_set +
                ", parm_seq=" + parm_seq +
                ", parm_control_value='" + parm_control_value + '\'' +
                ", parm_name='" + parm_name + '\'' +
                ", parm_is_modify='" + parm_is_modify + '\'' +
                ", parm_no='" + parm_no + '\'' +
                ", parm_value_set=" + parm_value_set +
                ", parm_control_type='" + parm_control_type + '\'' +
                '}';
    }
}

