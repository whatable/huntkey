package com.huntkey.rx.sceo.common.model.paramter.VO;

import java.util.List;

/**
 * @author zoulj
 * @create 2018/2/5 10:26
 **/
public class TreeVO {

    private String id;

    private String pid;

    private String text;

    private String values;

    private List<TreeVO> children;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getValues() {
        return values;
    }

    public void setValues(String values) {
        this.values = values;
    }

    public List<TreeVO> getChildren() {
        return children;
    }

    public void setChildren(List<TreeVO> children) {
        this.children = children;
    }
}
