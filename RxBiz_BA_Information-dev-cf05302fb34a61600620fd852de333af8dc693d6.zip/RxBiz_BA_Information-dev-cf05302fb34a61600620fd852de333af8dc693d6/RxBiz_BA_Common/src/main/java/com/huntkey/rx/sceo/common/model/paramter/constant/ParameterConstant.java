package com.huntkey.rx.sceo.common.model.paramter.constant;

/**
 * @author liucs
 * @date 2018-1-8 10:43:59
 */
public interface ParameterConstant {
    String PARAM_NO = "parm_no" ;
    String PARAM_NAME = "parm_name" ;
    String PARAM_VALUES = "parm_values" ;
    String PARAM_DESC = "parm_desc" ;
    String PARAM_SEQ = "parm_seq" ;
    String PARAM_IS_VISIBLE = "parm_is_visible" ;
    String PARAM_IS_MODIFY = "parm_is_modify" ;
    String PARAM_CONTROL_TYPE = "parm_control_type" ;
    String PARAM_CONTROL_VALUE = "parm_control_value" ;
    String PARAM_TYPE = "parm_type" ;
}
