package com.huntkey.rx.sceo.common.model.paramter.constant;

/**
 * @author liucs
 * @date 2018-1-8 15:32:09
 */
public interface ParmFormConstant {
    String PARM_FORM_NAME= "parm_form_name";
    String PARM_FORM_CODE = "parm_form_code";
    String CLASSNAME = "classname";
    String PID = "pid";
}
