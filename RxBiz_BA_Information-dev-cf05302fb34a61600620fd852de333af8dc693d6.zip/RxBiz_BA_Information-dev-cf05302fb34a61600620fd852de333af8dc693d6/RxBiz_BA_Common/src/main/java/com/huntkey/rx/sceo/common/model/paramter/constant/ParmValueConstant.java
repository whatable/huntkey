package com.huntkey.rx.sceo.common.model.paramter.constant;

/**
 * @author liucs
 * @date 2018-1-9 11:46:33
 */
public interface ParmValueConstant {
    String PARM_VALUE_SEQ = "parm_value_seq";
    String PARM_ONE = "parm_one";
    String PARM_TWO = "parm_two";
    String PARM_THREE = "parm_three";
    String PARM_FOUR = "parm_four";
    String PARM_FIVE = "parm_five";
    String CLASSNAME = "classname";
    String PARM_ONE_VIEW = "parm_one_view";
    String PARM_TWO_VIEW = "parm_two_view";
    String PARM_THREE_VIEW = "parm_three_view";
    String PARM_FOUR_VIEW = "parm_four_view";
    String PARM_FIVE_VIEW = "parm_five_view";
}
