package com.huntkey.rx.sceo.common.model.park;

public interface ParkConstant {
    String RPAK_CODE = "rpak_code";
    String RPAK_NAME = "rpak_name";
    String RPAK_ADDR  = "rpak_addr";
    String RPAK_ISDEFAULT = "rpak_isdefault";
//    String "rpak_addr_set";
    String RPAK_SEQ = "rpak_seq";
    String RPAK_ADDR_PROV = "rpak_addr_prov";
    String RPAK_ADDR_CITY = "rpak_addr_city";
    String RPAK_ADDR_DIST = "rpak_addr_dist";
    String RPAK_ENABLE = "rpak_enable";
    String RPAK_IS_STANDARD = "rpak_is_standard";

    /**
     * 默认园区值
     */
    Integer IS_DEFAULT_PARK = 1;
    Integer NOT_DEFAULT_PARK = 0;
}
