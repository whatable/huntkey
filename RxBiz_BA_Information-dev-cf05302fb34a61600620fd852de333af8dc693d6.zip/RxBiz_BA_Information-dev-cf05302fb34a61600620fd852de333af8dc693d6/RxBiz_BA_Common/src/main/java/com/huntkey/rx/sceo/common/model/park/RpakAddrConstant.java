package com.huntkey.rx.sceo.common.model.park;

/**
 * @author LIUCS
 * @date 2018-4-2 16:24:39
 */
public interface RpakAddrConstant {
    String RPAK_ADDRP = "rpak_addrp";
    String RPAK_ADDRC = "rpak_addrc";
    String RPAK_ADDRL = "rpak_addrl";
    String RPAK_DADDR = "rpak_daddr";
    String RPAK_CONTACT = "rpak_contact";
    String RPAK_CWAY = "rpak_cway";
    String REAK_ADDR_ENABLE = "reak_addr_enable";
}
