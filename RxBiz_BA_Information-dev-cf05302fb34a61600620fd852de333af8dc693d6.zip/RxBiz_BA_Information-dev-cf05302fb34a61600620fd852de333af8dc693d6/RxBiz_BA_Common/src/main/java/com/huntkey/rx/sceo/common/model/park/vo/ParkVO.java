package com.huntkey.rx.sceo.common.model.park.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;

import java.util.Date;
import java.util.List;

public class ParkVO extends BaseEntity{
    /**
     * 交货地址数量
     */
    private Integer deliveryAddrCount ;
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 园区代码
     */
    @JSONField(name = "rpak_code")
    private String rpakCode;
    /**
     * 园区名称
     */
    @JSONField(name = "rpak_name")
    private String rpakName;
    /**
     * 园区地址
     */
    @JSONField(name = "rpak_addr")
    private String rpakAddr;
    /**
     * 是否是默认园区
     */
    @JSONField(name = "rpak_isdefault")
    private Integer rpakIsdefault;
    /**
     * 交货地址集
     */
    @JSONField(name = "rpak_addr_set")
    private List<RpakRpakAddrSetaEntity> rpakAddrSet;
    /**
     * 园区排序
     */
    @JSONField(name = "rpak_seq")
    private Integer rpakSeq;
    /**
     * 园区地址——省
     */
    @JSONField(name = "rpak_addr_prov")
    private String rpakAddrProv;
    private String rpakAddrProvName;
    /**
     * 园区地址——市
     */
    @JSONField(name = "rpak_addr_city")
    private String rpakAddrCity;
    private String rpakAddrCityName;
    /**
     * 园区地址——区县
     */
    @JSONField(name = "rpak_addr_dist")
    private String rpakAddrDist;
    private String rpakAddrDistName;
    /**
     * 启用/禁用
     */
    @JSONField(name = "rpak_enable")
    private String rpakEnable;

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getRpakCode() {
        return rpakCode;
    }

    public void setRpakCode(String rpakCode) {
        this.rpakCode = rpakCode;
    }

    public String getRpakName() {
        return rpakName;
    }

    public void setRpakName(String rpakName) {
        this.rpakName = rpakName;
    }

    public String getRpakAddr() {
        return rpakAddr;
    }

    public void setRpakAddr(String rpakAddr) {
        this.rpakAddr = rpakAddr;
    }

    public Integer getRpakIsdefault() {
        return rpakIsdefault;
    }

    public void setRpakIsdefault(Integer rpakIsdefault) {
        this.rpakIsdefault = rpakIsdefault;
    }

    public List<RpakRpakAddrSetaEntity> getRpakAddrSet() {
        return rpakAddrSet;
    }

    public void setRpakAddrSet(List<RpakRpakAddrSetaEntity> rpakAddrSet) {
        this.rpakAddrSet = rpakAddrSet;
    }

    public Integer getRpakSeq() {
        return rpakSeq;
    }

    public void setRpakSeq(Integer rpakSeq) {
        this.rpakSeq = rpakSeq;
    }

    public String getRpakAddrProv() {
        return rpakAddrProv;
    }

    public void setRpakAddrProv(String rpakAddrProv) {
        this.rpakAddrProv = rpakAddrProv;
    }

    public String getRpakAddrCity() {
        return rpakAddrCity;
    }

    public void setRpakAddrCity(String rpakAddrCity) {
        this.rpakAddrCity = rpakAddrCity;
    }

    public String getRpakAddrDist() {
        return rpakAddrDist;
    }

    public void setRpakAddrDist(String rpakAddrDist) {
        this.rpakAddrDist = rpakAddrDist;
    }

    public String getRpakEnable() {
        return rpakEnable;
    }

    public void setRpakEnable(String rpakEnable) {
        this.rpakEnable = rpakEnable;
    }

    public Integer getDeliveryAddrCount() {
        return deliveryAddrCount;
    }

    public void setDeliveryAddrCount(Integer deliveryAddrCount) {
        this.deliveryAddrCount = deliveryAddrCount;
    }

    public String getRpakAddrProvName() {
        return rpakAddrProvName;
    }

    public void setRpakAddrProvName(String rpakAddrProvName) {
        this.rpakAddrProvName = rpakAddrProvName;
    }

    public String getRpakAddrCityName() {
        return rpakAddrCityName;
    }

    public void setRpakAddrCityName(String rpakAddrCityName) {
        this.rpakAddrCityName = rpakAddrCityName;
    }

    public String getRpakAddrDistName() {
        return rpakAddrDistName;
    }

    public void setRpakAddrDistName(String rpakAddrDistName) {
        this.rpakAddrDistName = rpakAddrDistName;
    }

    @Override
    public String toString() {
        return "ParkVO{" +
                "deliveryAddrCount=" + deliveryAddrCount +
                ", creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", rpakCode='" + rpakCode + '\'' +
                ", rpakName='" + rpakName + '\'' +
                ", rpakAddr='" + rpakAddr + '\'' +
                ", rpakIsdefault=" + rpakIsdefault +
                ", rpakAddrSet=" + rpakAddrSet +
                ", rpakSeq=" + rpakSeq +
                ", rpakAddrProv='" + rpakAddrProv + '\'' +
                ", rpakAddrCity='" + rpakAddrCity + '\'' +
                ", rpakAddrDist='" + rpakAddrDist + '\'' +
                ", rpakEnable='" + rpakEnable + '\'' +
                '}';
    }
}
