package com.huntkey.rx.sceo.common.model.park.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.PropertyBaseEntity;

public class RpakAddrVO extends PropertyBaseEntity {
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 交货省
     */
    @JSONField(name = "rpak_addrp")
    private String rpakAddrp;
    /**
     * 交货市
     */
    @JSONField(name = "rpak_addrc")
    private String rpakAddrc;
    /**
     * 交货区
     */
    @JSONField(name = "rpak_addrl")
    private String rpakAddrl;
    /**
     * 详细地址
     */
    @JSONField(name = "rpak_daddr")
    private String rpakDaddr;
    /**
     * 联系人
     */
    @JSONField(name = "rpak_contact")
    private String rpakContact;
    /**
     * 联系方式
     */
    @JSONField(name = "rpak_cway")
    private String rpakCway;
    /**
     * 启用/禁用
     */
    @JSONField(name = "reak_addr_enable")
    private String reakAddrEnable;

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getRpakAddrp() {
        return rpakAddrp;
    }

    public void setRpakAddrp(String rpakAddrp) {
        this.rpakAddrp = rpakAddrp;
    }

    public String getRpakAddrc() {
        return rpakAddrc;
    }

    public void setRpakAddrc(String rpakAddrc) {
        this.rpakAddrc = rpakAddrc;
    }

    public String getRpakAddrl() {
        return rpakAddrl;
    }

    public void setRpakAddrl(String rpakAddrl) {
        this.rpakAddrl = rpakAddrl;
    }

    public String getRpakDaddr() {
        return rpakDaddr;
    }

    public void setRpakDaddr(String rpakDaddr) {
        this.rpakDaddr = rpakDaddr;
    }

    public String getRpakContact() {
        return rpakContact;
    }

    public void setRpakContact(String rpakContact) {
        this.rpakContact = rpakContact;
    }

    public String getRpakCway() {
        return rpakCway;
    }

    public void setRpakCway(String rpakCway) {
        this.rpakCway = rpakCway;
    }

    public String getReakAddrEnable() {
        return reakAddrEnable;
    }

    public void setReakAddrEnable(String reakAddrEnable) {
        this.reakAddrEnable = reakAddrEnable;
    }

    @Override
    public String toString() {
        return "RpakAddrVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", rpakAddrp='" + rpakAddrp + '\'' +
                ", rpakAddrc='" + rpakAddrc + '\'' +
                ", rpakAddrl='" + rpakAddrl + '\'' +
                ", rpakDaddr='" + rpakDaddr + '\'' +
                ", rpakContact='" + rpakContact + '\'' +
                ", rpakCway='" + rpakCway + '\'' +
                ", reakAddrEnable='" + reakAddrEnable + '\'' +
                '}';
    }
}
