package com.huntkey.rx.sceo.common.model.period;

/**
 * 周期
 * @author liucs
 * @date 2018-3-27 17:08:28
 */
public interface PeriodConstant {
    String PEID_NAME = "peid_name";
    String PEID_SDATE = "peid_sdate";
    String PEID_EDATE = "peid_edate";
    String PEID_PROID = "peid_proid";
    String  PEID_FYR = "peid_fyr";
    String PEID_ENABLE = "peid_enable";
    String PEID_IS_STANDARD = "peid_is_standard";
    String PEID_FINA_NAME = "peid_fina_name";
    String PEID_CALE_NAME = "peid_cale_name";
    /**
     * 起始月份对应的周期起始时间（仅限年类型）
     */
    String JANUARY_YEAR_SDATE = "01-01 00:00:00";
    String APRIL_YEAR_SDATE = "04-01 00:00:00";
    String JULY_YEAR_SDATE = "07-01 00:00:00";
    String OCTOBER_YEAR_SDATE = "10-01 00:00:00";
    /**
     * 起始月份对应的周期结束时间（仅限年类型）
     */
    String JANUARY_YEAR_EDATE = "12-31 23:59:59";
    String APRIL_YEAR_EDATE = "03-31 23:59:59";
    String JULY_YEAR_EDATE = "06-30 23:59:59";
    String OCTOBER_YEAR_EDATE = "09-30 23:59:59";

    /**
     * 开始时间后缀—开始时间固定为1、4、7、10月的1号 0时0分0秒
     */
    String SDATE_SUFFIX = "-01 00:00:00";
    /**
     * 周期类型，分别为—年、季、月
     */
    String YEAR = "Y";
    String QUARTER = "Q";
    String MONTH = "M";
}

