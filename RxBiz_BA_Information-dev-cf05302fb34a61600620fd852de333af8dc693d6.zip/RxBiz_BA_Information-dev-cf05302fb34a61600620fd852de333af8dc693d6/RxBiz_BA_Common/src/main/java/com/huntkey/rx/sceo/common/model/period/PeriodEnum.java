
package com.huntkey.rx.sceo.common.model.period;

/**
 * 不建议试用。建议试用PeriodType（开放接口模块提供）
 */
@Deprecated
public enum PeriodEnum {
	// YEAR("YEAR","年"),
	// QUARTER("QUARTER","季"),
	// MONTH("MONTH","月"),
	// WEEK("WEEK","周"),
	// FISCAL_YEAR("FISCAL_YEAR","财年"),
	// FISCAL_QUARTER("FISCAL_QUARTER","财季"),
	// FISCAL_MONTH("FISCAL_MONTH","财月"),
	// FISCAL_WEEK("FISCAL_WEEK","财周");
	// /**
	// * 周期类型
	// */
	// private String type;
	// /**
	// * 周期类型对应中文名
	// */
	// private String name;
	// PeriodEnum(String type, String name){
	// this.name = name;
	// this.type = type;
	// }
	//
	// public String getType(){
	// return this.type;
	// }
	// public String getName(){
	// return this.name;
	// }
}
