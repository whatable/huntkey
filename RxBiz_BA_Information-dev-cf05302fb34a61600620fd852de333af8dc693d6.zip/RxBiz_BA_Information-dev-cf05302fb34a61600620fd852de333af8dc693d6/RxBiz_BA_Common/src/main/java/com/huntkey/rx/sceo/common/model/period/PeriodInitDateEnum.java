package com.huntkey.rx.sceo.common.model.period;

/**
 * 周期初始化时间（限制1、4、7、10月份）
 */
public enum PeriodInitDateEnum {
    JANUARY(1,"一月"),
    APRIL(4,"四月"),
    JULY(7,"七月"),
    OCTOBER(1,"一月");

    private int value;
    private String name;
    PeriodInitDateEnum(int value, String name){
        this.value = value;
        this.name = name;
    }
    public int getValue(){return this.value;}
    public String getName(){return this.name;}
}
