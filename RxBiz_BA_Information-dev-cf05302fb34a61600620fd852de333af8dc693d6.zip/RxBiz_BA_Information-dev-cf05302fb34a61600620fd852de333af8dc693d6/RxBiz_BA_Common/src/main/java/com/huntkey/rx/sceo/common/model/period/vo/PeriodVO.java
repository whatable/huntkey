package com.huntkey.rx.sceo.common.model.period.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;

import java.util.Date;

public class PeriodVO extends BaseEntity {
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 周期类型中文名称
     */
    private String peidTypeName;
    /**
     * 周期名称
     */
    @JSONField(name = "peid_name")
    private String peidName;
    /**
     * 开始时间
     */
    @JSONField(name = "peid_sdate")
    private Date peidSdate;
    /**
     * 结束时间
     */
    @JSONField(name = "peid_edate")
    private Date peidEdate;
    /**
     * 期次
     */
    @JSONField(name = "peid_proid")
    private Integer peidProid;
    /**
     * 财年
     */
    @JSONField(name = "peid_fyr")
    private String peidFyr;
    /**
     * 启用/禁用
     */
    @JSONField(name = "peid_enable")
    private String peidEnable;
    /**
     * 财务周期名称
     */
    @JSONField(name = "peid_fina_name")
    private String peidFinaName;
    /**
     * 日历周期名称
     */
    @JSONField(name = "peid_cale_name")
    private String peidCaleName;

    public String getPeidFinaName() {
        return peidFinaName;
    }

    public void setPeidFinaName(String peidFinaName) {
        this.peidFinaName = peidFinaName;
    }

    public String getPeidCaleName() {
        return peidCaleName;
    }

    public void setPeidCaleName(String peidCaleName) {
        this.peidCaleName = peidCaleName;
    }

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getPeidName() {
        return peidName;
    }

    public void setPeidName(String peidName) {
        this.peidName = peidName;
    }

    public Date getPeidSdate() {
        return peidSdate;
    }

    public void setPeidSdate(Date peidSdate) {
        this.peidSdate = peidSdate;
    }

    public Date getPeidEdate() {
        return peidEdate;
    }

    public void setPeidEdate(Date peidEdate) {
        this.peidEdate = peidEdate;
    }

    public Integer getPeidProid() {
        return peidProid;
    }

    public void setPeidProid(Integer peidProid) {
        this.peidProid = peidProid;
    }

    public String getPeidFyr() {
        return peidFyr;
    }

    public void setPeidFyr(String peidFyr) {
        this.peidFyr = peidFyr;
    }

    public String getPeidEnable() {
        return peidEnable;
    }

    public void setPeidEnable(String peidEnable) {
        this.peidEnable = peidEnable;
    }

    public String getPeidTypeName() {
        return peidTypeName;
    }

    public void setPeidTypeName(String peidTypeName) {
        this.peidTypeName = peidTypeName;
    }

    @Override
    public String toString() {
        return "PeriodVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", peidName='" + peidName + '\'' +
                ", peidSdate=" + peidSdate +
                ", peidEdate=" + peidEdate +
                ", peidProid=" + peidProid +
                ", peidFyr='" + peidFyr + '\'' +
                ", peidEnable='" + peidEnable + '\'' +
                ", peidFinaName='" + peidFinaName + '\'' +
                ", peidCaleName='" + peidCaleName + '\'' +
                '}';
    }
}
