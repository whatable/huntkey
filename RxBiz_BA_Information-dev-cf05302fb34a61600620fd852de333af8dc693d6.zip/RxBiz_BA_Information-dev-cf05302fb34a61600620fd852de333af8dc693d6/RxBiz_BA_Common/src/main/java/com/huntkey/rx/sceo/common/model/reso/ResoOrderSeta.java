package com.huntkey.rx.sceo.common.model.reso;

public class ResoOrderSeta {
    private String id;

    private String pId;

    private String className;

    private String resoOrderObj;

    private Integer isDel;

    private String creTime;

    private String creUser;

    private String modTime;

    private String modUser;

    private String resoOrderClass;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getResoOrderObj() {
        return resoOrderObj;
    }

    public void setResoOrderObj(String resoOrderObj) {
        this.resoOrderObj = resoOrderObj;
    }

    public Integer getIsDel() {
        return isDel;
    }

    public void setIsDel(Integer isDel) {
        this.isDel = isDel;
    }

    public String getCreTime() {
        return creTime;
    }

    public void setCreTime(String creTime) {
        this.creTime = creTime;
    }

    public String getCreUser() {
        return creUser;
    }

    public void setCreUser(String creUser) {
        this.creUser = creUser;
    }

    public String getModTime() {
        return modTime;
    }

    public void setModTime(String modTime) {
        this.modTime = modTime;
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public String getResoOrderClass() {
        return resoOrderClass;
    }

    public void setResoOrderClass(String resoOrderClass) {
        this.resoOrderClass = resoOrderClass;
    }
}
