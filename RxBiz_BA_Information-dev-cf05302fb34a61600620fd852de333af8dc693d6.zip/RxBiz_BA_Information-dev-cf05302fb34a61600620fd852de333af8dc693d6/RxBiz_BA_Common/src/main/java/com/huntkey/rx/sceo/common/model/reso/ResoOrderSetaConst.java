package com.huntkey.rx.sceo.common.model.reso;

public interface ResoOrderSetaConst {
     String TABLENAME = "reso_order_set";
     String ID = "id";
     String PID = "pid";
     String CLASSNAME = "classname";
     String RESOORDEROBJ = "reso_orderobj";
     String ISDEL = "is_del";
     String CRETIME = "cretime";
     String CREUSER = "creuser";
     String MODTIME = "modtime";
     String MODUSER = "moduser";
     String RESOORDERCLASS = "reso_orderclass";

     String RESOVO_ID = "id";
     String RESOVO_PID = "pId";
     String RESOVO_CLASSNAME= "className";
     String RESOVO_RESOORDEROBJ= "resoOrderObj";
     String RESOVO_ISDEL = "isDel";
     String RESOVO_CRETIME = "creTime";
     String RESOVO_CREUSER = "creUser";
     String RESOVO_MODTIME = "modTime";
     String RESOVO_MODUSER = "modUser";
     String RESOVO_RESOORDERCLASS = "resoOrderClass";
}
