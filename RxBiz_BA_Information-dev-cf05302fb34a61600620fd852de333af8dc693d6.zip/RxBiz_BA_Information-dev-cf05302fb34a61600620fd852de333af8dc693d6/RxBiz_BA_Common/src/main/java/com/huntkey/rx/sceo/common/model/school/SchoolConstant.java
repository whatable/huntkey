package com.huntkey.rx.sceo.common.model.school;

public interface SchoolConstant {
    String RSCH_CITY = "rsch_city";
    String RSCH_WEBSITE = "rsch_website";
    String RSCH_ENABLE = "rsch_enable";
    String RSCH_CODE = "rsch_code";
    String RSCH_NAME = "rsch_name";
    String RSCH_RANKING = "rsch_ranking";
    String RSCH_IS_STANDARD = "rsch_is_standard";
}
