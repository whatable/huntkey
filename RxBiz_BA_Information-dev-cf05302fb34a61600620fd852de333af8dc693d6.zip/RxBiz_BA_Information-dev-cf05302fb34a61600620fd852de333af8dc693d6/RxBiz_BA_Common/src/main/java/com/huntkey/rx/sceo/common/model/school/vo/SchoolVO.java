package com.huntkey.rx.sceo.common.model.school.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;

public class SchoolVO extends BaseEntity {
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 学校所在城市名称
     */
    private String rschCityName;
    /**
     * 学校所在省
     */
    private String rschProv;

    /**
     * 学校层次中文名称
     */
    private String rschRankingName;
    /**
     * 学校所在地
     */
    @JSONField(name = "rsch_city")
    private String rschCity;
    /**
     * 学校网址
     */
    @JSONField(name = "rsch_website")
    private String rschWebsite;
    /**
     * 启用/禁用
     */
    @JSONField(name = "rsch_enable")
    private String rschEnable;
    /**
     * 学校编号
     */
    @JSONField(name = "rsch_code")
    private String rschCode;
    /**
     * 学校名称
     */
    @JSONField(name = "rsch_name")
    private String rschName;
    /**
     * 学校层次
     */
    @JSONField(name = "rsch_ranking")
    private String rschRanking;
    /**
     * 是否标准
     */
    @JSONField(name = "rsch_is_standard")
    private String rschIsStandard;

    public String getRschRankingName() {
        return rschRankingName;
    }

    public void setRschRankingName(String rschRankingName) {
        this.rschRankingName = rschRankingName;
    }

    public String getRschProv() {
        return rschProv;
    }

    public void setRschProv(String rschProv) {
        this.rschProv = rschProv;
    }

    public String getRschCityName() {
        return rschCityName;
    }

    public void setRschCityName(String rschCityName) {
        this.rschCityName = rschCityName;
    }

    public String getRschIsStandard() {
        return rschIsStandard;
    }

    public void setRschIsStandard(String rschIsStandard) {
        this.rschIsStandard = rschIsStandard;
    }

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getRschCity() {
        return rschCity;
    }

    public void setRschCity(String rschCity) {
        this.rschCity = rschCity;
    }

    public String getRschWebsite() {
        return rschWebsite;
    }

    public void setRschWebsite(String rschWebsite) {
        this.rschWebsite = rschWebsite;
    }

    public String getRschEnable() {
        return rschEnable;
    }

    public void setRschEnable(String rschEnable) {
        this.rschEnable = rschEnable;
    }

    public String getRschCode() {
        return rschCode;
    }

    public void setRschCode(String rschCode) {
        this.rschCode = rschCode;
    }

    public String getRschName() {
        return rschName;
    }

    public void setRschName(String rschName) {
        this.rschName = rschName;
    }

    public String getRschRanking() {
        return rschRanking;
    }

    public void setRschRanking(String rschRanking) {
        this.rschRanking = rschRanking;
    }

    @Override
    public String toString() {
        return "SchoolVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", rschCity='" + rschCity + '\'' +
                ", rschWebsite='" + rschWebsite + '\'' +
                ", rschEnable='" + rschEnable + '\'' +
                ", rschCode='" + rschCode + '\'' +
                ", rschName='" + rschName + '\'' +
                ", rschRanking='" + rschRanking + '\'' +
                '}';
    }
}
