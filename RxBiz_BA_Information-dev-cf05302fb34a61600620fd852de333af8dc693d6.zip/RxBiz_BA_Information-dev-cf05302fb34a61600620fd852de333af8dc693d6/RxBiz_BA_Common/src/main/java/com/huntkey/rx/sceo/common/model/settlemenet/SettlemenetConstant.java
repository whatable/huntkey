package com.huntkey.rx.sceo.common.model.settlemenet;

/**
 * @author liucs
 * @date 2018-4-2 11:42:09
 */
public interface SettlemenetConstant {
    String SETT_DESC = "sett_desc";
    String SETT_WAY = "sett_way";
    String SETT_MDAYS = "sett_mdays";
    String SETT_MDATE = "sett_mdate";
    String SETT_DATYS = "sett_adays";
    String SETT_RATE = "sett_rate";
    String SETT_IDAYS = "sett_idays";
    String SETT_ODAYS = "sett_odays";
    String SETT_TYPE = "sett_type";
}
