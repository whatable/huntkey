package com.huntkey.rx.sceo.common.model.settlemenet.vo;

import com.huntkey.rx.base.BaseEntity;

public class SettlementetVO extends BaseEntity {
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 结算方式描述
     */
    private String settDesc;
    /**
     * 结算方式
     */
    private String settWay;
    /**
     * 月结天数
     */
    private String settMdays;
    /**
     * 月结日
     */
    private String settMdate;
    /**
     * 结算提前天数
     */
    private String settAdays;
    /**
     * 结算比例
     */
    private String settRate;
    /**
     * 货到天数
     */
    private String settIdays;
    /**
     * 出货天数
     */
    private String settOdays;
    /**
     * 结算类型
     */
    private String settType;
    /**
     * 付款方式
     */
    private String settPaymWay;
    /**
     * 付款期限
     */
    private String settPaymDate;
    /**
     * 启用/禁用
     */
    private String settEnable;

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getSettDesc() {
        return settDesc;
    }

    public void setSettDesc(String settDesc) {
        this.settDesc = settDesc;
    }

    public String getSettWay() {
        return settWay;
    }

    public void setSettWay(String settWay) {
        this.settWay = settWay;
    }

    public String getSettMdays() {
        return settMdays;
    }

    public void setSettMdays(String settMdays) {
        this.settMdays = settMdays;
    }

    public String getSettMdate() {
        return settMdate;
    }

    public void setSettMdate(String settMdate) {
        this.settMdate = settMdate;
    }

    public String getSettAdays() {
        return settAdays;
    }

    public void setSettAdays(String settAdays) {
        this.settAdays = settAdays;
    }

    public String getSettRate() {
        return settRate;
    }

    public void setSettRate(String settRate) {
        this.settRate = settRate;
    }

    public String getSettIdays() {
        return settIdays;
    }

    public void setSettIdays(String settIdays) {
        this.settIdays = settIdays;
    }

    public String getSettOdays() {
        return settOdays;
    }

    public void setSettOdays(String settOdays) {
        this.settOdays = settOdays;
    }

    public String getSettType() {
        return settType;
    }

    public void setSettType(String settType) {
        this.settType = settType;
    }

    public String getSettPaymWay() {
        return settPaymWay;
    }

    public void setSettPaymWay(String settPaymWay) {
        this.settPaymWay = settPaymWay;
    }

    public String getSettPaymDate() {
        return settPaymDate;
    }

    public void setSettPaymDate(String settPaymDate) {
        this.settPaymDate = settPaymDate;
    }

    public String getSettEnable() {
        return settEnable;
    }

    public void setSettEnable(String settEnable) {
        this.settEnable = settEnable;
    }

    @Override
    public String toString() {
        return "SettlementetVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", settDesc='" + settDesc + '\'' +
                ", settWay='" + settWay + '\'' +
                ", settMdays='" + settMdays + '\'' +
                ", settMdate='" + settMdate + '\'' +
                ", settAdays='" + settAdays + '\'' +
                ", settRate='" + settRate + '\'' +
                ", settIdays='" + settIdays + '\'' +
                ", settOdays='" + settOdays + '\'' +
                ", settType='" + settType + '\'' +
                ", settPaymWay='" + settPaymWay + '\'' +
                ", settPaymDate='" + settPaymDate + '\'' +
                ", settEnable='" + settEnable + '\'' +
                '}';
    }
}
