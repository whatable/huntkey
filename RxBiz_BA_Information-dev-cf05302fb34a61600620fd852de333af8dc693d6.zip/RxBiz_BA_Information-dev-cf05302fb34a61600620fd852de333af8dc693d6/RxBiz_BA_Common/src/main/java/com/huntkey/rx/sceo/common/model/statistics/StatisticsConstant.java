package com.huntkey.rx.sceo.common.model.statistics;

public interface StatisticsConstant {
    String STAT_PRIDOBJ = "stat_pridobj";
    String STAT_MONICLASS = "stat_moniclass";
    String STAT_MONIOBJ = "stat_moniobj";
    String STAT_MONIATTR = "stat_moniattr";
    String STAT_ISCOMPARE = "stat_iscompare";
    String STAT_PERIORNAME = "stat_periorname";
    String STAT_PERIOD = "stat_period";
    String STAT_PERAMT = "stat_peramt";
    String STAT_CURAMT = "stat_curamt";
    String STAT_CURSUM = "stat_cursum";
    String STAT_FYEAR = "stat_fyear";
    String STAT_BEG = "stat_beg";
    String STAT_END = "stat_end";
}
