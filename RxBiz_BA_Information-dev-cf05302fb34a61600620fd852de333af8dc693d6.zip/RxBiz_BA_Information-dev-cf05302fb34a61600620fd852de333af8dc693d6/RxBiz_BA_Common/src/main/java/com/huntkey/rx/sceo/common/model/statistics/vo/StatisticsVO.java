package com.huntkey.rx.sceo.common.model.statistics.vo;

import com.huntkey.rx.base.BaseEntity;

public class StatisticsVO extends BaseEntity {
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    private String statPridobj;
    private String statMoniclass;
    private String statMoniobj;
    private String statMoniattr;
    private String statIscompare;
    private String statFyear;
    private String statPeriorname;
    private String statPeriod;
    private String statBeg;
    private String statEnd;
    private String statPeramt;
    private String statCuramt;
    private String statCursum;
    private String statEnable;

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getStatPridobj() {
        return statPridobj;
    }

    public void setStatPridobj(String statPridobj) {
        this.statPridobj = statPridobj;
    }

    public String getStatMoniclass() {
        return statMoniclass;
    }

    public void setStatMoniclass(String statMoniclass) {
        this.statMoniclass = statMoniclass;
    }

    public String getStatMoniobj() {
        return statMoniobj;
    }

    public void setStatMoniobj(String statMoniobj) {
        this.statMoniobj = statMoniobj;
    }

    public String getStatMoniattr() {
        return statMoniattr;
    }

    public void setStatMoniattr(String statMoniattr) {
        this.statMoniattr = statMoniattr;
    }

    public String getStatIscompare() {
        return statIscompare;
    }

    public void setStatIscompare(String statIscompare) {
        this.statIscompare = statIscompare;
    }

    public String getStatFyear() {
        return statFyear;
    }

    public void setStatFyear(String statFyear) {
        this.statFyear = statFyear;
    }

    public String getStatPeriorname() {
        return statPeriorname;
    }

    public void setStatPeriorname(String statPeriorname) {
        this.statPeriorname = statPeriorname;
    }

    public String getStatPeriod() {
        return statPeriod;
    }

    public void setStatPeriod(String statPeriod) {
        this.statPeriod = statPeriod;
    }

    public String getStatBeg() {
        return statBeg;
    }

    public void setStatBeg(String statBeg) {
        this.statBeg = statBeg;
    }

    public String getStatEnd() {
        return statEnd;
    }

    public void setStatEnd(String statEnd) {
        this.statEnd = statEnd;
    }

    public String getStatPeramt() {
        return statPeramt;
    }

    public void setStatPeramt(String statPeramt) {
        this.statPeramt = statPeramt;
    }

    public String getStatCuramt() {
        return statCuramt;
    }

    public void setStatCuramt(String statCuramt) {
        this.statCuramt = statCuramt;
    }

    public String getStatCursum() {
        return statCursum;
    }

    public void setStatCursum(String statCursum) {
        this.statCursum = statCursum;
    }

    public String getStatEnable() {
        return statEnable;
    }

    public void setStatEnable(String statEnable) {
        this.statEnable = statEnable;
    }

    @Override
    public String toString() {
        return "StatisticsVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", statPridobj='" + statPridobj + '\'' +
                ", statMoniclass='" + statMoniclass + '\'' +
                ", statMoniobj='" + statMoniobj + '\'' +
                ", statMoniattr='" + statMoniattr + '\'' +
                ", statIscompare='" + statIscompare + '\'' +
                ", statFyear='" + statFyear + '\'' +
                ", statPeriorname='" + statPeriorname + '\'' +
                ", statPeriod='" + statPeriod + '\'' +
                ", statBeg='" + statBeg + '\'' +
                ", statEnd='" + statEnd + '\'' +
                ", statPeramt='" + statPeramt + '\'' +
                ", statCuramt='" + statCuramt + '\'' +
                ", statCursum='" + statCursum + '\'' +
                ", statEnable='" + statEnable + '\'' +
                '}';
    }
}
