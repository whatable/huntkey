package com.huntkey.rx.sceo.common.model.taxrate;

public interface TaxrateConstant {
    String TAXR_NAME = "taxr_name";
    String TAXR_ISDEDUCT = "taxr_isdeduct";
    String TAXR_DETAIL = "taxr_detail";
    String TAXR_ENABLE = "taxr_enable";
    String TAXR_CODE = "taxr_code";
    String TAXR_IS_STANDARD = "taxr_is_standard";
}
