package com.huntkey.rx.sceo.common.model.taxrate.vo;

import com.alibaba.fastjson.annotation.JSONField;
import com.huntkey.rx.base.BaseEntity;
import com.huntkey.rx.edm.entity.TaxrateEntity;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class TaxrateVO extends BaseEntity {
    /**
     * 创建人姓名
     */
    private String creUserName;
    /**
     * 维护人姓名
     */
    private String modUserName;
    /**
     * 名称
     */
    @JSONField(name = "taxr_name")
    private String taxrName;
    /**
     * 是否可抵扣
     */
    @JSONField(name = "taxr_isdeduct")
    private String taxrIsdeduct;
    /**
     * 详细税率
     */
    @JSONField(name = "taxr_detail")
    private BigDecimal taxrDetail;
    /**
     * 启用/禁用
     */
    @JSONField(name = "taxr_enable")
    private String taxrEnable;

    /**
     * 编码
     */
    @JSONField(name = "taxr_code")
    private String taxrCode;

    /**
     * 是否标准
     */
    @JSONField(name = "taxr_is_standard")
    private String taxrIsStandard;

    public String getTaxrCode() {
        return taxrCode;
    }

    public void setTaxrCode(String taxrCode) {
        this.taxrCode = taxrCode;
    }

    public String getTaxrIsStandard() {
        return taxrIsStandard;
    }

    public void setTaxrIsStandard(String taxrIsStandard) {
        this.taxrIsStandard = taxrIsStandard;
    }

    public String getCreUserName() {
        return creUserName;
    }

    public void setCreUserName(String creUserName) {
        this.creUserName = creUserName;
    }

    public String getModUserName() {
        return modUserName;
    }

    public void setModUserName(String modUserName) {
        this.modUserName = modUserName;
    }

    public String getTaxrName() {
        return taxrName;
    }

    public void setTaxrName(String taxrName) {
        this.taxrName = taxrName;
    }

    public String getTaxrIsdeduct() {
        return taxrIsdeduct;
    }

    public void setTaxrIsdeduct(String taxrIsdeduct) {
        this.taxrIsdeduct = taxrIsdeduct;
    }

    public BigDecimal getTaxrDetail() {
        return taxrDetail;
    }

    public void setTaxrDetail(BigDecimal taxrDetail) {
        this.taxrDetail = taxrDetail;
    }

    public String getTaxrEnable() {
        return taxrEnable;
    }

    public void setTaxrEnable(String taxrEnable) {
        this.taxrEnable = taxrEnable;
    }

    @Override
    public String toString() {
        return "TaxrateVO{" +
                "creUserName='" + creUserName + '\'' +
                ", modUserName='" + modUserName + '\'' +
                ", taxrName='" + taxrName + '\'' +
                ", taxrIsdeduct='" + taxrIsdeduct + '\'' +
                ", taxrDetail=" + taxrDetail +
                ", taxrEnable='" + taxrEnable + '\'' +
                ", taxrCode='" + taxrCode + '\'' +
                ", taxrIsStandard='" + taxrIsStandard + '\'' +
                '}';
    }
}
