package com.huntkey.rx.sceo.common.model.tip;

/**
 *
 * @author yexin
 * @date 2017/10/25
 */
public class TipData {

    // 信息类型，0-不提示,1-提示类,2-警告类,3-错误类
    private String msgType;

    // 提示信息内容
    private String msgDesc;

    // 显示时间, <0 为一直显示，需确认再关闭
    private int showTime;

    /**
     * 信息类型，0-不提示,1-提示类,2-警告类,3-错误类
     * @return String
     */
    public String getMsgType() {
        return msgType;
    }

    /**
     * 信息类型，0-不提示,1-提示类,2-警告类,3-错误类
     * @param msgType
     */
    public void setMsgType(String msgType) {
        this.msgType = msgType;
    }

    /**
     * 提示信息内容
     * @return String
     */
    public String getMsgDesc() {
        return msgDesc;
    }

    /**
     * 提示信息内容
     * @param msgDesc
     */
    public void setMsgDesc(String msgDesc) {
        this.msgDesc = msgDesc;
    }

    /**
     * 显示时间, <0 为一直显示，需确认再关闭
     * @return int
     */
    public int getShowTime() {
        return showTime;
    }

    /**
     * 显示时间, <0 为一直显示，需确认再关闭
     * @param showTime
     */
    public void setShowTime(int showTime) {
        this.showTime = showTime;
    }
}
