package com.huntkey.rx.sceo.common.model.tip;

/**
 * @author zhoucj
 */
public class TipMessage {
    private String id;

    private String tipPageCode;

    private String tipMsgCode;

    private String tipMsgType;

    private Integer tipShowTime;

    private String tipBaseMsg;

    private String tipShowMsg;

    private String tipModifyUser;

    private String tipModifyTime;

    private String isDel;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getTipPageCode() {
        return tipPageCode;
    }

    public void setTipPageCode(String tipPageCode) {
        this.tipPageCode = tipPageCode == null ? null : tipPageCode.trim();
    }

    public String getTipMsgCode() {
        return tipMsgCode;
    }

    public void setTipMsgCode(String tipMsgCode) {
        this.tipMsgCode = tipMsgCode == null ? null : tipMsgCode.trim();
    }

    public String getTipMsgType() {
        return tipMsgType;
    }

    public void setTipMsgType(String tipMsgType) {
        this.tipMsgType = tipMsgType == null ? null : tipMsgType.trim();
    }

    public Integer getTipShowTime() {
        return tipShowTime;
    }

    public void setTipShowTime(Integer tipShowTime) {
        this.tipShowTime = tipShowTime;
    }

    public String getTipBaseMsg() {
        return tipBaseMsg;
    }

    public void setTipBaseMsg(String tipBaseMsg) {
        this.tipBaseMsg = tipBaseMsg == null ? null : tipBaseMsg.trim();
    }

    public String getTipShowMsg() {
        return tipShowMsg;
    }

    public void setTipShowMsg(String tipShowMsg) {
        this.tipShowMsg = tipShowMsg == null ? null : tipShowMsg.trim();
    }

    public String getTipModifyUser() {
        return tipModifyUser;
    }

    public void setTipModifyUser(String tipModifyUser) {
        this.tipModifyUser = tipModifyUser == null ? null : tipModifyUser.trim();
    }

    public String getTipModifyTime() {
        return tipModifyTime;
    }

    public void setTipModifyTime(String tipModifyTime) {
        this.tipModifyTime = tipModifyTime == null ? null : tipModifyTime.trim();
    }

    public String getIsDel() {
        return isDel;
    }

    public void setIsDel(String isDel) {
        this.isDel = isDel == null ? null : isDel.trim();
    }
}