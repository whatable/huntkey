package com.huntkey.rx.sceo.common.model.tip;

/**
 *
 * @author zhoucj
 * @date 2017/11/14
 */
public interface TipMessageConst {
    String TABLENAME = "tipmessage";
    String ID = "id";
    String IS_DEL = "is_del";
    String MODUSER = "moduser";
    String TIPM_MSG_CODE = "tipm_msg_code";
    String TIPM_MSG_TYPE = "tipm_msg_type";
    String TIPM_PAGE_CODE = "tipm_page_code";
    String TIPM_SHOW_MSG = "tipm_show_msg";
    String TIPM_SHOW_TIME = "tipm_show_time";
    String TIPM_BASE_MSG = "tipm_base_msg";
    String MODTIME = "modtime";

    String TIP_PAGE_CODE = "tipPageCode";
    String TIP_MSG_CODE = "tipMsgCode";
    String TIP_MSG_TYPE = "tipMsgType";
    String TIP_SHOW_TIME = "tipShowTime";
    String TIP_BASE_MSG = "tipBaseMsg";
    String TIP_SHOW_MSG = "tipShowMsg";
    String TIP_MODIFY_USER = "tipModifyUser";
    String TIP_MODIFY_TIME = "tipModifyTime";
    String ISDEL = "isDel";
}
