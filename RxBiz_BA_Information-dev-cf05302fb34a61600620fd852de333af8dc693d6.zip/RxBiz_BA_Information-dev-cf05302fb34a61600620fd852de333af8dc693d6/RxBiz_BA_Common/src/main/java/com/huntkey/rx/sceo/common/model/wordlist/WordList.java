package com.huntkey.rx.sceo.common.model.wordlist;

import com.huntkey.rx.commons.utils.datetime.DateUtil;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.WordlistEntity;

/**
 *
 * @author zhoucj
 * @date 2017/11/20
 */
public class WordList {
	// 主键id
	protected String id;
	// 词汇编码
	protected String infoCode;
	// 词汇名称
	protected String wordName;
	// 词汇用途说明
	protected String wordRemark;
	// 是否标准词汇，1是，0否
	protected Integer wordIsStandard;
	// 上级词汇对象id
	protected String wordParent;
	// 状态，1开启，0禁用
	protected Integer wordEnable;
	// 序号
	protected String wordSeq;
	// 修改人
	protected String modifyUser;
	// 修改时间
	protected String modifyDate;
	// 是否删除，1删除，0未删除
	protected Integer isDel = 0;// 注：因为orm查询自动过滤is_del=0，所以此vo默认isDel=0

	// 使用类id列表，用逗号隔开
	protected String classIds;
	// 使用类名称列表，用逗号隔开
	protected String classNames;

	public WordList() {
	}

	/**
	 * 从枚举PO构建一个枚举VO，属性会一一对应复制
	 * 
	 * @param e
	 */
	public WordList(WordlistEntity e) {
		this.fill(e);
	}

	/**
	 * 用一个枚举PO的各条属性对应填充当前的枚举VO的属性（此前若有值会被覆盖）
	 * 
	 * @param e
	 */
	public void fill(WordlistEntity e) {
		this.setId(e.getId());
		this.setInfoCode(e.getInfo_code());
		this.setWordName(e.getWord_name());
		this.setWordRemark(e.getWord_remark());
		this.setModifyUser(e.getModuser());
		this.setWordParent(e.getWord_par());

		this.setWordIsStandard(e.getWord_issta());
		this.setWordEnable(e.getWord_enable());
		this.setWordSeq(String.valueOf(e.getWord_seq()));
		this.setModifyDate(DateUtil.formatDate(e.getModtime()));

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getInfoCode() {
		return infoCode;
	}

	public void setInfoCode(String infoCode) {
		this.infoCode = infoCode;
	}

	public String getWordName() {
		return wordName;
	}

	public void setWordName(String wordName) {
		this.wordName = wordName;
	}

	public String getWordRemark() {
		return wordRemark;
	}

	public void setWordRemark(String wordRemark) {
		this.wordRemark = wordRemark;
	}

	public Integer getWordIsStandard() {
		return wordIsStandard;
	}

	public void setWordIsStandard(Integer wordIsStandard) {
		this.wordIsStandard = wordIsStandard;
	}

	public String getWordParent() {
		return wordParent;
	}

	public void setWordParent(String wordParent) {
		this.wordParent = wordParent;
	}

	public Integer getWordEnable() {
		return wordEnable;
	}

	public void setWordEnable(Integer wordEnable) {
		this.wordEnable = wordEnable;
	}

	public String getWordSeq() {
		return wordSeq;
	}

	public void setWordSeq(String wordSeq) {
		this.wordSeq = wordSeq;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public Integer getIsDel() {
		return isDel;
	}

	public void setIsDel(Integer isDel) {
		this.isDel = isDel;
	}

	public String getClassIds() {
		return classIds;
	}

	public void setClassIds(String classIds) {
		this.classIds = classIds;
	}

	public String getClassNames() {
		return classNames;
	}

	public void setClassNames(String classNames) {
		this.classNames = classNames;
	}

	public WordlistEntity toEntity() {
		WordlistEntity e = new WordlistEntity();
		e.setId(this.getId());
		e.setWord_name(this.getWordName());
		e.setWord_par(this.getWordParent());
		e.setWord_remark(this.getWordRemark());
		e.setInfo_code(this.getInfoCode());
		e.setInfo_desc(this.getWordRemark());

		if (!StringUtil.isNullOrEmpty(this.getWordEnable())) {
			e.setWord_enable(this.getWordEnable());
		}
		if (!StringUtil.isNullOrEmpty(this.getWordIsStandard())) {
			e.setWord_issta(this.getWordIsStandard());
		}
		if (!StringUtil.isNullOrEmpty(this.getWordSeq())) {
			e.setWord_seq(Integer.valueOf(this.getWordSeq()));
		}
		return e;
	}

	@Override
	public String toString() {
		return "wordList{" + "id='" + id + '\'' + ", infoCode='" + infoCode + '\'' + ", wordName='" + wordName + '\''
				+ ", wordRemark='" + wordRemark + '\'' + ", wordIsStandard='" + wordIsStandard + '\'' + ", wordParent='"
				+ wordParent + '\'' + ", wordEnable='" + wordEnable + '\'' + ", wordSeq='" + wordSeq + '\''
				+ ", modifyUser='" + modifyUser + '\'' + ", modifyDate='" + modifyDate + '\'' + ", isDel='" + isDel
				+ '\'' + ", classIds= " + classIds + ", classNames= " + classNames + '}';
	}

}
