package com.huntkey.rx.sceo.common.model.wordlist;

/**
 * 不建议使用了。基础资料模块内都是比较内聚的组件，字段操作都集中在service组件内，不必定义这种公共的枚举。
 * @author zhoucj
 * @date 2017/11/20
 */
@Deprecated
enum WordListEnum{
    ID(0, "id", "id"),
    INFO_CODE(1, "infoCode", "info_code"),
    WORD_NAME(2, "wordName", "word_name"),
    WORD_REMARK(3, "wordRemark", "word_remark"),
    WORD_IS_STANDARD(4, "wordIsStandard", "word_issta"),
    WORD_PARENT(5, "wordParent", "word_par"),
    WORD_ENABLE(6, "wordEnable", "word_enable"),
    WORD_SEQ(7, "wordSeq", "word_seq"),
    MODIFY_USER(8, "modifyUser", "moduser"),
    MODIFY_DATE(9, "modifyDate", "modtime"),
    IS_DEL(10, "isDel", "is_del");

    private int index;
    private String voName;
    private String ormName;

    WordListEnum(int index, String voName, String ormName) {
        this.index = index;
        this.voName = voName;
        this.ormName = ormName;
    }

    public String getVoName() { return voName; }
    public String getOrmName() { return ormName; }
}
