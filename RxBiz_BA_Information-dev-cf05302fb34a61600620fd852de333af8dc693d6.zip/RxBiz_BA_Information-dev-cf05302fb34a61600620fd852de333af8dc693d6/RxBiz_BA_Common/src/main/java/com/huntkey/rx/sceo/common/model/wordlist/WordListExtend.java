package com.huntkey.rx.sceo.common.model.wordlist;

import java.util.ArrayList;
import java.util.List;

import com.huntkey.rx.edm.entity.WordlistEntity;

/**
 *
 * @author zhoucj
 * @date 2017/11/20
 */
public class WordListExtend extends WordList {

	// 子枚举列表
	private List<WordListExtend> childList = new ArrayList<>();

	public WordListExtend() {
	}

	/**
	 * 从枚举PO构建一个枚举VO，属性会一一对应复制
	 * 
	 * @param e
	 */
	public WordListExtend(WordlistEntity e) {
		super(e);
	}

	public List<WordListExtend> getChildList() {
		return childList;
	}

	public void setChildList(List<WordListExtend> childList) {
		this.childList = childList;
	}

	@Override
	public String toString() {
		return "WordListExtend{" + "id='" + id + '\'' + ", infoCode='" + infoCode + '\'' + ", wordName='" + wordName
				+ '\'' + ", wordRemark='" + wordRemark + '\'' + ", wordIsStandard='" + wordIsStandard + '\''
				+ ", wordParent='" + wordParent + '\'' + ", wordEnable='" + wordEnable + '\'' + ", wordSeq='" + wordSeq
				+ '\'' + ", modifyUser='" + modifyUser + '\'' + ", modifyDate='" + modifyDate + '\'' + ", isDel='"
				+ isDel + '\'' + ", childList=" + childList + '}';
	}

}
