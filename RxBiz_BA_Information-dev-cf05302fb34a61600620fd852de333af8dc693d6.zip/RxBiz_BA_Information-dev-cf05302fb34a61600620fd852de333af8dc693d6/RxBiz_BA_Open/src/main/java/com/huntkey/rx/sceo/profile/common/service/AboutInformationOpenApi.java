package com.huntkey.rx.sceo.profile.common.service;

/**
 * 
 * <ul>
 * <li>区域请调用{@link AreaService}</li>
 * <li>币别请调用{@link CurrencyService}</li>
 * <li>汇率请调用{@link CurrRateService}</li>
 * <li>计量单位请调用{@link MesureunitService}</li>
 * <li>参数请调用{@link ParameterService}</li>
 * <li>园区请调用{@link ParkService}</li>
 * <li>周期请调用{@link PeriodService}</li>
 * <li>学校请调用{@link SchoolService}</li>
 * <li>税率请调用{@link TaxrateService}</li>
 * <li>提示信息请调用{@link TipmessageService}</li>
 * <li>枚举请调用{@link WordlistService}</li>
 * </ul>
 * 
 * @author jiangshaoh
 *
 */
public interface AboutInformationOpenApi {
	String v1_180630 = "首次发布试用";
	String v1_180710 = "增加和修正若干方法，详见版本更新文档@2018-07-10";
}
