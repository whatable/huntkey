package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;
import java.util.Map;

import com.huntkey.rx.sceo.profile.common.service.AreaService.Area;

/**
 * 基础资料公共接口（开放接口）：区域管理
 *
 * @author jiangshaoh
 */
public interface AreaService extends IdFinder<Area> {
	/**
	 * 根据区域id、是否有效、级联深度等条件查询不定量区域对象（返回区域对象列表，所有级别区域都存储在列表第一级，利用pid确定各自层级）
	 *
	 * @param id
	 *            区域上级id
	 * @param enable
	 *            是否有效，若输入null则查询所有（有效和无效的）
	 * @param depth
	 *            级联深度，1则只取本级，2则包含下一级，以此类推。若输入null则默认取值2
	 * @return 区域对象列表，下一级区域不嵌套
	 */
	List<Area> find(String id, Boolean enable, Integer depth);

	/**
	 * 【特供前端】根据指定的区域节点id，获取从区域顶级根节点到本节点的路径链。现实意义就是给定一个区域，可知其完整的区域链（如给定“蜀山区”，可知“安徽省/合肥市/蜀山区”）。这个查询会忽略数据enable属性，无论是否enable都会读到。
	 *
	 * @param id
	 *            指定的区域节点数据id
	 * @return 数据区域是区域的对象列表（即使只有本节点一个节点，也就是说本节点就是顶级区域，也存储在列表中）
	 */
	List<Area> findChain(String id);

	/**
	 * 【特供】全球化业务系统谨慎调用本接口，专供非全球化业务系统使用，获取中国区域对象。
	 *
	 * @return
	 */
	Area findChina();

	/**
	 * 根据上级区域id查询下级节点
	 * @param pid 上级区域id
	 * @param enable 是否启用
	 * @return
	 */
	List<Map<String, Object>> getAreaByPid(String pid, Boolean enable);

	/**
	 * vo:区域
	 *
	 *
	 */
	public static interface Area extends SceoProfileVo {

		String getName();

		String getCode();

		String getDesc();

		String getParentId();

		int getLevel();

		String getAreaLevel();
	}

}
