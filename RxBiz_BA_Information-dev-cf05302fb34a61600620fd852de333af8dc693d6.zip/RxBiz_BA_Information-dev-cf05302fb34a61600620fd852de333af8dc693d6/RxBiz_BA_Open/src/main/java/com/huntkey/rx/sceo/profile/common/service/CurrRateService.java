package com.huntkey.rx.sceo.profile.common.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.CurrRateService.CurrRate;

/**
 * 基础资料公共接口（开放接口）：汇率管理
 * 
 * @author jiangshaoh
 *
 */
public interface CurrRateService extends IdFinder<CurrRate> {

	/**
	 * 综合条件查询汇率对象
	 * 
	 * @param originCurrencyId
	 *            被兑换币别id，输入null则不限
	 * @param targetCurrencyId
	 *            兑换目标币别id，输入null则不限
	 * @param date
	 *            指定的日期，输入null则不限
	 * @param enable
	 *            是否有效，输入null则查询所有（有效的和无效的）
	 * @return 符合条件的汇率对象列表
	 */
	List<CurrRate> find(String originCurrencyId, String targetCurrencyId, Date date, Boolean enable);

	/**
	 * 获取汇率。注意这个接口会过滤enable属性（汇率被禁用就得到null），若要获取不限定enable的汇率，请调用find(String,String,Date,Boolean)方法
	 * 
	 * @param originCurrencyId
	 *            被兑换币别id，输入null直接返回null
	 * @param targetCurrencyId
	 *            兑换目标币别id，输入null直接返回null
	 * @param date
	 *            指定日期，输入null则默认取当天
	 * @return
	 */
	BigDecimal getRate(String originCurrencyId, String targetCurrencyId, Date date);

	/**
	 * 指定日期汇率换算，只取有效的。日期字段输入null则取当天。
	 * 
	 * @param date
	 *            兑换日期，输入null则取当天
	 * @param originCurrencyId
	 *            被兑换币别id，输入null直接返回null
	 * @param targetCurrencyId
	 *            兑换目标币别id，输入null直接返回null
	 * @param originCurrencyAmount
	 *            兑换金额（被兑换币别的金额），输入null直接返回null
	 * @return 可兑金额（目标币别的金额）。如果没有配置汇率兑换信息，或者配置的信息不完整不合法（数据为null或除数为0等），就返回null
	 */
	BigDecimal exchange(String originCurrencyId, String targetCurrencyId, BigDecimal originCurrencyAmount, Date date);

	/**
	 * vo: 汇率
	 * 
	 * @author jiangshaoh
	 *
	 */
	public static interface CurrRate extends SceoProfileVo {
		/**
		 * 有效日期
		 * 
		 * @return
		 */
		Date getBegin();

		/**
		 * 失效日期
		 * 
		 * @return
		 */
		Date getEnd();

		/**
		 * 被兑币别id
		 * 
		 * @return
		 */
		String getOriginCurrencyId();

		/**
		 * 目标币别id
		 * 
		 * @return
		 */
		String getTargetCurrencyId();

		/**
		 * 汇率（以1为基数）——注意，edm的设计可能是以unit字段为基数，但本vo隐藏了unit属性，默认以1位基数。
		 * 
		 * @return
		 */
		BigDecimal getRate();

		/**
		 * 输入被兑币别金额，计算目标币别金额。本质上就是originCurrencyAmount * getRate()
		 * 
		 * @param originCurrencyAmount
		 * @return
		 */
		BigDecimal exchange(BigDecimal originCurrencyAmount);

	}

}
