package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.CurrencyService.Currency;

/**
 * 基础资料公共接口（开放接口）：币别管理
 * 
 * @author jiangshaoh
 *
 */
public interface CurrencyService extends IdFinder<Currency> {

	/**
	 * 根据系统编码查询特定币别对象。币别是互联互通资料，其系统编码在互联互通中保持不变，可根据系统编码查询
	 * 
	 * @param code
	 *            系统编码，不可输入null
	 * @return 特定币别对象
	 */
	Currency findByCode(String code);

	/**
	 * 综合条件查询币别列表
	 * 
	 * @param name
	 *            币别名称，模糊查询条件，输入null则不限名称
	 * @param enable
	 *            是否有效，输入null则取所有（有效的和无效的）
	 * @return 符合条件的币别列表
	 */
	List<Currency> list(String name, Boolean enable);

	/**
	 * vo:币别
	 */
	public static interface Currency extends SceoProfileVo {

		/**
		 * 系统编码，对应edm字段Curr_sys_code
		 * 
		 * @return
		 */
		String getCode();

		/**
		 * 币别名称
		 * 
		 * @return
		 */
		String getName();

		/**
		 * 币别代码，对应edm字段Curr_code（区别于“系统编码”，这个“币别代码”是相对于“币别名称”的易记易写的供人交流沟通的代码，未必是国际通行的，很可能是一个行业或企业内的惯例简称，如“人民币”记为“RMB”）
		 * 
		 * @return
		 */
		String getCodeName();

		/**
		 * 货币符号
		 * 
		 * @return
		 */
		String getSymbol();
	}

}
