package com.huntkey.rx.sceo.profile.common.service;

public interface IdFinder<T extends SceoProfileVo> {
	/**
	 * 根据id查询特定对象。若输入的id为null或空串，则直接返回null；若未查询到数据，则返回null；
	 * 
	 * @param id
	 *            对象在数据库中的id，若输入null或空串，则直接返回null
	 * @return 特定id的对象
	 */
	T find(String id);
}
