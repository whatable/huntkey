package com.huntkey.rx.sceo.profile.common.service;

import java.math.BigDecimal;
import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.MeasureunitService.Measure;

/**
 * 基础资料公共接口（开放接口）：计量单位管理
 * 
 * @author jiangshaoh
 *
 */
public interface MeasureunitService extends IdFinder<Measure> {

	/**
	 * 查询所有计量对象（也称为“计量单位分组”），可指定是否有效
	 * 
	 * @param enable
	 *            是否有效，输入null则取全部
	 * @return 符合有效性设定的所有计量对象
	 */
	List<Measure> find(Boolean enable);

	/**
	 * 根据计量id获取其下所有单位对象，可指定是否有效
	 * 
	 * @param measureId
	 *            计量id，不可输入null
	 * @param enable
	 *            是否有效，输入null则取全部
	 * @return 符合条件的计量对象列表
	 */
	List<Unit> getUnits(String measureId, Boolean enable);

	/**
	 * 根据计量分组的id或名称加上单位的名称，获取计量分组id加单位符号
	 * 
	 * @param measureIdOrName
	 *            计量分组的id或名称
	 * @param unitName
	 *            单位的名称如“千克”“平方米”
	 * @return 计量分组id加单位符号，分别存在数组的0、1索引处
	 */
	String[] getUnitSymbol(String measureIdOrName, String unitName);

	/**
	 * vo:计量（又称：计量单位分组、计量对象）
	 * 
	 * @author jiangshaoh
	 *
	 */
	public static interface Measure extends SceoProfileVo {
		/**
		 * 计量名称（计量分组名称）——特别注意：在edm模型中，meas_obj才是计量名称，另一个meas_name字段记录的是基准计量名称。也就是说这个属性实际对应meas_obj而不是meas_name
		 * 
		 * @return
		 */
		String getName();

		/**
		 * 基准单位名称。对应emd模型的meas_name字段。
		 * 
		 * @return
		 */
		String getDatumName();
	}

	/**
	 * vo:单位（又称：计量单位）
	 * 
	 * @author jiangshaoh
	 *
	 */
	public static interface Unit extends SceoProfileVo {
		/**
		 * 符号
		 * 
		 * @return
		 */
		String getSymbol();

		/**
		 * 名称
		 * 
		 * @return
		 */
		String getName();

		/**
		 * 制式
		 * 
		 * @return
		 */
		int getType();

		/**
		 * 小数点位数
		 * 
		 * @return
		 */
		int getRadixNum();

		/**
		 * 小数点归整方法
		 * 
		 * @return
		 */
		String getRadixPut();

		/**
		 * 与基准单位级差
		 * 
		 * @return
		 */
		BigDecimal getStage();

		/**
		 * 换算率
		 * 
		 * @return
		 */
		BigDecimal getRate();

		/**
		 * 是否基准单位
		 * 
		 * @return
		 */
		boolean isBase();
	}

}
