package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;

import com.huntkey.rx.edm.entity.AreaEntity;

/**
 * 为了在一段时间内兼容前端的区域级联选择控件，特意制作发布本组件，专为前述控件提供数据。严禁其他业务模块或新开发的模块调用本组件。
 * 
 * @author jiangshaoh
 *
 */
@Deprecated
public interface OldAreaService {

	/**
	 * 获取中国所有的省。严禁新开发的模块调用本接口。
	 * 
	 * @return
	 */
	public List<AreaFat> getProvinces() throws Exception;

	/**
	 * 根据上级区域id获取所有直接子级区域，支持省找市、市找区县，如果有下级节点则children字段为空列表[]，否则为空对象null。严禁新开发的模块调用本接口。
	 * 
	 * @param pid
	 * @return
	 */
	public List<AreaThin> getCityByProvince(String pid) throws Exception;

	/**
	 * 为了兼容前端公共控件，特意设计此vo，任何模块即日起的新版本中不得调用此类。
	 * 
	 * @author jiangshaoh
	 *
	 */
	@Deprecated
	public static class AreaThin {
		private AreaEntity e;
		private List<AreaThin> children;

		public AreaThin(AreaEntity e) {
			this.e = e;
		}

		public String getCaution() {
			return "不建议使用的数据";
		}

		public String getId() {
			return e.getId();
		}

		public String getGare_name() {
			return e.getArea_name();
		}

		public String getParentId() {
			return e.getArea_parent_area();
		}

		public List<AreaThin> getChildren() {
			return children;
		}

		public void setChildren(List<AreaThin> children) {
			this.children = children;
		}
	}

	/**
	 * 为了兼容前端公共控件，特意设计此vo，任何模块即日起的新版本中不得调用此类。
	 * 
	 * @author jiangshaoh
	 *
	 */
	@Deprecated
	public static class AreaFat {
		private AreaEntity e;

		public AreaFat(AreaEntity e) {
			this.e = e;
		}

		public String getCaution() {
			return "不建议使用的数据";
		}

		public String getId() {
			return e.getId();
		}

		public String getCreuser() {
			return e.getCreuser();
		}

		public Long getCretime() {
			return e.getCretime() == null ? null : e.getCretime().getTime();
		}

		public String getModuser() {
			return e.getModuser();
		}

		public Long getModtime() {
			return e.getModtime() == null ? null : e.getModtime().getTime();
		}

		public String getEcos_code() {
			return "";
		}

		public String getEcos_class_ecos() {
			return "area";
		}

		public String getEcos_parent_ecos() {
			return null;
		}

		public String getEcos_logic_del() {
			return "";
		}

		public String getEcos_idres_server() {
			return "";
		}

		public String getGinf_code() {
			return e.getInfo_code();
		}

		public String getGinf_name() {
			return e.getInfo_name();
		}

		public String getGinf_desc() {
			return e.getInfo_desc();
		}

		public String getGare_idcode() {
			return e.getArea_idcode();
		}

		public String getGare_code() {
			return e.getArea_code();
		}

		public String getGare_name() {
			return e.getArea_name();
		}

		public String getGare_parent_area() {
			return e.getArea_parent_area();
		}

		public String getGare_level() {
			return e.getArea_level();
		}

		public Integer getGare_order() {
			return e.getArea_order();
		}

		public String getGare_desc() {
			return e.getArea_desc();
		}
	}
}
