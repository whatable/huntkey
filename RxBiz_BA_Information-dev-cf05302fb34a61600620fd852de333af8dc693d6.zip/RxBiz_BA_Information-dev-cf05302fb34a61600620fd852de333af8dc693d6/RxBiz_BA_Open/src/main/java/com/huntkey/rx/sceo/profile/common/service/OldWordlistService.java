package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;
import java.util.Map;

/**
 * 兼容接口，重现了以前其他业务模块提供的并且被较广泛使用的基础资料接口，主要用于支持已经开发的公共控件或业务模块。强烈不建议新开发的模块使用本接口，而建议采用{@link WordlistService}，若具体API不满足场景需求，可明确提出需求。
 * 
 * @author jiangshaoh
 *
 */
@Deprecated
public interface OldWordlistService {
	/**
	 * @param codes
	 * @return
	 * @throws Exception
	 */
	Map<String, List<Map<String, Object>>> getEnumObjectsByCodes(String... codes) throws Exception;

	Map<String, Object> getEnumObject(String parCode, String code)throws Exception;
}
