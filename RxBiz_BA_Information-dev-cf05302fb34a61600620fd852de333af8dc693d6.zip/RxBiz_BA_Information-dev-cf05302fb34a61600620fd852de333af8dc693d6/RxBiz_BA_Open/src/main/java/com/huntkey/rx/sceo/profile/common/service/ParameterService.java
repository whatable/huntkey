package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.ParameterService.Parameter;

/**
 * 基础资料公共接口（开放接口）：参数管理
 * 
 * @author jiangshaoh
 *
 */
public interface ParameterService extends IdFinder<Parameter> {

	/**
	 * 是否标准系统
	 * 
	 * @return
	 */
	boolean isStandardSystem();

	/**
	 * 【调试用】切换标准系统。业务系统严禁调用本方法！
	 * 
	 * @return
	 */
	boolean switchSystemStandard();

	/**
	 * 获取关联某个表单页面的、指定信息类别和有效性的参数对象
	 * 
	 * @param formCode
	 *            表单编码，不建议输入null，输入null不表示此条件不限定，而是返回空列表
	 * @param type
	 *            参数类别，输入null则表示不限定
	 * @param enable
	 *            是否有效，输入null则表示不限定
	 * @return 符合条件的提示参数对象列表
	 */
	List<Parameter> find(String formCode, String type, Boolean enable);

	/**
	 * 根据参数编码获取特定参数对象，只取有效的
	 * 
	 * @param code
	 *            参数编码，唯一的，不可输入null
	 * @return 特定编码的参数对象
	 */
	Parameter findByCode(String code);

	/**
	 * vo:参数
	 * 
	 * @author jiangshaoh
	 *
	 */
	interface Parameter extends SceoProfileVo {
		/**
		 * 参数编码（对应edm的parm_no字段）
		 * 
		 * @return
		 */
		String getCode();

		/**
		 * 参数名称
		 * 
		 * @return
		 */
		String getName();

		/**
		 * 参数值
		 * 
		 * @return
		 */
		String getValues();

		/**
		 * 类别
		 * 
		 * @return
		 */
		String getType();

	}
}
