package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.ParkService.Park;

/**
 * 基础资料公共接口（开放接口）：园区管理
 * 
 * @author jiangshaoh
 *
 */
public interface ParkService extends IdFinder<Park> {

	/**
	 * 查询默认园区对象
	 * 
	 * @return 默认园区对象
	 */
	Park findDefault();

	/**
	 * 查询本司所有园区对象
	 * 
	 * @param name
	 *            园区名称，输入null则查询所有
	 * @param enable
	 *            是否有效，输入null则查询所有
	 * @return 园区对象列表
	 */
	List<Park> find(String name, Boolean enable);

	/**
	 * 根据id查询特定交货地址对象
	 * 
	 * @param id
	 *            交货地址对象id
	 * @return 交货地址对象
	 */
	DeliveryAddress findDeliveryAddress(String id);

	/**
	 * vo: 园区
	 * 
	 * @author jiangshaoh
	 *
	 */
	interface Park extends SceoProfileVo {
		String getName();

		String getCode();

		boolean isDefault();

		String getAddress();

		String getAddressProvince();

		String getAddressCity();

		String getAddressDistrict();

		/**
		 * 交货地址列表
		 * 
		 * @return
		 */
		List<DeliveryAddress> getDeliveryAddress();
	}

	/**
	 * vo: 交货地址
	 * 
	 * @author jiangshaoh
	 *
	 */
	interface DeliveryAddress extends SceoProfileVo {
		/**
		 * 位置，即edm模型中的“详细地址”，映射rpak_addrl字段
		 * 
		 * @return
		 */
		String getLocation();

		/**
		 * 联系人
		 * 
		 * @return
		 */
		String getContact();

		/**
		 * 联系方式
		 * 
		 * @return
		 */
		String getContactWay();
	}

}
