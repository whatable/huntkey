package com.huntkey.rx.sceo.profile.common.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.huntkey.rx.sceo.profile.common.service.PeriodService.Period;

/**
 * 基础资料公共接口（开放接口）：周期管理
 * 
 * @author jiangshaoh
 *
 */
public interface PeriodService extends IdFinder<Period> {

	/**
	 * 根据综合条件查询不定量周期对象
	 * 
	 * @param fiscalYear
	 *            财年，输入null则查询所有财年
	 * @param periodType
	 *            周期类型，输入null则查询所有类型
	 * @param sequence
	 *            期次，输入null则查询所有期次
	 * @param enable
	 *            是否有效，输入null则查询所有（有效的和无效的）
	 * @return 符合条件的周期对象列表
	 */
	List<Period> find(Integer fiscalYear, PeriodType periodType, Integer sequence, Boolean enable);

	/**
	 * 根据财年、周期类型、周期序数三个条件唯一确定一个周期对象  【by jiangshaoh@2018-8-1新增】
	 * 
	 * @param fiscalYear
	 *            年份数字，如2001,2018,2020等
	 * @param periodType
	 *            周期类型，输入null则默认取财月PeriodType.FISCAL_MONTH
	 * @param period
	 *            一个财年中的周期序数，如月是1,2,3,...,12，周是1,2,3,...,54，季是1,2,3,4，如果周期类型是年，这个位置可输入任意数字（建议输入1）
	 * @return
	 */
	Period find(int fiscalYear, PeriodType periodType, int period);

	/**
	 * 给定一个日期值（日历日期），并指定周期类型，可以查询得到对应的周期对象。只取有效的。
	 * 
	 * @param date
	 *            给定日期值，输入null则默认取当天
	 * @param periodType
	 *            周期类型，不可为null
	 * @return 对应的周期对象
	 */
	Period find(Date date, PeriodType periodType);

	/**
	 * 查询当天对应的、指定周期类型的周期对象。只取有效的。
	 * 
	 * @param periodType
	 *            周期类型，不可为null
	 * @return 对应的周期对象
	 */
	Period findToday(PeriodType periodType);

	/**
	 * 获取财务型周期类型列表（财周、财月、财季、财年） by jiangshaoh@2018-7-27新增
	 * 
	 * @return
	 */
	List<PeriodType> getFiscalTypes();

	/**
	 * 获取日历型周期类型列表（日历周、日历月、日历季、日历年） by jiangshaoh@2018-7-27新增
	 * 
	 * @return
	 */
	List<PeriodType> getCalendarTypes();

	/**
	 * @param type
	 * @param years
	 * @return
	 */
	Map<String, String> findByTypeInYears(PeriodType type, Integer... years);

	/**
	 * 输入周期id，获取其日历起止点，如可输入某个财月或某个日历季等 by jiangshaoh@2018-7-27新增
	 * 
	 * @param headPeriodId
	 *            起始周期数据id，若输入null则返回null
	 * @param tailPeriodId
	 *            结束周期数据id，若输入null，则以起始周期为默认值
	 * 
	 * @return
	 */
	Date[] getRange(String headPeriodId, String tailPeriodId);

	/**
	 * 输入周期对象，获取其日历起止点 【by jiangshaoh@2018-8-1新增】
	 * 
	 * @param from
	 *            起始周期对象，取其日历起始，不可输入null
	 * @param to
	 *            截止周期对象，取其日历结束，输入null则以起始周期为默认值
	 * @return
	 */
	Date[] getRange(Period from, Period to);

	/**
	 * 周期类型枚举
	 * 
	 * @author jiangshaoh
	 *
	 */
	public static enum PeriodType {
		YEAR("年"), QUARTER("季"), MONTH("月"), WEEK("周"), FISCAL_YEAR("财年"), FISCAL_QUARTER("财季"), FISCAL_MONTH(
				"财月"), FISCAL_WEEK("财周");
		private String zhName;

		private PeriodType(String zhName) {
			this.zhName = zhName;
		}

		public String zhName() {
			return zhName;
		}

	}

	/**
	 * vo: 周期
	 * 
	 * @author jiangshaoh
	 *
	 */
	interface Period extends SceoProfileVo {
		String getName();

		String getFiscalName();

		String getCalendarName();

		Date getStart();

		Date getEnd();

		int getPeriod();

		int getFiscalYear();
	}
}
