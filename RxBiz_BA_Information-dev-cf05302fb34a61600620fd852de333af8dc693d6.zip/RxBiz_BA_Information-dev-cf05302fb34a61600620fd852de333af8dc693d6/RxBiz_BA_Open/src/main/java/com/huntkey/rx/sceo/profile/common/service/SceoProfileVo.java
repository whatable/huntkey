package com.huntkey.rx.sceo.profile.common.service;

/**
 * Sceo2.0 基础资料各类vo共有的定义，各个vo接口都继承本接口，本接口主要提供id,enable,standard等共有属性的定义
 * 
 * @author jiangshaoh
 *
 */
public interface SceoProfileVo {
	String getId();

	boolean isEnable();

	boolean isStandard();
}
