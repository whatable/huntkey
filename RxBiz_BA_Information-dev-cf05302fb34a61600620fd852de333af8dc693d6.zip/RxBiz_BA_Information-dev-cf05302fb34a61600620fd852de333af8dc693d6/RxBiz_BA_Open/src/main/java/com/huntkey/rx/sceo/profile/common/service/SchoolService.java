package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.SchoolService.School;

/**
 * 基础资料公共接口（开放接口）：学校管理
 *
 * @author jiangshaoh
 *
 */
public interface SchoolService extends IdFinder<School> {

	/**
	 * 综合条件查询不定量学校对象
	 *
	 * @param name
	 *            学校名，模糊查询条件，输入null则不限名称
	 * @param areaId
	 *            学校所在地区域id，输入null则取不限区域
	 * @param enable
	 *            是否有效，输入null则查询所有（有效的和无效的）
	 * @return 符合条件的学校对象列表
	 */
	List<School> list(String name, String areaId, Boolean enable);

	/**
	 * vo: 学校
	 *
	 * @author jiangshaoh
	 *
	 */
	interface School extends SceoProfileVo {
		String getName();

		String getCode();

		String getRanking();
	}
}
