package com.huntkey.rx.sceo.profile.common.service;

import java.math.BigDecimal;
import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.TaxrateService.Taxrate;

/**
 * 基础资料公共接口（开放接口）：税率管理
 * 
 * @author jiangshaoh
 *
 */
public interface TaxrateService extends IdFinder<Taxrate> {

	/**
	 * 根据code查询特定税率对象。系统编码code是互联互通字段，特提供根据系统编码精确查询
	 * 
	 * @param code
	 *            系统编码，精确查询条件，唯一确定一条税率
	 * @return 特定税率对象
	 */
	Taxrate findByCode(String code);

	/**
	 * 综合条件查询税率对象
	 * 
	 * @param name
	 *            税率名称，模糊查询条件，输入null则不限
	 * @param isDeduct
	 *            是否抵扣，输入null则不限
	 * @param enable
	 *            是否有效，输入null则查询所有（有效的和无效的）
	 * @return 符合条件的税率对象列表
	 */
	List<Taxrate> find(String name, Boolean isDeduct, Boolean enable);

	/**
	 * vo: 税率
	 * 
	 * @author jiangshaoh
	 *
	 */
	interface Taxrate extends SceoProfileVo {
		String getName();

		String getCode();

		/**
		 * 是否可抵扣
		 * 
		 * @return
		 */
		boolean isDeduct();

		/**
		 * 税率值
		 * 
		 * @return
		 */
		BigDecimal getDetail();

	}
}
