package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;

import com.huntkey.rx.sceo.profile.common.service.TipmessageService.Tipmessage;

/**
 * 基础资料公共接口（开放接口）：提示信息管理
 * 
 * @author jiangshaoh
 *
 */
public interface TipmessageService extends IdFinder<Tipmessage> {
	/**
	 * 获取关联某个页面的、指定信息类别和有效性的提示信息
	 * 
	 * @param page
	 *            页面编码，不建议输入null，输入null不表示此条件不限定，而是返回空列表
	 * @param type
	 *            信息类别，输入null则表示不限定
	 * @param enable
	 *            是否有效，输入null则表示不限定
	 * @return 符合条件的提示信息对象列表
	 */
	List<Tipmessage> find(String page, String type, Boolean enable);

	/**
	 * vo: 提示信息
	 * 
	 * @author jiangshaoh
	 *
	 */
	interface Tipmessage extends SceoProfileVo {
		String getCode();

		String getType();

		/**
		 * 显示时间
		 * 
		 * @return
		 */
		int getShowTime();

		/**
		 * 信息内容，形如“订单提交成功,单号{1},价格{2},总价{3}”
		 * 
		 * @return
		 */
		String getBaseMsg();

		/**
		 * 自定义信息内容，形如“订单提交成功,单号{1},价格{2},总价{3}”
		 * 
		 * @return
		 */
		String getShowMsg();
	}
}
