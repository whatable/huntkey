package com.huntkey.rx.sceo.profile.common.service;

import java.util.List;
import java.util.Map;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.sceo.profile.common.service.WordlistService.Wordlist;

/**
 * 基础资料公共接口（开放接口）：枚举管理
 * 
 * @author jiangshaoh
 *
 */
public interface WordlistService extends IdFinder<Wordlist> {

	/**
	 * 根据编码获取不定量枚举关键字
	 * 
	 * @param enable
	 *            是否有效，输入null则取全部
	 * @param codes
	 *            编码（数据库中的info_code字段）
	 * @return 枚举关键字列表
	 */
	List<Wordlist> findKeysByCodes(Boolean enable, String... codes);

	/**
	 * 查询所有枚举关键字(word_par为空)，可指定是否有效。特别注意，只取关键字，而不是所有的枚举对象，获取所有枚举对象的集合是没有实用意义的。
	 * 
	 * @param name
	 *            枚举名称，输入null则不限定
	 * @param enable
	 *            是否有效，输入null则取全部
	 * @return 枚举关键字列表
	 */
	List<Wordlist> find(String name, Boolean enable);

	/**
	 * 以编码和名称作为过滤条件获取不定量枚举关键字，编码是精确条件，名称是模糊条件
	 * 
	 * (新增by jiangshaoh @2018-7-17)
	 * 
	 * @param enable
	 *            是否有效，输入null则取全部
	 * @param name
	 *            枚举名，模糊过滤条件
	 * @param codes
	 *            编码，精确条件
	 * @return
	 */
	List<Wordlist> find(String name, Boolean enable, String... codes);

	/**
	 * 分页查询所有枚举关键字(word_par为空)，可指定是否有效。特别注意，只取关键字，而不是所有的枚举对象，获取所有枚举对象的集合是没有实用意义的。
	 * 
	 * @param enable
	 *            是否有效，输入null则取全部
	 * @param pageNum
	 *            分页页码，输入null则取1，输入对结果的影响规则暂与orm的处理规则一致
	 * @param pageSize
	 *            分页页大小，输入null则取15，输入对结果的影响规则暂与orm的处理规则一致
	 * @return
	 */
	Pagination<Wordlist> find(Boolean enable, Integer pageNum, Integer pageSize);

	/**
	 * 分页查询所有枚举关键字(word_par为空)，可指定是否有效。特别注意，只取关键字，而不是所有的枚举对象，获取所有枚举对象的集合是没有实用意义的。
	 * 
	 * @param name
	 *            枚举名称，输入null则不限定
	 * @param enable
	 *            是否有效，输入null则取全部
	 * @param pageNum
	 *            分页页码，输入null则取1，输入对结果的影响规则暂与orm的处理规则一致
	 * @param pageSize
	 *            分页页大小，输入null则取15，输入对结果的影响规则暂与orm的处理规则一致
	 * @return
	 */
	Pagination<Wordlist> find(String name, Boolean enable, Integer pageNum, Integer pageSize);

	/**
	 * 分页查询枚举关键字，除了可指定名称、是否有效等，同时还可以指定枚举的结构（1:列表；2:树） 【新增】by jiangshaoh@2018-7-28
	 * 
	 * @param type
	 *            枚举的结构（1:列表；2:树），其他值会查不到数据
	 * @param name
	 * @param enable
	 * @param pageNum
	 * @param pageSize
	 * @return
	 */
	Pagination<Map<String, Object>> find(Integer type, String name, Boolean enable, Integer pageNum, Integer pageSize);

	/**
	 * 判断枚举结构类型
	 * 
	 * @param id
	 *            枚举数据对象id
	 * @return 指定枚举的结构类型
	 */
	WordlistType typeOf(String id);

	/**
	 * 判断枚举结构类型
	 * 
	 * @param wordlist
	 *            枚举对象
	 * @return 指定枚举的结构类型
	 */
	WordlistType typeOf(Wordlist wordlist);

	/**
	 * 指定枚举关键字id，获取其枚举项，拼装为列表返回。建议先调用typeOf()方法预判数据的内在形式（树或枚举）
	 * 
	 * @param id
	 *            枚举关键字id，不可输入null
	 * @param enable
	 *            是否有效，若输入null则查询所有（有效和无效的）
	 * @return
	 */
	List<Wordlist> getOptions(String id, Boolean enable);

	/**
	 * 指定关键枚举，获取其枚举项，拼装为列表返回。建议先调用typeOf()方法预判数据的内在形式（树或枚举）
	 * 
	 * @param wordlist
	 *            关键枚举对象，不可输入null
	 * @param enable
	 *            是否有效，若输入null则查询所有（有效和无效的）
	 * @return
	 */
	List<Wordlist> getOptions(Wordlist wordlist, Boolean enable);

	/**
	 * 用枚举关键字（大枚举）编码、枚举项（小枚举）名称等条件查询枚举项（仅枚举项）。因为涉及到多层查询，所以不设enable条件，因为会引起困扰。该查询只取enable=1的数据。
	 * 
	 * @param codes
	 *            枚举关键字编码，多个用逗号隔开，精确查询条件，若输入null则方法直接返回空列表
	 * @param name
	 *            枚举项名称，模糊过滤条件
	 * @return 枚举项列表。codes输入null或数组长度为0则直接返回空列表
	 */
	List<Wordlist> getOptions(String[] codes, String name);

	/**
	 * 根据枚举id和子节点枚举code，查询子节点
	 * @param id 枚举id
	 * @param childCode 子节点枚举code
	 * @param enable 子节点枚举是否启用
	 * @return
	 */
	Wordlist getEnumChild(String id, String childCode, Boolean enable);


	/**
	 * 根据大枚举code和小枚举code，查询小枚举; 如果小枚举code是用“,”分割的多个code字符串，则返回多个枚举
	 * @param parCode 大枚举code
	 * @param code 小枚举code
	 * @return
	 */
	List<Map<String, Object>> getEnumObject(String parCode, String code);

	/**
	 * 根据枚举id集合查询枚举
	 * @param ids 枚举id集
	 * @return
	 */
	List<Wordlist> getWordlistByIds(String ids);

	/**
	 * 枚举内在结构。判断的依据是首先测试有无下级枚举对象，若有下级，那么根据有没有更深的下级：1、不再有下级，则为ENUM；2、仍有至少一级下级，则为TREE；
	 * 若无下级，那么根据有无上级：1、有上级，则为ELEMENT；2、无上级，则为ISOLATED
	 * 
	 * <table border=1>
	 * <tr>
	 * ; *
	 * <td rowspan=2>只有1级下级</td>
	 * <td rowspan=2>有超过1级下级</td>
	 * <td colspan=2>无下级</td>
	 * </tr>
	 * <tr>
	 * <td>有上级</td>
	 * <td>无上级</td>
	 * </tr>
	 * <tr>
	 * <td>ENUM</td>
	 * <td>TREE</td>
	 * <td>ELEMENT</td>
	 * <td>ISOLATED</td>
	 * </tr>
	 * </table>
	 * 
	 * @author jiangshaoh
	 *
	 */
	public static enum WordlistType {
		/**
		 * 枚举（无嵌套，单层多元素的结构）
		 */
		ENUM,
		/**
		 * 树（有嵌套的、多层级联的结构）
		 */
		TREE,
		/**
		 * 单一元素（枚举ENUM的一个元素或树TREE的一个叶子节点）
		 */
		ELEMENT,
		/**
		 * 孤立元素（无上下级，可能是未配置完成的数据）
		 */
		ISOLATED
	}

	/**
	 * vo: 枚举
	 * 
	 * @author jiangshaoh
	 *
	 */
	interface Wordlist extends SceoProfileVo {
		String getName();

		int getSequence();

		String getParentId();

		/**
		 * 枚举项层级（枚举项是树结构）
		 * 
		 * @return
		 */
		int getLevel();
	}

}
