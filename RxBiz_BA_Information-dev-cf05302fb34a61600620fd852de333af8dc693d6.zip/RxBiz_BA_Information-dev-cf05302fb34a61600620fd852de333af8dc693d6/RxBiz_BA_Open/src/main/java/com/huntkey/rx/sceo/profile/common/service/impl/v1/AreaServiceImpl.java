package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.*;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.string.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.constant.AreaProperty;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.AreaService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.AREA)
public class AreaServiceImpl implements AreaService {

	@Autowired
	private OrmService orm;

	@Override
	public Area find(String id) {
		AreaImpl a = new AreaImpl();
		try {
			a.e = orm.load(AreaEntity.class, id);
			if (a.e == null) {
				return null;
			}
			setAreaLevel(a);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return a.e == null ? null : a;
	}

	@Override
	public List<Area> find(String id, Boolean enable, Integer depth) {
		String areaEnable = enable == null ? null :(enable?"1":"0");
		try {
			List<Area> areaList = getAreas(depth, areaEnable, id);
			return areaList;

		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	@Override
	public List<Area> findChain(String id) {
		if(StringUtil.isNullOrEmpty(id)){
			return null;
		}
		List<Area> entities = new LinkedList<>();
		return setAreaChain(entities,id);
	}

	@Override
	public Area findChina() {
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(OrmParam.or(ormParam.getEqualXML(AreaProperty.AREA_NAME, "中国"),
				ormParam.getEqualXML(AreaProperty.AREA_NAME, "中华人民共和国")));
		try {
			List<AreaEntity> list = orm.selectBeanList(AreaEntity.class, ormParam);
			if(list == null || list.size() == 0){
				return null;
			}
			AreaImpl area = new AreaImpl();
			area.e = list.get(0);
			return area;
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	@Override
	public List<Map<String, Object>> getAreaByPid(String pid, Boolean enable) {
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaProperty.AREA_PARENT_AREA,pid),
				ormParam.getEqualXML(AreaProperty.AREA_ENABLE,enable?"1":"0")));
        List<Map<String,Object>> areaList;
		try {
            List<AreaEntity> areaEntities = orm.selectBeanList(AreaEntity.class, ormParam);
            areaList = new ArrayList<>(areaEntities.size());
            if(areaEntities == null || areaEntities.size() == 0){
				return null;
			}
			for (AreaEntity areaEntity : areaEntities) {
				AreaImpl area = new AreaImpl();
				area.e = areaEntity;
				Map<String,Object> map = JSONObject.parseObject(JSONObject.toJSONString(area),Map.class);
                ormParam.setWhereExp(ormParam.getEqualXML(AreaProperty.AREA_PARENT_AREA,areaEntity.getId()));
                List<AreaEntity> list = orm.selectBeanList(AreaEntity.class, ormParam);
				if(list != null && list.size() > 0){
                    map.put("children", new ArrayList<>());
                }else{
                    map.put("children", null);
                }
				areaList.add(map);
			}
		}catch (Exception e){
			throw new OrmException(e);
		}
		return areaList;
	}


	private List<Area> setAreaChain(List<Area> entities,String id) {

		AreaEntity areaEntity ;
		try {
			areaEntity = orm.load(AreaEntity.class,id);
			if(areaEntity == null){
				return entities;
			}
		}catch (Exception e){
			throw new OrmException(e);
		}
		AreaImpl area = new AreaImpl();
		area.e = areaEntity;
		setAreaLevel(area);
		entities.add(area);
		if(!StringUtil.isNullOrEmpty(areaEntity.getArea_parent_area())){
			setAreaChain(entities,areaEntity.getArea_parent_area());
		}
		return entities;
	}

	/**
	 * 获取区域集合
	 *
	 * @param depth
	 * @param areaEnable
	 * @param id
	 * @return
	 */
	private List<Area> getAreas(Integer depth, String areaEnable, String id) {
		if(StringUtil.isNullOrEmpty(id)){
			return null;
		}
		List<Area> areaList = new LinkedList<>();
		if (depth == null || depth == 0) {
			depth = 2;
		}
		AreaEntity areaEntity;
		String[] areaLevel;
		try {
			areaEntity = orm.load(AreaEntity.class,id);
			if(areaEntity == null){
				return null;
			}
			areaLevel =areaEntity.getArea_level().split(",");
		}catch (Exception e){
			throw new OrmException(e);
		}
		StringBuilder sql = new StringBuilder("select id,area_parent_area,area_level,area_order,area_desc,area_code,area_name,area_enable,area_is_standard from area where ");
		for (int i=1;i <= areaLevel.length;i++) {
			/**
			 * 	拼接查询条件，以安徽省为例，i=1时的查询条件为：and sunstr(area_level,1,3) = '001'
			 * 	i = 2 时的查询条件为：and sunstr(area_level,1,3) = '001' and substr(area_level,5,3) = '012'
			 */
			if(i > 1){
				sql.append(" and ");
			}
			sql.append("SUBSTR(area_level,"+(1+4*(i-1))+",3) = '"+areaLevel[i-1]+"'");
		}
		int levelLength = 0;
		if(areaEntity.getArea_level().length()%2 == 0){
			levelLength = areaEntity.getArea_level().length() + (depth-1) * 4;
		}else{
			levelLength = areaEntity.getArea_level().length() + 1 + (depth-1) * 4;
		}
		sql.append(" and ").append("CHAR_LENGTH(area_level) <= "+levelLength+"");
		if(areaEnable!=null){
			sql.append(" and ").append("area_enable = '"+areaEnable+"'");
		}
		List<AreaEntity> entities ;
		try {
			List<Map<String,Object>> mapList = orm.getDataBySql(sql.toString());
			entities = JSONObject.parseArray(JSONObject.toJSONString(mapList),AreaEntity.class);
		}catch (Exception e){
			throw new OrmException(e);
		}
		Iterator it = entities.iterator();
		while (it.hasNext()){
			AreaEntity entity = (AreaEntity) it.next();
//			if(entity.getArea_level().split(",").length <= (depth -1) + areaLevel.length){
				AreaImpl area = new AreaImpl();
				area.e = entity;
				setAreaLevel(area);
				areaList.add(area);
//			}
		}
		return areaList;
	}

	/**
	 * 设置区域等级；1、国家，2、省，3、市，4、区县，5、镇，6、村
	 *
	 * @param areaImpl
	 */
	private void setAreaLevel(AreaImpl areaImpl) {
		String level = areaImpl.e.getArea_level();
		areaImpl.level = level.split(",").length;
	}

	/**
	 * Area vo的一个实现，内置了AreaEntity
	 *
	 * @author jiangshaoh
	 *
	 */
	private static class AreaImpl implements Area {
		AreaEntity e;
		int level;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public String getName() {
			return e.getArea_name();
		}

		@Override
		public String getCode() {
			return e.getArea_code();
		}

		@Override
		public String getDesc() {
			return e.getArea_desc();
		}

		@Override
		public boolean isEnable() {
			return "true".equalsIgnoreCase(e.getArea_enable()) || "1".equalsIgnoreCase(e.getArea_enable());
		}

		@Override
		public String getParentId() {
			return e.getArea_parent_area();
		}

		@Override
		public int getLevel() {
			return level;
		}

		@Override
		public String getAreaLevel() {
			return e.getArea_level();
		}

		@Override
		public boolean isStandard() {
			return new Integer(1).equals(e.getArea_is_standard());

		}
	}

}
