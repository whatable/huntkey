package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.currency.CurrRateConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.CurrRateService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.CURR_RATE)
public class CurrRateServiceImpl implements CurrRateService {

	@Autowired
	OrmService orm;

	@Override
	public CurrRate find(String id) {
		CurrRateImpl cr = new CurrRateImpl();
		try {
			cr.e = orm.load(CurrCurrRateSetaEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return cr.e == null ? null : cr;
	}

	@Override
	public List<CurrRate> find(String originCurrencyId, String targetCurrencyId, Date date, Boolean enable) {
		String rateEnable = enable == null ? null : (enable ? "1" : "0");
		List<CurrCurrRateSetaEntity> entityList = queryCurrRates(originCurrencyId, targetCurrencyId, date, rateEnable);
		if (entityList == null || entityList.size() == 0) {
			return null;
		}
		List<CurrRate> list = new ArrayList<>(entityList.size());
		for (CurrCurrRateSetaEntity entity : entityList) {
			CurrRateImpl currRate = new CurrRateImpl();
			currRate.e = entity;
			list.add(currRate);
		}
		return list;
	}

	private List<CurrCurrRateSetaEntity> queryCurrRates(String originCurrencyId, String targetCurrencyId, Date date,
			String rateEnable) {
		OrmParam ormParam = new OrmParam();
		StringBuilder whereExp = new StringBuilder();
		if (!StringUtil.isNullOrEmpty(originCurrencyId)) {
			whereExp.append(" and ").append(ormParam.getEqualXML(BasicConst.PID, originCurrencyId));
		}
		if (!StringUtil.isNullOrEmpty(targetCurrencyId)) {
			whereExp.append(" and ").append(ormParam.getEqualXML(CurrRateConstant.CURR_CONV_CURR, targetCurrencyId));
		}
		if (date != null) {
			whereExp.append(" and ").append(ormParam.getLessThanAndEqualXML(CurrRateConstant.CURR_BEG, date));
			whereExp.append(" and (").append(ormParam.getGreaterThanXML(CurrRateConstant.CURR_END, date));
			whereExp.append(" or ").append(ormParam.getIsNull(CurrRateConstant.CURR_END)).append(")");
		}
		if (rateEnable != null) {
			whereExp.append(" and ").append(ormParam.getEqualXML(CurrRateConstant.CURR_RATE_ENABLE, rateEnable));
		}
		ormParam.setWhereExp(whereExp.toString());
		List<CurrCurrRateSetaEntity> entityList;
		try {
			entityList = orm.selectBeanList(CurrCurrRateSetaEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return entityList;
	}

	@Override
	public BigDecimal getRate(String originCurrencyId, String targetCurrencyId, Date date) {
		if (originCurrencyId == null || targetCurrencyId == null) {
			return null;
		}
		if (originCurrencyId.equals(targetCurrencyId)) {
			return new BigDecimal(1);
		}
		if (date == null) {
			date = new Date();
		}
		List<CurrCurrRateSetaEntity> entityList = queryCurrRates(originCurrencyId, targetCurrencyId, date, null);
		if (entityList == null || entityList.size() != 1) {
			return null;// 没有配置汇率或查出超过一条汇率（脏数据）就返回null
		}
		CurrRateImpl cr = new CurrRateImpl();
		cr.e = entityList.get(0);
		return cr.isEnable() ? cr.getRate() : null;// 过滤enable
	}

	@Override
	public BigDecimal exchange(String originCurrencyId, String targetCurrencyId, BigDecimal originCurrencyAmount,
			Date date) {
		BigDecimal rate = getRate(originCurrencyId, targetCurrencyId, date);
		return rate == null ? null : originCurrencyAmount.multiply(rate);
	}

	private static class CurrRateImpl implements CurrRate {
		CurrCurrRateSetaEntity e;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "1".equals(e.getCurr_rate_enable()) || "true".equalsIgnoreCase(e.getCurr_rate_enable());
		}

		@Override
		public boolean isStandard() {
			return false;// 汇率不存在标准数据，全是各企业自行设定。
		}

		@Override
		public Date getBegin() {
			return e.getCurr_beg();
		}

		@Override
		public Date getEnd() {
			return e.getCurr_end();
		}

		@Override
		public String getOriginCurrencyId() {
			return e.getPid();
		}

		@Override
		public String getTargetCurrencyId() {
			return e.getCurr_conv_curr();
		}

		@Override
		public BigDecimal getRate() {
			// 这个rate属性不同于数据库中的rate字段，这里是真正的汇率，数据库里那个其实是“（以unit为交易单位的）外汇价”
			BigDecimal unit = e.getCurr_conv_unit();
			BigDecimal price = e.getCurr_rate();
			if (unit == null || unit.compareTo(BigDecimal.ZERO) != 1 || price == null
					|| price.compareTo(new BigDecimal(0)) != 1) {
				return null;
			}
			return price.divide(unit).setScale(4, BigDecimal.ROUND_HALF_UP);
		}

		@Override
		public BigDecimal exchange(BigDecimal originCurrencyAmount) {
			return getRate().multiply(originCurrencyAmount);
		}
	}

}
