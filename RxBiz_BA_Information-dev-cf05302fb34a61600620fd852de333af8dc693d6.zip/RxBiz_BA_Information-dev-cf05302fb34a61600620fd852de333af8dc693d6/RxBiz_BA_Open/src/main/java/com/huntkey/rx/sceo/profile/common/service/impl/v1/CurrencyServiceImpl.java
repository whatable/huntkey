package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.ArrayList;
import java.util.List;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.sceo.common.model.currency.CurrencyConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.entity.CurrencyEntity;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.CurrencyService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

/**
 *
 */
@Service(_ProfileQualifiersV1.CURRENCY)
public class CurrencyServiceImpl implements CurrencyService {

	@Autowired
	OrmService orm;

	@Override
	public Currency find(String id) {
		CurrencyImpl c = new CurrencyImpl();
		try {
			c.e = orm.load(CurrencyEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return c.e == null ? null : c;
	}

	@Override
	public Currency findByCode(String sysCode) {
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(ormParam.getEqualXML(CurrencyConstant.CURR_SYS_CODE,sysCode));
		List<CurrencyEntity> entityList;
		try {
			entityList = orm.selectBeanList(CurrencyEntity.class,ormParam);
		}catch (Exception e){
			throw new OrmException(e);
		}
		if(entityList == null || entityList.size() == 0){
			return null;
		}
		CurrencyImpl currency = new CurrencyImpl();
		currency.e = entityList.get(0);
		return currency;
	}

	@Override
	public List<Currency> list(String name, Boolean enable) {
		String currEnable =enable == null ? null :(enable?"1":null);
		OrmParam ormParam = new OrmParam();
		String whereExp = "";
		if(!StringUtil.isNullOrEmpty(name)){
			whereExp = whereExp.concat(" and ").concat(ormParam.getMatchMiddleXML(CurrencyConstant.CURR_NAME,name));
		}
		if(currEnable != null){
			whereExp = whereExp.concat(" and ").concat(ormParam.getEqualXML(CurrencyConstant.CURR_ENABLE,currEnable));
		}
		ormParam.setWhereExp(whereExp);
		List<CurrencyEntity> entityList;
		try {
			entityList = orm.selectBeanList(CurrencyEntity.class,ormParam);
		}catch (Exception e){
			throw new OrmException(e);
		}
		if(entityList == null || entityList.size() == 0){
			return null;
		}
		List<Currency> currencies = new ArrayList<>();
		for (CurrencyEntity entity : entityList) {
			CurrencyImpl currency = new CurrencyImpl();
			currency.e = entity;
			currencies.add(currency);
		}
		return currencies;
	}

	private static class CurrencyImpl implements Currency {
		CurrencyEntity e;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "1".equals(e.getCurr_enable());
		}

		@Override
		public boolean isStandard() {
			return new Integer(1).equals(e.getCurr_is_standard());
		}

		@Override
		public String getCode() {
			return e.getCurr_sys_code();
		}

		@Override
		public String getName() {
			return e.getCurr_name();
		}

		@Override
		public String getCodeName() {
			return e.getCurr_code();
		}

		@Override
		public String getSymbol() {
			return e.getCurr_symbol();
		}
	}

}
