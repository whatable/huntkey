package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.MeasMeasDefineSetaProperty;
import com.huntkey.rx.edm.constant.MeasureunitProperty;
import com.huntkey.rx.edm.entity.MeasMeasDefineSetaEntity;
import com.huntkey.rx.edm.entity.MeasureunitEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.MeasureunitService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.MEASUREUNIT)
public class MeasureunitServiceImpl implements MeasureunitService {

	@Autowired
	OrmService orm;

	@Override
	public Measure find(String id) {
		if (id == null || id.isEmpty()) {
			return null;
		}
		MeasureImpl m = new MeasureImpl();
		try {
			m.e = orm.load(MeasureunitEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return m.e == null ? null : m;
	}

	@Override
	public List<Measure> find(Boolean enable) {
		String meaEnable = enable == null ? null : (enable ? "1" : "0");
		OrmParam ormParam = new OrmParam();
		if (!StringUtil.isNullOrEmpty(meaEnable)) {
			ormParam.setWhereExp(ormParam.getEqualXML(MeasureunitProperty.MEAS_ENABLE, meaEnable));
		}
		List<MeasureunitEntity> entities;
		try {
			entities = orm.selectBeanList(MeasureunitEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		if (entities == null || entities.size() == 0) {
			return null;
		}
		List<Measure> measureList = new ArrayList<>(entities.size());
		for (MeasureunitEntity entity : entities) {
			MeasureImpl measure = new MeasureImpl();
			measure.e = entity;
			measureList.add(measure);
		}
		return measureList;
	}

	@Override
	public List<Unit> getUnits(String measureId, Boolean enable) {
		if (measureId == null || measureId.isEmpty()) {
			return new LinkedList<Unit>();
		}
		String unitEnable = null;
		if (enable != null) {
			if (enable) {
				unitEnable = "1";
			} else {
				unitEnable = "0";
			}
		}
		OrmParam ormParam = new OrmParam();
		StringBuilder whereExp = new StringBuilder();
		if (!StringUtil.isNullOrEmpty(measureId)) {
			whereExp.append(" and ").append(ormParam.getEqualXML(BasicConst.PID, measureId));
		}
		if (!StringUtil.isNullOrEmpty(unitEnable)) {
			whereExp.append(" and ").append(ormParam.getEqualXML(MeasMeasDefineSetaProperty.MEAS_DENABLE, unitEnable));
		}
		ormParam.setWhereExp(whereExp.toString());
		List<MeasMeasDefineSetaEntity> entities;
		try {
			entities = orm.selectBeanList(MeasMeasDefineSetaEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		if (entities == null || entities.size() == 0) {
			return null;
		}
		List<Unit> list = new ArrayList<>(entities.size());
		for (MeasMeasDefineSetaEntity entity : entities) {
			UnitImpl unit = new UnitImpl();
			unit.e = entity;
			list.add(unit);
		}
		return list;
	}

	@Override
	public String[] getUnitSymbol(String measureIdOrName, String unitName) {
		try {
			MeasureunitEntity entity = orm.load(MeasureunitEntity.class, measureIdOrName);
			if (entity != null) {
				// 用id查到了分组
				if (new Integer(1).equals(entity.getMeas_enable()) == false) {
					// 但分组不可用，则直接返回空
					return null;
				}
				// 分组可用，则measureIdOrName就是id，后续继续处理
			} else {
				// 看做id查不到分组，那么尝试一下看做name再查
				OrmParam ormParam = new OrmParam();
				ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(MeasureunitProperty.MEAS_ENABLE, new Integer(1)),
						ormParam.getEqualXML(MeasureunitProperty.MEAS_OBJ, measureIdOrName)));
				List<MeasureunitEntity> entities = orm.selectBeanList(MeasureunitEntity.class, ormParam);
				if (entities == null || entities.size() != 1) {
					// 查不到或结果不是一条数据（脏数据），则返回空
					return null;
				}
				// 看做name查到了，把measureIdOrName的值改写为id，后续继续处理
				measureIdOrName = entities.get(0).getId();
			}
			// 执行到这里则measureIdOrName的值一定是合法的计量分组的id

			// 用measureIdOrName作为pid从单位集里面查
			OrmParam ormParam = new OrmParam();
			ormParam.setWhereExp(
					OrmParam.and(ormParam.getEqualXML(MeasMeasDefineSetaProperty.MEAS_DENABLE, new Integer(1)),
							ormParam.getEqualXML("pid", measureIdOrName),
							ormParam.getEqualXML(MeasMeasDefineSetaProperty.MEAS_DNAME, unitName)));
			List<MeasMeasDefineSetaEntity> entities = orm.selectBeanList(MeasMeasDefineSetaEntity.class, ormParam);
			if (entities == null || entities.size() != 1) {
				// 查不到或结果不是一条数据（脏数据），则返回空
				return null;
			}
			// 查到了
			String symbol = entities.get(0).getMeas_dsymbol();
			return new String[] { measureIdOrName, symbol };
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	/**
	 * {@link Measure}的一个实现
	 * 
	 * @author jiangshaoh
	 */
	private class MeasureImpl implements Measure {
		MeasureunitEntity e;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return new Integer(1).equals(e.getMeas_enable());
		}

		@Override
		public boolean isStandard() {
			return new Integer(1).equals(e.getMeas_isstand());
		}

		@Override
		public String getName() {
			return e.getMeas_obj();
		}

		@Override
		public String getDatumName() {
			return e.getMeas_name();
		}
	}

	/**
	 * {@link Unit}的一个实现
	 * 
	 * @author jiangshaoh
	 */
	private class UnitImpl implements Unit {
		MeasMeasDefineSetaEntity e;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return new Integer(1).equals(e.getMeas_denable());
		}

		@Override
		public boolean isStandard() {
			// TODO EDM待实现该字段
			return true;
		}

		@Override
		public String getSymbol() {
			return e.getMeas_dsymbol();
		}

		@Override
		public String getName() {
			return e.getMeas_dname();
		}

		@Override
		public int getType() {
			return e.getMeas_dtype();
		}

		@Override
		public int getRadixNum() {
			return e.getMeas_dradix_num();
		}

		@Override
		public String getRadixPut() {
			return e.getMeas_dradix_put();
		}

		@Override
		public BigDecimal getStage() {
			return e.getMeas_dstages();
		}

		@Override
		public BigDecimal getRate() {
			return e.getMeas_drate();
		}

		@Override
		public boolean isBase() {
			return new Integer(1).equals(e.getMeas_dbase());
		}
	}

}
