package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.constant.AreaProperty;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.OldAreaService;

@Service
public class OldAreaServiceImpl implements OldAreaService {
	@Autowired
	private OrmService orm;

	@Override
	public List<AreaFat> getProvinces() throws Exception {
		String ChinaId = null;
		{
			OrmParam ormParam = new OrmParam();
			ormParam.setWhereExp(OrmParam.or(ormParam.getEqualXML(AreaProperty.AREA_NAME, "中国"),
					ormParam.getEqualXML(AreaProperty.AREA_NAME, "中华人民共和国")));
			List<AreaEntity> entities = orm.selectBeanList(AreaEntity.class, ormParam);
			if (entities == null || entities.size() != 1) {
				throw new RuntimeException("找不到中国信息");
			}
			ChinaId = entities.get(0).getId();
		}
		{
			OrmParam ormParam = new OrmParam();
			ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaProperty.AREA_PARENT_AREA, ChinaId),
					ormParam.getEqualXML(AreaProperty.AREA_ENABLE, 1)));
			ormParam.setOrderExp(SQLSortEnum.ASC, AreaProperty.AREA_ORDER);
			List<AreaEntity> entities = orm.selectBeanList(AreaEntity.class, ormParam);
			List<AreaFat> ret = new ArrayList<>(entities.size());
			if (entities != null && entities.size() > 0) {
				entities.forEach(e -> ret.add(new AreaFat(e)));
			}
			return ret;
		}
	}

	@Override
	public List<AreaThin> getCityByProvince(String pid) throws Exception {
		List<AreaThin> ret = null;
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaProperty.AREA_PARENT_AREA, pid),
				ormParam.getEqualXML(AreaProperty.AREA_ENABLE, 1)));
		ormParam.setOrderExp(SQLSortEnum.ASC, AreaProperty.AREA_ORDER);
		List<AreaEntity> entities = orm.selectBeanList(AreaEntity.class, ormParam);
		if (entities != null && entities.size() > 0) {
			ret = new ArrayList<>(entities.size());
			String[] ids = new String[entities.size()];
			for (int i = 0; i < ids.length; i++) {
				AreaEntity e = entities.get(i);
				ret.add(new AreaThin(e));
				ids[i] = e.getId();
			}
			ormParam = new OrmParam();
			ormParam.setWhereExp(OrmParam.and(ormParam.getInXML(AreaProperty.AREA_PARENT_AREA, ids),
					ormParam.getEqualXML(AreaProperty.AREA_ENABLE, 1)));
			entities = orm.selectBeanList(AreaEntity.class, ormParam);
			if (entities != null && entities.size() > 0) {
				Set<String> pids = new HashSet<>();
				for (AreaEntity e : entities) {
					pids.add(e.getArea_parent_area());
				}
				for (AreaThin a : ret) {
					if (pids.contains(a.getId())) {
						a.setChildren(new LinkedList<>());// -_-! 有下级节点的区域，其children属性会是一个空列表[]而不是空对象null
					}
				}
			}
		}
		return ret;
	}

}
