package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.*;
import java.util.Map.Entry;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.WordlistProperty;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.entity.WordlistEntity;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.OldWordlistService;

/**
 * 参考{@link OldWordlistService}
 * 
 * @author jiangshaoh
 *
 */
@Service
public class OldWordlistServiceImpl implements OldWordlistService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OrmService orm;

	@SuppressWarnings("unchecked")
	@Override
	public Map<String, List<Map<String, Object>>> getEnumObjectsByCodes(String... codes) throws Exception {

		// 待返回的数据，存顶级枚举关键字，键是info_code，值是关键字对象
		Map<String, Map<String, Object>> all = new HashMap<>();

		OrmParam param = new OrmParam();
		param.setColumns(Arrays.asList("id", "word_par", "word_name", "word_seq", "info_code"));
		param.setWhereExp(param.getEqualXML("word_enable", 1));
		param.setOrderExp(SQLSortEnum.ASC, "word_seq");

		List<Map<String, Object>> entities = orm.selectMapList(WordlistEntity.class, param);
		if (entities != null && entities.size() > 0) {
			// 第一趟遍历，所有数据装进一个临时的快速索引map，键是id
			final Map<String, Map<String, Object>> ID_ENTITY_MAP = new HashMap<>();
			for (Map<String, Object> e : entities) {
				ID_ENTITY_MAP.put((String) e.get("id"), e);
			}
			// 第二趟遍历，拼成树
			for (Map<String, Object> e : entities) {
				final String id = (String) e.get("id");
				final String pid = (String) e.get("word_par");
				if (pid == null || pid.isEmpty()) {
					// 顶级枚举关键字，装进待返回的all，键是info_code（而不是id）
					String infoCode = (String) e.get("info_code");
					if (infoCode == null || infoCode.isEmpty()) {
						logger.warn("枚举关键字(#{})未设置编码，数据无法正确返回，已跳过本枚举关键字", id);
					} else {
						all.put((String) e.get("info_code"), e);
					}
				} else {
					// 非顶级枚举项，挂接到其父节点下（父节点填加children列表属性，枚举项追加到该列表）
					Map<String, Object> parent = ID_ENTITY_MAP.get(pid);
					if (parent == null) {
						// throw new IllegalStateException("枚举项(#" + id + ")找不到父节点(#" + pid + ")，数据损坏");
						logger.warn("枚举项(#{})找不到父节点(#{})，数据可能损坏，已跳过本枚举项", id, pid);
					} else {
						List<Map<String, Object>> children = (List<Map<String, Object>>) parent.get("children");
						if (children == null) {
							parent.put("children", children = new LinkedList<Map<String, Object>>());
						}
						children.add(e);
					}
				}
			}
			if (codes != null && codes.length > 0) {
				Map<String, Map<String, Object>> selected = new HashMap<>();
				for (String c : codes) {
					if (all.containsKey(c)) {
						selected.put(c, all.get(c));
					}
				}
				all = selected;
			}
		}

		Map<String, List<Map<String, Object>>> ret = new HashMap<>();
		for (Entry<String, Map<String, Object>> entry : all.entrySet()) {
			String key = entry.getKey();
			Map<String, Object> value = entry.getValue();
			ret.put(key, (List<Map<String, Object>>) value.get("children"));
		}
		return ret;
	}

	@Override
	public Map<String, Object> getEnumObject(String parCode, String code) throws Exception {
		OrmParam ormParam = new OrmParam();
		ormParam.setColumns(Arrays.asList(BasicConst.ID));
		ormParam.setWhereExp(OrmParam.or(ormParam.getEqualXML("info_code",parCode),ormParam.getEqualXML(BasicConst.ID, parCode)));
		// 根据上级编号查询上级枚举集合
		List<WordlistEntity> parWordList = orm.selectBeanList(WordlistEntity.class, ormParam);
		if(parWordList == null || parWordList.size() == 0){
			return null;
		}
		OrmParam ormParam1 = new OrmParam();
		ormParam1.setColumns(Arrays.asList(BasicConst.ID, "info_code", WordlistProperty.WORD_PAR,WordlistProperty.WORD_NAME,WordlistProperty.WORD_SEQ));
		ormParam1.setWhereExp(ormParam1.getEqualXML("info_code",code));
		// 根据编号查询枚举集合
		List<WordlistEntity> wordlist = orm.selectBeanList(WordlistEntity.class, ormParam1);
		if(wordlist == null || wordlist.size() == 0){
			return null;
		}
		WordlistEntity result = new WordlistEntity();
		// 过滤wordlist中对象word_par和parWordList中对象id相同的枚举对象
		for (WordlistEntity wordlistEntity : parWordList) {
			Optional<WordlistEntity> optional = wordlist.stream().filter(entity -> wordlistEntity.getId().equals(entity.getWord_par())).findFirst();
			if(optional.isPresent()){
				result = optional.get();
				break;
			}
		}
		Map<String, Object> map = new HashMap<>(5);
		map.put(WordlistProperty.WORD_PAR,result.getWord_par());
		map.put(BasicConst.ID,result.getId());
		map.put(WordlistProperty.WORD_NAME,result.getWord_name());
		map.put(WordlistProperty.WORD_SEQ,result.getWord_seq());
		map.put("info_code",result.getInfo_code());
		return map;
	}

}
