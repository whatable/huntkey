package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.sceo.common.model.paramter.constant.ParameterConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.PARAMETER)
public class ParameterServiceImpl implements ParameterService {

	@Autowired
	OrmService orm;

	@Autowired
	RxSystemProperties rx;

	private static Boolean STANDARD = null;

	@Override
	public Parameter find(String id) {
		if (id == null || id.isEmpty()) {
			return null;
		}
		ParameterImpl p = new ParameterImpl();
		try {
			p.e = orm.load(ParameterEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return p.e == null ? null : p;
	}

	@Override
	public boolean isStandardSystem() {
		if (STANDARD == null) {
			STANDARD = rx.getStandard();
		}
		return STANDARD;
	}

	@Override
	public boolean switchSystemStandard() {
		return STANDARD = !isStandardSystem();
	}

	@Override
	public List<Parameter> find(String formCode, String type, Boolean enable) {
		if (formCode == null || formCode.isEmpty()) {
			return new LinkedList<>();
		}
		String paramEnable = enable == null ? null : (enable ? "1" : "0");
		StringBuilder sql = new StringBuilder(
				"select p.* from parameter p LEFT JOIN parm_parm_form_seta ps on p.id = ps.pid where p.is_del = '0' and ps.is_del = '0'");
		if (!StringUtil.isNullOrEmpty(formCode)) {
			sql.append(" and ").append("FIND_IN_SET(" + "'" + formCode + "'" + ",ps.parm_form_code" + ")");
		}
		if (!StringUtil.isNullOrEmpty(paramEnable)) {
			sql.append(" and ").append("p.parm_enable = '" + paramEnable + "'");
		}
		if (!StringUtil.isNullOrEmpty(type)) {
			sql.append(" and ").append("p.parm_type = '" + type + "'");
		}
		List<Map<String, Object>> parameters;
		try {
			parameters = orm.getDataBySql(sql.toString());
		} catch (Exception e) {
			throw new OrmException(e);
		}
		if (parameters == null || parameters.size() == 0) {
			return new LinkedList<>();
		}
		List<ParameterEntity> entities = JSONObject.parseArray(JSONObject.toJSONString(parameters),
				ParameterEntity.class);
		List<Parameter> list = new ArrayList<>(entities.size());
		for (ParameterEntity entity : entities) {
			ParameterImpl parameter = new ParameterImpl();
			parameter.e = entity;
			list.add(parameter);
		}
		return list;
	}

	@Override
	public Parameter findByCode(String code) {
		if (code == null || code.isEmpty()) {
			return null;
		}
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(ormParam.getEqualXML(ParameterConstant.PARAM_NO, code));
		List<ParameterEntity> parameters;
		try {
			parameters = orm.selectBeanList(ParameterEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		if (parameters == null || parameters.size() == 0) {
			return null;
		}
		ParameterImpl parameter = new ParameterImpl();
		parameter.e = parameters.get(0);
		return parameter;
	}

	/**
	 * {@link Parameter} 的一个实现
	 * 
	 * @author jiangshaoh
	 */
	private class ParameterImpl implements Parameter {
		ParameterEntity e;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "1".equals(e.getParm_enable()) || "true".equalsIgnoreCase(e.getParm_enable());
		}

		@Override
		public boolean isStandard() {
			// TODO 添加is_standard属性，完成此方法
			return true;
		}

		@Override
		public String getCode() {
			return e.getParm_no();
		}

		@Override
		public String getName() {
			return e.getParm_name();
		}

		@Override
		public String getValues() {
			return e.getParm_values();
		}

		@Override
		public String getType() {
			return e.getParm_type();
		}
	}

}
