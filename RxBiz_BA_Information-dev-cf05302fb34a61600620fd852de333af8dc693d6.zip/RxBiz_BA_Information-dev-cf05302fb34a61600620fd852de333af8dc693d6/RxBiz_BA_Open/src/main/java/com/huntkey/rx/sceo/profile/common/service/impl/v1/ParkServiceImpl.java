package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;
import com.huntkey.rx.sceo.common.model.park.ParkConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.ParkService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.PARK)
public class ParkServiceImpl implements ParkService {

	@Autowired
	OrmService orm;

	@Override
	public Park find(String id) {
		ParkImpl p = new ParkImpl();
		try {
			p.e = orm.load(ParkEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return p.e == null ? null : p;
	}

	@Override
	public Park findDefault() {
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(ormParam.getEqualXML(ParkConstant.RPAK_ISDEFAULT, "1"));
		List<ParkEntity> entities;
		try {
			entities = orm.selectBeanList(ParkEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		if (entities == null || entities.size() == 0) {
			return null;
		}
		ParkImpl park = new ParkImpl();
		park.e = entities.get(0);
		return park;
	}

	@Override
	public List<Park> find(String name, Boolean enable) {
		String parkEnable =enable == null ? null :(enable?"1":"0");
		OrmParam ormParam = new OrmParam();
		if (!StringUtil.isNullOrEmpty(parkEnable)) {
			ormParam.setWhereExp(ormParam.getEqualXML(ParkConstant.RPAK_ENABLE, parkEnable));
		}
		if (!StringUtil.isNullOrEmpty(name)) {
			ormParam.setWhereExp(ormParam.getEqualXML(ParkConstant.RPAK_NAME, name));
		}
		List<ParkEntity> entities;
		try {
			entities = orm.selectBeanList(ParkEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		if (entities == null || entities.size() == 0) {
			return null;
		}
		List<Park> parks = new ArrayList<>(entities.size());
		for (ParkEntity entity : entities) {
			ParkImpl park = new ParkImpl();
			park.e = entity;
			parks.add(park);
		}
		return parks;
	}

	@Override
	public DeliveryAddress findDeliveryAddress(String id) {
		RpakRpakAddrSetaEntity entity;
		try {
			entity = orm.load(RpakRpakAddrSetaEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		if (entity == null) {
			return null;
		}
		return new DeliveryAddress() {
			@Override
			public String getLocation() {
				return entity.getRpak_addrl();
			}

			@Override
			public String getContact() {
				return entity.getRpak_contact();
			}

			@Override
			public String getContactWay() {
				return entity.getRpak_cway();
			}

			@Override
			public String getId() {
				return entity.getId();
			}

			@Override
			public boolean isEnable() {
				return entity.getReak_addr_enable().equals("1") ? true : false;
			}

			@Override
			public boolean isStandard() {
				return false;
			}
		};
	}

	private static class ParkImpl implements Park {
		ParkEntity e = null;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "true".equalsIgnoreCase(e.getRpak_enable()) || "1".equalsIgnoreCase(e.getRpak_enable());
		}

		@Override
		public boolean isStandard() {
			return false;// 园区不存在标准数据，全是用户自定义
		}

		@Override
		public String getName() {
			return e.getRpak_name();
		}

		@Override
		public String getCode() {
			return e.getRpak_code();
		}

		@Override
		public boolean isDefault() {
			return new Integer(1).equals(e.getRpak_isdefault());
		}

		@Override
		public String getAddress() {
			return e.getRpak_addr();
		}

		@Override
		public String getAddressProvince() {
			return e.getRpak_addr_prov();
		}

		@Override
		public String getAddressCity() {
			return e.getRpak_addr_city();
		}

		@Override
		public String getAddressDistrict() {
			return e.getRpak_addr_dist();
		}

		@Override
		public List<DeliveryAddress> getDeliveryAddress() {
			List<RpakRpakAddrSetaEntity> addrs = e.loadRpak_addr_set();
			if (addrs == null || addrs.size() == 0) {
				return new LinkedList<DeliveryAddress>();
			}
			List<DeliveryAddress> list = new ArrayList<>(addrs.size());
			for (final RpakRpakAddrSetaEntity addr : addrs) {
				list.add(new DeliveryAddress() {

					@Override
					public boolean isStandard() {
						return false;// 收货地址无标准数据，全是用户自定义
					}

					@Override
					public boolean isEnable() {
						return "1".equals(addr.getReak_addr_enable());
					}

					@Override
					public String getId() {
						return addr.getId();
					}

					@Override
					public String getLocation() {
						return addr.getRpak_addrl();
					}

					@Override
					public String getContactWay() {
						return addr.getRpak_cway();
					}

					@Override
					public String getContact() {
						return addr.getRpak_contact();
					}
				});
			}
			return list;
		}
	}

}
