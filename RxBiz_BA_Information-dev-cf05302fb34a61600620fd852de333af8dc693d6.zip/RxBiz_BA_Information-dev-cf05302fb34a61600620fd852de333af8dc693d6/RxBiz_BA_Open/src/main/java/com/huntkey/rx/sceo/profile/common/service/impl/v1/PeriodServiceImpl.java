package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.sceo.common.model.period.PeriodConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.PeriodService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.PERIOD)
public class PeriodServiceImpl implements PeriodService {

	@Autowired
	OrmService orm;

	@Override
	public Period find(String id) {
		PeriodImpl p = new PeriodImpl();
		try {
			p.e = orm.load(PeriodEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return p.e == null ? null : p;
	}

	@Override
	public List<Period> find(Integer fiscalYear, PeriodType periodType, Integer periodSequence, Boolean enable) {
		List<PeriodEntity> entities = queryPeriods(fiscalYear, periodType, periodSequence,
				enable == null ? null : (enable ? "1" : "0"));
		if (entities == null || entities.size() == 0) {
			return null;
		}
		List<Period> list = new ArrayList<>(entities.size());
		for (PeriodEntity entity : entities) {
			PeriodImpl period = new PeriodImpl();
			period.e = entity;
			list.add(period);
		}
		return list;
	}

	@Override
	public Period find(Date date, PeriodType periodType) {
		if (periodType == null) {
			return null;
		}
		if (date == null) {
			date = new Date();
		}
		List<PeriodEntity> entities = queryPeriods(date, periodType);
		if (entities == null || entities.size() == 0) {
			return null;
		}
		PeriodImpl period = new PeriodImpl();
		period.e = entities.get(0);
		return period;
	}

	@Override
	public Period findToday(PeriodType periodType) {
		Date date = new Date();
		List<PeriodEntity> entities = queryPeriods(date, periodType);
		if (entities == null || entities.size() == 0) {
			return null;
		}
		PeriodImpl period = new PeriodImpl();
		period.e = entities.get(0);
		return period;
	}

	@Override
	public List<PeriodType> getFiscalTypes() {
		return Arrays.asList(PeriodType.FISCAL_WEEK, PeriodType.FISCAL_MONTH, PeriodType.FISCAL_QUARTER,
				PeriodType.FISCAL_YEAR);
	}

	@Override
	public List<PeriodType> getCalendarTypes() {
		return Arrays.asList(PeriodType.WEEK, PeriodType.MONTH, PeriodType.QUARTER, PeriodType.YEAR);
	}

	@Override
	public Date[] getRange(String headPeriodId, String tailPeriodId) {
		if (headPeriodId == null)
			return null;
		try {
			PeriodEntity head = orm.load(PeriodEntity.class, headPeriodId);
			PeriodEntity tail = tailPeriodId == null ? head : orm.load(PeriodEntity.class, tailPeriodId);
			return new Date[] { head.getPeid_sdate(), tail.getPeid_edate() };
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	@Override
	public Period find(int fiscalYear, PeriodType periodType, int period) {
		if (periodType == null) {
			periodType = PeriodType.FISCAL_MONTH;
		}

		OrmParam param = new OrmParam();
		String where = OrmParam.and(param.getEqualXML(PeriodConstant.PEID_ENABLE, 1),
				param.getEqualXML(PeriodConstant.PEID_FYR, fiscalYear),
				param.getEqualXML(PeriodConstant.PEID_NAME, periodType.name()));
		param.setWhereExp(where);

		// 因为根据少龙的而需求，“期次”是在一百年的范围内排的，也即是2018年的第1个财月，其期次已经是200多了，而不是我们直观上以为的1
		// 而前端目前是用日历控件输入周期的（理应是用周期专用的控件来选），所以前端只能输入一年以内的期次，不可能输入全局期次
		// 所以这里不能直接把前端输入的期次和数据库里的期次对应，只好用变通的办法
		// 即，取出一年的数据，按期次排序，然后取第n个（n即页面输入的期次）
		param.setOrderExp(SQLSortEnum.ASC, "peid_proid");
		try {
			List<PeriodEntity> entities = orm.selectBeanList(PeriodEntity.class, param);
			if (entities != null && entities.size() >= period) {
				PeriodImpl p = new PeriodImpl();
				p.e = entities.get(period - 1);
				return p;
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return null;
	}

	@Override
	public Date[] getRange(Period from, Period to) {
		if (from == null) {
			return null;
		}
		if (to == null) {
			to = from;
		}
		return new Date[] { from.getStart(), to.getEnd() };
	}

	private static class PeriodImpl implements Period {
		PeriodEntity e;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "1".equals(e.getPeid_enable()) || "true".equalsIgnoreCase(e.getPeid_enable());
		}

		@Override
		public boolean isStandard() {
			return new Integer(1).equals(e.getPeid_enable());
		}

		@Override
		public String getName() {
			return e.getPeid_name();
		}

		@Override
		public String getFiscalName() {
			return e.getPeid_fina_name();
		}

		@Override
		public String getCalendarName() {
			return e.getPeid_cale_name();
		}

		@Override
		public Date getStart() {
			return e.getPeid_sdate();
		}

		@Override
		public Date getEnd() {
			return e.getPeid_edate();
		}

		@Override
		public int getPeriod() {
			return e.getPeid_proid();
		}

		@Override
		public int getFiscalYear() {
			return Integer.parseInt(e.getPeid_fyr());
		}
	}

	private List<PeriodEntity> queryPeriods(Integer fiscalYear, PeriodType periodType, Integer periodSequence,
			String peidEnable) {
		OrmParam ormParam = new OrmParam();
		StringBuilder whereExp = new StringBuilder();
		// TODO 如果年输入null，最好默认取当年吧。。。。否则数据量太可怕
		if (!StringUtil.isNullOrEmpty(fiscalYear)) {
			whereExp.append(" and ").append(ormParam.getEqualXML(PeriodConstant.PEID_FYR, fiscalYear));
		}
		if (periodType != null) {
			whereExp.append(" and ").append(ormParam.getEqualXML(PeriodConstant.PEID_NAME, periodType.name()));
		}
		if (periodSequence != null) {
			whereExp.append(" and ").append(ormParam.getEqualXML(PeriodConstant.PEID_PROID, periodSequence));
		}
		if (peidEnable != null) {
			whereExp.append(" and ").append(ormParam.getEqualXML(PeriodConstant.PEID_ENABLE, peidEnable));
		}
		ormParam.setWhereExp(whereExp.toString());
		List<PeriodEntity> entities;
		try {
			entities = orm.selectBeanList(PeriodEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return entities;
	}

	private List<PeriodEntity> queryPeriods(Date date, PeriodType periodType) {
		OrmParam ormParam = new OrmParam();
		StringBuilder whereExp = new StringBuilder();
		whereExp.append(" and ").append(ormParam.getLessThanAndEqualXML(PeriodConstant.PEID_SDATE, date));
		whereExp.append(" and ").append(ormParam.getGreaterThanAndEqualXML(PeriodConstant.PEID_EDATE, date));
		whereExp.append(" and ").append(ormParam.getEqualXML(PeriodConstant.PEID_NAME, periodType.name()));
		ormParam.setWhereExp(whereExp.toString());
		List<PeriodEntity> entities;
		try {
			entities = orm.selectBeanList(PeriodEntity.class, ormParam);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return entities;
	}

	@Override
	public Map<String, String> findByTypeInYears(PeriodType type, Integer... years) {
		// TODO Auto-generated method stub
		return null;
	}
}
