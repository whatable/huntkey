package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "ruixin.system")
public class RxSystemProperties {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private Boolean standard;

	public Boolean getStandard() {
		return standard == null ? false : true;
	}

	public void setStandard(Boolean standard) {
		logger.debug("set rx:system:standard={}", standard);
		this.standard = standard;
	}

}
