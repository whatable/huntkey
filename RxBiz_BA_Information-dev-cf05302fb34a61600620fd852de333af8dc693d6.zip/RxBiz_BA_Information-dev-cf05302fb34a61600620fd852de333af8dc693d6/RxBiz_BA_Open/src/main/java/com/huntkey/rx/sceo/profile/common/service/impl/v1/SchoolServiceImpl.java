package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.ArrayList;
import java.util.List;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.sceo.common.model.school.SchoolConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.entity.SchoolEntity;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.SchoolService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.SCHOOL)
public class SchoolServiceImpl implements SchoolService {

	@Autowired
	OrmService orm;

	@Override
	public School find(String id) {
		SchoolImpl s = new SchoolImpl();
		try {
			s.e = orm.load(SchoolEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return s.e == null ? null : s;
	}

	@Override
	public List<School> list(String name, String areaId, Boolean enable) {
		String schoolEnable = enable == null ? null :(enable?"1":"0");
		List<SchoolEntity> entities = querySchoolEntities(name, areaId, schoolEnable);
		if(entities ==null || entities.size() == 0){
			return null;
		}
		List<School> list = new ArrayList<>(entities.size());
		for (SchoolEntity entity : entities) {
			SchoolImpl school = new SchoolImpl();
			school.e = entity;
			list.add(school);
		}
		return list;
	}



	private static class SchoolImpl implements School {

		SchoolEntity e = null;

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "1".equals(e.getRsch_enable());
		}

		@Override
		public boolean isStandard() {
			return new Integer(1).equals(e.getRsch_is_standard());
		}

		@Override
		public String getName() {
			return e.getRsch_name();
		}

		@Override
		public String getCode() {
			return e.getRsch_code();
		}

		@Override
		public String getRanking() {
			return e.getRsch_ranking();
		}
	}


	private List<SchoolEntity> querySchoolEntities(String name, String areaId, String schoolEnable) {
		OrmParam ormParam = new OrmParam();
		StringBuilder whereExp = new StringBuilder();
		if(!StringUtil.isNullOrEmpty(name)){
			whereExp.append(" and ").append(ormParam.getMatchMiddleXML(SchoolConstant.RSCH_NAME,name));
		}
		if(!StringUtil.isNullOrEmpty(areaId)){
			whereExp.append(" and ").append(ormParam.getEqualXML(SchoolConstant.RSCH_CITY,areaId));
		}
		if(!StringUtil.isNullOrEmpty(schoolEnable)){
			whereExp.append(" and ").append(ormParam.getEqualXML(SchoolConstant.RSCH_ENABLE,schoolEnable));
		}
		ormParam.setWhereExp(whereExp.toString());
		List<SchoolEntity> entities;
		try {
			entities = orm.selectBeanList(SchoolEntity.class,ormParam);
		}catch (Exception e){
			throw new OrmException(e);
		}
		return entities;
	}
}
