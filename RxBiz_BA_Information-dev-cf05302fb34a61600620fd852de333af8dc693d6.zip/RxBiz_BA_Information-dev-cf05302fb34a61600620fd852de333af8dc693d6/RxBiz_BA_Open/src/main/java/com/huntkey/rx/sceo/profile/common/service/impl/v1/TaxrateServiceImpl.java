package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.constant.TaxrateProperty;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.TaxrateService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.TAXRATE)
public class TaxrateServiceImpl implements TaxrateService {

	@Autowired
	OrmService orm;

	@Override
	public Taxrate find(String id) {
		if (id == null || id.isEmpty()) {
			return null;
		}
		TaxrateImpl t = new TaxrateImpl();
		try {
			t.e = orm.load(TaxrateEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return t.e == null ? null : t;
	}

	@Override
	public Taxrate findByCode(String code) {
		if (code == null || code.isEmpty()) {
			return null;
		}
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(TaxrateProperty.TAXR_CODE, code)));

		TaxrateImpl t = new TaxrateImpl();
		try {
			List<TaxrateEntity> list = orm.selectBeanList(TaxrateEntity.class, ormParam);
			if (list != null && list.size() == 1) {
				t.e = list.get(0);
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return t.e == null ? null : t;
	}

	@Override
	public List<Taxrate> find(String name, Boolean isDeduct, Boolean enable) {
		OrmParam ormParam = new OrmParam();

		// 设置查询结果列
		// ormParam.setColumns(
		// Arrays.asList(TaxrateProperty.TAXR_ENABLE, TaxrateProperty.TAXR_IS_STANDARD,
		// TaxrateProperty.TAXR_NAME,
		// TaxrateProperty.TAXR_CODE, TaxrateProperty.TAXR_ISDEDUCT,
		// TaxrateProperty.TAXR_DETAIL));

		// 设置查询条件
		// is_deduct和enable都是varchar(1)字段，内容是1/0（应该不允许null）
		ormParam.setWhereExp(OrmParam.and(ormParam.getMatchMiddleXML(TaxrateProperty.TAXR_NAME, name),
				ormParam.getEqualXML(TaxrateProperty.TAXR_ISDEDUCT, isDeduct == null ? null : (isDeduct ? "1" : "0")),
				ormParam.getEqualXML(TaxrateProperty.TAXR_ENABLE, enable == null ? null : (enable ? "1" : "0"))));

		// 设置排序：以名字排序，便于用户快速找到单个条目
		ormParam.setOrderExp(SQLSortEnum.ASC, TaxrateProperty.TAXR_NAME);

		// 执行查询，po转vo
		List<Taxrate> ret = null;
		try {
			List<TaxrateEntity> entities = orm.selectBeanList(TaxrateEntity.class, ormParam);
			if (entities != null && entities.size() > 0) {
				ret = new ArrayList<>(entities.size());
				for (TaxrateEntity e : entities) {
					ret.add(new TaxrateImpl(e));
				}
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}

		return ret == null ? new ArrayList<>(0) : ret;
	}

	private class TaxrateImpl implements Taxrate {

		TaxrateEntity e;

		public TaxrateImpl() {
		}

		public TaxrateImpl(TaxrateEntity e) {
			this.e = e;
		}

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "1".equals(e.getTaxr_enable()) || "true".equalsIgnoreCase(e.getTaxr_enable());
		}

		@Override
		public boolean isStandard() {
			return new Integer(1).equals(e.getTaxr_is_standard());
		}

		@Override
		public String getName() {
			return e.getTaxr_name();
		}

		@Override
		public String getCode() {
			return e.getTaxr_code();
		}

		@Override
		public boolean isDeduct() {
			return "1".equals(e.getTaxr_isdeduct());
		}

		@Override
		public BigDecimal getDetail() {
			return e.getTaxr_detail();
		}
	}
}
