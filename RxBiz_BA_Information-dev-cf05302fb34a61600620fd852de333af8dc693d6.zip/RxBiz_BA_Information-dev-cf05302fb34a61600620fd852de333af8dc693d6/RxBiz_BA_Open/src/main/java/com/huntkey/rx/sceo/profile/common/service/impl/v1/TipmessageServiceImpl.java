package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.edm.constant.TipmessageProperty;
import com.huntkey.rx.edm.entity.TipmessageEntity;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.TipmessageService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.TIPMESSAGE)
public class TipmessageServiceImpl implements TipmessageService {

	@Autowired
	OrmService orm;

	@Override
	public Tipmessage find(String id) {
		TipmessageImpl t = new TipmessageImpl();
		try {
			t.e = orm.load(TipmessageEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return t.e == null ? null : t;
	}

	@Override
	public List<Tipmessage> find(String page, String type, Boolean enable) {
		// 不输入页面编码则直接返回空列表（我们认为在不指定页面的情况下使用此接口是无现实意义的）
		if (page == null) {
			return new LinkedList<Tipmessage>();
		}

		OrmParam ormParam = new OrmParam();

		// // 设置查询结果列
		// ormParam.setColumns(Arrays.asList(TipmessageProperty.TIPM_ENABLE,
		// TipmessageProperty.TIPM_BASE_MSG,
		// TipmessageProperty.TIPM_MSG_CODE, TipmessageProperty.TIPM_MSG_TYPE,
		// TipmessageProperty.TIPM_SHOW_MSG,
		// TipmessageProperty.TIPM_SHOW_TIME));

		// 设置查询条件
		// enable是varchar(1)字段，内容是1/0（应该不允许null）
		ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(TipmessageProperty.TIPM_PAGE_CODE, page),
				ormParam.getEqualXML(TipmessageProperty.TIPM_MSG_TYPE, type),
				ormParam.getEqualXML(TipmessageProperty.TIPM_ENABLE, enable == null ? null : (enable ? "1" : "0"))));

		// 执行查询，po转vo
		List<Tipmessage> ret = null;
		try {
			List<TipmessageEntity> entities = orm.selectBeanList(TipmessageEntity.class, ormParam);
			if (entities != null && entities.size() > 0) {
				ret = new ArrayList<>(entities.size());
				for (TipmessageEntity e : entities) {
					ret.add(new TipmessageImpl(e));
				}
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}

		return ret == null ? new LinkedList<Tipmessage>() : ret;
	}

	private static class TipmessageImpl implements Tipmessage {

		TipmessageEntity e;

		public TipmessageImpl() {
		}

		public TipmessageImpl(TipmessageEntity e) {
			this.e = e;
		}

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return "1".equals(e.getTipm_enable());
		}

		@Override
		public boolean isStandard() {
			// TODO 数据库中无对应列，可能尚未配置emd？
			return true;
		}

		@Override
		public String getCode() {
			return e.getTipm_msg_code();
		}

		@Override
		public String getType() {
			return e.getTipm_msg_type();
		}

		@Override
		public int getShowTime() {
			return e.getTipm_show_time() == null ? 0 : e.getTipm_show_time();
		}

		@Override
		public String getBaseMsg() {
			return e.getTipm_base_msg();
		}

		@Override
		public String getShowMsg() {
			return e.getTipm_show_msg();
		}
	}

}
