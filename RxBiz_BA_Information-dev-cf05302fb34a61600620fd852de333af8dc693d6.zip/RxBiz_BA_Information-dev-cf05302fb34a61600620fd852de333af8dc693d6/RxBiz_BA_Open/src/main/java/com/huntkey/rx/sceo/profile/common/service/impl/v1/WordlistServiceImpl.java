package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import java.util.*;

import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.WordlistProperty;
import com.huntkey.rx.edm.entity.WordlistEntity;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.WordlistService;
import com.huntkey.rx.sceo.profile.common.util.OrmException;

@Service(_ProfileQualifiersV1.WORDLIST)
public class WordlistServiceImpl implements WordlistService {

	private static final String WORD_PAR = "word_par";
	private static final String WORD_NAME = "word_name";
	private static final String WORD_ENABLE = "word_enable";
	private static final String INFO_CODE = "info_code";

	@Autowired
	OrmService orm;

	@Override
	public Wordlist find(String id) {
		if (id == null || id.isEmpty()) {
			return null;
		}
		WordlistImpl w = new WordlistImpl();
		try {
			w.e = orm.load(WordlistEntity.class, id);
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return w.e == null ? null : w;
	}

	@Override
	public List<Wordlist> findKeysByCodes(Boolean enable, String... codes) {
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(OrmParam.and(ormParam.getIsNull(WordlistProperty.WORD_PAR),
				ormParam.getEqualXML(WordlistProperty.WORD_ENABLE, enable == null ? null : (enable ? "1" : "0")),
				ormParam.getInXML("info_code", codes)));
		try {
			List<WordlistEntity> entities = orm.selectBeanList(WordlistEntity.class, ormParam);
			if (entities != null && entities.size() > 0) {
				final List<Wordlist> ret = new ArrayList<>(entities.size());
				entities.forEach(e -> ret.add(new WordlistImpl(e)));
				return ret;
			} else {
				return new LinkedList<Wordlist>();
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	@Override
	public List<Wordlist> find(String name, Boolean enable) {
		return find(name, enable, (String[]) null);
	}

	@Override
	public List<Wordlist> find(String name, Boolean enable, String... codes) {
		OrmParam ormParam = new OrmParam();
		// 设置查询条件
		String where = OrmParam.and(ormParam.getIsNull(WordlistProperty.WORD_PAR),
				ormParam.getMatchMiddleXML(WordlistProperty.WORD_NAME, name),
				ormParam.getEqualXML(WordlistProperty.WORD_ENABLE, enable == null ? null : (enable ? "1" : "0")));
		if (codes != null && codes.length > 0 && !StringUtil.isNullOrEmpty(codes[0])) {
			where = OrmParam.and(where, ormParam.getInXML("info_code", codes));
		}
		ormParam.setWhereExp(where);
		// 查询并po转vo
		try {
			List<WordlistEntity> entities = orm.selectBeanList(WordlistEntity.class, ormParam);
			if (entities != null && entities.size() > 0) {
				final List<Wordlist> ret = new ArrayList<>(entities.size());
				entities.forEach(e -> ret.add(new WordlistImpl(e)));
				return ret;
			} else {
				// 返回，若无结果返回size=0的List对象（而不是返回null）
				return new LinkedList<Wordlist>();
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	@Override
	public Pagination<Wordlist> find(Boolean enable, Integer pageNum, Integer pageSize) {
		return find(null, enable, pageNum, pageSize);
	}

	@Override
	public Pagination<Wordlist> find(String name, Boolean enable, Integer pageNum, Integer pageSize) {
		OrmParam ormParam = new OrmParam();
		// 设置查询条件
		ormParam.setPageNo(pageNum == null ? 1 : pageNum);
		ormParam.setPageSize(pageSize == null ? 15 : pageSize);
		ormParam.setWhereExp(OrmParam.and(ormParam.getIsNull(WordlistProperty.WORD_PAR),
				ormParam.getMatchMiddleXML(WordlistProperty.WORD_NAME, name),
				ormParam.getEqualXML(WordlistProperty.WORD_ENABLE, enable == null ? null : (enable ? "1" : "0"))));
		// 查询并po(Pagination)转vo(Pagination)
		try {
			Pagination<WordlistEntity> entitiesPage = orm.selectPagedBeanList(WordlistEntity.class, ormParam);
			List<WordlistEntity> entitiesList = entitiesPage.getList();
			List<Wordlist> list = new ArrayList<>(entitiesList.size());
			entitiesList.forEach(e -> list.add(new WordlistImpl(e)));
			return new Pagination<>(list, entitiesPage.getPageNum(), entitiesPage.getPageSize(),
					entitiesPage.getTotal());
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	private static final Integer INTEGER_1 = new Integer(1);

	@Override
	public Pagination<Map<String, Object>> find(Integer type, String name, Boolean enable, Integer pageNum,
			Integer pageSize) {
		if (type == null || type > 2 || type < 1) {
			return new Pagination<>(new LinkedList<>(), pageNum, pageSize, 0);
		}
//		StringBuilder where = new StringBuilder("w0a.word_par IS NULL AND w0a.is_del=0 AND w0b.is_del=0 ");
//		if (name != null && !name.isEmpty()) {
//			// TODO 这里需要防SQL注入，暂略
//			where.append(" AND w0a.word_name LIKE '%").append(name).append("%' ");
//		}
//		if (enable != null && enable) {
//			where.append(" AND w0a.word_enable=1 AND w0b.word_enable=1 ");
//		}
//		String w1 = String.format(
//				"(SELECT w0a.*,w0b.id id1 FROM wordlist w0a INNER JOIN wordlist w0b ON w0a.id=w0b.word_par WHERE %s) w1",
//				where);
//		String wx = String.format(
//				"(SELECT DISTINCT w1.id,w1.word_name AS name,w1.word_par AS parentId,w1.word_enable AS enable,w1.word_issta=1 AS standard,w1.word_seq AS sequence,w1.info_code AS infoCode,w1.info_name AS infoName,w1.info_desc AS infoDesc,(CASE WHEN w2.is_del=0 AND w2.word_enable=1 THEN 2 ELSE 1 END) type"
//						+ " FROM %s LEFT JOIN wordlist w2 ON w1.id1=w2.word_par) wx",
//				w1);
//		String from = String.format("FROM %s WHERE wx.type=%d", wx, type);
//		try {
//			final long total = (Long) orm.getDataBySql(String.format("SELECT COUNT(wx.id) c %s", from)).get(0).get("c");
//			if (total > 0) {
//				List<Map<String, Object>> entities = orm.getDataBySql(
//						String.format("SELECT * %s LIMIT %d,%d", from, (pageNum - 1) * pageSize, pageSize));
//				entities.forEach(e -> {
//					e.put("level", 0);
//					e.put("parentId", null);
//					e.remove("type");
//					e.put("standard", INTEGER_1.equals(e.get("standard")) ? true : false);
//				});
//				return new Pagination<>(entities, pageNum, pageSize, total);
//			}
//		} catch (Exception ex) {
//			throw new OrmException(ex);
//		}
		List<Map<String,Object>> mapList = new ArrayList<>();
		StringBuilder dataSql= new StringBuilder();
		StringBuilder countSql = new StringBuilder();
		if(type==1){
			dataSql.append("select w6.word_issta as standard, w6.word_name as name, w6.word_enable as enable, w6.info_code as infoCode, w6.info_desc as infoDesc, w6.word_par as parentId,w6.word_seq as sequence, w6.id from wordlist w6 where w6.id not IN (select DISTINCT w3.word_par as id from \n" +
					"(select w2.id id,w2.word_name,w2.word_par from wordlist w1 INNER JOIN wordlist w2 on w1.id=w2.word_par where w1.word_par is NULL and w1.is_del=0 and w2.is_del=0 ) w3 \n" +
					"INNER JOIN wordlist w4 on w3.id=w4.word_par where w4.is_del=0)  and w6.word_par is null and w6.is_del=0");
			countSql.append("select count(1) count from wordlist w6 where w6.id not IN (select DISTINCT w3.word_par as id from \n" +
					"(select w2.id id,w2.word_name,w2.word_par from wordlist w1 INNER JOIN wordlist w2 on w1.id=w2.word_par where w1.word_par is NULL and w1.is_del=0 and w2.is_del=0 ) w3 \n" +
					"INNER JOIN wordlist w4 on w3.id=w4.word_par where w4.is_del=0)  and w6.word_par is null and w6.is_del=0");
		}else{
			dataSql.append("select w6.word_issta as standard, w6.word_name as name, w6.word_enable as enable, w6.info_code as infoCode, w6.info_desc as infoDesc, w6.word_par as parentId,w6.word_seq as sequence, w6.id from wordlist w6 where w6.id IN (select DISTINCT w3.word_par as id from \n" +
					"(select w2.id id,w2.word_name,w2.word_par from wordlist w1 INNER JOIN wordlist w2 on w1.id=w2.word_par where w1.word_par is NULL and w1.is_del=0 and w2.is_del=0 ) w3 \n" +
					"INNER JOIN wordlist w4 on w3.id=w4.word_par where w4.is_del=0)  and w6.word_par is null and w6.is_del=0");
			countSql.append("select count(1) count from wordlist w6 where w6.id IN (select DISTINCT w3.word_par as id from \n" +
					"(select w2.id id,w2.word_name,w2.word_par from wordlist w1 INNER JOIN wordlist w2 on w1.id=w2.word_par where w1.word_par is NULL and w1.is_del=0 and w2.is_del=0 ) w3 \n" +
					"INNER JOIN wordlist w4 on w3.id=w4.word_par where w4.is_del=0)  and w6.word_par is null and w6.is_del=0");
		}
		if (name != null && !name.isEmpty()) {
			// TODO 这里需要防SQL注入，暂略
			dataSql.append(" AND w6.word_name LIKE '%").append(name).append("%' ");
			countSql.append(" AND w6.word_name LIKE '%").append(name).append("%' ");
		}
		if (enable != null && enable) {
			dataSql.append(" AND w6.word_enable=1");
			countSql.append(" AND w6.word_enable=1");
		}
		dataSql.append(" limit "+(pageNum-1)*pageSize+", "+pageSize);
		long count=0;
		try {
			mapList = orm.getDataBySql(dataSql.toString());
			count = (long) orm.getDataBySql(countSql.toString()).get(0).get("count");
		} catch (Exception e) {
			e.printStackTrace();
		}
		mapList.forEach(e -> {
					e.put("level", 0);
					e.put("parentId", null);
					e.put("standard", INTEGER_1.equals(e.get("standard")) ? true : false);
				});
		return new Pagination<>(mapList, pageNum, pageSize, count);
	}

	@Override
	public WordlistType typeOf(Wordlist wordlist) {
		if (wordlist == null)
			return null;
		return typeOf(wordlist.getId());
	}

	@Override
	public WordlistType typeOf(String id) {
		if (id == null || id.isEmpty()) {
			return null;
		}
		try {
			// 测试有无下级
			List<WordlistEntity> children0 = _getChildren(Arrays.asList(id));
			if (children0 != null && children0.size() > 0) {
				// 1、有下级，测试下下级
				List<String> ids = new ArrayList<String>(children0.size());
				children0.forEach(c0 -> ids.add(c0.getId()));
				List<WordlistEntity> children1 = _getChildren(ids);
				// 1A、有下下级：TREE；1B、无下下级：ENUM
				return (children1 != null && children1.size() > 0) ? WordlistType.TREE : WordlistType.ENUM;
			} else {
				// 2、无下级，测试上级
				WordlistEntity e = orm.load(WordlistEntity.class, id);
				// 2A、有上级：ELEMENT；2B、无上级：孤立的枚举，可能是尚未配置完毕
				return (e != null && e.getWord_par() != null) ? WordlistType.ELEMENT : WordlistType.ISOLATED;
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	/**
	 * 私有工具方法：获取指定id枚举对象的直接子项对象，默认带有is_del=0和enable=1两个条件，返回的是只有id字段的entity列表
	 *
	 * @param ids
	 * @return
	 * @throws Exception
	 */
	private List<WordlistEntity> _getChildren(List<String> ids) throws Exception {
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(OrmParam.and(ormParam.getInXML(WordlistProperty.WORD_PAR, ids.toArray()),
				ormParam.getEqualXML(WordlistProperty.WORD_ENABLE, 1)));
		return orm.selectBeanList(WordlistEntity.class, ormParam);
	}

	@Override
	public List<Wordlist> getOptions(String id, Boolean enable) {
		if (id == null || id.isEmpty()) {
			return new LinkedList<Wordlist>();
		}
		try {
			// 返回列表
			List<Wordlist> ret = new LinkedList<>();
			// 循环递归所有子项并加入返回列表
			int lv = 0;
			OrmParam ormParam = new OrmParam();
			String where = OrmParam.and(ormParam.getEqualXML(WordlistProperty.WORD_PAR, id),
					ormParam.getEqualXML(WordlistProperty.WORD_ENABLE, enable == null ? null : (enable ? "1" : "0")));
			ormParam.setWhereExp(where);
			List<WordlistEntity> children = orm.selectBeanList(WordlistEntity.class, ormParam);
			while (children != null && children.size() > 0) {
				if (lv++ > 5) {
					throw new IllegalStateException("真的存在这么多层级联的枚举吗？如果是，请删除此行代码（防无限循环）并原谅我的孤陋寡闻");
				}
				String[] ids = new String[children.size()];
				for (int i = 0; i < children.size(); i++) {
					WordlistEntity w = children.get(i);
					ret.add(new WordlistImpl(w, lv));
					ids[i] = w.getId();
				}
				ormParam = new OrmParam();
				where = OrmParam.and(ormParam.getInXML(WordlistProperty.WORD_PAR, ids), ormParam
						.getEqualXML(WordlistProperty.WORD_ENABLE, enable == null ? null : (enable ? "1" : "0")));
				ormParam.setWhereExp(where.toString());
				children = orm.selectBeanList(WordlistEntity.class, ormParam);
			}

			// 返回最终列表，所有层级的枚举项都在同一个列表，靠level和parentId区分
			return ret;
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	@Override
	public List<Wordlist> getOptions(Wordlist wordlist, Boolean enable) {
		if (wordlist == null)
			return new LinkedList<Wordlist>();
		return getOptions(wordlist.getId(), enable);
	}

	@Override
	public List<Wordlist> getOptions(String[] codes, String name) {
		if (codes == null || codes.length == 0) {
			return new LinkedList<>();
		}
		try {
			// 先用codes查询顶级枚举关键字
			OrmParam param = new OrmParam();
			String where = OrmParam.and(param.getIsNull(WORD_PAR), param.getInXML(INFO_CODE, codes),
					param.getEqualXML(WORD_ENABLE, 1));
			param.setWhereExp(where);
			List<WordlistEntity> keys = orm.selectBeanList(WordlistEntity.class, param);
			if (keys != null && keys.size() > 0) {
				// 枚举关键字的id列表
				String[] keyIds = new String[keys.size()];
				for (int i = 0; i < keyIds.length; i++) {
					keyIds[i] = keys.get(i).getId();
				}
				// 根据枚举关键字id列表和枚举项的名字作为条件，查询枚举项
				return getOptionsAsListByCodesAndName(true, name, keyIds);
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
		// 没有数据的情况下返回空列表（而不是null对象）
		return new LinkedList<>();
	}

	@Override
	public Wordlist getEnumChild(String id, String childCode, Boolean enable) {
		Wordlist childWord = null;
		List<Wordlist> wordlists = getOptions(id, enable);
		if (wordlists == null || wordlists.size() == 0){
			return null;
		}
		for (Wordlist word : wordlists) {
			WordlistImpl impl = (WordlistImpl) word;
			if(!StringUtil.isNullOrEmpty(impl.getInfoCode()) && impl.getInfoCode().equals(childCode)){
				childWord = word;
				break;
			}
		}
		return childWord;
	}

	@Override
	public List<Map<String, Object>> getEnumObject(String parCode, String code) {
		String[] codes = code.split(",");
		List<Map<String,Object>> list = new ArrayList<>();
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(ormParam.getEqualXML("info_code", parCode));
		try {
			List<WordlistEntity> parWords = orm.selectBeanList(WordlistEntity.class, ormParam);
			if (parWords == null || parWords.size() == 0) {
				return null;
			}
			List<Wordlist> children =  getOptions(parWords.get(0).getId(), null);
			for (Wordlist child : children) {
				WordlistImpl impl = (WordlistImpl) child;
				for (String wordCode : codes) {
					if (!StringUtil.isNullOrEmpty(impl.getInfoCode()) && StringUtils.equals(impl.getInfoCode(), wordCode.trim())) {
						Map<String, Object> var = new HashMap<>();
						var.put(WordlistProperty.WORD_PAR, impl.getParentId());
						var.put(BasicConst.ID, impl.getId());
						var.put(WordlistProperty.WORD_NAME, impl.getName());
						var.put(WordlistProperty.WORD_SEQ, impl.getSequence());
						var.put("info_code", impl.getInfoCode());
						list.add(var);
					}
				}
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return list;
	}

	@Override
	public List<Wordlist> getWordlistByIds(String ids) {
		List<Wordlist> result;
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(ormParam.getInXML(BasicConst.ID, ids.split(",")));
		try {
			List<WordlistEntity> list = orm.selectBeanList(WordlistEntity.class, ormParam);
			result = new ArrayList<>(list.size());
			if (list == null || list.size() == 0){
				return null;
			}
			for (WordlistEntity wordlistEntity : list) {
				WordlistImpl impl = new WordlistImpl();
				impl.e = wordlistEntity;
				result.add(impl);
			}
		} catch (Exception e) {
			throw new OrmException(e);
		}
		return result;
	}

	/**
	 * 根据枚举关键字的ids，获取所有下属枚举项（含所有层级），且可以根据名称过滤，构成列表返回。枚举项名称这个条件并不考虑树结构的完整性，只是对所有条目的直接过滤，不排除出现子树根被排除但叶子保留在列表中的情况。
	 * 
	 * @param enable
	 *            是否有效，输入null返回所有
	 * @param name
	 *            枚举项名称，模糊过滤条件
	 * @param keyIds
	 *            枚举关键字编码
	 * @return
	 */
	private List<Wordlist> getOptionsAsListByCodesAndName(Boolean enable, String name, String... keyIds) {
		try {
			// 返回列表
			List<Wordlist> ret = new LinkedList<>();
			if (keyIds != null && keyIds.length > 0) {
				// 循环递归所有子项并加入返回列表
				int lv = 0;
				OrmParam param = new OrmParam();
				String where = OrmParam.and(param.getInXML(WORD_PAR, keyIds),
						param.getEqualXML(WORD_ENABLE, enable == null ? null : (enable ? 1 : 0)));
				param.setWhereExp(where);
				List<WordlistEntity> children = orm.selectBeanList(WordlistEntity.class, param);
				while (children != null && children.size() > 0) {
					if (lv++ > 7) {
						throw new IllegalStateException("真的存在这么多（" + lv + "）层级联的枚举吗？请联系管理员解决此问题。");// TODO
					}
					String[] ids = new String[children.size()];
					for (int i = 0; i < children.size(); i++) {
						WordlistEntity w = children.get(i);
						ret.add(new WordlistImpl(w, lv));
						ids[i] = w.getId();
					}
					param = new OrmParam();
					where = OrmParam.and(param.getInXML(WORD_PAR, ids), param.getMatchMiddleXML(WORD_NAME, name),
							param.getEqualXML(WORD_ENABLE, enable == null ? null : (enable ? 1 : 0)));
					param.setWhereExp(where);
					children = orm.selectBeanList(WordlistEntity.class, param);
				}

			}
			if (ret.size() > 0 && name != null && !name.isEmpty()) {
				for (Iterator<Wordlist> it = ret.iterator(); it.hasNext();) {
					Wordlist w = it.next();
					if (w.getName() == null || w.getName().isEmpty() || !w.getName().contains(name)) {
						it.remove();
					}
				}
			}
			// 返回最终列表，所有层级的枚举项都在同一个列表，靠level和parentId区分
			return ret;
		} catch (Exception e) {
			throw new OrmException(e);
		}
	}

	private static class WordlistImpl extends _EntityBasedInformationObject<WordlistEntity> implements Wordlist {
		int level = 0;

		public WordlistImpl() {
			super();
		}

		public WordlistImpl(WordlistEntity e) {
			super(e);
		}

		public WordlistImpl(WordlistEntity e, int level) {
			super(e);
			this.level = level;
		}

		@Override
		public String getId() {
			return e.getId();
		}

		@Override
		public boolean isEnable() {
			return new Integer(1).equals(e.getWord_enable());
		}

		@Override
		public boolean isStandard() {
			return new Integer(1).equals(e.getWord_issta());
		}

		@Override
		public String getName() {
			return e.getWord_name();
		}

		@Override
		public int getSequence() {
			return e.getWord_seq() == null ? -1 : e.getWord_seq();
		}

		@Override
		public String getParentId() {
			return e.getWord_par();
		}

		@Override
		public int getLevel() {
			return level;
		}
	}
}