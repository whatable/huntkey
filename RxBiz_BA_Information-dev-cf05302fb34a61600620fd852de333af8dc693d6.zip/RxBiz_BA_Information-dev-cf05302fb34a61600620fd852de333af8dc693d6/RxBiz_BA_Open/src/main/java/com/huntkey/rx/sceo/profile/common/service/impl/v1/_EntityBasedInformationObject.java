package com.huntkey.rx.sceo.profile.common.service.impl.v1;

import com.huntkey.rx.edm.entity.InformationEntity;

/**
 * 建议公共接口统一使用的父类（仅限信息类子类），目前提供两类共性：一是InformationEntity成员变量，二是读取infomation类属性的方法
 * 
 * @author jiangshaoh
 *
 */
public class _EntityBasedInformationObject<T extends InformationEntity> {
	protected T e;

	public _EntityBasedInformationObject() {
	}

	public _EntityBasedInformationObject(T e) {
		this.e = e;
	}

	public String getInfoCode() {
		return e.getInfo_code();
	}

	public String getInfoName() {
		return e.getInfo_name();
	}

	public String getInfoDesc() {
		return e.getInfo_desc();
	}

}
