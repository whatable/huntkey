package com.huntkey.rx.sceo.profile.common.service.impl.v1;

/**
 * 基础资料公共接口bean的qualifier(v1)，用于给公共接口子项目内的service
 * bean指派qualifier，避免与管理子项目内的service
 * bean名字冲突（两个子项目service接口名相同，bean自动装载会发生id冲突）；同时，对于公共接口项目来说，可以用来区分不同版本的service
 * bean实现。
 * 
 * @author jiangshaoh
 *
 */
public interface _ProfileQualifiersV1 {

	/**
	 * 区域管理的service bean id(v1)
	 */
	String AREA = "AreaServiceImpl.v1";

	/**
	 * 学校管理的service bean id(v1)
	 */
	String SCHOOL = "SchoolServiceImpl.v1";

	/**
	 * 周期管理的service bean id(v1)
	 */
	String PERIOD = "PeriodServiceImpl.v1";

	/**
	 * 园区管理的service bean id(v1)
	 */
	String PARK = "ParkServiceImpl.v1";

	/**
	 * 币别管理的service bean id(v1)
	 */
	String CURRENCY = "CurrencyServiceImpl.v1";

	/**
	 * 汇率管理的service bean id(v1)
	 */
	String CURR_RATE = "CurrRateServiceImpl.v1";

	/**
	 * 税率管理的service bean id(v1)
	 */
	String TAXRATE = "TaxrateServiceImpl.v1";

	/**
	 * 枚举的service bean id(v1)
	 */
	String WORDLIST = "WordlistServiceImpl.v1";

	/**
	 * 提示信息的service bean id(v1)
	 */
	String TIPMESSAGE = "TipmessageServiceImpl.v1";

	/**
	 * 参数的service bean id(v1)
	 */
	String PARAMETER = "ParameterServiceImpl.v1";
	
	/**
	 * 计量单位的service bean id(v1)
	 */
	String MEASUREUNIT = "MeasureunitServiceImpl.v1";
}
