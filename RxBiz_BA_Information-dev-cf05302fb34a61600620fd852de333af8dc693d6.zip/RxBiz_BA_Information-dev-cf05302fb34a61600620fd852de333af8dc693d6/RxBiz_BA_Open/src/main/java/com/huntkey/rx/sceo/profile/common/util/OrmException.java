package com.huntkey.rx.sceo.profile.common.util;

/**
 * 基础资料公共接口内部调用orm发生异常是统一向外抛出的运行时异常，这通常意味着数据库服务发生了无法挽救的错误（脏数据、服务崩溃或网络中断）。这不是测试能发现的，且无法预先设置解决方案，所以设定为runtime异常（ORM层抛出的异常是checked
 * exception，是不恰当的）。
 * 
 * @author jiangshaoh
 */
public class OrmException extends RuntimeException {

	private static final long serialVersionUID = 328791128298813018L;

	/**
	 * 构造方法。基础资料公共接口内部调用orm发生异常是统一向外抛出的运行时异常，这通常意味着数据库服务发生了无法挽救的错误（脏数据、服务崩溃或网络中断）。这不是测试能发现的，且无法预先设置解决方案，所以设定为runtime异常（ORM层抛出的异常是checked
	 * exception，是不恰当的）。
	 * 
	 * @param e
	 *            orm模块的异常，将被封装为OrmException
	 */
	public OrmException(Exception e) {
		super(e.getMessage());
	}

}
