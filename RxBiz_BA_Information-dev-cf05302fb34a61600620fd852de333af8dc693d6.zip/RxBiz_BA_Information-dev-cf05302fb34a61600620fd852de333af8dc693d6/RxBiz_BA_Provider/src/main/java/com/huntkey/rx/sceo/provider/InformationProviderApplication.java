package com.huntkey.rx.sceo.provider;

import com.huntkey.rx.sceo.method.register.plugin.annotation.EnableDriverMethod;
import com.huntkey.rx.sceo.method.register.plugin.annotation.EnableMethodRegisterScanner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;

/**
 * @author zhoucj
 */
@SpringBootApplication(scanBasePackages = {"com.huntkey.rx"})
@EnableEurekaClient
@EnableDriverMethod
@EnableFeignClients(basePackages = "com.huntkey.rx.sceo.provider.feign")
@EnableMethodRegisterScanner(startApplicationClass = InformationProviderApplication.class,
		edmServiceName = "${edmServiceName:modeler-provider}",
		serviceApplicationName = "${spring.application.name}")
public class InformationProviderApplication {
	public static void main(String[] args) {
		SpringApplication.run(InformationProviderApplication.class, args);
	}
}
