package com.huntkey.rx.sceo.provider.api.controller;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.AreaService;
import com.huntkey.rx.sceo.profile.common.service.AreaService.Area;
import com.huntkey.rx.sceo.profile.common.service.OldAreaService;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/areas")
public class ApiOfAreaController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	AreaService areaService;
	@Autowired
	OldAreaService oldAreaService;

	/**
	 * 根据给定的区域节点id，获取本节点完整的信息（不包含子级，也不包含上级）。这个查询会忽略数据enable属性，无论是否enable都会读到。
	 * 
	 * @param id
	 *            给定的区域节点数据id
	 * @return 数据区域是一个区域的对象
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "根据id获取区域", methodCate = "表单通用方法")
	public Result findById(@PathVariable("id") String id) {
		return RestResultHelper.success(areaService.find(id));
	}

	/**
	 * 根据指定的区域节点id，获取以其为根的区域对象树。现实意义就是取某个区域的所有下辖区域（含间接下级辖区）。
	 * 
	 * @param id
	 *            树根节点的数据id
	 * @param enable
	 *            是否有效，取值true(default)/false。默认值true，整个结果树只包含有效的子代节点（无效的节点，其子节点全部无效，所以不存在“隔代有效”）；若设定为false，则有效和无效的子代都包含；
	 * @param depth
	 *            递归获取下辖区域的层级，只接受整数值输入。输入1只取本级（与/area/{id}等效，但返回的是列表），输入2则包含下一级，以此类推，不输入默认值为2
	 * @return 数据区域是区域的对象列表（即使只有根节点一个元素，也存储在列表中，这种情况更建议调用/areas/{id}），注意：虽然数据结构本质上是树，但以列表形式存储
	 */
	@RequestMapping(value = "/{id}/tree", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "根据id获取区域及其下级（含间接下级，构成树结构）", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable", "depth" })
	public Result findTree(@PathVariable("id") String id,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable,
			@RequestParam(value = "depth", defaultValue = "2") Integer depth) {
		List<Area> areas = areaService.find(id, enable ? true : null, depth);
		return RestResultHelper.success(areas);
	}

	/**
	 * 【特供前端】根据指定的区域节点id，获取从区域顶级根节点到本节点的路径链。现实意义就是给定一个区域，可知其完整的区域链（如给定“蜀山区”，可知“安徽省/合肥市/蜀山区”）。这个查询会忽略数据enable属性，无论是否enable都会读到。
	 * 
	 * @param id
	 *            指定的区域节点数据id
	 * @return 数据区域是区域的对象列表（即使只有本节点一个节点，也就是说本节点就是顶级区域，也存储在列表中）
	 */
	@RequestMapping(value = "/{id}/chain", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "以指定id的区域为叶子节点，获取其上级区域直至最初级根区域，构成链结构", methodCate = "表单通用方法")
	public Result findChain(@PathVariable("id") String id) {
		List<Area> areaList = areaService.findChain(id);
		return RestResultHelper.success(areaList);
	}

	/**
	 * 获取中国（国家级区域对象）
	 * 
	 * @return
	 */
	@RequestMapping(value = "/China", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "获取中国", methodCate = "表单通用方法")
	public Result getChina() {
		return RestResultHelper.success(areaService.findChina());
	}

	/**
	 * 获取中国所有省（自动过滤掉禁用的）
	 * 
	 * @return
	 */
	@RequestMapping(value = "/China/provinces", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "获取中国所有省（直辖市、自治区）", methodCate = "表单通用方法")
	public Result getChinaProvinces() {
		final Area CHINA = areaService.findChina();
		List<Area> list = areaService.find(CHINA.getId(), true, 2);
		Iterator<Area> it = list.iterator();
		while (it.hasNext()) {
			Area area = it.next();
			if (area.getId().equals(CHINA.getId())) {
				it.remove();
				break;
			}
		}
		return RestResultHelper.success(list);
	}

	@RequestMapping(value = "/old/getProvinces", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "【兼容方法】获取中国所有省（直辖市、自治区）", methodCate = "表单通用方法")
	public Result getProvinces() {
		try {
			Result res = new Result() {
				public String getCaution() {
					return "18-07-10以后版本的任何组件、系统不要再继续使用本接口获取数据了，改用基础资料新接口，详询@jiangshaoh";
				}
			};
			res.setRetCode(Result.RECODE_SUCCESS);
			res.setData(oldAreaService.getProvinces());
			return res;
		} catch (Exception e) {
			return RestResultHelper.error(e.getMessage());
		}
	}

	@RequestMapping(value = "/old/getCitiesByProvince/{pid}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "【兼容方法】根据上级区域id获取所有下级区域", methodCate = "表单通用方法")
	public Result getCityByProvince(@PathVariable("pid") String pid) {
		try {
			Result res = new Result() {
				public String getCaution() {
					return "18-07-10以后版本的任何组件、系统不要再继续使用本接口获取数据了，改用基础资料新接口，详询@jiangshaoh";
				}
			};
			res.setRetCode(Result.RECODE_SUCCESS);
			res.setData(oldAreaService.getCityByProvince(pid));
			return res;
		} catch (Exception e) {
			return RestResultHelper.error(e.getMessage());
		}
	}

	@RequestMapping(value = "/getAreasByPid/{pid}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "area", methodDesc = "根据上级id查询子节点", methodCate = "表单通用方法",
			getReqParamsNameNoPathVariable = {"enable"})
	public Result getAreasByPid(@PathVariable(value = "pid")String pid,
							   @RequestParam(required = false,value = "enable", defaultValue = "true")Boolean enable){
		return RestResultHelper.success(areaService.getAreaByPid(pid, enable));
	}
}
