package com.huntkey.rx.sceo.provider.api.controller;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.order.vo.CurrRateSetOrderVO;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.method.register.plugin.entity.ProgramCate;
import com.huntkey.rx.sceo.profile.common.service.CurrRateService;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/currRates")
public class ApiOfCurrRateController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private static final DateFormat DATEFORMAT = new SimpleDateFormat("yyyy-MM-dd");

	@Autowired
	CurrRateService currRateService;

	@Autowired
	com.huntkey.rx.sceo.provider.currency.service.CurrRateService rateService;

	/**
	 * 根据id获取特定一条汇率信息
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "currency", methodDesc = "根据id获取汇率", methodCate = "表单通用方法")
	public Result getCurrRateById(@PathVariable("id") String id) {
		return RestResultHelper.success(currRateService.find(id));
	}

	/**
	 * 多个条件查询不定量汇率
	 * 
	 * @param originCurrencyId
	 * @param targetCurrencyId
	 * @param date
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "currency", methodDesc = "查询汇率", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"originCurrencyId", "targetCurrencyId", "date" })
	public Result findRates(@RequestParam(value = "originCurrencyId", required = false) String originCurrencyId,
			@RequestParam(value = "targetCurrencyId", required = false) String targetCurrencyId,
			@RequestParam(value = "date", required = false) String date) {
		logger.debug("find(): originCurrencyId={}, targetCurrencyId={}, date={}", originCurrencyId, targetCurrencyId,
				date);
		try {
			final Date d = (date == null || date.isEmpty()) ? new Date() : DATEFORMAT.parse(date);
			return RestResultHelper.success(currRateService.find(originCurrencyId, targetCurrencyId, d, true));
		} catch (ParseException e) {
			return RestResultHelper.error("illegal date(format):" + date);
		}
	}

	/**
	 * 获取特定两种币别之间的兑换汇率
	 * 
	 * @param originCurrencyId
	 * @param targetCurrencyId
	 * @param date
	 * @return
	 */
	@RequestMapping(value = "/{originCurrencyId}/{targetCurrencyId}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "currency", methodDesc = "获取特定两种币别之间的兑换汇率", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"date" })
	public Result getRate(@PathVariable("originCurrencyId") String originCurrencyId,
			@PathVariable("targetCurrencyId") String targetCurrencyId,
			@RequestParam(value = "date", required = false) String date) {
		logger.debug("getRate(): originCurrencyId={}, targetCurrencyId={}, date={}", originCurrencyId, targetCurrencyId,
				date);
		try {
			final Date d = (date == null || date.isEmpty()) ? new Date() : DATEFORMAT.parse(date);
			BigDecimal ret = currRateService.getRate(originCurrencyId, targetCurrencyId, d);
			return RestResultHelper.success(ret);
		} catch (ParseException e) {
			return RestResultHelper.error("illegal date(format):" + date);
		}
	}

	/**
	 * 按指定日期做汇率换算
	 * 
	 * @param originCurrencyId
	 *            必填
	 * @param targetCurrencyId
	 *            必填
	 * @param amount
	 *            兑换金额，数额，可以是小数，不输入或输入小于等于零则返回错误信息
	 * @param date
	 *            兑换日期，格式符合yyyy-MM-dd，不输入则默认今天
	 * @return
	 */
	@RequestMapping(value = "/{originCurrencyId}/{targetCurrencyId}/{amount:.+}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "currency", methodDesc = "汇率换算", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"date" })
	public Result exchange(@PathVariable("originCurrencyId") String originCurrencyId,
			@PathVariable("targetCurrencyId") String targetCurrencyId,
			@PathVariable(value = "amount", required = false) BigDecimal amount,
			@RequestParam(value = "date", required = false) String date) {
		logger.debug("exchange(): originCurrencyId={}, targetCurrencyId={}, date={}, amount={}", originCurrencyId,
				targetCurrencyId, date, amount);
		// 去掉金额必须为正的限制，财务系统中可能有负值
		// if (amount.compareTo(BigDecimal.ZERO) != 1) {
		// return RestResultHelper.error("illegal amount value:" + amount);
		// }
		try {
			final Date d = (date == null || date.isEmpty()) ? new Date() : DATEFORMAT.parse(date);
			BigDecimal ret = currRateService.exchange(originCurrencyId, targetCurrencyId, amount, d);
			return RestResultHelper.success(ret);
		} catch (ParseException e) {
			return RestResultHelper.error("illegal date(format):" + date);
		}
	}

	/**
	 * 創建匯率維護單
	 *
	 * @param vo
	 *            汇率集合
	 * @return 返回对象id
	 */
	@RequestMapping(value = "/creCurrRateOrder", method = RequestMethod.POST)
	@MethodRegister(edmClass = "currratesetorder", methodDesc = "创建汇率维护单", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"authorization", "CurrRateSetOrderVO" })
	public Result creCurrRateOrder(HttpServletRequest request, @RequestBody CurrRateSetOrderVO vo) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		Map<String, Object> map = null;
		try {
			map = rateService.creCurrRateOrder(request, vo);
			result.setData(map);
		} catch (Exception e) {
			logger.error("currRate/creCurrRateOrder:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
			// if (map != null) {
			// try {
			// rateService.revokeOrder(map.get("orderId").toString());
			// } catch (Exception e1) {
			// logger.error("currRate/creCurrRateOrder:" + e.getMessage());
			// }
			// }
		}
		return result;
	}

	/**
	 * 帮助文档维护单填写审核意见方法
	 *
	 * @param auditSet
	 * @return
	 */
	@RequestMapping(value = "/audit", method = RequestMethod.POST)
	@MethodRegister(edmClass = "currratesetorder", methodCate = "表单通用方法", programCate = ProgramCate.Java, methodDesc = "汇率维护单提交审核意见")
	public Result audit(HttpServletRequest request, @RequestBody JSONObject auditSet) {
		Result result = new Result();
		try {
			rateService.audit(request, auditSet);
		} catch (Exception e) {
			logger.info("audit fail :" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg("提交审核意见失败 :" + e.getMessage());
		}
		return result;
	}

	/**
	 *
	 * @param request
	 * @param orderInstanceId
	 * @param handlerType
	 * @return
	 */
	@RequestMapping(value = "/approve", method = RequestMethod.GET)
	@MethodRegister(edmClass = "currratesetorder", methodCate = "表单通用方法", methodDesc = "汇率维护单通过审批", getReqParamsNameNoPathVariable = {
			"orderInstanceId", "handlerType" })
	public Result approve(HttpServletRequest request, @RequestParam(value = "orderInstanceId") String orderInstanceId,
			@RequestParam(value = "handlerType") String handlerType) {
		Result result = new Result();
		try {
			rateService.approve(request, orderInstanceId, handlerType);
		} catch (Exception e) {
			logger.info("approve fail :" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg("通过审批失败 :" + e.getMessage());
		}
		return result;
	}
}
