package com.huntkey.rx.sceo.provider.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.CurrencyService;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/currencies")
public class ApiOfCurrencyController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private CurrencyService currencyService;

	/**
	 * 根据货币的数据id或系统编码，获取唯一一条数据。
	 * 
	 * @param idOrCode
	 * @return
	 */
	@RequestMapping(value = "/{idOrCode}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "currency", methodDesc = "根据id或编码获取币别", methodCate = "表单通用方法")
	public Result findByIdOrCode(@PathVariable("idOrCode") String idOrCode) {
		CurrencyService.Currency c = currencyService.find(idOrCode);
		if (c == null) {
			c = currencyService.findByCode(idOrCode);
		}
		return RestResultHelper.success(c);
	}

	/**
	 * 条件查询不定量货币信息，按货币名称排序
	 * 
	 * @param name
	 *            货币名称。模糊查询条件，不输入则不限定
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "currency", methodDesc = "条件获取币别", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable" })
	public Result find(@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		return RestResultHelper.success(currencyService.list(name, enable));
	}
}
