package com.huntkey.rx.sceo.provider.api.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.MeasureunitService;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/measures")
public class ApiOfMeasureController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	MeasureunitService measureunitService;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "measureunit", methodDesc = "根据id获取计量（分组）", methodCate = "表单通用方法")
	public Result findById(@PathVariable("id") String id) {
		return RestResultHelper.success(measureunitService.find(id));
	}

	/**
	 * 获取所有计量（也称“计量单位分组”）
	 * 
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "measureunit", methodDesc = "获取所有计量（分组）", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable" })
	public Result find(@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		return RestResultHelper.success(measureunitService.find(enable ? true : null));
	}

	/**
	 * 获取指定计量（计量单位分组）下属的所有单位
	 * 
	 * @param id
	 *            计量（计量单位分组）的数据id
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "/{id}/units", method = RequestMethod.GET)
	@MethodRegister(edmClass = "measureunit", methodDesc = "获取某计量（分组）下所有单位", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable" })
	public Result getUnits(@PathVariable("id") String measureId,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		return RestResultHelper.success(measureunitService.getUnits(measureId, enable ? true : null));
	}

	/**
	 * 获取计量单位符号
	 * 
	 * @param group
	 *            计量分组的id或name
	 * @param unit
	 *            单位的name
	 * @return
	 */
	@RequestMapping(value = "/symbols", method = RequestMethod.GET)
	@MethodRegister(edmClass = "measureunit", methodDesc = "获取计量单位符号", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"group", "unit" })
	public Result getSymbol(@RequestParam(value = "group") String group, @RequestParam(value = "unit") String unit) {
		return RestResultHelper.success(measureunitService.getUnitSymbol(group, unit));
	}
}
