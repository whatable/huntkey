package com.huntkey.rx.sceo.provider.api.controller;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.order.vo.parameter.ParameterOrderVO;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.method.register.plugin.entity.ProgramCate;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.profile.common.service.ParameterService.Parameter;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/parameters")
public class ApiOfParameterController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ParameterService parameterService;

	@Autowired
	com.huntkey.rx.sceo.provider.parameter.service.ParameterService service;

	/**
	 * 根据参数的数据id或编码，获取唯一一条数据。特别的，当输入是"rx:system:standard"，会获得当前系统是否标准系统。
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{idOrCode}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "parameter", methodDesc = "根据id或编码获取参数", methodCate = "表单通用方法")
	public Result findByIdOrCode(@PathVariable("idOrCode") String idOrCode) {
		logger.debug("findByIdOrCode(idOrCode : {})", idOrCode);
		if ("rx:system:standard".equals(idOrCode)) {
			logger.debug("rx:system:standard={}", parameterService.isStandardSystem());
			return RestResultHelper.success(parameterService.isStandardSystem());
		}
		Parameter p = parameterService.find(idOrCode);
		if (p == null) {
			p = parameterService.findByCode(idOrCode);
		}
		return RestResultHelper.success(p);
	}

	@RequestMapping(value = "/_standard", method = RequestMethod.POST)
	public Result switchSystemStandar() {
		return RestResultHelper.success(parameterService.switchSystemStandard());
	}

	/**
	 * 根据多个条件获取不定量参数对象
	 * 
	 * @param pageCode
	 *            页面编码。不输入或输入空串则会直接得到空列表的返回结果
	 * @param type
	 *            参数类型，不输入则不限定
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "parameter", methodDesc = "条件查询参数", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable", "page", "type" })
	public Result find(@RequestParam(value = "page", required = false) String pageCode,
			@RequestParam(value = "type", required = false) String type,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		// 页面编码不输入或输入空串则会直接得到空列表的返回结果
		if (pageCode == null || pageCode.isEmpty()) {
			return RestResultHelper.success(new LinkedList<Parameter>());
		}
		List<Parameter> list = parameterService.find(pageCode, type, enable ? true : null);
		return RestResultHelper.success(list);
	}

	@RequestMapping(value = "/creParamOrder", method = RequestMethod.POST)
	@MethodRegister(edmClass = "parameterorder", methodDesc = "参数设置管理", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"authorization", "ParameterOrderVO" })
	public Result creParamOrder(HttpServletRequest request, @RequestBody ParameterOrderVO orderVO) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		Map<String, String> map = null;
		try {
			map = service.creParamOrder(request, orderVO);
			result.setData(map);
		} catch (Exception e) {
			logger.error("parameters/creParamOrder:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
			// if (map != null) {
			// try {
			// service.revokeOrder(map.get("orderId").toString());
			// } catch (Exception e1) {
			// logger.error("profile/v1/parameters/creParamOrder:" + e.getMessage());
			// }
			// }
		}
		return result;
	}

	/**
	 * 帮助文档维护单填写审核意见方法
	 *
	 * @param auditSet
	 * @return
	 */
	@RequestMapping(value = "/audit", method = RequestMethod.POST)
	@MethodRegister(edmClass = "parameterorder", methodCate = "表单通用方法", programCate = ProgramCate.Java, methodDesc = "参数设置单提交审核意见")
	public Result audit(HttpServletRequest request, @RequestBody JSONObject auditSet) {
		Result result = new Result();
		try {
			service.audit(request, auditSet);
		} catch (Exception e) {
			logger.info("parameterorder audit fail :" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg("提交审核意见失败 :" + e.getMessage());
		}
		return result;
	}

	/**
	 *
	 * @param request
	 * @param orderInstanceId
	 * @param handlerType
	 * @return
	 */
	@RequestMapping(value = "/approve", method = RequestMethod.GET)
	@MethodRegister(edmClass = "parameterorder", methodCate = "表单通用方法", methodDesc = "参数设置单通过审批", getReqParamsNameNoPathVariable = {
			"orderInstanceId", "handlerType" })
	public Result approve(HttpServletRequest request, @RequestParam(value = "orderInstanceId") String orderInstanceId,
			@RequestParam(value = "handlerType") String handlerType) {
		Result result = new Result();
		try {
			service.approve(request, orderInstanceId, handlerType);
		} catch (Exception e) {
			logger.info("parameterorder approve fail :" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg("通过审批失败 :" + e.getMessage());
		}
		return result;
	}
}
