package com.huntkey.rx.sceo.provider.api.controller;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.ParkService;
import com.huntkey.rx.sceo.profile.common.service.ParkService.DeliveryAddress;
import com.huntkey.rx.sceo.profile.common.service.ParkService.Park;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/parks")
public class ApiOfParkController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ParkService parkService;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "park", methodDesc = "根据id获取园区", methodCate = "表单通用方法")
	public Result findById(@PathVariable("id") String id) {
		return RestResultHelper.success(parkService.find(id));
	}

	/**
	 * 获取本司所有园区对象
	 * 
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "park", methodDesc = "获取本司所有园区", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable" })
	public Result find(@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		List<Park> list = parkService.find(null, enable ? true : null);
		return RestResultHelper.success(list);
	}

	/**
	 * 获取本司默认园区对象，默认园区
	 * 
	 * @return
	 */
	@RequestMapping(value = "/default", method = RequestMethod.GET)
	@MethodRegister(edmClass = "park", methodDesc = "获取本司默认园区", methodCate = "表单通用方法")
	public Result findDefault() {
		return RestResultHelper.success(parkService.findDefault());
	}

	/**
	 * 获取指定园区所有收货地址的列表
	 * 
	 * @param id
	 *            园区数据id
	 * @return
	 */
	@RequestMapping(value = "/{id}/deliveryAddresses", method = RequestMethod.GET)
	@MethodRegister(edmClass = "park", methodDesc = "获取某园区所有收货地址", methodCate = "表单通用方法")
	public Result getDeliveryAddressesInPark(@PathVariable("id") String parkId) {
		Park park = parkService.find(parkId);
		if (park == null) {
			return RestResultHelper.success(new LinkedList<DeliveryAddress>());
		} else {
			return RestResultHelper.success(park.getDeliveryAddress());
		}
	}

	/**
	 * 获取特定某个收货地址的详细信息
	 * 
	 * @param id
	 *            收货地址在数据库中的数据id
	 * @return
	 */
	@RequestMapping(value = "/deliveryAddresses/{id}")
	@MethodRegister(edmClass = "park", methodDesc = "根据id获取收货地址", methodCate = "表单通用方法")
	public Result getDeliveryAddressById(@PathVariable("id") String id) {
		return RestResultHelper.success(parkService.findDeliveryAddress(id));
	}

}
