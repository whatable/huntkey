package com.huntkey.rx.sceo.provider.api.controller;

import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.PeriodService;
import com.huntkey.rx.sceo.profile.common.service.PeriodService.Period;
import com.huntkey.rx.sceo.profile.common.service.PeriodService.PeriodType;
import com.huntkey.rx.sceo.provider.period.service.PeriodGeneratingService;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;
import com.huntkey.rx.sceo.provider.utils.Utils;

@RestController
@RequestMapping("/profile/v1/periods")
public class ApiOfPeriodController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	private static final String ERROR_INVALID_PERIOD_TYPE = "Invalid parameter 'type': %s, choose from 'week/quarter/month/year/fiscal-week/fiscal-quarter/fiscal-month/fiscal-year'";

	@Autowired
	PeriodService periodService;

	@Autowired
	PeriodGeneratingService periodGeneratingService;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "period", methodDesc = "根据id获取周期", methodCate = "表单通用方法")
	public Result findById(@PathVariable("id") String id) {
		return RestResultHelper.success(periodService.find(id));
	}

	/**
	 * 根据多个条件获取不定量周期对象。现实意义是用于生成多个周期项的选择列表，如某财年的所有财月。
	 * 
	 * @param fiscalYear
	 *            财年，可输入2000~2099（但含义是财年而不是日历年），不输入则不限定
	 * @param type
	 *            周期类型，可输入week/quarter/month/year/fiscal-week/fiscal-quarter/fiscal-month/fiscal-year/，默认取全部
	 * @param sequence
	 *            期次，数字，不输入则不限定
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "period", methodDesc = "条件获取周期", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable", "type", "sequence", "year" })
	public Result find(@RequestParam(value = "year", required = false) Integer fiscalYear,
			@RequestParam(value = "type", required = false) String type,
			@RequestParam(value = "sequence", required = false) Integer sequence,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		PeriodType periodType = null;
		if (type != null && !type.isEmpty()) {
			try {
				periodType = PeriodType.valueOf(type.toUpperCase());
			} catch (IllegalArgumentException e) {
				return RestResultHelper.error(String.format(ERROR_INVALID_PERIOD_TYPE, type));
			}
		}
		List<Period> list = periodService.find(fiscalYear, periodType, sequence, enable ? true : null);
		return RestResultHelper.success(list);
	}

	/**
	 * 获取所有周期类型的枚举
	 * 
	 * @return
	 */
	@RequestMapping(value = "/types", method = RequestMethod.GET)
	@MethodRegister(edmClass = "period", methodDesc = "获取所有周期类型的枚举", methodCate = "表单通用方法")
	public Result getTypes() {
		List<Map<String, String>> types = new LinkedList<>();
		for (PeriodType t : PeriodType.values()) {
			Map<String, String> m = new HashMap<>();
			m.put(t.name(), t.zhName());
			types.add(m);
		}
		return RestResultHelper.success(types);
	}

	/**
	 * 给定一个日历日期和周期类型，可获取该日期对应的周期对象，年月日任何位置输入0则取当天。
	 * 
	 * @param year
	 *            年，2000~2099，不可空，超出范围会返回预期以外的结果
	 * @param month
	 *            月，1~12，不可空，超出范围会返回预期以外的结果
	 * @param day
	 *            日，符合月内天数的数字，不可空，超出范围会返回预期以外的结果
	 * @param type
	 *            周期类型，接受week/quarter/month/year/fiscal_week/fiscal_quarter/fiscal_month/fiscal_year，必填
	 * @return
	 */
	@RequestMapping(value = "/{y}/{m}/{d}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "period", methodDesc = "获取某天的周期", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"type" })
	public Result findByDay(@PathVariable("y") Integer year, @PathVariable("m") Integer month,
			@PathVariable("d") Integer day, @RequestParam(value = "type", required = false) String type) {
		Calendar c = Calendar.getInstance();
		if (year * month * day != 0) {
			c.set(year, month - 1, day);
			if (c.get(Calendar.YEAR) >= 2100 || c.get(Calendar.YEAR) <= 2000) {
				return RestResultHelper.success(null);
			}
		}
		if (type != null) {
			try {
				PeriodType periodType = PeriodType.valueOf(type.toUpperCase());
				Period p = periodService.find(c.getTime(), periodType);
				return RestResultHelper.success(p);
			} catch (IllegalArgumentException e) {
			}
		}
		return RestResultHelper.error(String.format(ERROR_INVALID_PERIOD_TYPE, type));
	}

	/**
	 * 获取给定周期类型的自然日期时间起始（年月日时分秒到年月日时分秒） 【ADD by jiangshaoh @ 2018-7-28】
	 * 
	 * @param from
	 *            起始周期的id，若不输入，会直接得到返回null
	 * @param to
	 *            结束周期的id，若不输入，则默认以起始周期作为结束周期，也就是取起始周期的开端和结束
	 * @return 两个日期值，分别是起始和结束
	 */
	@RequestMapping(value = "/range", method = RequestMethod.GET)
	@MethodRegister(edmClass = "period", methodDesc = "获取给定周期类型的自然日期时间起始（年月日时分秒到年月日时分秒）", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"from", "to" })
	public Result getRange(@RequestParam(value = "from", required = false) String from,
			@RequestParam(value = "to", required = false) String to) {
		return RestResultHelper.success(periodService.getRange(from, to));
	}

	/**
	 * 获取给定周期类型的自然日期时间起始 【ADD by jiangshaoh @ 2018-8-1】
	 * 
	 * @param type
	 *            周期类型。接受week/quarter/month/year/fiscal_week/fiscal_quarter/fiscal_month/fiscal_year，不输入则默认取fiscal_month
	 * @param year
	 *            财年数字。如2001,2018,2020等，必填。
	 * @param period
	 *            周期在一个财年中的序数，从1开始，必填
	 * @param year2
	 *            财年数字。选填，默认拷贝前一个参数year的值。如果period2未输入，则本参数即使输入也视为未输入。
	 * @param period2
	 *            周期在一个财年中的序数。选填，默认拷贝前一个参数period的值。如果year2未输入，则本参数即使输入也视为未输入。
	 * @return
	 */
	@RequestMapping(value = "/range1", method = RequestMethod.GET)
	@MethodRegister(edmClass = "period", methodDesc = "获取给定周期类型的自然日期时间起始", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"type", "year", "period", "year2", "period2" })
	public Result getRangeByParticular(@RequestParam(value = "type", defaultValue = "FISCAL_MONTH") String type,
			@RequestParam(value = "year", required = true) Integer year,
			@RequestParam(value = "period", required = true) Integer period,
			@RequestParam(value = "year2", required = false) Integer year2,
			@RequestParam(value = "period2", required = false) Integer period2) {

		try {
			PeriodType periodType = PeriodType.valueOf(type.toUpperCase());
			Period from = periodService.find(year, periodType, period);
			if (from == null) {
				return RestResultHelper.error("Can't find any period, check parameters.");
			}
			Period to = year2 != null && period2 != null ? periodService.find(year2, periodType, period2) : from;
			if (to == null) {
				return RestResultHelper.error("Can't find any period, check parameters.");
			}
			return RestResultHelper.success(periodService.getRange(from, to));
		} catch (IllegalArgumentException e) {
			return RestResultHelper.error(String.format(ERROR_INVALID_PERIOD_TYPE, type));
		}
	}

	/**
	 * 自动生成周期数据，供系统初始化模块使用（一般业务模块不要调用）。参数中用到的模式字符串，其模式符号的定义是百分号加一个特定字母，特定字母目前支持包括Y,y,Q,q,M,m,W,w，分别代表年季月周，小写表示短模式（年取2位，季月日只取数字本身不补零），大写表示长模式（年取4位，季月日都显示2位数，缺位补零）
	 * 
	 * 例如“%YFYR”会得到"2018FYR"，"%yM%m"会得到"18M7"或"18M11"，"%YW%W"会得到"2018W07"或"2018W45"
	 * 
	 * @param authorization
	 * @param start
	 *            财年起始，可输入1,2,3,4中的一个值，分别代表取第几个季度的第一天作为财年起始（也就是依次代表1月1日、4月1日、7月1日、10月1日）
	 * @param offset
	 * 
	 * @param fyearPattern
	 *            自定义财年模式串
	 * @param yearPattern
	 *            自定义日历年模式串
	 * @param fquaterPattern
	 *            自定义财年模式串
	 * @param quarterPattern
	 *            自定义日历年模式串
	 * @param fmonthPattern
	 *            自定义财年模式串
	 * @param monthPattern
	 *            自定义日历年模式串
	 * @param fweekPattern
	 *            自定义财年模式串
	 * @param weekPattern
	 *            自定义日历年模式串
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.POST)
	@MethodRegister(edmClass = "period", methodDesc = "初始化周期数据（慎用！业务系统禁用！）", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"inception", "authorization", "start", "offset", "fy", "y", "fq", "q", "fm", "m", "fw", "w" })
	public Result generate(@RequestParam(value = "authorization") String authorization,
			@RequestParam(value = "inception", defaultValue = "1") Integer inception,
			@RequestParam(value = "start", defaultValue = "2000") Integer start,
			@RequestParam(value = "offset", defaultValue = "100") Integer offset,
			@RequestParam(value = "fy", required = false) String fyearPattern,
			@RequestParam(value = "y", required = false) String yearPattern,
			@RequestParam(value = "fq", required = false) String fquaterPattern,
			@RequestParam(value = "q", required = false) String quarterPattern,
			@RequestParam(value = "fm", required = false) String fmonthPattern,
			@RequestParam(value = "m", required = false) String monthPattern,
			@RequestParam(value = "fw", required = false) String fweekPattern,
			@RequestParam(value = "w", required = false) String weekPattern) {
		if (1 > inception || 4 < inception) {
			return RestResultHelper.error("invalid value of parameter 'inception':" + inception + "(invalid:1/2/3/4)");
		}
		String userId = Utils.getCurentUserId(authorization);

		final int g = periodGeneratingService.generate(userId, start, offset, inception, fyearPattern, yearPattern,
				fquaterPattern, quarterPattern, fmonthPattern, monthPattern, fweekPattern, weekPattern);
		switch (g) {
		case 0:
			return RestResultHelper.success("Generating is in processing. plz check the datas after about 2 minute.");
		case -1:
			return RestResultHelper.error("Previous generating is still in processing. plz call later.");

		default:
			return RestResultHelper.error("Unknown result.");
		}
	}

}
