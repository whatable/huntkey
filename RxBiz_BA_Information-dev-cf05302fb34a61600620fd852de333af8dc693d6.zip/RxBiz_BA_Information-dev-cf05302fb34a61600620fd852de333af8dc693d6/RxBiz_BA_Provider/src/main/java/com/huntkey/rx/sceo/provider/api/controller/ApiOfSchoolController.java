package com.huntkey.rx.sceo.provider.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.SchoolService;
import com.huntkey.rx.sceo.profile.common.service.SchoolService.School;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/schools")
public class ApiOfSchoolController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	SchoolService schoolService;

	/**
	 * 根据学校的数据id，获取唯一一条数据。
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "school", methodDesc = "根据id获取学校", methodCate = "表单通用方法")
	public Result findById(@PathVariable("id") String id) {
		School s = schoolService.find(id);
		return RestResultHelper.success(s);
	}

	/**
	 * 多个条件查询不定量学校对象
	 * 
	 * @param name
	 *            学校名称。模糊查询条件，不输入则不限定
	 * @param cityId
	 *            学校所在城市id。精确查询条件，不输入则不限定
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "school", methodDesc = "条件查询学校", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable", "name", "city" })
	public Result find(@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "city", required = false) String cityId,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		List<School> list = schoolService.list(name, cityId, enable ? true : null);
		return RestResultHelper.success(list);
	}
}
