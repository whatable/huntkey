package com.huntkey.rx.sceo.provider.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.TaxrateService;
import com.huntkey.rx.sceo.profile.common.service.TaxrateService.Taxrate;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/taxrates")
public class ApiOfTaxrateController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	TaxrateService taxrateService;

	/**
	 * 根据税率的数据id或编码，获取唯一一条数据。
	 * 
	 * @param idOrCode
	 * @return
	 */
	@RequestMapping(value = "/{idOrCode}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "taxrate", methodDesc = "根据id或编码获取税率", methodCate = "表单通用方法")
	public Result findByIdOrCode(@PathVariable("idOrCode") String idOrCode) {
		Taxrate t = taxrateService.find(idOrCode);
		if (t == null) {
			t = taxrateService.findByCode(idOrCode);
		}
		return RestResultHelper.success(t);
	}

	/**
	 * 根据多个条件获取不定量税率对象
	 * 
	 * @param name
	 *            税种名称，模糊查询条件，不输入则不限定
	 * @param isDeduct
	 *            是否可抵扣，可输入true/false，不输入则不限定
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "taxrate", methodDesc = "条件税率", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable", "name", "deduct" })
	public Result find(@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "deduct", required = false) Boolean isDeduct,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		List<Taxrate> list = taxrateService.find(name, isDeduct, enable ? true : null);
		return RestResultHelper.success(list);
	}
}
