package com.huntkey.rx.sceo.provider.api.controller;

import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.TipmessageService;
import com.huntkey.rx.sceo.profile.common.service.TipmessageService.Tipmessage;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/tipmessages")
public class ApiOfTipmessageController {

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	TipmessageService tipmessageService;

	@RequestMapping(value = "/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "tipmessage", methodDesc = "根据id获取提示信息", methodCate = "表单通用方法")
	public Result findById(@PathVariable("id") String id) {
		Tipmessage t = tipmessageService.find(id);
		return RestResultHelper.success(t);
	}

	/**
	 * 根据页面编码等多个条件，获取不定量提示信息。
	 * 
	 * @param pageCode
	 *            页面编码，不填则直接返回空列表
	 * @param type
	 *            信息类型，具体可填内容参见edm说明，不输入则不限定
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "tipmessage", methodDesc = "条件查询提示信息", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable", "page", "type" })
	public Result find(@RequestParam(value = "page", required = false) String pageCode,
			@RequestParam(value = "type", required = false) String type,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		if (pageCode == null || pageCode.isEmpty()) {
			return RestResultHelper.success(new LinkedList<Tipmessage>());
		}
		List<Tipmessage> list = tipmessageService.find(pageCode, type, enable ? true : null);
		return RestResultHelper.success(list);
	}
}
