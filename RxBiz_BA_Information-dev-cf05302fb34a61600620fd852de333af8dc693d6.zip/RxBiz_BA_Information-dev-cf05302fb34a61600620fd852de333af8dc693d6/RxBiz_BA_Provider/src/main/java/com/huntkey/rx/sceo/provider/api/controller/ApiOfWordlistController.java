package com.huntkey.rx.sceo.provider.api.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.profile.common.service.OldWordlistService;
import com.huntkey.rx.sceo.profile.common.service.WordlistService;
import com.huntkey.rx.sceo.profile.common.service.WordlistService.Wordlist;
import com.huntkey.rx.sceo.profile.common.service.WordlistService.WordlistType;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;

@RestController
@RequestMapping("/profile/v1/wordlists")
public class ApiOfWordlistController {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	WordlistService wordlistService;

	@Autowired
	OldWordlistService oldWordlistService;

	/**
	 * @param idOrCodes
	 *            id或codes，多个code用逗号隔开拼成一个字符串
	 * @param enable
	 *            find by id的场景下，无视enable
	 * @return
	 */
	@RequestMapping(value = "/{idOrCodes}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "根据id或codes获取枚举（多个code用逗号分隔）", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable" })
	public Result findByIdOrCodes(@PathVariable("idOrCodes") String idOrCodes,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		Wordlist w = wordlistService.find(idOrCodes);
		if (w != null) {
			return RestResultHelper.success(w);// find by id的场景下，无视enable
		} else {
			return RestResultHelper.success(wordlistService.findKeysByCodes(enable, idOrCodes.split(",")));
		}
	}

	/**
	 * 获取所有的枚举关键字(word_par为NUL)
	 * 
	 * @param name
	 *            枚举名，模糊查询条件，不输入则不限定
	 * @param codes
	 *            枚举编码，多个code用逗号隔开拼成一个字符串 (新增by jiangshaoh @2018-7-17)
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return
	 */
	@RequestMapping(value = "", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "获取枚举关键字", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"name", "codes", "enable" })
	public Result findKeys(@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "codes", required = false) String codes,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		List<Wordlist> list = wordlistService.find(name, enable ? true : null,
				(codes != null && codes.length() > 0) ? codes.split(",") : null);
		return RestResultHelper.success(list);
	}

	/**
	 * 条件获取枚举关键字(word_par为NUL)，可分页
	 * 
	 * @param name
	 *            枚举名，模糊查询条件，不输入则不限定
	 * @param type
	 *            数据结构类型，列表(1)或树(2)，不输入则不限定，输入1、2以外的值会取不到任何数据 【新增】by
	 *            jiangshaoh@2018-7-28
	 * @param pageNum
	 *            页码，不输入则默认1
	 * @param pageSize
	 *            页大小，不输入则默认15
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return 数据域是Pagination<Wordlist>对象
	 */
	@RequestMapping(value = "/page", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "获取枚举关键字（分页）", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"type", "name", "enable", "pageNum", "pageSize" })
	public Result findKeysAsPage(@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "type", required = false) Integer type,
			@RequestParam(value = "pageNum", defaultValue = "1") Integer pageNum,
			@RequestParam(value = "pageSize", defaultValue = "15") Integer pageSize,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		logger.debug("type={}, pageSize={}, pageNum={}", type, pageSize, pageNum);
		if (type != null) {
			return RestResultHelper.success(wordlistService.find(type, name, enable ? true : null, pageNum, pageSize));
		} else {
			return RestResultHelper.success(wordlistService.find(name, enable ? true : null, pageNum, pageSize));
		}
	}

	/**
	 * 获取指定枚举关键字下所有的项
	 * 
	 * @param id
	 *            枚举关键字数据id
	 * @param enable
	 *            是否有效，接受的值是true(default)/false。默认输入true，只取有效数据；输入false则包含有效和无效的；（不支持只取无效的）
	 * @return 数据区域data中包含两个子属性，一是type属性，声明枚举项的内在数据结构，是TREE/ENUM/ELEMENT/ISOLATE中的一种；二是wordlist属性，是枚举项的列表
	 */
	@RequestMapping(value = "/{id}/options", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "获取某枚举关键字下的项", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enable" })
	public Result getOptions(@PathVariable("id") String id,
			@RequestParam(value = "enable", defaultValue = "true") Boolean enable) {
		WordlistType type = wordlistService.typeOf(id);
		List<Wordlist> list = wordlistService.getOptions(id, enable ? true : null);
		Map<String, Object> m = new HashMap<>();
		m.put("type", type.toString());
		m.put("wordlist", list);
		return RestResultHelper.success(m);
	}

	/**
	 * 根据关键字编码和枚举项名称等条件查询枚举项
	 * 
	 * @param codes
	 *            枚举关键字编码，多个用逗号隔开，精确查询条件，必填项，若输入空白则方法直接返回空列表
	 * @param name
	 *            枚举项名称，模糊条件
	 * @return
	 */
	@RequestMapping(value = "/options", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "根据关键字编码和枚举项名称等条件查询枚举项", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"codes", "name" })
	public Result findOptions(@RequestParam(value = "codes", defaultValue = "") String codes,
			@RequestParam(value = "name", required = false) String name) {
		return RestResultHelper.success(wordlistService.getOptions(codes.isEmpty() ? null : codes.split(","), name));
	}

	/**
	 * 【兼容方法】根据枚举关键字编码，获取枚举树，可输入多个编码，用逗号隔开
	 * 
	 * @param enumCodes
	 *            枚举关键字编码，多个用逗号隔开，不输入则取全部
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/old/enums/objects", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "【兼容方法】根据枚举关键字编码，获取枚举树，可输入多个", methodCate = "表单通用方法", getReqParamsNameNoPathVariable = {
			"enumCodes" })
	public Result getEnumObjectsByCodes(@RequestParam(value = "enumCodes", required = false) String enumCodes)
			throws Exception {
		return RestResultHelper.success(oldWordlistService
				.getEnumObjectsByCodes((enumCodes == null || enumCodes.isEmpty()) ? null : enumCodes.split(",")));
	}

	@RequestMapping(value = "/getObject", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "根据上级词汇对象code和本级code查询枚举", methodCate = "表单通用方法",
			getReqParamsNameNoPathVariable = {"parCode","code"})
	public Result getEnumObject(@RequestParam(value = "parCode")String parCode,@RequestParam(value = "code")String code){
		List<Map<String, Object>> map = null;
		try {
            /**
             * 老接口，据明建说这个没用，所以更改了实现方式
             */
//			map = oldWordlistService.getEnumObject(parCode, code);
			map = wordlistService.getEnumObject(parCode, code);
		}catch (Exception e){
			logger.info("/profile/v1/wordlists/getObject", e.getMessage());
		}
		return RestResultHelper.success(map);
	}

	/**
	 * 根据枚举id和子节点枚举code，查询子节点
	 * @param id 枚举id
	 * @param childCode 子节点枚举code
	 * @param enable 子节点枚举是否启用
	 * @return
	 */
	@RequestMapping(value = "/getEnumChild/{id}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "根据上级词汇对象id和本级code查询枚举", methodCate = "表单通用方法",
			getReqParamsNameNoPathVariable = {"childCode", "enable"})
	public Result getEnumChild(@PathVariable(value = "id")String id,
							   @RequestParam(value = "childCode")String childCode,
							   @RequestParam(required = false,value = "enable", defaultValue = "true")boolean enable){
		Wordlist childWord = null;
		try {
			childWord = wordlistService.getEnumChild(id, childCode, enable);
		}catch (Exception e){
			logger.info("/profile/v1/wordlists/getObject", e.getMessage());
		}
		return RestResultHelper.success(childWord);
	}

	@RequestMapping(value = "/getWordlistByIds/{ids}", method = RequestMethod.GET)
	@MethodRegister(edmClass = "wordlist", methodDesc = "根据枚举id集查询枚举，多个id通过英文“,”分割", methodCate = "表单通用方法")
	public Result getWordlistByIds(@PathVariable(value = "ids")String ids){
		List<Wordlist> wordlists = null;
		try {
			wordlists = wordlistService.getWordlistByIds(ids);
		}catch (Exception e){
			logger.info("/profile/v1/wordlists/getByIds", e.getMessage());
		}
		return RestResultHelper.success(wordlists);
	}
}
