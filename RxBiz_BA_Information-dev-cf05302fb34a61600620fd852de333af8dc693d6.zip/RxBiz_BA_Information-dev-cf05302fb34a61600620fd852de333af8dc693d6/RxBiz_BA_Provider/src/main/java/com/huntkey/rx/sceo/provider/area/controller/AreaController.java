package com.huntkey.rx.sceo.provider.area.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;
import com.huntkey.rx.sceo.provider.area.service.AreaService;
import com.huntkey.rx.sceo.provider.utils.Utils;

/**
 * 区域
 * 
 * @author liucs
 * @date 2018-3-30 14:21:35
 */
@RestController
@RequestMapping("/area")
public class AreaController {
	private static Logger logger = LoggerFactory.getLogger(AreaController.class);
	@Autowired
	private AreaService areaService;

	/**
	 * 新增
	 * 
	 * @param authorization
	 *            用户登录认证
	 * @param areaVO
	 *            区域对象
	 * @return 返回对象id
	 */
	@RequestMapping(value = "/v1/insert", method = RequestMethod.POST)
	public Result insert(@RequestParam("authorization") String authorization, @RequestBody AreaVO areaVO) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		// 当前登录用户id
		String currentUserId = Utils.getCurentUserId(authorization);
		areaVO.setCreuser(currentUserId);
		try {
			result.setData(areaService.insert(areaVO));
		} catch (Exception e) {
			logger.error("area/v1/insert:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 删除
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param id
	 *            对象id
	 * @return 返回删除数量
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public Result delete(@RequestParam("authorization") String authorization, @RequestParam("id") String id) {
		String currentUserId = Utils.getCurentUserId(authorization);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.delete(currentUserId, id));
		} catch (Exception e) {
			logger.error("area/delete:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 修改
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param areaVO
	 *            统计对象
	 * @return 返回修改记录条数
	 */
	@RequestMapping(value = "/v1/update", method = RequestMethod.PUT)
	public Result update(@RequestParam("authorization") String authorization, @RequestBody AreaVO areaVO) {
		String currentUserId = Utils.getCurentUserId(authorization);
		areaVO.setModuser(currentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.update(areaVO));
		} catch (Exception e) {
			logger.error("area/v1/update:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 根据id查询
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/v1/qeuryObjectById/{id}", method = RequestMethod.GET)
	public Result qeuryObjectById(@PathVariable(value = "id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.queryById(id));
		} catch (Exception e) {
			logger.error("area/v1/qeuryObjectById/{id}:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 分页、模糊查询税率列表
	 * @param countryId 国家id
	 * @return
	 */
	@RequestMapping(value = "/v1/list", method = RequestMethod.GET)
	public Result list(@RequestParam(required = false,value = "countryId")String countryId) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.list(countryId));
		} catch (Exception e) {
			logger.error("area/v1/list:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 模糊查询、查询下级区域列表
	 * 
	 * @param areaParentArea
	 *            区域上一级
	 * @param areaEnable
	 *            启用/禁用
	 * @return
	 */
	@RequestMapping(value = "/v1/childList", method = RequestMethod.GET)
	public Result childList(@RequestParam(required = false, value = "areaParentArea") String areaParentArea,
			@RequestParam(required = false, value = "areaEnable") String areaEnable) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.childList(areaParentArea, areaEnable));
		} catch (Exception e) {
			logger.error("area/v1/childList:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 查询省市级联数据
	 * 
	 * @return
	 */
	@RequestMapping(value = "/v1/loadOptions", method = RequestMethod.GET)
	public Result loadOptions() {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			List<AreaVO> voList = areaService.loadOptions();
			areaService.sorListByChineseName(voList);
			result.setData(voList);
		} catch (Exception e) {
			logger.error("area/v1/loadOptions:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 区域中文排序
	 * 
	 * @param areaParentArea
	 * @return
	 */
	@RequestMapping(value = "/v1/sortList/{areaParentArea}", method = RequestMethod.GET)
	public Result sortList(@PathVariable(value = "areaParentArea", required = false) String areaParentArea) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			List<AreaVO> voList = areaService.objectsByParent(areaParentArea, null);
			areaService.sorListByChineseName(voList);
			result.setData(voList);
		} catch (Exception e) {
			logger.error("area/v1/sortList:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 上下移
	 * 
	 * @param entityList
	 * @return
	 */
	@RequestMapping(value = "/updateList", method = RequestMethod.PUT)
	public Result sortArea(@RequestBody List<AreaVO> entityList) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.updateList(entityList));
		} catch (Exception e) {
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 查询国家列表
	 * @return
	 */
	@RequestMapping(value = "/countryList",method = RequestMethod.GET)
	public Result countryList () {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.countryList());
		} catch (Exception e) {
			logger.info("area/countryList:",e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 
	 * 根据id查询——公共接口
	 * 
	 * @param id
	 *            对象id
	 * @return 返回对象
	 */
	@RequestMapping(value = "/v1/objects/{id}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "area", methodDesc = "根据id查询区域", methodCate =
	// "表单通用方法")
	@Deprecated
	public Result queryById(@PathVariable(value = "id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.queryById(id));
		} catch (Exception e) {
			logger.error("area/v1/objects/{id}:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 根据上级查询——公共接口
	 * 
	 * @param parentArea
	 * @return
	 */
	@RequestMapping(value = "/v1/objectsByParent/{parentArea}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "area", methodDesc = "根据上级区域码查询区域列表", methodCate =
	// "表单通用方法", getReqParamsNameNoPathVariable = {
	// "areaEnable" })
	@Deprecated
	public Result objectsByParent(@PathVariable(value = "parentArea", required = false) String parentArea,
			@RequestParam(value = "areaEnable", required = false) String areaEnable) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(areaService.objectsByParent(parentArea, areaEnable));
		} catch (Exception e) {
			logger.error("area/v1/objectsByParent/{pid}:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

}
