package com.huntkey.rx.sceo.provider.area.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;

import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 09:13:47
 */
public interface AreaService {

    /**
     * 新增
     * @param areaVO 区域对象
     * @return 返回对象id
     * @throws Exception 抛出异常
     */
    String insert(AreaVO areaVO)throws Exception;

    /**
     * 删除
     * @param id 对象id
     * @param currentUserId 当前登录用户id
     * @return 返回删除数量
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 修改
     * @param areaVO 区域对象
     * @return 返回修改数量
     * @throws Exception 抛出异常
     */
    int update(AreaVO areaVO)throws Exception;

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回区域对象
     * @throws Exception 抛出异常
     */
    AreaVO queryById(String id)throws Exception;

    List<AreaVO> objectsByParent(String areaParentArea,String areaEnable)throws Exception;

    /**
     * @return 返回区域列表
     * @throws Exception 抛出异常
     */
    List<AreaVO> list(String countryId)throws Exception;

    /**
     * 模糊查询、查询下级区域列表
     * @param areaParentArea 区域上一级
     * @param areaEnable 启用/禁用
     * @return
     * @throws Exception
     */
    List<AreaVO> childList(String areaParentArea,String areaEnable) throws Exception;

    /**
     * 省市级联数据
     * @return
     * @throws Exception
     */
    List<AreaVO> loadOptions() throws Exception;

    /**
     * 上下移
     * @param entityList
     * @return
     * @throws Exception
     */
    String updateList(List<AreaVO> entityList)throws Exception;

    /**
     * 	 查询国家列表
     * @return
     * @throws Exception
     */
    List<AreaVO> countryList()throws Exception;

    /**
     * 根据中文名称排序
     * @param list
     * @return
     */
    List<AreaVO> sorListByChineseName(List<AreaVO> list);
}
