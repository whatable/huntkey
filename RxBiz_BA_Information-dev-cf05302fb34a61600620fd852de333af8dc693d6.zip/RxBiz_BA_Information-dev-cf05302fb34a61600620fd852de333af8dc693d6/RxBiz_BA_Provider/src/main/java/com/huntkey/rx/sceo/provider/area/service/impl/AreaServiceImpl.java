package com.huntkey.rx.sceo.provider.area.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.AreaProperty;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.sceo.common.model.area.AreaConstant;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.code.Const.NumberRulesConst;
import com.huntkey.rx.sceo.common.model.paramter.constant.ParameterConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.provider.area.service.AreaService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;

import org.apache.poi.ss.formula.functions.Roman;
import org.apache.tomcat.jni.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import scala.App;

import java.text.Collator;
import java.util.*;

/**
 * @author liucs
 * @date 2018-4-2 09:27:26
 */
@Service
@Transactional(rollbackFor = Exception.class)
public class AreaServiceImpl implements AreaService {
    @Autowired
    private OrmService ormService;
    @Autowired
    private ParameterService parameterService;

    @Override
    public String insert(AreaVO areaVO) throws Exception {
        // 判断是否标准系统
        boolean isStandardSystem = parameterService.isStandardSystem();
        if (!isStandardSystem) {
            areaVO.setAreaIsStandard(Constants.NOT_STANDARD);
        }
        //areaCode和areaName非空校验
        if (StringUtil.isNullOrEmpty(areaVO.getAreaCode().trim())){
            throw new RuntimeException("区域代码为空！");
        }
        if(StringUtil.isNullOrEmpty(areaVO.getAreaName().trim())){
            throw new RuntimeException("区域名称为空");
        }
        //areaCode重复校验
        if(isExistAreaCode(areaVO)){
            throw new RuntimeException("区域代码重复！");
        }
        //areaName重复校验
        if(isExistAreaName(areaVO)){
            throw new RuntimeException("区域名称重复！");
        }
        AreaEntity areaEntity = JSONObject.parseObject(JSONObject.toJSONString(areaVO),AreaEntity.class);

        //查询兄弟区域数量；
        long brotherCount = queryBrotherCount(areaVO);
        //若兄弟区域数量为0，则排序码为1，否则为兄弟区域数量加1
        if(brotherCount == 0){
            areaEntity.setArea_order(1);
        }else{
            areaEntity.setArea_order((int) (brotherCount+1));
        }
        //如果区域上级为空则直接添加，否则拼接区域层级码;
        if(!StringUtil.isNullOrEmpty(areaVO.getAreaParentArea())){
            areaEntity.setArea_level(spliAreaLevel(areaEntity));
        }
        areaEntity.setArea_level(areaEntity.getArea_level()+",");
        return ormService.insert(areaEntity).toString();
    }



    @Override
    public int delete(String currentUserId, String id) throws Exception {
        AreaEntity entity = new AreaEntity();
        entity.setModuser(currentUserId);
        entity.setId(id);
        ormService.updateSelective(entity);
        return ormService.delete(AreaEntity.class,id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(AreaVO areaVO) throws Exception {
        OrmParam ormParam = new OrmParam();
        List<String> columns = Arrays.asList("id,area_parent_area");
        ormParam.setColumns(columns);
        //areaCode和areaName非空校验
        if (StringUtil.isNullOrEmpty(areaVO.getAreaCode().trim())){
            throw new RuntimeException("区域代码名称为空！");
        }
        if(StringUtil.isNullOrEmpty(areaVO.getAreaName().trim())){
            throw new RuntimeException("区域名称为空");
        }
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_CODE,areaVO.getAreaCode().trim())));
        List<AreaEntity> codeEntities = ormService.selectBeanList(AreaEntity.class,ormParam);
        //areaCode重复校验
        if(codeEntities != null && codeEntities.size() > 0){
            if(codeEntities.size() > 1 || !codeEntities.get(0).getId().equals(areaVO.getId())){
                throw new RuntimeException("区域代码重复！");
            }
        }
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_NAME,areaVO.getAreaName().trim())));
        List<AreaEntity> nameEntities = ormService.selectBeanList(AreaEntity.class,ormParam);
        //areaName重复校验
        if(nameEntities != null && nameEntities.size() > 0){
            for (AreaEntity nameEntity : nameEntities) {
                if(areaVO.getAreaParentArea().equals(nameEntity.getArea_parent_area()) && !areaVO.getId().equals(nameEntity.getId())){
                    throw new RuntimeException("区域名称重复！");
                }
            }
        }
        AreaEntity areaEntity = JSONObject.parseObject(JSONObject.toJSONString(areaVO),AreaEntity.class);
        AreaEntity oldEntity = ormService.load(AreaEntity.class,areaVO.getId());
        //修改了上级区域情况，1、重新拼接层级码，2、同时要修改区域排序码
        if(StringUtils.isNotEmpty(areaVO.getAreaParentArea()) && !areaVO.getAreaParentArea().equals(oldEntity.getArea_parent_area())){
            //查询兄弟区域数量；
            long brotherCount = queryBrotherCount(areaVO);
            //则排序码为兄弟区域数量加1
            areaEntity.setArea_order((int) (brotherCount+1));
            areaEntity.setArea_level(spliAreaLevel(areaEntity));
        }
        // 如果区域修改为禁用,则同时设置其下级区域为禁用状态
        if(areaVO.getAreaEnable().equals(Constants.DISABLE) &&!areaVO.getAreaEnable().equals(oldEntity.getArea_enable())){
            String[] ids = {areaVO.getId()};
            setChildrenDisable(ids);
        }
        if(areaEntity.getArea_level().lastIndexOf(",") != areaEntity.getArea_level().length()-1){
            areaEntity.setArea_level(areaEntity.getArea_level()+",");
        }
        return ormService.updateSelective(areaEntity);
    }

    @Override
    public AreaVO queryById(String id) throws Exception {
        AreaEntity entity = ormService.load(AreaEntity.class,id);
        if(entity == null){
            return null;
        }
        AreaVO areaVO = JSONObject.parseObject(JSONObject.toJSONString(entity),AreaVO.class);
        setParentName(areaVO);
        return areaVO;
    }

    @Override
    public List<AreaVO> objectsByParent(String parentArea,String areaEnable) throws Exception {
        OrmParam ormParam = setQueryCondition(null,parentArea,areaEnable);
        List<AreaEntity> entityList = ormService.selectBeanList(AreaEntity.class, ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        List<AreaVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),AreaVO.class);
        for (AreaVO areaVO : voList) {
            setParentName(areaVO);
        }
        return voList;
    }

    @Override
    public List<AreaVO> list(String countryId) throws Exception {
        //设置查询属性
        List<String> list = Arrays.asList(AreaConstant.AREA_IS_STANDARD,AreaProperty.AREA_PARENT_AREA,AreaProperty.AREA_LEVEL,
                AreaProperty.AREA_ORDER,AreaProperty.AREA_DESC,AreaProperty.AREA_CODE,AreaProperty.AREA_NAME,AreaConstant.AREA_ENABLE);
        List<String> columns = new ArrayList<>(list);
        Utils.setBaseQueryColums(columns);
        columns.remove("pid");
        //设置查询国家级区域条件
        OrmParam ormParam = new OrmParam();
        String whereExp = "";
        // countryId 为空则默认为中国
        if(!StringUtil.isNullOrEmpty(countryId)){
            whereExp = OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_PARENT_AREA,countryId),whereExp);
        }else{
            OrmParam var = new OrmParam();
            StringBuilder where = new StringBuilder();
            where.append(" and ").append(var.getMatchMiddleXML(AreaProperty.AREA_NAME,"中国"));
            where.append(" and (").append(var.getIsNull(AreaProperty.AREA_PARENT_AREA)).append(" or ");
            where.append(var.getEqualXML(AreaProperty.AREA_PARENT_AREA,"")).append(")");
            var.setWhereExp(where.toString());
            List<AreaEntity> chinas = ormService.selectBeanList(AreaEntity.class,var);
            whereExp = OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_PARENT_AREA,chinas.get(0).getId()),whereExp);
        }
        ormParam.setWhereExp(whereExp);
        ormParam.setColumns(columns);
        //查询省列表
        List<AreaEntity> provEntities = ormService.selectBeanList(AreaEntity.class,ormParam);
        if(provEntities == null || provEntities.size() == 0){
            return null;
        }
        AreaEntity contry = ormService.load(AreaEntity.class, provEntities.get(0).getArea_parent_area());
        //entity转VO
        List<AreaVO> provList = JSONObject.parseArray(JSONObject.toJSONString(provEntities),AreaVO.class);
        for (AreaVO areaVO : provList) {
            areaVO.setLevel(areaVO.getAreaLevel().split(",").length);
            areaVO.setModUserName(Utils.getUserNameByUserId(areaVO.getModuser(),ormService));
            areaVO.setCreUserName(Utils.getUserNameByUserId(areaVO.getCreuser(),ormService));
            areaVO.setParentAreaName(contry.getArea_name());
//            String where = "";
//            ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_PARENT_AREA,areaVO.getId()),where));
//            ormParam.setOrderExp(SQLSortEnum.ASC,AreaConstant.AREA_ORDER);
//            List<AreaEntity> cityEntities = ormService.selectBeanList(AreaEntity.class,ormParam);
//            List<AreaVO> cityList = JSONObject.parseArray(JSONObject.toJSONString(cityEntities),AreaVO.class);
//            for (AreaVO vo : cityList) {
//                vo.setLevel(vo.getAreaLevel().split(",").length);
//                vo.setModUserName(Utils.getUserNameByUserId(vo.getModuser(),ormService));
//                vo.setCreUserName(Utils.getUserNameByUserId(vo.getCreuser(),ormService));
//                vo.setParentAreaName(areaVO.getAreaName());
//            }
//            areaVO.setAreaVOS(cityList);
        }
        return provList;
    }

    @Override
    public List<AreaVO> childList(String areaParentArea, String areaEnable) throws Exception {
        //如果areaParentArea为空，则返回list()
        if (StringUtil.isNullOrEmpty(areaParentArea)){
            return this.list(areaEnable);
        }
        OrmParam ormParam = setQueryCondition(null,areaParentArea,areaEnable);
        //根据条件查询去与集合
        List<AreaEntity> childentities = ormService.selectBeanList(AreaEntity.class,ormParam);
        if(childentities == null || childentities.size()==0){
            return null;
        }
        List<AreaVO> childList = JSONObject.parseArray(JSONObject.toJSONString(childentities),AreaVO.class);
        for (AreaVO areaVO : childList) {
            areaVO.setLevel(areaVO.getAreaLevel().split(",").length);
            setParentName(areaVO);
        }
        return childList;
    }

    @Override
    public List<AreaVO> loadOptions() throws Exception {
        String provSql = "select id, area_name from area where LENGTH(area_level) = 8 and is_del = 0 and area_enable=1";
        List<Map<String,Object>> provList = ormService.getDataBySql(provSql);
        if(provList == null || provList.size() == 0){
            return null;
        }
        List<AreaVO> provAreaList = JSONObject.parseArray(JSONObject.toJSONString(provList),AreaVO.class);
//        OrmParam ormParam = new OrmParam();
//        ormParam.setColumns(Arrays.asList("id","area_name"));
//        List<AreaEntity> cityList;
//        for (AreaVO areaVO : provAreaList) {
//            ormParam.setWhereExp(ormParam.getEqualXML(AreaProperty.AREA_PARENT_AREA,areaVO.getId()));
//            cityList = ormService.selectBeanList(AreaEntity.class,ormParam);
//            if(cityList != null && cityList.size() > 0){
//                List<AreaVO> areaVOS = JSONObject.parseArray(JSONObject.toJSONString(cityList),AreaVO.class);
//                areaVO.setAreaVOS(areaVOS);
//            }
//        }
        return provAreaList;
    }


    @Override
    @Transactional(readOnly = false,rollbackFor = Exception.class)
    public String updateList(List<AreaVO> entityList) throws Exception {
        List<AreaEntity> list = JSONObject.parseArray(JSONObject.toJSONString(entityList),AreaEntity.class);
        //临时集合记录排序值
        List<Integer> areaSeqs = new ArrayList<>(entityList.size());
        for (AreaEntity entity : list) {
            areaSeqs.add(entity.getArea_order());
        }
        //排序
        Collections.sort(areaSeqs);
        int index = 0;
        int len = entityList.size();
        for (AreaEntity entity : list) {
            entity.setArea_order(areaSeqs.get(index++));
            len -= ormService.updateSelective(entity);
        }
        if(len == 0){
            return "success";
        }
        return "warning";
    }

    @Override
    public List<AreaVO> countryList() throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(OrmParam.or(ormParam.getIsNull(AreaConstant.AREA_PARENT_AREA),ormParam.getEqualXML(AreaConstant.AREA_PARENT_AREA,"")));
        List<AreaEntity> countryList = ormService.selectBeanList(AreaEntity.class,ormParam);
        List<AreaVO> voList = JSONObject.parseArray(JSONObject.toJSONString(countryList),AreaVO.class);
        return voList;
    }

    /**
     * 拼接查询条件
     * @param areaName 查询参数
     * @param areaParentArea 区域上级
     * @param areaEnable 启用/禁用
     * @return 返回OrmParm
     */
    private OrmParam setQueryCondition(String areaName,String areaParentArea,String areaEnable){
        //设置查询属性
        List<String> columns = new ArrayList<>(Arrays.asList(AreaConstant.AREA_IS_STANDARD,AreaConstant.AREA_PARENT_AREA,AreaConstant.AREA_LEVEL,
                AreaConstant.AREA_ORDER,AreaConstant.AREA_DESC,AreaConstant.AREA_CODE,AreaConstant.AREA_NAME,AreaConstant.AREA_ENABLE));
        Utils.setBaseQueryColums(columns);
        columns.remove("pid");
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columns);
        String whereExp = "";
        if(StringUtils.isNotEmpty(areaName)){
            whereExp = OrmParam.and(ormParam.getMatchMiddleXML(AreaConstant.AREA_NAME,areaName));
        }

        if(StringUtils.isNotEmpty(areaParentArea)){
            whereExp = OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_PARENT_AREA,areaParentArea),whereExp);
        }
        if(StringUtils.isNotEmpty(areaEnable)){
            whereExp = OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_ENABLE,areaEnable),whereExp);
        }

        ormParam.setWhereExp(whereExp);
        ormParam.setOrderExp(SQLSortEnum.ASC,AreaConstant.AREA_ORDER);
        return ormParam;
    }

    /**
     * 区域中文名称排序
     * @param voList
     * @return
     */
    @Override
    public List<AreaVO> sorListByChineseName(List<AreaVO> voList){
        Collections.sort(voList,(AreaVO o1,AreaVO o2)-> Collator.getInstance(Locale.CHINESE).compare(o1.getAreaName(),o2.getAreaName()));
        return voList;
    }

    /**
     * Pagination<AreaEntity> 转 Pagination<AreaVO>，并设置维护人和创建人姓名
     * @param voList
     * @return
     * @throws Exception
     */
    private Pagination<AreaVO> sortAreaList(List<AreaVO> voList)throws Exception{
        //根据区域中文名排序
        List<AreaVO> sortList = sorListByChineseName(voList);
        for (AreaVO areaVO : voList) {
            areaVO.setCreUserName(Utils.getUserNameByUserId(areaVO.getId(),ormService));
            areaVO.setModUserName(Utils.getUserNameByUserId(areaVO.getId(),ormService));
        }
        return new Pagination<AreaVO>(voList,1,100,sortList.size());
    }

    /**
     * areaCode 查重
     * @param vo
     * @return
     * @throws Exception
     */
    private boolean isExistAreaCode(AreaVO vo)throws Exception{
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_CODE,vo.getAreaCode().trim())));
        long count = ormService.count(AreaEntity.class,ormParam);
        return count > 0;
    }

    /**
     * 区域内，是否存在相同名称下级区域
     * @param vo
     * @return
     * @throws Exception
     */
    private boolean isExistAreaName(AreaVO vo)throws Exception{
        OrmParam ormParam = new OrmParam();
        // 根据新增区域名称查询
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_NAME,vo.getAreaName().trim())));
        List<AreaEntity> areaEntities = ormService.selectBeanList(AreaEntity.class,ormParam);
        //如果集合为空， 则说明无重复名称
        if(areaEntities == null || areaEntities.size() == 0) {
            return false;
        }
        // 否则判断集合中是否有区域的上级区域和新增区域是同一上级区域，是则证明有重复区域
        for (AreaEntity areaEntity : areaEntities) {
            if(vo.getAreaParentArea().equals(areaEntity.getArea_parent_area())){
                return true;
            }
        }
        return false;
    }

    /**
     * 拼接区域层级码
     * @param areaVO
     * @return
     * @throws Exception
     */
    private String spliAreaLevel(AreaEntity areaVO) throws Exception{
        OrmParam ormParam = new OrmParam();
        //查询上级区域
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(BasicConst.ID,areaVO.getArea_parent_area())));
        List<AreaEntity> parentAreaList = ormService.selectBeanList(AreaEntity.class,ormParam);
        if(parentAreaList == null || parentAreaList.size() == 0){
            throw new RuntimeException("上级区域不存在！");
        }
        //上级区域的层级码
        String parentAreaLevel = parentAreaList.get(0).getArea_level();
        //如果上级区域层级码不是以“,”结尾，则在结尾处拼接“,”
        if(parentAreaLevel.lastIndexOf(",") != parentAreaLevel.length()-1){
            parentAreaLevel += ",";
        }
        // 排序码补全三为数
        String areaOrder = String.format("%03d", areaVO.getArea_order());
        //拼接区域层级码
        StringBuilder areaLevel = new StringBuilder(parentAreaLevel).append(areaOrder);
        return areaLevel.toString();
    }

    /**
     * 设置上级区域名称及创建人、维护人
     * @param areaVO
     * @throws Exception
     */
    private void setParentName(AreaVO areaVO) throws Exception {
        areaVO.setCreUserName(Utils.getUserNameByUserId(areaVO.getCreuser(),ormService));
        areaVO.setModUserName(Utils.getUserNameByUserId(areaVO.getModuser(),ormService));
        //查询上级区域
        if(!StringUtil.isNullOrEmpty(areaVO.getAreaParentArea())){
            AreaEntity parentEntity = ormService.load(AreaEntity.class,areaVO.getAreaParentArea());
            if(parentEntity != null){
                areaVO.setParentAreaName(parentEntity.getArea_name());
            }
        }
    }
    /**
     * 查询兄弟区域数量
     * @param areaVO
     * @return
     * @throws Exception
     */
    private long queryBrotherCount(AreaVO areaVO) throws Exception {
        OrmParam ormParam = new OrmParam();
        String whereExp = "";
        if(StringUtil.isNullOrEmpty(areaVO.getAreaParentArea())){
            whereExp  = OrmParam.or(ormParam.getIsNull(AreaConstant.AREA_PARENT_AREA),ormParam.getEqualXML(AreaConstant.AREA_PARENT_AREA,""));
        }else {
            whereExp = OrmParam.and(ormParam.getEqualXML(AreaConstant.AREA_PARENT_AREA,areaVO.getAreaParentArea()));
        }
        ormParam.setWhereExp(whereExp);
        //查询
        return ormService.count(AreaEntity.class, ormParam);
    }

    /**
     * 设置区域所有下级为禁用状态
     * @param ids
     */
    public void setChildrenDisable(Object[] ids) throws Exception{
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getInXML(AreaProperty.AREA_PARENT_AREA,ids));
        List<AreaEntity> list = ormService.selectBeanList(AreaEntity.class,ormParam);
        List<String> childrenIds = new ArrayList<>();
        if(list != null && list.size() > 0){
            for (AreaEntity areaEntity : list) {
                childrenIds.add(areaEntity.getId());
                areaEntity.setArea_enable(Constants.DISABLE);
                ormService.updateSelective(areaEntity);
            }
            setChildrenDisable(childrenIds.toArray());
        }
    }

}
