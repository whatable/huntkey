package com.huntkey.rx.sceo.provider.basic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.basic.ParkVO;
import com.huntkey.rx.sceo.common.model.basic.PerioVO;
import com.huntkey.rx.sceo.common.model.basic.TaxrateVO;
import com.huntkey.rx.sceo.provider.basic.service.BasicService;
import com.huntkey.rx.sceo.provider.basic.service.ParkService;
import com.huntkey.rx.sceo.provider.utils.Utils;

/**
 * @author liucs
 * @date 2018-1-8 09:46:42
 */
@RestController
@RequestMapping("/basic")
@Deprecated
public class BasicController {
	@Autowired
	private ParkService parkService;
	@Autowired
	private BasicService basicService;

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 保存园区类
	 * 
	 * @param parkVO
	 * @return
	 */
	@RequestMapping(value = "/submitPark", method = RequestMethod.POST)
	// @MethodRegister(edmClass = "park", methodDesc = "保存园区类", methodCate =
	// "表单通用方法")
	@Deprecated
	public Result submitPark(@RequestBody ParkVO parkVO) {
		Result result = new Result();
		parkVO.setCreuser("admin");
		parkVO.setModuser("admin");
		parkService.insertPark(parkVO);
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 保存周期
	 * 
	 * @param perioVO
	 * @return
	 */
	@RequestMapping(value = "/submitPerio", method = RequestMethod.POST)
	// @MethodRegister(edmClass = "period", methodDesc = "保存周期类", methodCate =
	// "表单通用方法")
	public Result submitPerio(@RequestBody PerioVO perioVO) {
		Result result = new Result();
		perioVO.setCreuser("admin");
		perioVO.setModuser("admin");
		parkService.insertPerio(perioVO);
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 保存税率
	 * 
	 * @param taxrateVO
	 * @return
	 */
	@RequestMapping(value = "/submitTaxrate", method = RequestMethod.POST)
	// @MethodRegister(edmClass = "taxrate", methodDesc = "保存税率类", methodCate =
	// "表单通用方法")
	public Result submitTaxrate(@RequestBody TaxrateVO taxrateVO) {
		Result result = new Result();
		taxrateVO.setCreuser("admin");
		taxrateVO.setModuser("admin");
		parkService.insertTaxrate(taxrateVO);
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * @param oddObjld
	 * @param infoObjld
	 * @return
	 */
	@RequestMapping(value = "/delInfoObj", method = RequestMethod.DELETE)
	// @MethodRegister(edmClass = "information", methodDesc = "删除数据", methodCate =
	// "表单通用方法")
	public Result delInfoObj(@RequestParam(value = "oddObjld") String oddObjld,
			@RequestParam(value = "infoObjld") String infoObjld) {
		Result result = new Result();
		parkService.delete(oddObjld, infoObjld);
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * @param oddObjld
	 * @param infoObjlds
	 * @return
	 */
	@RequestMapping(value = "/delInfoObjBatch/{oddObjld}/{infoObjlds}", method = RequestMethod.DELETE)
	// @MethodRegister(edmClass = "information", methodDesc = "批量删除数据", methodCate =
	// "表单通用方法")
	public Result delInfoObjBatch(@PathVariable(value = "oddObjld") String oddObjld,
			@PathVariable(value = "infoObjlds") String infoObjlds) {
		return parkService.deleteBatch(oddObjld, infoObjlds);

	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 
	 * @param oddfObjld
	 * @param infoName
	 * @param infoCode
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/queryInfoList", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "taxrate", methodDesc = "查询", methodCate =
	// "表单通用方法", getReqParamsNameNoPathVariable = {
	// "oddfObjld", "infoName", "infoCode", "pageNumber", "pageSize" })
	public Result queryInfoList(@RequestParam(value = "oddfObjld") String oddfObjld,
			@RequestParam(required = false, value = "infoName") String infoName,
			@RequestParam(required = false, value = "infoCode") String infoCode,
			@RequestParam(value = "pageNumber", defaultValue = "1") int pageNumber,
			@RequestParam(value = "pageSize", defaultValue = "15") int pageSize) {
		Result result = parkService.queryInfoList(oddfObjld, infoName, infoCode, pageNumber, pageSize);
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * @param oddfObjld
	 * @return
	 */
	@RequestMapping(value = "/getProperty", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "taxrate", methodDesc = "获取属性", methodCate =
	// "表单通用方法", getReqParamsNameNoPathVariable = {
	// "oddfObjld" })
	public Result getProperty(@RequestParam(value = "oddfObjld") String oddfObjld) {
		Result result = parkService.getProperty(oddfObjld);
		return result;
	}

	/**
	 * 启用or禁用
	 * 
	 * @param authorization
	 * @param id
	 *            对象id
	 * @param classSimpleName
	 *            类简称
	 * @return
	 */
	@RequestMapping(value = "/enable", method = RequestMethod.PUT)
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	@Deprecated
	public Result enable(@RequestParam(value = "authorization") String authorization,
			@RequestParam(value = "id") String id, @RequestParam(value = "classSimpleName") String classSimpleName) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		String currentUserId = Utils.getCurentUserId(authorization);
		try {
			result.setData(basicService.enable(id, currentUserId, classSimpleName));
		} catch (Exception e) {
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}
}
