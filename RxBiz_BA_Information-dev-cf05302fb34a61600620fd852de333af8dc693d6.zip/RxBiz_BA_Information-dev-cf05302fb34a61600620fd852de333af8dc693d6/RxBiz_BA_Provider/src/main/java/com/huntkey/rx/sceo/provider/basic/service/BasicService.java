package com.huntkey.rx.sceo.provider.basic.service;

public interface BasicService {
    int enable(String id, String currentUserId,String classSimpleName) throws Exception;
}
