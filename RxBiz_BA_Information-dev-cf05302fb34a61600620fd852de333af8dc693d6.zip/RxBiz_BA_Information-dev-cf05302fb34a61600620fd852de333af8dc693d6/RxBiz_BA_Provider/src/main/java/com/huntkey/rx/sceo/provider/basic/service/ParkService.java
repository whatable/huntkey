package com.huntkey.rx.sceo.provider.basic.service;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.basic.ParkVO;
import com.huntkey.rx.sceo.common.model.basic.TaxrateVO;
import com.huntkey.rx.sceo.common.model.basic.PerioVO;
import com.sun.org.apache.regexp.internal.RE;

/**
 * @author liucs
 * @date 2018-1-8 10:19:42
 */
public interface ParkService {
    int insertPark(ParkVO parkVO);
    int insertPerio(PerioVO perioVO);
    int insertTaxrate(TaxrateVO taxrateVO);
    int delete(String oddObjld,String infoObjld);
    Result deleteBatch(String oddObjld, String infoObjlds);
    Result queryInfoList(String oddfObjld, String infoName, String infoCode, int pageNumber, int pageSize);
    Result getProperty(String oddfObjld);
}
