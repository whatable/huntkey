package com.huntkey.rx.sceo.provider.basic.service.impl;

import com.huntkey.rx.base.BaseEntity;
import com.huntkey.rx.edm.entity.TipmessageEntity;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.basic.service.BasicService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.netflix.discovery.converters.Auto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Method;
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class BasicServiceImpl implements BasicService {
    @Autowired
    private OrmService ormService;

    @Override
    public int enable(String id, String currentUserId,String classSimpleName) throws Exception {
        //拼接classname
        String className = Constants.CLASSNAMEPREFIX+classSimpleName;
        //获取类的Class对象
        Class clazz = Class.forName(className);
        //根据id和clzz 查询对象
        BaseEntity entity = ormService.load(clazz,id);
        Method[] methods = clazz.getDeclaredMethods();
        String enable = Constants.DISABLE;
        for (Method method : methods) {
            String methodName = method.getName();
            //过滤包含“enable”的get方法，并获取enable
            if(methodName.startsWith("get")&&methodName.contains("enable")){
                enable = (String)method.invoke(entity);
                break;
            }
        }
        if(enable != null && enable.equals(Constants.ENABLE)){
            enable = Constants.DISABLE;
        }else{
            enable = Constants.ENABLE;
        }
        entity.setModuser(currentUserId);
        for (Method method : methods) {
            String methodName = method.getName();
            //过滤包含“enable”的set方法，并设置enable
            if(methodName.startsWith("set")&&methodName.contains("is_used")){
               method.invoke(entity,enable);
                break;
            }
        }
        return ormService.updateSelective(entity);
    }
}
