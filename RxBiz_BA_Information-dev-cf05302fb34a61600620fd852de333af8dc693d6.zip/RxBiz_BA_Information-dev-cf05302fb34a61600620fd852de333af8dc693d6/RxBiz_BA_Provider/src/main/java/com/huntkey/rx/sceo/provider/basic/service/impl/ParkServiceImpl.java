package com.huntkey.rx.sceo.provider.basic.service.impl;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.sceo.common.model.basic.ParkVO;
import com.huntkey.rx.sceo.common.model.basic.RpakRpakAddrSetaVO;
import com.huntkey.rx.sceo.common.model.basic.TaxrateVO;
import com.huntkey.rx.sceo.common.model.basic.PerioVO;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.basic.service.ParkService;
import com.huntkey.rx.sceo.provider.basic.transformation.TfToXhx;
import com.huntkey.rx.sceo.provider.basic.transformation.XhxToTf;
import com.huntkey.rx.sceo.provider.code.service.Impl.NbrlGetCodeImpl;
import com.huntkey.rx.sceo.provider.code.service.Impl.NumberRulesSereviceImpl;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author liucs
 * @date 2018-1-8 10:24:38
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class ParkServiceImpl implements ParkService {
    @Autowired
    private OrmService ormService;
    private static Logger log = LoggerFactory.getLogger(NbrlGetCodeImpl.class);

    @Autowired
    private ModelerProvider modelerProvider;

    @Autowired
    private NumberRulesSereviceImpl numberRulesSereviceImpl;

    private static SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

    /**
     * 添加
     * @param parkVO
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int insertPark(ParkVO parkVO){
        ParkEntity parkEntity = TfToXhx.getParkEntity(parkVO);
        String parameterId = StringUtil.generateUUID();
        parkEntity.setModtime(new Date());
        int seq = getSeq();
        parkEntity.setRpak_seq(seq+1);
        try {
            if(StringUtil.isNullOrEmpty(parkEntity.getId())){
                parkEntity.setId(parameterId);
                parkEntity.setCretime(new Date());
                ormService.insert(parkEntity);
            }else{
                ormService.update(parkEntity);
            }
            List<RpakRpakAddrSetaEntity> rpakRpakAddrSetaEntityList = parkEntity.getRpak_addr_set();
            if(rpakRpakAddrSetaEntityList!=null&&rpakRpakAddrSetaEntityList.size()>0){
                for (RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity:rpakRpakAddrSetaEntityList) {
                    rpakRpakAddrSetaEntity.setModtime(new Date());
                    rpakRpakAddrSetaEntity.setPid(parkEntity.getId());
                    if (StringUtil.isNullOrEmpty(rpakRpakAddrSetaEntity.getId())){
                        rpakRpakAddrSetaEntity.setCretime(new Date());
                        rpakRpakAddrSetaEntity.setCreuser("admin");
                        rpakRpakAddrSetaEntity.setModuser("admin");
                        rpakRpakAddrSetaEntity.setModtime(new Date());
                        rpakRpakAddrSetaEntity.setClassName("park");
                        ormService.insert(rpakRpakAddrSetaEntity);
                    }else {
                        ormService.update(rpakRpakAddrSetaEntity);
                    }

                }

            }
        } catch (Exception e) {
            log.error("数据插入失败",e);
            return 0;
        }
        return 0;
    }



    /**
     * 添加
     * @param perioVO
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int insertPerio(PerioVO perioVO){
        PeriodEntity periodEntity = new PeriodEntity();
        try {
            periodEntity = TfToXhx.getPerioEntity(perioVO);
        }catch (Exception e){

        }
        String parameterId = StringUtil.generateUUID();
        periodEntity.setModtime(new Date());
        try {
            if(StringUtil.isNullOrEmpty(periodEntity.getId())) {
                periodEntity.setId(parameterId);
                periodEntity.setCretime(new Date());
                ormService.insert(periodEntity);
            }else{
                ormService.update(periodEntity);
            }
        } catch (Exception e) {
            log.error("数据插入失败",e);
            return 0;
        }
        return 0;
    }

    /**
     * 添加
     * @param taxrateVO
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int insertTaxrate(TaxrateVO taxrateVO){
        TaxrateEntity taxrateEntity = new TaxrateEntity();
        try {
            taxrateEntity = TfToXhx.getTaxrateEntity(taxrateVO);
        }catch (Exception e){}
        String parameterId = StringUtil.generateUUID();
        taxrateEntity.setModtime(new Date());
        try {
            if(StringUtil.isNullOrEmpty(taxrateEntity.getId())) {
                taxrateEntity.setId(parameterId);
                taxrateEntity.setCretime(new Date());
                ormService.insert(taxrateEntity);
            }else{
                ormService.update(taxrateEntity);
            }
        } catch (Exception e) {
            log.error("数据插入失败",e);
            return 0;
        }
        return 0;
    }

    /**
     * 查詢
     * @param oddfObjld
     * @param infoName
     * @param infoCode
     * @param pageNumber
     * @param pageSize
     * @return
     */
    @Override
    public Result queryInfoList(String oddfObjld, String infoName, String infoCode, int pageNumber, int pageSize){

        Result result = new Result();
        String className = getClassName(oddfObjld);
        if("park".equals(className)){
            try {
                Pagination<ParkEntity> parkEntity = getParameterPageList(infoCode,infoName,pageNumber,pageSize,"park");

                result.setData(parkEntity);
            }catch (Exception e){

            }
        }else if("period".equals(className)){
            try {
                Pagination<PeriodEntity> periodEntity = getPeriodPageList(infoCode,infoName,pageNumber,pageSize,"period");
                result.setData(periodEntity);
            }catch (Exception e){

            }
        }else if("taxrate".equals(className)){
            try {
                Pagination<TaxrateEntity> taxrateEntity = getTaxPageList(infoCode,infoName,pageNumber,pageSize,"taxrate");
                result.setData(taxrateEntity);
            }catch (Exception e){

            }
        }

      return result;
    }

    @Override
    public Result getProperty(String oddfObjld) {
        Result result = new Result();

        OperationdocumentdefinitionEntity opera = new OperationdocumentdefinitionEntity();
        try {
            opera = ormService.load(OperationdocumentdefinitionEntity.class, oddfObjld);
        }catch (Exception e){

        }
       if(opera!=null){
           String classId =  opera.getOddf_orde_class();
           if(!StringUtil.isNullOrEmpty(classId)){
               Result result1 = modelerProvider.getPropsAndParentProps(classId);
               Object data =  result1.getData();
               result.setData(data);
           }
       }
        return result;
    }

    private Pagination<ParkEntity> getParameterPageList( String infoCode, String infoName, int pageNum, int pageSize,String className) throws Exception {
        OrmParam parameterOrmParam = new OrmParam();
        //查询参数列表——参数设置
        setParkParam(parameterOrmParam, pageNum, pageSize,infoCode, infoName, className);
        return  ormService.selectPagedBeanList(ParkEntity.class,parameterOrmParam);
    }
    private void setParkParam(OrmParam ormParam, int pageNum, int pageSize, String infoCode, String infoName,String className) {
        //设置ormParam参数
        setParkParam(ormParam, infoCode, infoName,className);
        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);
        ormParam.setOrderExp(SQLSortEnum.DESC,"cretime");
    }
    private Pagination<PeriodEntity> getPeriodPageList( String infoCode, String infoName, int pageNum, int pageSize,String className) throws Exception {
        OrmParam parameterOrmParam = new OrmParam();
        //查询参数列表——参数设置
        setParkParam(parameterOrmParam, pageNum, pageSize,infoCode, infoName, className);
        return  ormService.selectPagedBeanList(PeriodEntity.class,parameterOrmParam);
    }

    private Pagination<TaxrateEntity> getTaxPageList( String infoCode, String infoName, int pageNum, int pageSize,String className) throws Exception {
        OrmParam parameterOrmParam = new OrmParam();
        //查询参数列表——参数设置
        setParkParam(parameterOrmParam, pageNum, pageSize,infoCode, infoName,className);
        return  ormService.selectPagedBeanList(TaxrateEntity.class,parameterOrmParam);
    }


    private void setParkParam(OrmParam ormParam, String infoCode, String infoName,String className) {
        List<String> list = Arrays.asList("id","rpak_code");
        List<String> columnList = new ArrayList<>(list);
        numberRulesSereviceImpl.setBaseProperties(columnList);
        columnList.remove(columnList.indexOf("pid"));
        List<String> params = new ArrayList<>();
        if("park".equals(className)){
            if(!StringUtil.isNullOrEmpty(infoCode)){
                params.add(ormParam.getMatchMiddleXML("rpak_code", infoCode));
            }
            if(!StringUtil.isNullOrEmpty(infoName)){
                params.add(ormParam.getMatchMiddleXML("rpak_name", infoName));
            }
        }else if("period".equals(className)){
            if(!StringUtil.isNullOrEmpty(infoName)){
                params.add(ormParam.getMatchMiddleXML("peid_name", infoName));
            }
        }else if("taxrate".equals(className)){
            if(!StringUtil.isNullOrEmpty(infoName)){
                params.add(ormParam.getMatchMiddleXML("taxr_name", infoName));
            }
        }



        String whereExp = OrmParam.and(params);
        ormParam.setWhereExp(whereExp);
//        ormParam.addOrderExpElement(SQLSortEnum.DESC,ParameterConstant.PARAM_SEQ);
    }

    /**
     * 刪除
     * @param oddObjld
     * @param infoObjld
     * @return
     */
    @Override
    public int delete(String oddObjld,String infoObjld) {
        String className = getClassName(oddObjld);
        // 删除操作
        try {
            ormService.getDataBySql("UPDATE " + className + " SET is_del = '1' WHERE id ='" + infoObjld + "';");
        } catch (Exception e) {
        }
        return 0;
    }

    /**
     * 刪除
     * @param oddObjld
     * @param infoObjlds
     * @return
     */
    @Override
    @Transactional
    public Result deleteBatch(String oddObjld,String infoObjlds) {
        Result result = new Result();
        String className = getClassName(oddObjld);
        String infoObjld []= infoObjlds.split(",");
        int sum = 0;
        // 删除操作
        try {
            if ("taxrate".equals(className)){
                for (int i = 0;i<infoObjld.length;i++){
                    int count = ormService.delete(TaxrateEntity.class,infoObjld[i]);
                    sum = sum+count;
                }
            }
            if ("period".equals(className)){
                for (int i = 0;i<infoObjld.length;i++){
                    int count = ormService.delete(PeriodEntity.class,infoObjld[i]);
                    sum = sum+count;
                }
            }
            if ("park".equals(className)){
                for (int i = 0;i<infoObjld.length;i++){
                    int count =ormService.delete(ParkEntity.class,infoObjld[i]);
                    sum = sum+count;
                }
            }

        } catch (Exception e) {
            result.setRetCode(0);
            result.setErrMsg("删除失败");
        }
        if(sum>0){
            result.setRetCode(1);
            result.setData("成功删除"+sum+"条数据！");
        }else{
            result.setRetCode(0);
            result.setErrMsg("删除失败");
        }
        return result;
    }

    private String getClassName(String oddObjld){
        OperationdocumentdefinitionEntity opera = new OperationdocumentdefinitionEntity();
        String className ="";
        try {
            opera = ormService.load(OperationdocumentdefinitionEntity.class, oddObjld);
        } catch (Exception e) {
            return "";
        }
        if (opera != null) {
            String classId = opera.getOddf_orde_class();
            if (!StringUtil.isNullOrEmpty(classId)) {
                Result result = modelerProvider.getClassById(classId);
                Object dataClass = result.getData();
                Map<String, String> classMap = (Map<String, String>) dataClass;
                if (dataClass != null) {
                    className = classMap.get("edmcCode");
                }
            }
        }
        return className;
    }

    /**
     * 获取系统最大编号
     * @return
     */
    private int getSeq() {
        int seq = 0;
        try{
            List<Map<String, Object>> list = ormService.getDataBySql("SELECT MAX(rpak_seq) rpak_seq FROM park;");
            if(list!=null&&list.size()>0){
                Map<String,Object> maps = list.get(0);
                String parmSeq = String.valueOf(maps.get("rpak_seq"));
                seq = Integer.valueOf(parmSeq);
            }
        }catch (Exception e){
            log.error("获取最大值失败");
        }
        return seq;
    }


}
