package com.huntkey.rx.sceo.provider.basic.transformation;

import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.common.model.basic.ParkVO;
import com.huntkey.rx.sceo.common.model.basic.PerioVO;
import com.huntkey.rx.sceo.common.model.basic.RpakRpakAddrSetaVO;
import com.huntkey.rx.sceo.common.model.basic.TaxrateVO;

import java.util.ArrayList;
import java.util.List;

public class TfToXhx {
    public static ParkEntity getParkEntity(ParkVO parkVO){
        ParkEntity parkEntity = new ParkEntity();
        parkEntity.setCretime(parkVO.getCretime());
        parkEntity.setCreuser(parkVO.getCreuser());
        parkEntity.setEdmd_class(parkVO.getEdmdClass());
        parkEntity.setEdmd_code(parkVO.getEdmdCode());
        parkEntity.setEdmd_ente(parkVO.getEdmdEnte());
        parkEntity.setEdmd_src_class(parkVO.getEdmdSrcClass());
        parkEntity.setEdmd_srcobj(parkVO.getEdmdSrcobj());
        parkEntity.setId(parkVO.getId());
        parkEntity.setInfo_code(parkVO.getInfoCode());
        parkEntity.setInfo_desc(parkVO.getInfoDesc());
        parkEntity.setInfo_name(parkVO.getInfoName());
//        parkVO.setIsdel(parkEntity.get);
        parkEntity.setModuser(parkVO.getModuser());
        parkEntity.setModtime(parkVO.getModtime());
        parkEntity.setModuser(parkVO.getModuser());
        parkEntity.setRpak_addr(parkVO.getRpakAddr());
        parkEntity.setRpak_code(parkVO.getRpakCode());
        parkEntity.setRpak_isdefault(parkVO.getRpakIsdefault());
        parkEntity.setRpak_name(parkVO.getRpakName());
        parkEntity.setRpak_seq(parkVO.getRpakSeq());
        List<RpakRpakAddrSetaVO> rpakRpakAddrSetaVOList = parkVO.getRpakAddrSet();
        List<RpakRpakAddrSetaEntity> rpakRpakAddrSetaEntityList = new ArrayList<>();
        if(rpakRpakAddrSetaVOList!=null&&rpakRpakAddrSetaVOList.size()>0){
            for (RpakRpakAddrSetaVO rpakRpakAddrSetaVO:rpakRpakAddrSetaVOList) {
                RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity = getRpakRpakAddrSetaEntity(rpakRpakAddrSetaVO);
                rpakRpakAddrSetaEntityList.add(rpakRpakAddrSetaEntity);
            }
            parkEntity.setRpak_addr_set(rpakRpakAddrSetaEntityList);
        }
        return parkEntity;
    }

    public static PeriodEntity getPerioEntity(PerioVO perioVO){
        PeriodEntity periodEntity = new PeriodEntity();
        periodEntity.setCretime(perioVO.getCretime());
        periodEntity.setCreuser(perioVO.getCreuser());
        periodEntity.setEdmd_class(perioVO.getEdmdClass());
        periodEntity.setEdmd_code(perioVO.getEdmdCode());
        periodEntity.setEdmd_ente(perioVO.getEdmdEnte());
        periodEntity.setEdmd_src_class(perioVO.getEdmdSrcClass());
        periodEntity.setEdmd_srcobj(perioVO.getEdmdSrcobj());
        periodEntity.setId(perioVO.getId());
        periodEntity.setInfo_code(perioVO.getInfoCode());
        periodEntity.setInfo_desc(perioVO.getInfoDesc());
        periodEntity.setInfo_name(perioVO.getInfoName());
        periodEntity.setModuser(perioVO.getModuser());
        periodEntity.setModtime(perioVO.getModtime());
        periodEntity.setModuser(perioVO.getModuser());
        periodEntity.setPeid_sdate(perioVO.getPeidSdate());
        periodEntity.setPeid_edate(perioVO.getPeidEdate());
        periodEntity.setPeid_fyr(perioVO.getPeidFyr());
        periodEntity.setPeid_name(perioVO.getPeidName());
        periodEntity.setPeid_proid(perioVO.getPeidProid());
        return periodEntity;
    }

    public static TaxrateEntity getTaxrateEntity(TaxrateVO taxrateVO){
        TaxrateEntity taxrateEntity = new TaxrateEntity();
        taxrateEntity.setCretime(taxrateVO.getCretime());
        taxrateEntity.setCreuser(taxrateVO.getCreuser());
        taxrateEntity.setEdmd_class(taxrateVO.getEdmdClass());
        taxrateEntity.setEdmd_code(taxrateVO.getEdmdCode());
        taxrateEntity.setEdmd_ente(taxrateVO.getEdmdEnte());
        taxrateEntity.setEdmd_src_class(taxrateVO.getEdmdSrcClass());
        taxrateEntity.setEdmd_srcobj(taxrateVO.getEdmdSrcobj());
        taxrateEntity.setId(taxrateVO.getId());
        taxrateEntity.setInfo_code(taxrateVO.getInfoCode());
        taxrateEntity.setInfo_desc(taxrateVO.getInfoDesc());
        taxrateEntity.setInfo_name(taxrateVO.getInfoName());
        taxrateEntity.setModuser(taxrateVO.getModuser());
        taxrateEntity.setModtime(taxrateVO.getModtime());
        taxrateEntity.setModuser(taxrateVO.getModuser());
        taxrateEntity.setTaxr_detail(taxrateVO.getTaxrDetail());
        taxrateEntity.setTaxr_isdeduct(taxrateVO.getTaxrIsdeduct());
        taxrateEntity.setTaxr_name(taxrateVO.getTaxrName());
        return taxrateEntity;
    }

    public static RpakRpakAddrSetaEntity getRpakRpakAddrSetaEntity(RpakRpakAddrSetaVO rpakRpakAddrSetaVO){
        RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity = new RpakRpakAddrSetaEntity();
        rpakRpakAddrSetaEntity.setCretime(rpakRpakAddrSetaVO.getCretime());
        rpakRpakAddrSetaEntity.setCreuser(rpakRpakAddrSetaVO.getCreuser());
        rpakRpakAddrSetaEntity.setId(rpakRpakAddrSetaVO.getId());
        rpakRpakAddrSetaEntity.setModuser(rpakRpakAddrSetaVO.getModuser());
        rpakRpakAddrSetaEntity.setModtime(rpakRpakAddrSetaVO.getModtime());
        rpakRpakAddrSetaEntity.setModuser(rpakRpakAddrSetaVO.getModuser());
        rpakRpakAddrSetaEntity.setRpak_addrc(rpakRpakAddrSetaVO.getRpakAddrc());
        rpakRpakAddrSetaEntity.setRpak_addrl(rpakRpakAddrSetaVO.getRpakAddrl());
        rpakRpakAddrSetaEntity.setRpak_addrp(rpakRpakAddrSetaVO.getRpakAddrp());
        rpakRpakAddrSetaEntity.setRpak_contact(rpakRpakAddrSetaVO.getRpakContact());
        rpakRpakAddrSetaEntity.setRpak_cway(rpakRpakAddrSetaVO.getRpakCway());
        rpakRpakAddrSetaEntity.setRpak_daddr(rpakRpakAddrSetaVO.getRpakDaddr());
        rpakRpakAddrSetaEntity.setPid(rpakRpakAddrSetaVO.getPid());
        rpakRpakAddrSetaEntity.setClassName(rpakRpakAddrSetaVO.getClassname());
        return rpakRpakAddrSetaEntity;
    }
}
