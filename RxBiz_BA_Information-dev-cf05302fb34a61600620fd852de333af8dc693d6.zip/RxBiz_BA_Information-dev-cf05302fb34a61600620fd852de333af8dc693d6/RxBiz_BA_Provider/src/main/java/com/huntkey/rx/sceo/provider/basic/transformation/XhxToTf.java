package com.huntkey.rx.sceo.provider.basic.transformation;

import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.common.model.basic.ParkVO;
import com.huntkey.rx.sceo.common.model.basic.PerioVO;
import com.huntkey.rx.sceo.common.model.basic.RpakRpakAddrSetaVO;
import com.huntkey.rx.sceo.common.model.basic.TaxrateVO;

import java.util.ArrayList;
import java.util.List;

public class XhxToTf {
    public static ParkVO getParkVO(ParkEntity parkEntity){
        ParkVO parkVO = new ParkVO();
        parkVO.setCretime(parkEntity.getCretime());
        parkVO.setCreuser(parkEntity.getCreuser());
        parkVO.setEdmdClass(parkEntity.getEdmd_class());
        parkVO.setEdmdCode(parkEntity.getEdmd_code());
        parkVO.setEdmdEnte(parkEntity.getEdmd_ente());
        parkVO.setEdmdSrcClass(parkEntity.getEdmd_src_class());
        parkVO.setEdmdSrcobj(parkEntity.getEdmd_srcobj());
        parkVO.setId(parkEntity.getId());
        parkVO.setInfoCode(parkEntity.getInfo_code());
        parkVO.setInfoDesc(parkEntity.getInfo_desc());
        parkVO.setInfoName(parkEntity.getInfo_name());
//        parkVO.setIsdel(parkEntity.get);
        parkVO.setModuser(parkEntity.getModuser());
        parkVO.setModtime(parkEntity.getModtime());
        parkVO.setModUserName(parkEntity.getModuser());
        parkVO.setRpakAddr(parkEntity.getRpak_addr());
        parkVO.setRpakCode(parkEntity.getRpak_code());
        parkVO.setRpakIsdefault(parkEntity.getRpak_isdefault());
        parkVO.setRpakName(parkEntity.getRpak_name());
        parkVO.setRpakSeq(parkEntity.getRpak_seq());

        List<RpakRpakAddrSetaVO> rpakRpakAddrSetaVOList = new ArrayList<>();
        List<RpakRpakAddrSetaEntity> rpakRpakAddrSetaEntityList = parkEntity.getRpak_addr_set();
        if(rpakRpakAddrSetaEntityList!=null&&rpakRpakAddrSetaEntityList.size()>0){
            for (RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity:rpakRpakAddrSetaEntityList) {
                RpakRpakAddrSetaVO rpakRpakAddrSetaVO = getRpakRpakAddrSetaVO(rpakRpakAddrSetaEntity);
                rpakRpakAddrSetaVOList.add(rpakRpakAddrSetaVO);
            }
            parkVO.setRpakAddrSet(rpakRpakAddrSetaVOList);
        }
        return parkVO;
    }

    public static PerioVO getParkVO(PeriodEntity periodEntity){
        PerioVO perioVO = new PerioVO();
        perioVO.setCretime(periodEntity.getCretime());
        perioVO.setCreuser(periodEntity.getCreuser());
        perioVO.setEdmdClass(periodEntity.getEdmd_class());
        perioVO.setEdmdCode(periodEntity.getEdmd_code());
        perioVO.setEdmdEnte(periodEntity.getEdmd_ente());
        perioVO.setEdmdSrcClass(periodEntity.getEdmd_src_class());
        perioVO.setEdmdSrcobj(periodEntity.getEdmd_srcobj());
        perioVO.setId(periodEntity.getId());
        perioVO.setInfoCode(periodEntity.getInfo_code());
        perioVO.setInfoDesc(periodEntity.getInfo_desc());
        perioVO.setInfoName(periodEntity.getInfo_name());
//        perioVO.setIsdel(periodEntity.get);
        perioVO.setModuser(periodEntity.getModuser());
        perioVO.setModtime(periodEntity.getModtime());
        perioVO.setModUserName(periodEntity.getModuser());
        perioVO.setPeidEdate(periodEntity.getPeid_edate());
        perioVO.setPeidSdate(periodEntity.getPeid_sdate());
        perioVO.setPeidFyr(periodEntity.getPeid_fyr());
        perioVO.setPeidName(periodEntity.getPeid_name());
        perioVO.setPeidProid(periodEntity.getPeid_proid());
        return perioVO;
    }

    public static TaxrateVO getTaxrateVO(TaxrateEntity taxrateEntity){
        TaxrateVO taxrateVO = new TaxrateVO();
        taxrateVO.setCretime(taxrateEntity.getCretime());
        taxrateVO.setCreuser(taxrateEntity.getCreuser());
        taxrateVO.setEdmdClass(taxrateEntity.getEdmd_class());
        taxrateVO.setEdmdCode(taxrateEntity.getEdmd_code());
        taxrateVO.setEdmdEnte(taxrateEntity.getEdmd_ente());
        taxrateVO.setEdmdSrcClass(taxrateEntity.getEdmd_src_class());
        taxrateVO.setEdmdSrcobj(taxrateEntity.getEdmd_srcobj());
        taxrateVO.setId(taxrateEntity.getId());
        taxrateVO.setInfoCode(taxrateEntity.getInfo_code());
        taxrateVO.setInfoDesc(taxrateEntity.getInfo_desc());
        taxrateVO.setInfoName(taxrateEntity.getInfo_name());
//        taxrateVO.setIsdel(taxrateEntity.get);
        taxrateVO.setModuser(taxrateEntity.getModuser());
        taxrateVO.setModtime(taxrateEntity.getModtime());
        taxrateVO.setModUserName(taxrateEntity.getModuser());
        taxrateVO.setTaxrDetail(taxrateEntity.getTaxr_detail());
        taxrateVO.setTaxrIsdeduct(taxrateEntity.getTaxr_isdeduct());
        taxrateVO.setTaxrName(taxrateEntity.getTaxr_name());
        return taxrateVO;
    }

    public static RpakRpakAddrSetaVO getRpakRpakAddrSetaVO(RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity){
        RpakRpakAddrSetaVO rpakRpakAddrSetaVO = new RpakRpakAddrSetaVO();
        rpakRpakAddrSetaVO.setCretime(rpakRpakAddrSetaEntity.getCretime());
        rpakRpakAddrSetaVO.setCreuser(rpakRpakAddrSetaEntity.getCreuser());
        rpakRpakAddrSetaVO.setId(rpakRpakAddrSetaEntity.getId());
        rpakRpakAddrSetaVO.setModuser(rpakRpakAddrSetaEntity.getModuser());
        rpakRpakAddrSetaVO.setModtime(rpakRpakAddrSetaEntity.getModtime());
        rpakRpakAddrSetaVO.setModuser(rpakRpakAddrSetaEntity.getModuser());
        rpakRpakAddrSetaVO.setRpakAddrc(rpakRpakAddrSetaEntity.getRpak_addrc());
        rpakRpakAddrSetaVO.setRpakAddrl(rpakRpakAddrSetaEntity.getRpak_addrl());
        rpakRpakAddrSetaVO.setRpakAddrp(rpakRpakAddrSetaEntity.getRpak_addrp());
        rpakRpakAddrSetaVO.setRpakContact(rpakRpakAddrSetaEntity.getRpak_contact());
        rpakRpakAddrSetaVO.setRpakCway(rpakRpakAddrSetaEntity.getRpak_cway());
        rpakRpakAddrSetaVO.setRpakDaddr(rpakRpakAddrSetaEntity.getRpak_daddr());
        rpakRpakAddrSetaVO.setPid(rpakRpakAddrSetaEntity.getPid());
        rpakRpakAddrSetaVO.setClassname(rpakRpakAddrSetaEntity.getClassName());
        return rpakRpakAddrSetaVO;
    }
}
