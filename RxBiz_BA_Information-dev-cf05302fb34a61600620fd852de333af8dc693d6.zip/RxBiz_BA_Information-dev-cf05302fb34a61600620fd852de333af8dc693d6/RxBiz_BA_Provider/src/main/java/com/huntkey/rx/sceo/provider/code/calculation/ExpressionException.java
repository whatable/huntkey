package com.huntkey.rx.sceo.provider.code.calculation;


/**
 * 运算式计算
 * @author zhuyj
 * @create 2017-12-07
 */
public class ExpressionException extends RuntimeException{

    private static final long serialVersionUID = 1L;

    public ExpressionException() {
        super();
    }

    public ExpressionException(String msg) {
        super(msg);
    }

    public ExpressionException(String msg, Throwable cause) {
        super(msg,cause);
    }

    public ExpressionException(Throwable cause) {
        super(cause);
    }
}