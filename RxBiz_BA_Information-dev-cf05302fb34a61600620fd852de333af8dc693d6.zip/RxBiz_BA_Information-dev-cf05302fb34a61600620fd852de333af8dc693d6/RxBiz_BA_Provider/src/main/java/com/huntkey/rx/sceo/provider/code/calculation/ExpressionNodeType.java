package com.huntkey.rx.sceo.provider.code.calculation;

/**
 * 运算式计算
 * @author zhuyj
 * @create 2017-12-07
 */
public enum ExpressionNodeType {

    Unknown,
    // +
    Plus,
    /// -
    Subtract,
    // *
    MultiPly,
    // /
    Divide,
    //(
    LParentheses,
    /// )
    RParentheses,
    //% (求模,取余)
    Mod,
    // ^ (次幂)
    Power,
    /// & (按位与)
    BitwiseAnd,
    /// | (按位或)
    BitwiseOr,
    // && (逻辑与)
    And,
    /// || (逻辑或)
    Or,
    /// ! (逻辑非)
    Not,
    /// == (相等)
    Equal,
    /// != 或 <> (不等于)
    Unequal,
    /// > (大于)
    GT,
    /// < (小于)
    LT,
    /// >= (大于等于)
    GTOrEqual,
    /// <= (小于等于)
    LTOrEqual,
    /// << (左移位)
    LShift,
    /// >> (右移位)
    RShift,
    /// 数值,
    Numeric,
    String,
    Date,
    //包含
    Like,
    //不包含
    NotLike,
    //已什么开始
    StartWith,
    //已什么结尾
    EndWith
}