package com.huntkey.rx.sceo.provider.code.constants;

public class Constants {
    /** 年 **/
    public static final String YEAR = "year";

    /** 月 **/
    public static final String MONTH = "month";

    /** 日 **/
    public static final String DAY = "day";

    /** 时 **/
    public static final String HOURS = "hours";

    /** 分 **/
    public static final String MINUTE = "minute";

    /** 秒 **/
    public static final String SECOND = "second";

    /** 季 **/
    public static final String SEASON = "season";

    /** 周 **/
    public static final String WEEK = "week";

    /** 星期 **/
    public static final String SUNDAY = "Sunday";

    /** AM/PM **/
    public static final String AMPM = "AMPM";

    /** 长度 4 **/
    public static final int Length4 = 4;

    /** 长度 2 **/
    public static final int Length2 = 2;

    /** 长度 1 **/
    public static final int Length1 = 1;


    /**  参数截取类型：不截取**/
    public static final String ICPT_NO = "icpt_no";

    /**  参数截取类型：从左**/
    public static final String ICPT_LEFT = "icpt_left";

    /**  参数截取类型：从右**/
    public static final String ICPT_RIGHT = "icpt_right";

    /**  参数截取类型：从中间**/
    public static final String ICPT_MIDDLE = "icpt_middle";

    /**  规则项类型 时间**/
    public static final String TIME = "time";

    /**  规则项类型 文本**/
    public static final String TEXT = "text";

    /**  规则项类型 流水号**/
    public static final String SERIAL = "serial";

    /**  规则项类型 属性**/
    public static final String PROPERTY = "property";

    /**  规则项类型 参数**/
    public static final String PARAM = "param";

    /** 规则条件状态  启用 **/
    public static final String ENABLE = "1";

    /** 规则条件状态  禁用 **/
    public static final String DISABLE = "0";

    /** 手工编号状态  已使用 **/
    public static final String USED = "1";

    /** 手工编号状态  未使用 **/
    public static final String UNUSE = "0";

    /**Excel文件格式*/
    public static final String XLSX = ".xlsx";
    public static final String XLS = ".xls";

    /** 时间格式 YYYY **/
    public static final String YYYY = "YYYY";

    /** 时间格式 YYYYMM **/
    public static final String YYYYMM = "YYYYMM";

    /** 时间格式 YYYYMMDD **/
    public static final String YYYYMMDD = "YYYYMMDD";

    /** 规则条件类型 参数**/
    public static final String CF_TYPE_PARAMS = "0";

    /** 规则条件类型 属性**/
    public static final String CF_TYPE_PROPERTY = "1";

    /** Redis节点地址 **/
    public static final String REDIS_NODES = "10.3.98.153:7000,10.3.98.153:7001,10.3.98.154:7002,10.3.98.154:7003,10.3.98.155:7004,10.3.98.155:7005";

    /**编号生成器项目前缀**/
    public static final String REDISKEY = "RxBiz_BA_Information:ManualNumber:";

    /** 类名称前缀**/
    public static final String CLASSNAMEPREFIX = "com.huntkey.rx.edm.entity.";

    /**是否标准:  1、标准，0、非标准**/
    public static final String STANDARD = "1";
    public static final String NOT_STANDARD = "0";
}
