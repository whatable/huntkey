package com.huntkey.rx.sceo.provider.code.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NbrlNbrlManualNumberSetbEntity;
import com.huntkey.rx.sceo.common.model.code.AddManualNumberByExcelDto;
import com.huntkey.rx.sceo.common.model.code.QryNumberRulesDto;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.NbrlGetCodeService;
import com.huntkey.rx.sceo.provider.code.service.NbrlManualNumberSetService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author zoulj
 * @create 2017/11/27 9:14
 **/
@RestController
@RequestMapping("/getCode")
public class NbrlGetCodeController {

    private static Logger log = LoggerFactory.getLogger(NbrlGetCodeController.class);

    @Autowired
    private NbrlGetCodeService nbrlGetCodeService;

    @RequestMapping(value = "/callByActive", method = RequestMethod.POST)
    @Deprecated
    @MethodRegister(edmClass = "numberrules",methodDesc = "获取编号",methodCate = "表单通用方法",
            getReqParamsNameNoPathVariable = {"nbrlCode","params"})
    public synchronized Result callByActive(@RequestParam(value ="nbrlCode" ) String nbrlCode,@RequestParam(value = "params",required = false) String params) {
        Result result = new Result();
        List<String> param = new ArrayList<>();
        if(params==""){
            result.setErrMsg("请输入正确的参数格式");
            result.setRetCode(0);
            return result;
        }
        if(params!=null){
            String [] paramArr = params.split(",");
            param = java.util.Arrays.asList(paramArr);
        }
        result = nbrlGetCodeService.callByActive(nbrlCode,param);
        log.debug("Provider::NbrlManualNumberSetController::list data{}", result.getData());
        return result;
    }

    @RequestMapping(value = "/getCodeByActive", method = RequestMethod.GET)
    @MethodRegister(edmClass = "numberrules",methodDesc = "获取编号",methodCate = "表单通用方法",
            getReqParamsNameNoPathVariable = {"nbrlCode","params"})
    public synchronized Result getCodeByActive(@RequestParam(value ="nbrlCode" ) String nbrlCode,@RequestParam(value = "params",required = false) String params) {
        Result result = new Result();
        List<String> param = new ArrayList<>();
        if(params!=null && params!=""){
            String [] paramArr = params.split(",");
            param = java.util.Arrays.asList(paramArr);
        }
        result = nbrlGetCodeService.callByActive(nbrlCode,param);
        log.debug("Provider::NbrlManualNumberSetController::list data{}", result.getData());
        return result;
    }

  /*  @RequestMapping(value = "/callByPassive", method = RequestMethod.POST)
    public Result callByPassive(@RequestParam(value ="nbrlCode" ) String nbrlCode,@RequestParam(value = "params",required = false) String params,@RequestBody Map<String,String> properties) {
        Result result = new Result();
        List<String> param = new ArrayList<>();
        if(params!=null&&params.length()>0){
            String [] paramArr = params.split(",");
            param = java.util.Arrays.asList(paramArr);
        }
        String code = nbrlGetCodeService.callByPassive(nbrlCode,param,properties);
        result.setData(code);
        log.debug("Provider::NbrlManualNumberSetController::list data{}", result.getData());
        return result;

    }*/

}
