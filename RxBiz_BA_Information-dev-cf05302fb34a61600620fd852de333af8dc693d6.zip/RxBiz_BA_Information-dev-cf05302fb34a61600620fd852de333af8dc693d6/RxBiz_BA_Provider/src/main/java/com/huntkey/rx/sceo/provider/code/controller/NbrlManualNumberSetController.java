package com.huntkey.rx.sceo.provider.code.controller;

import com.huntkey.rx.commons.utils.redis.RedisClusterUtils;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.NbrlNbrlManualNumberSetbEntity;
import com.huntkey.rx.sceo.common.model.code.AddManualNumberByExcelDto;
import com.huntkey.rx.sceo.common.model.code.QryNumberRulesDto;
import com.huntkey.rx.sceo.common.model.code.VO.ManualNumberAddToRedis;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.NbrlManualNumberSetService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

/**
 * @author zoulj
 * @create 2017/11/27 9:14
 **/
@RestController
@RequestMapping("/manualNumberSet")
public class NbrlManualNumberSetController {

    private static Logger log = LoggerFactory.getLogger(NbrlManualNumberSetController.class);

    @Autowired
    private NbrlManualNumberSetService nbrlManualNumberSetService;

    /**
     * 分页查询手工编号列表数据，支持模糊查询
     *
     * @param nbrl_manual_number
     * @param nbrl_is_use
     * @param pageNum
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public Result list(@RequestParam(required = false, value = "nbrl_manual_number") String nbrl_manual_number,
                       @RequestParam(required = false, value = "nbrl_is_use") String nbrl_is_use,
                       @RequestParam(required = false, value = "pid") String pid,
                       @RequestParam(required = false, value = "authorization") String authorization,
                       @RequestParam(required = false, value = "token") String token,
                       @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                       @RequestParam(required = false, value = "pageSize", defaultValue = "15") int pageSize) throws Exception {
        Result result = new Result();
        RedisClusterUtils rcu = new RedisClusterUtils(Constants.REDIS_NODES);
        Map<String, String> map = rcu.getHashMap(Constants.REDISKEY + token);
        Map<String, Object> ret = new HashMap<>();
        if (StringUtil.isNullOrEmpty(map.get(pid))) {
            ret.put("disable", 0);
        } else {
            ret.put("disable", 1);
        }
        ret.put("list", nbrlManualNumberSetService.list(nbrl_manual_number, nbrl_is_use, pid, authorization, token, pageNum, pageSize));
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(ret);
        log.debug("Provider::NbrlManualNumberSetController::list data{}", result.getData());
        return result;

    }

    /**
     * 批量删除手工编码集
     *
     * @param manualNumberCodes
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public Result delete(@RequestParam(required = false, value = "manualNumberCodes") String manualNumberCodes,
                         @RequestParam(required = false, value = "token") String token,
                         @RequestParam(required = false, value = "pid") String pid) throws Exception {
        Result result = new Result();
        token = nbrlManualNumberSetService.removeToRedis(Arrays.asList(manualNumberCodes.split(",")), token, pid);
        result.setData(token);
        return result;
    }

    /**
     * 列表排序修改
     *
     * @param nbs
     * @return
     */
    @RequestMapping(value = "/updateList", method = RequestMethod.PUT)
    public Result updateList(@RequestBody List<NbrlNbrlManualNumberSetbEntity> nbs) throws Exception {
        Result result = new Result();
        result.setData(nbrlManualNumberSetService.updateList(nbs));
        return result;
    }

    /**
     * 单条插入手工编码
     *
     * @param nbrlManualNumberSet
     * @return
     */
    @RequestMapping(value = "/insert", method = RequestMethod.POST)
    public Result insert(@RequestBody NbrlNbrlManualNumberSetbEntity nbrlManualNumberSet,
                         @RequestParam(required = false, value = "token") String token) throws Exception {
        Result result = new Result();
        token = nbrlManualNumberSetService.addToRedis(nbrlManualNumberSet.getNbrl_manual_number(), nbrlManualNumberSet.getPid(), token);
        result.setData(token);
        return result;
    }

    /**
     * 批量插入手动编码
     *
     * @param nbrlManualNumberSets
     * @return
     */
    @RequestMapping(value = "/insertList", method = RequestMethod.POST)
    public Result insertList(@RequestBody List<NbrlNbrlManualNumberSetbEntity> nbrlManualNumberSets,
                             @RequestParam(required = false, value = "authorization") String authorization,
                             @RequestParam(required = false, value = "token") String token) throws Exception {
        Result result = new Result();
        result.setData(nbrlManualNumberSetService.insert(nbrlManualNumberSets, authorization, token));
        return result;
    }

    /**
     * 批量插入手动编码，通过文件流解析对象
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/insertListByIo", method = RequestMethod.POST)
    public Result insertListByIo(@RequestBody AddManualNumberByExcelDto dto) throws Exception {
        Map<Integer, String> map = new HashMap();
        int succ = 0, error = 0;
        Result result = new Result();
        String pid;
        if (StringUtils.isEmpty(dto.getPid())) {
            pid = "tempManualNumberPid";
        } else {
            pid = dto.getPid();
        }

        String nbrlManualNumberCodes = "";
        InputStream inp = null;
        FileInputStream fs = null;
        Workbook wb = null;
        Sheet hssfSheet = null;
        try {
            inp = new ByteArrayInputStream(dto.getBytes());
            if (dto.getFileName().indexOf(Constants.XLSX) > -1) {
                wb = new XSSFWorkbook(inp);
            } else {
                wb = new HSSFWorkbook(inp);
            }
            hssfSheet = wb.getSheetAt(0);
        } catch (Exception e) {
            result.setErrMsg("文件格式有误，请用模板文件编辑上传");
        }

        if (hssfSheet != null) {
            //遍历excel,从第二行开始 即 rowNum=1,逐个获取单元格的内容,然后进行格式处理,最后插入数据库
            for (int rowNum = 1; rowNum <= hssfSheet.getLastRowNum(); rowNum++) {
                try {
                    Row hssfRow = hssfSheet.getRow(rowNum);
                    if (hssfRow == null) {
                        continue;
                    }
                    String num = getValue(hssfRow.getCell(0));
                    if (!StringUtils.isEmpty(num)) {
                        if (this.nbrlManualNumberSetService.qryManualNumberCount(num, pid, dto.getToken()) > 0) {
                            error++;
                            map.put(rowNum + 1, "手工编号已存在");
                            continue;
                        }
                        nbrlManualNumberCodes = nbrlManualNumberCodes + num + ",";
                        succ++;
                    }
                    {
                       /* error++;
                        map.put(rowNum,"手工编号为空");*/
                    }
                } catch (Exception e) {
                   /* error++;
                    map.put(rowNum+1,"手工编号解析异常");*/
                    continue;
                }
            }
        }
        inp.close();

        Map<Integer, String> m = new HashMap<>();
        m.put(1, nbrlManualNumberCodes);
        int del = deleteDuplicateData(m);
        error += del;
        succ -= del;
        String token = nbrlManualNumberSetService.addToRedis(m.get(1), pid, dto.getToken());

        Map<String, Object> temp = new HashMap<>();
        temp.put("token", token);
        temp.put("succ", succ);
        temp.put("error", error);
        temp.put("data", map.keySet());
        result.setData(temp);
        return result;
    }

    /**
     * 检验手动编号可存在
     *
     * @param nbrl_manual_number
     * @return
     */
    @RequestMapping(value = "/qryManualNumberCount", method = RequestMethod.GET)
    public Result qryManualNumberCount(@RequestParam(required = false, value = "nbrl_manual_number") String nbrl_manual_number,
                                       @RequestParam(required = false, value = "pid") String pid,
                                       @RequestParam(required = false, value = "token") String token) throws Exception {
        Result result = new Result();
        result.setData(nbrlManualNumberSetService.qryManualNumberCount(nbrl_manual_number, pid, token));
        return result;
    }

    /**
     * 编码规则列表
     *
     * @param dto
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/qryNumberRules", method = RequestMethod.POST)
    public Result qryNumberRules(@RequestBody QryNumberRulesDto dto) throws Exception {
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(nbrlManualNumberSetService.qryNumberRules(dto));
        return result;

    }

    /**
     * 删除编码规则
     *
     * @param id
     * @return
     */
    @RequestMapping(value = "/deleteNumberRule", method = RequestMethod.DELETE)
    public Result deleteNumberRule(@RequestParam(required = false, value = "id") String id) throws Exception {
        Result result = new Result();
        int ret = nbrlManualNumberSetService.deleteNumberRule(id);
        if (ret == -1) {
            result.setRetCode(-2);
            result.setErrMsg("规则编号已使用，不允许删除");
        }
        result.setData(ret);
        return result;
    }

    /**
     * 添加手工编号保存redis
     *
     * @param vo
     * @return
     */
    @RequestMapping(value = "/addToRedis", method = RequestMethod.POST)
    public Result addToRedis(@RequestBody ManualNumberAddToRedis vo) throws Exception {
        Result result = new Result();
        String token = nbrlManualNumberSetService.addToRedis(vo.getManualNumberCodes(), vo.getPid(), vo.getToken());
        result.setData(token);
        return result;
    }

    /**
     * 从redis中删除手工编码
     *
     * @param token
     * @return
     */
    @RequestMapping(value = "/removeToRedis", method = RequestMethod.DELETE)
    public Result removeToRedis(@RequestParam(required = false, value = "manualNumberCodes") String manualNumberCodes,
                                @RequestParam(required = false, value = "token") String token,
                                @RequestParam(required = false, value = "pid") String pid) throws Exception {
        Result result = new Result();
        token = nbrlManualNumberSetService.removeToRedis(Arrays.asList(manualNumberCodes.split(",")), token, pid);
       /* if(ret){
            result.setRetCode(-2);
            result.setErrMsg("删除手工编码失败");
        }*/
        result.setData(token);
        return result;
    }


   /* @RequestMapping(value = "/redisSynchronizeToMysql", method = RequestMethod.PUT)
    public Result redisSynchronizeToMysql(@RequestParam(required = false, value = "token") String token,
                                          @RequestParam(required = false, value = "authorization") String authorization) throws Exception {
        Result result = new Result();
        String ret = nbrlManualNumberSetService.redisSynchronizeToMysql(token,authorization);
        result.setData(ret);
        return result;
    }*/

    private String getValue(Cell hssfCell) {
        try {
            return String.valueOf(hssfCell.getStringCellValue()).trim();

        } catch (Exception e) {
            return null;
        }
    }

    /**
     * 删除批量导入中
     *
     * @param m
     * @return
     */
    private int deleteDuplicateData(Map<Integer, String> m) {
        if (StringUtil.isNullOrEmpty(m.get(1))) {
            return 0;
        }
        String temp = "";
        List<String> list = new ArrayList<>(Arrays.asList(m.get(1).split(",")));
        Set<String> set = new HashSet<>(list);
        Map<String,String> map = new HashMap<>();
        for (String s : list) {
            if (StringUtil.isNullOrEmpty(temp)) {
                temp = s;
                map.put(s,"true");
                continue;
            }
            if(map.get(s)==null){
                temp = temp + "," + s;
                map.put(s,"true");
            }

        }
        m.put(1, temp);
        return list.size() - set.size();
    }

}
