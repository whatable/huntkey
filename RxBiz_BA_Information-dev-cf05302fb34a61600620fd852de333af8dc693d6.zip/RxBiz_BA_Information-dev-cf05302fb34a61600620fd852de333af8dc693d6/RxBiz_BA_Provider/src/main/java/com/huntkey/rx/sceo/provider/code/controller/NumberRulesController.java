package com.huntkey.rx.sceo.provider.code.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.sceo.common.model.code.VO.NumberRulesVO;
import com.huntkey.rx.sceo.common.model.code.VO.NumberVO;
import com.huntkey.rx.sceo.provider.code.service.NumberRulesService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;


/**
 * @author liucs
 * @date 2017-11-24 13:44:10
 */
@RestController
@RequestMapping("/numberRules")
public class NumberRulesController {
    private static Logger logger = LoggerFactory.getLogger(NumberRulesController.class);
    @Autowired
    private NumberRulesService numberRuleService;

    /**
     * 新增规则
     * @param numberrulesEntity 前端参数
     * @return 返回结果
     */
    @RequestMapping(value = "/addNumberRules",method = RequestMethod.POST)
    public Result addNumberRules(@RequestParam("authorization")String authorization,
                                 @RequestParam("token")String token,
                                 @RequestBody NumberrulesEntity numberrulesEntity){
        Result result = new Result();
        String curentUserId = Utils.getCurentUserId(authorization);
        String errMessage = numberRuleService.isCodeOrNameEmpty(numberrulesEntity.getNbrl_code(),numberrulesEntity.getNbrl_name());
        if(!"".equals(errMessage)){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(errMessage);
            return result;
        }
        boolean flag = numberRuleService.isUseItemOrManualnumber(numberrulesEntity);
        if(flag){
            result.setErrMsg("请设置规则项或手工编号");
            result.setRetCode(Result.RECODE_ERROR);
            return result;
        }
        boolean isUseSerial = numberRuleService.isUseSerial(numberrulesEntity);
        if(!isUseSerial){
            result.setErrMsg("至少设置一个流水号选项");
            result.setRetCode(Result.RECODE_ERROR);
            return result;
        }
        try {
            //不存在返回false
            boolean isCodeExist = numberRuleService.isCodeExisted(numberrulesEntity.getNbrl_code());
            if(isCodeExist){
                result.setErrMsg("规则代码已被使用");
                result.setRetCode(Result.RECODE_ERROR);
                return result;
            }
           boolean isNameExist = numberRuleService.isNameExisted(numberrulesEntity.getNbrl_name());
            if(isNameExist){
                result.setErrMsg("规则名称已被使用");
                result.setRetCode(Result.RECODE_ERROR);
                return result;
            }
            numberrulesEntity.setNbrl_code(numberrulesEntity.getNbrl_code().replaceAll(" ",""));
            numberrulesEntity.setNbrl_name(numberrulesEntity.getNbrl_name().replaceAll(" ",""));
            String id = numberRuleService.addNumberRules(curentUserId, numberrulesEntity,authorization,token);
            result.setRetCode(Result.RECODE_SUCCESS);
            result.setData(id);
        } catch (Exception e) {
            logger.info(e.getMessage());
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
       return result;
    }


    /**
     * 根据id查询规则编号信息
     * @param id 编号规则id
     * @return 返回结果
     */
    @RequestMapping(value = "/getNumberRule/{id}",method = RequestMethod.GET)
    public Result getNumberRule(@PathVariable("id") String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        NumberRulesVO numberrulesEntity ;
        try{
            numberrulesEntity =  numberRuleService.getNumberRule(id);
            if(numberrulesEntity != null){
               NumberVO numberVO = numberRuleService.numberruleEntityAttribute2VO(numberrulesEntity);
                result.setData(numberVO);
            }
        }catch(Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 启用、禁用
     * @param id 规则编号id
     * @return 返回result
     */
    @RequestMapping(value = "/enableOrNot/{id}",method = RequestMethod.POST)
    public Result enableOrNot(@RequestParam("authorization")String authorization,@PathVariable("id") String id){
        String currentUserId = Utils.getCurentUserId(authorization);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try{
            result.setData(numberRuleService.enableOrNot(id,currentUserId));
        }catch(Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 生成32位UUID
     * @return 返回result
     */
    @RequestMapping(value = "/generateUUID", method = RequestMethod.GET)
    public Result generateUUID(){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(StringUtil.generateUUID());
        return result;
    }

    /**
     * 查询编号使用情况(支持模糊查询)
     * @param nbrl_code 规则代码
     * @param nbrl_cu_code 已使用编号
     * @param pageNum 页数
     * @param pageSize 每页行数
     * @return 返回结果
     */
    @RequestMapping(value = "/queryCodeUsed",method = RequestMethod.GET)
    public Result queryCodeUsed(@RequestParam(value = "nbrl_code")String nbrl_code,
                    @RequestParam(required = false, value = "nbrl_cu_code")String nbrl_cu_code,
                    @RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
                    @RequestParam(required = false, value = "pageSize", defaultValue = "10") int pageSize){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(numberRuleService.queryCodeUsed(nbrl_code,nbrl_cu_code,pageNum,pageSize));
        }catch(Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 编号规则修改
     * @param numberrulesEntity 前端封装参数
     * @return  返回结果
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public Result update(@RequestParam("authorization")String authorization,
                         @RequestParam("token")String token,
                         @RequestBody NumberrulesEntity numberrulesEntity){
        String curentUserId = Utils.getCurentUserId(authorization);
        Result result = new Result();
        String errMessage = numberRuleService.isCodeOrNameEmpty(numberrulesEntity.getNbrl_code(),numberrulesEntity.getNbrl_name());
        if(!"".equals(errMessage)){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(errMessage);
            return result;
        }
        boolean flag = numberRuleService.isUseItemOrManualnumber(numberrulesEntity);
        if(flag){
            result.setErrMsg("请设置规则项或手工编号");
            result.setRetCode(Result.RECODE_ERROR);
            return result;
        }
        boolean isUseSerial = numberRuleService.isUseSerial(numberrulesEntity);
        if(!isUseSerial){
            result.setErrMsg("至少设置一个流水号选项");
            result.setRetCode(Result.RECODE_ERROR);
            return result;
        }
        try {
            numberrulesEntity.setNbrl_code(numberrulesEntity.getNbrl_code().replaceAll(" ",""));
            numberrulesEntity.setNbrl_name(numberrulesEntity.getNbrl_name().replaceAll(" ",""));
            result =  numberRuleService.update(curentUserId, numberrulesEntity,token,authorization);
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 规则代码校验
     * @param nbrl_code 规则代码
     * @return  返回数据
     */
    @RequestMapping(value = "/isCodeExisted/{nbrl_code}",method = RequestMethod.GET)
    public Result isCodeExisted(@PathVariable("nbrl_code") String nbrl_code){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        Map<String ,String> map = new HashMap<>(2);
        try {
            boolean flag =  numberRuleService.isCodeExisted(nbrl_code);
            if(flag){
                map.put("message","规则代码已被使用");
            }else{
                map.put("message","");
            }
            result.setData(map);
        }catch(Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 规则名称校验
     * @param nbrlName 规则名称
     * @return 返回结果
     */
    @RequestMapping(value="/isNameExisted/{nbrlName}",method = RequestMethod.GET)
    public Result isNameExisted(@PathVariable("nbrlName") String nbrlName){
        Result result = new Result();
        Map<String ,String> map = new HashMap<>();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            boolean flag =  numberRuleService.isNameExisted(nbrlName);
            if(flag){
                map.put("message","规则名称已被使用");

            }else{
                map.put("message","");
            }
            result.setData(map);
        }catch(Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }


    @RequestMapping(value = "/getDefaultItems", method = RequestMethod.GET)
    public Result getDefaultItems(){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(numberRuleService.getDefaultItems());
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }
}
