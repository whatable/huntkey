package com.huntkey.rx.sceo.provider.code.service.Impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.NbrlNbrlConditionFormulaSetbEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlConditionSetaEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlItemSetbEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlManualNumberSetbEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlParamSetcEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlSerialSetcEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlTextSetcEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlTimeSetcEntity;
import com.huntkey.rx.sceo.common.model.code.VO.NumberRulesVO;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.NbrlGetCodeService;
import com.huntkey.rx.sceo.provider.feign.FormulaProvider;
import com.huntkey.rx.sceo.provider.utils.BigNumber;
import com.huntkey.rx.sceo.provider.utils.DateEquality;
import com.huntkey.rx.sceo.provider.utils.DateUtils;
import com.huntkey.rx.sceo.provider.utils.Utils;

@Service
public class NbrlGetCodeImpl implements NbrlGetCodeService {

	@Autowired
	private NumberRulesSereviceImpl nbrlService;

	@Autowired
	private NbrlManualNumberSetServiceImpl manualService;

	@Autowired
	private FormulaProvider formulaProvider;

	private Logger log = LoggerFactory.getLogger(this.getClass());

	/**
	 * 主动调用
	 * 
	 * @param nbrlCode
	 * @param params
	 * @return
	 */
	@Transactional
	@Override
	public synchronized Result callByActive(String nbrlCode, List<String> params) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_ERROR);
		String code = "";
		int maxSerial = 0;
		Map<String, String> map = new HashMap<>();
		// 根据 nbrlCode 查询 编号规则
		NumberRulesVO numberrulesEntity = null;
		try {
			numberrulesEntity = nbrlService.getNumberRuleByCode(nbrlCode);
			if (numberrulesEntity == null) {
				result.setErrMsg("规则不存在");
				return result;
			}
		} catch (Exception e) {
			result.setErrMsg("查询出错,可能规则不存在");
			return result;
		}

		// 流水号是否按条件递增
		String increase = numberrulesEntity.getNbrl_serial_increase();

		// 获取规则条件集
		List<NbrlNbrlConditionSetaEntity> nbrlNbrlConditionSetaEntityList = numberrulesEntity.getNbrl_condition_set();

		// 初始化规则条件
		NbrlNbrlConditionSetaEntity nbrlNbrlCondition = null;
		for (NbrlNbrlConditionSetaEntity nbrlNbrlConditionSetaEntity : nbrlNbrlConditionSetaEntityList) {
			if (Integer.valueOf(nbrlNbrlConditionSetaEntity.getNbrl_current_serial() == null ? "0"
					: nbrlNbrlConditionSetaEntity.getNbrl_current_serial()) > maxSerial) {
				maxSerial = Integer.valueOf(nbrlNbrlConditionSetaEntity.getNbrl_current_serial());
			}
		}
		for (NbrlNbrlConditionSetaEntity nbrlNbrlConditionSetaEntity : nbrlNbrlConditionSetaEntityList) {

			// 遍历规则条件集 ，查找符合条件的规则条件
			List<NbrlNbrlConditionFormulaSetbEntity> formulaList = nbrlNbrlConditionSetaEntity
					.getNbrl_condition_formula_set();

			if (formulaList.size() == 0) {
				nbrlNbrlCondition = nbrlNbrlConditionSetaEntity;
				continue;
			}

			// 判断是否满足参数条件
			String isAccord = "false";
			for (NbrlNbrlConditionFormulaSetbEntity formulaSet : formulaList) {

				String formula = formulaSet.getNbrl_condition_formula();
				formula = analsisParams(formula, params);
				if (StringUtil.isNullOrEmpty(formula)) {
					isAccord = "true";
					continue;
				}
				Map<String, Object> formulaParams = new HashMap<>();
				formulaParams.put("frmuContent", formula);
				formulaParams.put("dataContext", new HashMap<>());
				Object object = "";
				try {
					Result result1 = formulaProvider.calcPPI(formulaParams);
					object = result1.getData();
				} catch (Exception e) {
					object = false;
				}
				if ("true".equals(String.valueOf(object))) {
					isAccord = "true";
				} else {
					isAccord = "false";
					continue;
				}
			}

			if (!"false".equals(isAccord)) {
				nbrlNbrlCondition = nbrlNbrlConditionSetaEntity;
				break;
			} else {
				continue;
				// return "传入规则不符合条件，获取编号失败";
			}
		}
		if (nbrlNbrlCondition == null) {
			result.setErrMsg("未获取相对应的规则，编号获取失败");
			return result;
		}
		String currentSerial = nbrlNbrlCondition.getNbrl_current_serial();
		if (currentSerial == null) {
			currentSerial = "0";
		}
		if (!"1".equals(increase) && maxSerial > Integer.valueOf(currentSerial)) {
			currentSerial = String.valueOf(maxSerial);
		}
		try {
			map = getCode(nbrlNbrlCondition, increase, currentSerial, params);
			if ("".equals(map.get("sg"))) {
				result.setErrMsg("未取到手工编号，或手工编号已取完");
				return result;
			}
			code = map.get("code");
		} catch (Exception e) {
			result.setErrMsg("获取编号出错");
			return result;
		}
		if ("".equals(map.get("currentSerial"))) {
			result.setErrMsg("当前流水号已取到最大值，请重新设置");
			return result;
		}
		if ("".equals(map.get("property"))) {
			result.setErrMsg("参数截取错误，请重新设置");
			return result;
		}

		if (!StringUtil.isNullOrEmpty(code)) {
			try {
				if ("1".equals(increase)) {
					nbrlService.updatTakenoDate(nbrlNbrlCondition.getId(), map.get("currentSerial"));
				} else {
					for (NbrlNbrlConditionSetaEntity nbrlNbrlConditionSetaEntity : nbrlNbrlConditionSetaEntityList) {
						nbrlService.updatTakenoDate(nbrlNbrlConditionSetaEntity.getId(), map.get("currentSerial"));
					}
				}

			} catch (Exception e) {
				result.setErrMsg("更新出错");
				return result;
			}
		}
		result.setRetCode(Result.RECODE_SUCCESS);
		result.setData(code);
		return result;
	}

	/**
	 * 获取编号
	 * 
	 * @param nbrlNbrlCondition
	 * @param increace
	 * @param currentSerial
	 * @param params
	 *            参数格式是啥样？？？？？？？
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> getCode(NbrlNbrlConditionSetaEntity nbrlNbrlCondition, String increace,
			String currentSerial, List<String> params) throws Exception {

		// 判断是否手工编号
		String isManualNumber = nbrlNbrlCondition.getNbrl_is_manual_number();

		StringBuilder sb = new StringBuilder();
		String sg = "true";
		String property = "true";
		if ("1".equals(isManualNumber)) {
			// ↓↓↓↓↓ 手工编号
			NbrlNbrlManualNumberSetbEntity manual = manualService
					.getMinAndUnusedManualNumber(nbrlNbrlCondition.getId());
			sg = manual == null ? "" : manual.getNbrl_manual_number();
			sb.append(sg);
			// ↑↑↑↑↑↑ 手工编号
		} else {
			// ↓↓↓↓↓ 非手工编号
			for (NbrlNbrlItemSetbEntity item : nbrlNbrlCondition.getNbrl_item_set()) {
				switch (item.getNbrl_item_type()) {
				case Constants.TIME:
					// 生成日期时间编码
					for (NbrlNbrlTimeSetcEntity time : item.getNbrl_time_set()) {
						sb.append(encodeByTime(time.getNbrl_time_type(), time.getNbrl_time_length()));
					}
					break;
				case Constants.TEXT:
					for (NbrlNbrlTextSetcEntity text : item.getNbrl_text_set()) {
						sb.append(text.getNbrl_test_content());
					}
					break;
				case Constants.SERIAL:
					currentSerial = getSerialNumber(item.getNbrl_serial_set(), currentSerial, increace,
							nbrlNbrlCondition.getNbrl_takeno_date());
					sb.append(currentSerial);
					break;
				case Constants.PARAM:
					property = getParam(item.getNbrl_param_set(), params);
					sb.append(property);
					break;
				default:
					sb.append("");
					break;
				}
			}
			// ↑↑↑↑↑↑ 非手工编号
		}
		Map<String, String> map = new HashMap<>();
		map.put("code", sb.toString());
		map.put("currentSerial", currentSerial);
		// map.put("property",property);
		map.put("sg", sg);
		return map;
	}

	private static final String[] AM_AND_PM = { "AM", "PM" };
	private static final DateFormat YEAR4 = new SimpleDateFormat("yyyy");
	private static final DateFormat YEAR2 = new SimpleDateFormat("yy");

	private static String encodeByTime(String type, Integer length) {
		Calendar now = Calendar.getInstance();
		Date date = now.getTime();
		switch (type) {
		case Constants.YEAR:
			return length == 2 ? YEAR2.format(date) : YEAR4.format(date);
		case Constants.MONTH:
			return String.format(length == 2 ? "%02d" : "%x", now.get(Calendar.MONTH) + 1);
		case Constants.DAY:
			return String.format("%02d", now.get(Calendar.DAY_OF_MONTH));
		case Constants.HOURS:
			return String.format("%02d", now.get(Calendar.HOUR_OF_DAY));
		case Constants.MINUTE:
			return String.format("%02d", now.get(Calendar.MINUTE));
		case Constants.SECOND:
			return String.format("%02d", now.get(Calendar.SECOND));
		case Constants.SEASON:
			return Integer.toString(now.get(Calendar.MONTH) / 3 + 1);
		case Constants.WEEK:
			return Integer.toString(now.get(Calendar.WEEK_OF_YEAR));
		case Constants.SUNDAY:
			return Integer.toString(now.get(Calendar.DAY_OF_WEEK));
		case Constants.AMPM:
			return AM_AND_PM[now.get(Calendar.AM_PM)];
		default:
			return "";
		}
	}

	/**
	 * 获取流水号
	 * 
	 * @param nbrlNbrlSerialSetcEntityList
	 * @return
	 */
	public String getSerialNumber(List<NbrlNbrlSerialSetcEntity> nbrlNbrlSerialSetcEntityList, String currentSerial,
			String increase, Date lastDate) {
		String serialNumber = "";

		NbrlNbrlSerialSetcEntity nbrlNbrlSerialSetcEntity = nbrlNbrlSerialSetcEntityList.get(0);
		// 流水号长度
		int length = nbrlNbrlSerialSetcEntity.getNbrl_serial_length();
		// 重置条件
		String reset = nbrlNbrlSerialSetcEntity.getNbrl_serial_reset_condition();
		// 步长
		int step = nbrlNbrlSerialSetcEntity.getNbrl_serial_step();
		// 流水号重置开始值
		String resetNumber = nbrlNbrlSerialSetcEntity.getNbrl_serial_reset_number();
		// 进位规则
		String rule = nbrlNbrlSerialSetcEntity.getNbrl_serial_rule();

		if (lastDate == null) {
			serialNumber = resetNumber;
		} else {
			DateEquality equal = new DateEquality(lastDate);
			switch (reset) {
			case Constants.YEAR:
				if (!equal.year()) {
					// 当前年份和上次取号年份不一致情况，则重置流水号 跨年
					serialNumber = resetNumber;
				} else {
					serialNumber = getSerial(length, step, currentSerial, rule);
				}
				break;
			case Constants.MONTH:
				if (!equal.yearMonth()) {
					// 当前月份和上次取号月份不一致情况，则重置流水号 跨月
					serialNumber = resetNumber;
				} else {
					serialNumber = getSerial(length, step, currentSerial, rule);
				}
				break;
			case Constants.DAY:
				if (!equal.yearMonthDay()) {
					// 当前日期和上次取号日期不一致情况，则重置流水号 跨天
					serialNumber = resetNumber;
				} else {
					serialNumber = getSerial(length, step, currentSerial, rule);
				}
				break;
			case Constants.SEASON:
				if (!equal.yearSeason()) {
					// 当前季节和上次取号季节不一致情况，则重置流水号 跨季
					serialNumber = resetNumber;
				} else {
					serialNumber = getSerial(length, step, currentSerial, rule);
				}
				break;
			case Constants.WEEK:
				if (!equal.yearWeek()) {
					// 当前周和上次取号周不一致 重置流水号 跨周
					serialNumber = resetNumber;
				} else {
					serialNumber = getSerial(length, step, currentSerial, rule);
				}
				break;

			default:
				// 时分秒 AM/PM 不在做重置
				serialNumber = getSerial(length, step, currentSerial, rule);
				break;
			}
		}
		if (serialNumber.length() > length) {
			return "";
		}

		// TODO 更新当前流水号字段
		return BigNumber.AddToLeft(serialNumber, length);
	}

	/**
	 * 获取流水号
	 * 
	 * @param length
	 * @param step
	 * @param serial
	 * @param rule
	 * @return
	 */
	private String getSerial(int length, int step, String serial, String rule) {
		int hexRule = Integer.valueOf(rule);
		serial = BigNumber.Add_Positive(serial, String.valueOf(step), hexRule);
		return BigNumber.AddToLeft(serial, length);
	}

	/**
	 * 获取参数
	 * 
	 * @param nbrlParamSets
	 * @return
	 */
	public String getParam(List<NbrlNbrlParamSetcEntity> nbrlParamSets, List<String> params) {
		StringBuilder sb = new StringBuilder();
		if (nbrlParamSets != null && nbrlParamSets.size() > 0) {
			for (NbrlNbrlParamSetcEntity nbrlParamSet : nbrlParamSets) {
				String property = nbrlParamSet.getNbrl_param();
				for (int i = 1; i <= params.size(); i++) {
					if (property.contains(String.valueOf(i))) {
						property = params.get(i - 1);
						break;
					}
				}
				if (property.contains("参数")) {
					return "";
				}

				int firstNum = nbrlParamSet.getNbrl_param_start_position() == null ? 0
						: nbrlParamSet.getNbrl_param_start_position();
				int count = nbrlParamSet.getNbrl_param_intercept_count();
				switch (nbrlParamSet.getNbrl_param_type()) {
				case Constants.ICPT_NO:
					sb.append(property);
					break;
				case Constants.ICPT_LEFT:
					if (property.length() <= count) {
						sb.append(property);
					} else {
						sb.append(Utils.subStr(property, 0, count));
					}

					break;
				case Constants.ICPT_MIDDLE:
					if (property.length() < firstNum) {
						sb.append("");
					} else {
						if (property.length() - firstNum < count) {
							sb.append(property.substring(firstNum == 0 ? 0 : (firstNum - 1)));
						} else {
							sb.append(Utils.subStr(property, firstNum == 0 ? 0 : (firstNum - 1), firstNum + count - 1));
						}
					}
					break;
				case Constants.ICPT_RIGHT:
					if (property.length() <= count) {
						sb.append(property);
					} else {
						sb.append(Utils.subStr(property, property.length() - count, property.length()));
					}
					break;
				default:
					sb.append(property);
				}

			}
		}
		return sb.toString();
	}

	/**
	 * 获取参数解析后结果
	 * 
	 * @param formula
	 * @param params
	 * @return
	 */
	private String analsisParams(String formula, List<String> params) {
		if (params == null || params.size() == 0) {
			return formula;
		}

		if (formula.contains("参数1") && params.size() > 0) {
			formula = formula.replace("参数1", params.get(0));
		}
		if (formula.contains("参数2") && params.size() > 1) {
			formula = formula.replace("参数2", params.get(1));
		}
		if (formula.contains("参数3") && params.size() > 2) {
			formula = formula.replace("参数3", params.get(2));
		}
		formula = Utils.analytical(formula);

		return formula;

	}

}
