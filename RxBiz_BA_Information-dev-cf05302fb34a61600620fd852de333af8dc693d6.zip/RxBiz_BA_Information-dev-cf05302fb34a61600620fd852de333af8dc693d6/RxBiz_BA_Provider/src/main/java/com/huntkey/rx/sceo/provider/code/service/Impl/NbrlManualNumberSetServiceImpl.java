package com.huntkey.rx.sceo.provider.code.service.Impl;

import com.huntkey.rx.commons.utils.redis.RedisClusterUtils;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.sceo.common.model.code.Const.NumberRulesConst;
import com.huntkey.rx.sceo.common.model.code.NbrlManualNumberSetConst;
import com.huntkey.rx.sceo.common.model.code.QryNumberRulesDto;
import com.huntkey.rx.sceo.common.model.code.VO.NbrlNbrlUseSetaVO;
import com.huntkey.rx.sceo.common.model.code.VO.NumberRulesVO;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.NbrlManualNumberSetService;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import com.huntkey.rx.sceo.provider.utils.EntityConvertVOUtil;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.*;

/**
 * @author zoulj
 * @create 2017/11/27 9:20
 **/
@Service
public class NbrlManualNumberSetServiceImpl implements NbrlManualNumberSetService {

    private static Logger log = LoggerFactory.getLogger(NbrlManualNumberSetServiceImpl.class);

    @Autowired
    private OrmService ormService;

    @Autowired
    private ModelerProvider modelerProvider;

    @Override
    public String insert(NbrlNbrlManualNumberSetbEntity nbrlNbrlManualNumberSetbEntity, String authorization) throws Exception {
        nbrlNbrlManualNumberSetbEntity.setNbrl_manual_number_order(getMaxManualNumberOrder(nbrlNbrlManualNumberSetbEntity.getPid()) + 1);
        nbrlNbrlManualNumberSetbEntity.setCretime(new Date());
        nbrlNbrlManualNumberSetbEntity.setClassName("nbrl_manual_number_set");
        nbrlNbrlManualNumberSetbEntity.setCreuser(Utils.getCurentUserId(authorization));
        nbrlNbrlManualNumberSetbEntity.setModuser(Utils.getCurentUserId(authorization));
        nbrlNbrlManualNumberSetbEntity.setNbrl_is_use(Constants.UNUSE);

        Serializable serializable = ormService.insert(nbrlNbrlManualNumberSetbEntity);
        if (serializable == null) {
            return null;
        }
        return serializable.toString();
    }

    @Override
    public Pagination<NumberRulesVO> qryNumberRules(QryNumberRulesDto dto) throws Exception {
        //获取规则条件中属性集合
        OrmParam ormParamUseSeta = new OrmParam();
        ormParamUseSeta.addColumn("*");
//        if (!StringUtils.isEmpty(dto.getNbrl_useproperty())) {
//            List<String> paramsUseSeta = new ArrayList<>();
//            List<String> usepropertyIds = new ArrayList<>();
//            Result result = modelerProvider.selectEdmpIdsByEdmpName(dto.getNbrl_useproperty());
//            if (result.getData() != null) {
//                usepropertyIds = (List<String>) result.getData();
//            }
//            List<String> nbrl_class_ids = new ArrayList<>();
//            result = modelerProvider.selectClassIdsByClassName(dto.getNbrl_useproperty());
//            if (result.getData() != null) {
//                nbrl_class_ids = (List<String>) result.getData();
//            }
//            String temp = OrmParam.or(ormParamUseSeta.getInXML("nbrl_useproperty", usepropertyIds.toArray()), ormParamUseSeta.getInXML("nbrl_class_id", nbrl_class_ids.toArray()));
//            paramsUseSeta.add(temp);
//            String whereExp = OrmParam.and(paramsUseSeta);
//            ormParamUseSeta.setWhereExp(whereExp);
//        }
//        List<NbrlNbrlUseSetaEntity> nnus = ormService.selectBeanList(NbrlNbrlUseSetaEntity.class, ormParamUseSeta);
//        Map<String, List<NbrlNbrlUseSetaEntity>> useSetaMap = new HashMap<>();
//        for (NbrlNbrlUseSetaEntity entity : nnus) {
//            if (useSetaMap.get(entity.getPid()) == null) {
//                List<NbrlNbrlUseSetaEntity> list = new ArrayList<>();
//                list.add(entity);
//                useSetaMap.put(entity.getPid(), list);
//            } else {
//                List<NbrlNbrlUseSetaEntity> list = useSetaMap.get(entity.getPid());
//                list.add(entity);
//                useSetaMap.put(entity.getPid(), list);
//            }
//        }
//
//        //属性条件为空且属性集为空时，则说明规则条件集为空
//        if (useSetaMap.isEmpty() && !StringUtils.isEmpty(dto.getNbrl_useproperty())) {
//            return new Pagination(new ArrayList(), dto.getPageNum(), dto.getPageSize(), 0);
//        }

        //获取编码规则中规则条件集
        OrmParam ormParamConditionSeta = new OrmParam();
        ormParamUseSeta.addColumn("*");
        List<String> paramsConditionSeta = new ArrayList<>();
        if (!StringUtils.isEmpty(dto.getNbrl_is_used())) {
            paramsConditionSeta.add(ormParamConditionSeta.getEqualXML("nbrl_is_used", dto.getNbrl_is_used()));
        }
        String whereExp = OrmParam.and(paramsConditionSeta);
        ormParamConditionSeta.setWhereExp(whereExp);
        ormParamConditionSeta.addOrderExpElement(SQLSortEnum.ASC, "nbrl_condition_order");
        List<NbrlNbrlConditionSetaEntity> nbrlConditionSetaEntities = ormService.selectBeanList(NbrlNbrlConditionSetaEntity.class, ormParamConditionSeta);
        Utils.getUserNameByUserId(ormService, nbrlConditionSetaEntities, "moduser");
        Map<String, List<NbrlNbrlConditionSetaEntity>> conditionSetaMap = new HashMap<>();
        for (NbrlNbrlConditionSetaEntity entity : nbrlConditionSetaEntities) {
            String pid = entity.getId();
            OrmParam ormParam2 = new OrmParam();
            ormParam2.addColumn("*");
            ormParam2.setWhereExp(ormParam2.getEqualXML("pid", pid));
            entity.setNbrl_condition_formula_set(ormService.selectBeanList(NbrlNbrlConditionFormulaSetbEntity.class, ormParam2));
            if (conditionSetaMap.get(entity.getPid()) == null) {
                List<NbrlNbrlConditionSetaEntity> list = new ArrayList<>();
                list.add(entity);
                conditionSetaMap.put(entity.getPid(), list);
            } else {
                List<NbrlNbrlConditionSetaEntity> list = conditionSetaMap.get(entity.getPid());
                list.add(entity);
                conditionSetaMap.put(entity.getPid(), list);
            }
        }

        //属性条件为空且属性集为空时，则说明规则条件集为空
        if (conditionSetaMap.isEmpty() && !StringUtils.isEmpty(dto.getNbrl_is_used())) {
            return new Pagination(new ArrayList(), dto.getPageNum(), dto.getPageSize(), 0);
        }

        //获取规则条件集
        OrmParam ormParam = new OrmParam();
        ormParam.setPageSize(dto.getPageSize());
        ormParam.setPageNo(dto.getPageNum());
        List<String> list = new ArrayList<>();
        String[] as = {"id", "info_code", "info_desc", "info_name", "nbrl_code", "nbrl_name", "nbrl_serial_increase", "creuser", "modtime"};
        list.addAll(Arrays.asList(as));
        ormParam.setColumns(list);
        List<String> params = new ArrayList<>();
        if (!StringUtils.isEmpty(dto.getNbrl_code())) {
            params.add(ormParam.getMatchMiddleXML(NumberRulesConst.NBRL_NBRL_CODE, dto.getNbrl_code()));
        }
        if (!StringUtils.isEmpty(dto.getNbrl_name())) {
            params.add(ormParam.getMatchMiddleXML(NumberRulesConst.NBRL_NBRL_NAME, dto.getNbrl_name()));
        }

        //取两个子集中pid的交集部分，查询编码规则
        List<String> ids = new ArrayList<>();
        for (String id : conditionSetaMap.keySet()) {
//            if (conditionSetaMap.keySet().contains(id)) {
            ids.add(id);
//            }
        }
        params.add(ormParam.getInXML("id", ids.toArray()));
        whereExp = OrmParam.and(params);
        ormParam.setWhereExp(whereExp);
        ormParam.addOrderExpElement(SQLSortEnum.DESC, "modtime");

        List<NumberRulesVO> vos = new ArrayList<>();
        Pagination<NumberrulesEntity> pagination = ormService.selectPagedBeanList(NumberrulesEntity.class, ormParam);
        if (pagination.getTotal() == 0) {
            return new Pagination(vos, pagination.getPageNum(), pagination.getPageSize(), 0);
        }
        List<NumberrulesEntity> numberrulesEntities = pagination.getList();

        for (NumberrulesEntity nb : numberrulesEntities) {
            NumberRulesVO vo = new NumberRulesVO();
            EntityConvertVOUtil.assignmentOfTheSameField(nb, vo);
//            vo.setNbrl_use_set(convertNbrlNbrlUseSetaEntity(useSetaMap.get(nb.getId())));
            vo.setNbrl_condition_set(conditionSetaMap.get(nb.getId()));
            vos.add(vo);

        }
        return new Pagination(vos, pagination.getPageNum(), pagination.getPageSize(), pagination.getTotal());
    }

    /**
     * 将NbrlNbrlUseSetaEntity 转换成 NbrlNbrlUseSetaVO
     *
     * @param nnus
     * @return
     */
    public List<NbrlNbrlUseSetaVO> convertNbrlNbrlUseSetaEntity(List<NbrlNbrlUseSetaEntity> nnus) throws Exception {
        List<NbrlNbrlUseSetaVO> vos = new ArrayList<>();
        if (nnus == null || nnus.size() == 0) {
            return vos;
        }
        for (NbrlNbrlUseSetaEntity entity : nnus) {
            NbrlNbrlUseSetaVO vo = new NbrlNbrlUseSetaVO();
            EntityConvertVOUtil.assignmentOfTheSameField(entity, vo);
            String className = (String) (modelerProvider.getClassNamesByIds(entity.getNbrl_class_id()).getData());
            vo.setNbrl_class_name(className);
            Map<String, String> map = (Map<String, String>) modelerProvider.getProperty(entity.getNbrl_useproperty()).getData();
            if (map != null) {
                vo.setNbrl_useproperty_name(map.get("edmpName"));
            }
            vos.add(vo);
        }
        return vos;
    }


    @Override
    public int insert(List<NbrlNbrlManualNumberSetbEntity> nbrlManualNumberSets, String authorization, String token) throws Exception {
        if (nbrlManualNumberSets.size() == 0) {
            return -1;
        }

        //FIXME 存在数据并发风险
        int index = getMaxManualNumberOrder(nbrlManualNumberSets.get(0).getPid());
        List<NbrlNbrlManualNumberSetbEntity> temp = new ArrayList<>();
        for (NbrlNbrlManualNumberSetbEntity nb : nbrlManualNumberSets) {
            if (qryManualNumberCount(nb.getNbrl_manual_number(), nb.getPid()) > 0) {
                continue;
            }
            nb.setNbrl_manual_number_order(++index);
            nb.setCretime(new Date());
            nb.setNbrl_is_use(Constants.UNUSE);
            nb.setClassName("nbrl_manual_number_set");
            nb.setCreuser(Utils.getCurentUserId(authorization));
            nb.setModuser(Utils.getCurentUserId(authorization));
            temp.add(nb);
        }

        return ormService.insert(temp);
    }

    @Override
    public int qryManualNumberCount(String manualNumber, String pid, String token) throws Exception {
        RedisClusterUtils rcu = new RedisClusterUtils(Constants.REDIS_NODES);
        OrmParam ormParam = new OrmParam();
        ormParam.addColumn(NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_TB);
        List<String> params = new ArrayList<>();
        params.add(ormParam.getEqualXML(NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_TB, manualNumber));
        params.add(ormParam.getEqualXML("pid", pid));
        ormParam.setWhereExp(OrmParam.and(params));
        long count = ormService.count(NbrlNbrlManualNumberSetbEntity.class, ormParam);

        if (!StringUtil.isNullOrEmpty(token)) {
            Map<String, String> mapDel = rcu.getHashMap(Constants.REDISKEY + "del_dbdata" + token);
            String v = mapDel.get(pid);
            if (!StringUtil.isNullOrEmpty(v) && new ArrayList<>(Arrays.asList(v.split(","))).contains(manualNumber)) {
                count--;
            }
            Map<String, String> mapAdd = rcu.getHashMap(Constants.REDISKEY + token);
            String values = mapAdd.get(pid);
            if (!StringUtil.isNullOrEmpty(values) && new ArrayList<>(Arrays.asList(values.split(","))).contains(manualNumber)) {
                count++;
            }
        }
        return (int) count;
    }

    @Override
    public int qryManualNumberCount(String manualNumber, String pid) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.addColumn(NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_TB);
        List<String> params = new ArrayList<>();
        params.add(ormParam.getEqualXML(NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_TB, manualNumber));
        params.add(ormParam.getEqualXML("pid", pid));
        ormParam.setWhereExp(OrmParam.and(params));
        long count = ormService.count(NbrlNbrlManualNumberSetbEntity.class, ormParam);
        return (int) count;
    }

    /**
     * 获取数据库最大排序值
     *
     * @return
     */
    private int getMaxManualNumberOrder(String pid) throws Exception {
        int num = 0;
        //FIXME 存在并发数据不同步风险；并且ORM暂未提供max函数查询
        OrmParam ormParam = new OrmParam();
        // ormParam.addColumn(OrmParam.sqlMaxFunctionXML("nbrl_manual_number_order"));
        ormParam.setWhereExp(ormParam.getEqualXML("pid", pid));
        ormParam.addOrderExpElement(SQLSortEnum.DESC, "nbrl_manual_number_order");
        ormParam.setPageSize(1);
        ormParam.setPageNo(1);

        Pagination<NbrlNbrlManualNumberSetbEntity> pagination = ormService.selectPagedBeanList(NbrlNbrlManualNumberSetbEntity.class, ormParam);
        List<NbrlNbrlManualNumberSetbEntity> list = pagination.getList();
        if (list != null && list.size() > 0) {
            num = list.get(0).getNbrl_manual_number_order();
        }
        return num;
    }

    @Override
    public int delete(String ids) throws Exception {
        int ret = 0;
        for (String id : ids.split(",")) {
            NbrlNbrlManualNumberSetbEntity entity = ormService.load(NbrlNbrlManualNumberSetbEntity.class, id);
            if (entity.getNbrl_is_use().equals(Constants.USED)) {
                continue;
            }
            ormService.delete(NbrlNbrlManualNumberSetbEntity.class, id);
            ret++;
        }
        return ret;
    }

    @Override
    public Pagination<NbrlNbrlManualNumberSetbEntity> list(String nbrlManualNumber, String nbrlIsUse, String pid, String authorization, String token, int pageNum, int pageSize) throws Exception {
        RedisClusterUtils rcu = new RedisClusterUtils(Constants.REDIS_NODES);
        Map<String, String> mapDel = rcu.getHashMap(Constants.REDISKEY + "del_dbdata" + token);
        OrmParam ormParam = new OrmParam();
        List<String> list = new ArrayList<>();
        String[] as = {"id", "nbrl_manual_number", "nbrl_manual_number_order", "nbrl_is_use", "pid", "cretime", "moduser", "creuser", "modtime"};
        list.addAll(Arrays.asList(as));
        ormParam.setColumns(list);

        List<String> params = new ArrayList<>();
        if (!StringUtil.isNullOrEmpty(mapDel.get(pid))) {
            String[] predelete = mapDel.get(pid).split(",");
            params.add(ormParam.getNotInXML("nbrl_manual_number", predelete));
        }
        if (!StringUtil.isNullOrEmpty(pid)) {
            params.add(ormParam.getEqualXML("pid", pid));
        } else {
            return new Pagination<>(new ArrayList<>(), pageNum, pageSize, 0);
        }
        if (!StringUtil.isNullOrEmpty(nbrlManualNumber)) {
            params.add(ormParam.getMatchMiddleXML(NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_TB, nbrlManualNumber));
        }
        if (!StringUtil.isNullOrEmpty(nbrlIsUse)) {
            params.add(ormParam.getEqualXML(NbrlManualNumberSetConst.NBRL_IS_USE_TB, nbrlIsUse));
        }

        String whereExp = OrmParam.and(params);
        ormParam.addOrderExpElement(SQLSortEnum.ASC, "nbrl_manual_number_order");

        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);

        ormParam.setWhereExp(whereExp);
        if (nbrlIsUse != null && nbrlIsUse.equals(Constants.USED)) {
            Pagination pp = ormService.selectPagedBeanList(NbrlNbrlManualNumberSetbEntity.class, ormParam);
            if (pp.getList() == null) {
                pp.setList(new ArrayList());
            }
            Utils.getUserNameByUserId(ormService, pp.getList(), "moduser");
            return pp;
        }
        Pagination<NbrlNbrlManualNumberSetbEntity> p = ormService.selectPagedBeanList(NbrlNbrlManualNumberSetbEntity.class, ormParam);
        Map<String, String> mapAdd = rcu.getHashMap(Constants.REDISKEY + token);
        String values = mapAdd.get(pid);
        List<String> redisEntity = new ArrayList<>();

        if (!StringUtil.isNullOrEmpty(values)) {
            for (String manualNumber : values.split(",")) {
                if (StringUtil.isNullOrEmpty(manualNumber) || (!StringUtil.isNullOrEmpty(nbrlManualNumber) && !manualNumber.contains(nbrlManualNumber))) {
                    continue;
                }
                redisEntity.add(manualNumber);
            }
        }
        if (p.getList() == null || p.getList().size() < p.getPageSize()) {

            List<NbrlNbrlManualNumberSetbEntity> temp = p.getList() == null ? new ArrayList<>() : p.getList();

            if (StringUtil.isNullOrEmpty(values)) {
                return new Pagination<>(temp, pageNum, pageSize, p.getTotal());
            }
            int order = getMaxManualNumberOrder(pid);
            long index = p.getTotal();
            int start = p.getPageSize() * (p.getPageNum() - 1) + 1;
            int end = p.getPageSize() * (p.getPageNum());
            for (String manualNumber : redisEntity) {
                order++;
                if (StringUtil.isNullOrEmpty(manualNumber)) {
                    continue;
                }
                if (start <= ++index) {
                    NbrlNbrlManualNumberSetbEntity nb = new NbrlNbrlManualNumberSetbEntity();
                    nb.setModuser(pid);
                    nb.setNbrl_manual_number(manualNumber);
                    nb.setNbrl_manual_number_order(order);
                    nb.setModtime(new Date());
                    nb.setCreuser(Utils.getCurentUserName(authorization));
                    nb.setModuser(Utils.getCurentUserName(authorization));
                    nb.setNbrl_is_use(Constants.UNUSE);
                    temp.add(nb);
                }
                if (index == end) {
                    break;
                }
            }
            return new Pagination<>(temp, pageNum, pageSize, p.getTotal() + redisEntity.size());
        }
        p.setTotal(p.getTotal() + redisEntity.size());
        return p;

    }

    @Override
    public String updateList(List<NbrlNbrlManualNumberSetbEntity> nbs) throws Exception {
        List<Integer> index = new ArrayList<>();

        for (NbrlNbrlManualNumberSetbEntity entity : nbs) {
            if (StringUtil.isNullOrEmpty(entity.getId())) {
                return "存在临时数据不能进行上移（下移）操作";
            }
            index.add(entity.getNbrl_manual_number_order());
        }
        Collections.sort(index);

        int temp = 0;
        int lenth = nbs.size();
        for (NbrlNbrlManualNumberSetbEntity nb : nbs) {
            nb.setNbrl_manual_number_order(index.get(temp++));
            lenth = lenth - ormService.updateSelective(nb);
        }
        if (lenth == 0) {
            return "success";
        }
        /*可能出现不影响结果的不完全更新*/
        return "warning";
    }

    /**
     * 获取排序最小的可用手工编号
     *
     * @return
     * @throws Exception
     */
    public NbrlNbrlManualNumberSetbEntity getMinAndUnusedManualNumber(String pid) throws Exception {
        OrmParam ormParam = new OrmParam();
        //ormParam.addColumn(OrmParam.sqlMinFunctionXML("nbrl_manual_number_order"));
        List<String> params = new ArrayList<>();
        params.add(ormParam.getEqualXML("nbrl_is_use", Constants.UNUSE));
        params.add(ormParam.getEqualXML("pid", pid));
        String whereExp = OrmParam.and(params);
        ormParam.setWhereExp(whereExp);
        ormParam.addOrderExpElement(SQLSortEnum.ASC, "nbrl_manual_number_order");

        NbrlNbrlManualNumberSetbEntity entity = null;

        List<NbrlNbrlManualNumberSetbEntity> list = ormService.selectBeanList(NbrlNbrlManualNumberSetbEntity.class, ormParam);
        if (list != null && list.size() > 0) {
            entity = list.get(0);
            entity.setNbrl_is_use(Constants.USED);
            ormService.updateSelective(entity);
        }
        return entity;

    }

    @Transactional
    @Override
    public int deleteNumberRule(String id) throws Exception {
        NumberrulesEntity entity = ormService.load(NumberrulesEntity.class, id);
        if (entity == null) {
            return 0;
        }
        /***********删除规则条件集**************/
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML("pid", entity.getId()));
        List<NbrlNbrlConditionSetaEntity> conditionSetaEntities = ormService.selectBeanList(NbrlNbrlConditionSetaEntity.class, ormParam);
        List<String> conditionSetIds = new ArrayList<>();
        for (NbrlNbrlConditionSetaEntity entity1 : conditionSetaEntities) {
            if (!StringUtil.isNullOrEmpty(entity1.getNbrl_takeno_date())) {
                return -1;
            }
            conditionSetIds.add(entity1.getId());
        }
        //删除规则条件公式集
        ormParam.reset();
        ormParam.setWhereExp(ormParam.getInXML("pid", conditionSetIds.toArray()));
        ormService.delete(NbrlNbrlConditionFormulaSetbEntity.class, ormParam);

        //删除规则项集
        ormService.delete(NbrlNbrlItemSetbEntity.class, ormParam);

        //删除手工编号集
        ormService.delete(NbrlNbrlManualNumberSetbEntity.class, ormParam);

        //删除规则条件
        ormParam.reset();
        ormParam.setWhereExp(ormParam.getEqualXML("pid", entity.getId()));
        ormService.delete(NbrlNbrlConditionSetaEntity.class, ormParam);

        /***********删除规则使用属性集**************/
        OrmParam ormParamUseSeta = new OrmParam();
        ormParamUseSeta.setWhereExp(ormParamUseSeta.getEqualXML("pid", entity.getId()));
        ormService.delete(NbrlNbrlUseSetaEntity.class, ormParamUseSeta);
        return ormService.delete(NumberrulesEntity.class, id);
    }

    @Override
    public String addToRedis(String manualNumberCodes, String pid, String token) throws Exception {
        long timeStamp = System.currentTimeMillis();
        RedisClusterUtils rcu = new RedisClusterUtils(Constants.REDIS_NODES);
        Map<String, String> map = rcu.getHashMap(Constants.REDISKEY + token);
        if (map.isEmpty() || StringUtil.isNullOrEmpty(manualNumberCodes)) {
            map = new HashMap<>();
        }

        manualNumberCodes = map.get(pid) == null ? "" + manualNumberCodes : map.get(pid) + "," + manualNumberCodes;
        map.put(pid, manualNumberCodes);

        token = StringUtil.isNullOrEmpty(token) ? String.valueOf(timeStamp) : token;

        rcu.setHashMap(Constants.REDISKEY + token, map);
        //设置一小时过期时间
        rcu.expire(Constants.REDISKEY + token, 3600 * 1000);
        return token;
    }

    @Override
    public String removeToRedis(List<String> manualNumberCodes, String token, String pid) throws Exception {
        if (StringUtil.isNullOrEmpty(token)) {
            long timeStamp = System.currentTimeMillis();
            token = String.valueOf(timeStamp);
        }
        RedisClusterUtils rcu = new RedisClusterUtils(Constants.REDIS_NODES);
        Map<String, String> map = rcu.getHashMap(Constants.REDISKEY + token);
        String values = map.get(pid);
        List<String> addList = new ArrayList<>();
        if (!StringUtil.isNullOrEmpty(values)) {
            addList = new ArrayList<>(Arrays.asList(values.split(",")));
        }
        String delTemp = "";
        for (String code : manualNumberCodes) {
            if (addList.contains(code)) {
                addList.remove(code);
                continue;
            }
            delTemp = delTemp + code + ",";

        }
        map.put(pid, listToString(addList));
        rcu.setHashMap(Constants.REDISKEY + token, map);

        Map<String, String> mapDel = rcu.getHashMap(Constants.REDISKEY + "del_dbdata" + token);
        mapDel.put(pid, (mapDel.get(pid) == null ? "" : (mapDel.get(pid) + ",")) + delTemp);

        //需要删除数据库中的数据
        rcu.setHashMap(Constants.REDISKEY + "del_dbdata" + token, mapDel);
        //设置一小时过期时间
        rcu.expire(Constants.REDISKEY + "del_dbdata" + token, 3600 * 1000);
        return token;
    }

    /**
     * redis中数据同步到mysql中
     *
     * @param token
     * @return
     */
    @Override
    public String redisSynchronizeToMysql(String token, String authorization) throws Exception {
        //添加
        RedisClusterUtils rcu = new RedisClusterUtils(Constants.REDIS_NODES);
        Map<String, String> mapAdd = rcu.getHashMap(Constants.REDISKEY + token);
        List<NbrlNbrlManualNumberSetbEntity> entities = new ArrayList<>();
        for (String key : mapAdd.keySet()) {
            if (!StringUtil.isNullOrEmpty(mapAdd.get(key))) {
                for (String manualNumberCode : mapAdd.get(key).split(",")) {
                    if (StringUtil.isNullOrEmpty(manualNumberCode)) {
                        continue;
                    }
                    NbrlNbrlManualNumberSetbEntity entity = new NbrlNbrlManualNumberSetbEntity();
                    entity.setPid(key);
                    entity.setNbrl_manual_number(manualNumberCode);
                    entities.add(entity);
                }
            }
        }
        int add = this.insert(entities, authorization, token);

        //删除
        Map<String, String> mapDel = rcu.getHashMap(Constants.REDISKEY + "del_dbdata" + token);
        int i = 0;
        for (String key : mapDel.keySet()) {
            String removeEntityIsManualNumberCodes = mapDel.get(key);
            OrmParam ormParam = new OrmParam();
            List<String> params = new ArrayList<>();
            params.add(ormParam.getEqualXML("pid", key));
            params.add(ormParam.getInXML("nbrl_manual_number", removeEntityIsManualNumberCodes.split(",")));
            ormParam.setWhereExp(OrmParam.and(params));
            i += ormService.delete(NbrlNbrlManualNumberSetbEntity.class, ormParam);
        }
        return "成功添加" + add + "条数据，成功删除" + i + "条数据";
    }

    /**
     * 删除字符串最后一位‘，’
     *
     * @param
     */
    private String listToString(List<String> list) {
        String string = "";
        if (list == null || list.size() == 0) {
            return string;
        }
        for (String s : list) {
            if (StringUtil.isNullOrEmpty(s)) {
                continue;
            }
            if (!string.equals("")) {
                string += ",";
            }
            string = string + s;
        }
        return string;
    }
}
