package com.huntkey.rx.sceo.provider.code.service.Impl;

import com.huntkey.rx.base.BaseEntity;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.sceo.common.model.code.Const.*;
import com.huntkey.rx.sceo.common.model.code.NbrlManualNumberSetConst;
import com.huntkey.rx.sceo.common.model.code.VO.*;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLCurdEnum;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.common.util.EdmUtil;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.NbrlManualNumberSetService;
import com.huntkey.rx.sceo.provider.code.service.NumberRulesService;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import com.huntkey.rx.sceo.provider.utils.EntityConvertVOUtil;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Method;
import java.util.*;

/**
 * @author liucs
 * @create 2017-12-21 17:41:07
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class NumberRulesSereviceImpl implements NumberRulesService {
    private static Logger logger = LoggerFactory.getLogger(NumberRulesSereviceImpl.class);
    /**
     * 反射——方法类型
     */
    private static final String METHOD_TYPE_GET = "get";
    /**
     * 方法名称
     */
    private static final String METHOD_NAME_GETID = "getId";
    /**
     * 待删除的集合
     */
    private static final String TO_DELETE_LIST = "toDeleteList";
    /**
     * 待添加的集合
     */
    private static final String TO_ADD_LIST = "toAddList";
    /**
     * 待修改的集合
     */
    private static final String TO_UPDATE_LIST = "toUpdateList";
    /**
     * 待操作的规则条件公式集
     */
    private static final String CONDITION_FORMULASETB_ENTITY_LIST = "conditionFormulaSetbEntityList";
    /**
     * 待操作的规则项集
     */
    private static final String ITEMSETB_ENTITY_LIST = "itemSetbEntityList";
    /**
     * 待操作的已使用编号集
     */
    private static final String CODEUSEDB_ENTITY_LIST = "codeUsedbEntityList";
    /**
     * 待操作的公式集
     */
    private static final String FORMULAC_ENTITY_LIST = "formulacEntityList";
    /**
     * 待操作的时间集
     */
    private static final String TIMESTEC_ENTITY_LIST = "timeSetcEntityList";
    /**
     * 待操作的文本集
     */
    private static final String TEXTSETC_ENTITY_LIST = "textSetcEntityList";
    /**
     * 待操作的流水号集
     */
    private static final String SERIALSETC_ENTITY_LIST = "serialSetcEntityList";
    /**
     * 待操作的属性集
     */
    private static final String PROPERTY_TYPEC_ENTITY_LIST = "propertyTypecEntityList";
    /**
     * 待操作的参数集
     */
    private static final String PARAMSETC_ENTITY_LIST = "paramSetcEntityList";

    @Autowired
    private OrmService ormService;
    @Autowired
    private ModelerProvider provider;

    @Autowired
    private NbrlManualNumberSetService nbrlManualNumberSetService;


    @SuppressWarnings("unchecked")
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String addNumberRules(String curentUserName, NumberrulesEntity numberRules, String authorization,String token) throws Exception{
        //主表NumberRules插入
        numberRules.setCreuser(curentUserName);
        String id = ormService.insertSelective(numberRules).toString();
        //setPropertyBaseEntitiesSysColumns  根据操作的模式为属性集添加上属性集特有的系统信息 pid classname creuser moduser
        if(null != numberRules.getNbrl_condition_set() && numberRules.getNbrl_condition_set().size() > 0){
            EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,numberRules, numberRules.getNbrl_condition_set(), SQLCurdEnum.INSERT);
            //设置公共属性
            setPublicProperties(curentUserName, numberRules.getNbrl_condition_set());
            //设置规则条件状态初始值__1__启用
            for(NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : numberRules.getNbrl_condition_set()){
                nbrlConditionSetaEntity.setNbrl_is_used(Constants.ENABLE);
            }
            //插入规则条件集
            ormService.insert(numberRules.getNbrl_condition_set());

            //添加手工编号
            if (!StringUtil.isNullOrEmpty(token)) {
                nbrlManualNumberSetService.redisSynchronizeToMysql(token, authorization);
            }
            //设置第三层属性集
            Map<String, List> map = setThirdSubattributeSet(curentUserName, numberRules.getNbrl_condition_set());
            //规则条件公式集
            List<NbrlNbrlConditionFormulaSetbEntity> nbrlConditionFormulaSetbEntityList = map.get("nbrlConditionFormulaSetbEntityList");
            if(null != nbrlConditionFormulaSetbEntityList && nbrlConditionFormulaSetbEntityList.size() > 0){
                ormService.insert(nbrlConditionFormulaSetbEntityList);
                //设置条件公式集-获取所有条件公式
                List<NbrlNbrlFormulacEntity> formulacEntityList = setFormualacSet(nbrlConditionFormulaSetbEntityList);
                if(null != formulacEntityList && formulacEntityList.size()>0){
                    ormService.insert(formulacEntityList);
                }
            }
            //规则项集
            List<NbrlNbrlItemSetbEntity> nbrlItemSetbEntityList = map.get("nbrlItemSetbEntityList");
            if(null != nbrlItemSetbEntityList && nbrlItemSetbEntityList.size() > 0){
                ormService.insert(nbrlItemSetbEntityList);
                //设置第四层属性集-时间、文本、参数、流水号、属性集
                Map<String, List> childMap = setFourthSubattributeSet(curentUserName, nbrlItemSetbEntityList);
                //时间集
                List<NbrlNbrlTimeSetcEntity> nbrlTimeSetcEntityList = childMap.get("nbrlTimeSetcEntityList");
                if(null != nbrlTimeSetcEntityList && nbrlTimeSetcEntityList.size() > 0){
                    ormService.insert(nbrlTimeSetcEntityList);
                }
                //文本集
                List<NbrlNbrlTextSetcEntity> nbrlTextSetcEntityList =  childMap.get("nbrlTextSetcEntityList");
                if(null != nbrlTextSetcEntityList && nbrlTextSetcEntityList.size() > 0){
                    ormService.insert(nbrlTextSetcEntityList);
                }
                //流水号集
                List<NbrlNbrlSerialSetcEntity> nbrlSerialSetcEntityList = childMap.get("nbrlSerialSetcEntityList");
                if(null != nbrlSerialSetcEntityList && nbrlSerialSetcEntityList.size() > 0){
                    ormService.insert(nbrlSerialSetcEntityList);
                }
                //参数集
                List<NbrlNbrlParamSetcEntity> nbrlParamSetcEntityList = childMap.get("nbrlParamSetcEntityList");
                if( null != nbrlParamSetcEntityList && nbrlParamSetcEntityList.size() > 0){
                    ormService.insert(nbrlParamSetcEntityList);
                }
                //属性集
                List<NbrlNbrlPropertyTypecEntity> nbrlPropertyTypecEntityList = childMap.get("nbrlPropertyTypecEntityList");
                if(null != nbrlPropertyTypecEntityList && nbrlPropertyTypecEntityList.size()> 0){
                    ormService.insert(nbrlPropertyTypecEntityList);
                }
            }
        }
        return id;
    }

    @Override
    @Transactional(readOnly = false, rollbackFor = Exception.class)
    public int enableOrNot(String id, String currentUserId) throws Exception{
        List<String> columnList = new ArrayList<>(Arrays.asList(NbrlConditionSetConst.NBRL_CONDITION_ORDER,NbrlConditionSetConst.NBRL_IS_USED,NbrlConditionSetConst.NBRL_CURRENT_SERIAL,NbrlConditionSetConst.NBRL_DESC,NbrlConditionSetConst.NBRL_IS_MANUAL_NUMBER,NbrlConditionSetConst.NBRL_CODE_EPSN,NbrlConditionSetConst.NBRL_TAKENO_DATE));
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("id", id));
        ormParam.setWhereExp(whereExp);
        //根据条件查询规则条件
        List<NbrlNbrlConditionSetaEntity> conditionSetaEntityList = ormService.selectBeanList(NbrlNbrlConditionSetaEntity.class,ormParam);
        NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity = null;
        if(null != conditionSetaEntityList && conditionSetaEntityList.size() > 0){
            nbrlConditionSetaEntity = conditionSetaEntityList.get(0);
        }
        if(null == nbrlConditionSetaEntity){
            return 0;
        }
        if(null == nbrlConditionSetaEntity.getNbrl_is_used()||nbrlConditionSetaEntity.getNbrl_is_used().equals(Constants.ENABLE)){
            nbrlConditionSetaEntity.setNbrl_is_used(Constants.DISABLE);
        }else{
            nbrlConditionSetaEntity.setNbrl_is_used(Constants.ENABLE);
        }
        nbrlConditionSetaEntity.setModuser(currentUserId);
        return ormService.updateSelective(nbrlConditionSetaEntity,ormParam);
    }

    /**
     * 根据id查询numberRules
     * @param id  numberRules 的 id
     * @return  返回NumberRulesVO——包含内部的属性集信息
     * @throws Exception 抛出Exception
     */
    @Override
    public NumberRulesVO getNumberRule(String id) throws Exception{
        //设置查询条件
        OrmParam ormParam = new OrmParam();
        List<String> list = Arrays.asList(NumberRulesConst.NBRL_NBRL_CODE,NumberRulesConst.NBRL_NBRL_NAME,NumberRulesConst.NBRL_NBRL_SERIAL_INCREASE);
        List<String> columnList = new ArrayList<>(list);
        setBaseProperties(columnList);
        columnList.remove(columnList.indexOf("pid"));
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("id", id));
        ormParam.setWhereExp(whereExp);
        return getNumberrulesEntity(ormParam);
    }

    private NumberRulesVO getNumberrulesEntity(OrmParam ormParam) throws Exception {
        String pid ;
        List<NumberrulesEntity> numberrulesEntityList = ormService.selectBeanList(NumberrulesEntity.class,ormParam);
        if(null == numberrulesEntityList || numberrulesEntityList.size() == 0){
            return null;
        }
        NumberRulesVO numberRulesVO = new NumberRulesVO();
        NumberrulesEntity numberrulesEntity = numberrulesEntityList.get(0);
        //entity转VO
        EntityConvertVOUtil.assignmentOfTheSameField(numberrulesEntity, numberRulesVO);

        pid = numberrulesEntity.getId();
        //规则条件集
        List<NbrlNbrlConditionSetaEntity> nbrlConditionSetaEntityList = queryNbrlConditionSetListByPid(pid);
        numberRulesVO.setNbrl_condition_set(nbrlConditionSetaEntityList);
        if(null != nbrlConditionSetaEntityList && nbrlConditionSetaEntityList.size() > 0){
            //规则项集合
            List<NbrlNbrlItemSetbEntity> nbrlItemSetbEntityList ;
            //规则条件公式集合
            List<NbrlNbrlConditionFormulaSetbEntity> nbrlConditionFormulaSetbEntityList ;
            //手工编号集
            List<NbrlNbrlManualNumberSetbEntity> nbrlManualNumberSetbEntityList ;
            for(NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : nbrlConditionSetaEntityList){
                nbrlConditionSetaEntity.setNbrl_code_used(new ArrayList<>());
                pid = nbrlConditionSetaEntity.getId();
                nbrlItemSetbEntityList = queryItemSetListByPid(pid);
                nbrlConditionSetaEntity.setNbrl_item_set(nbrlItemSetbEntityList);
                nbrlManualNumberSetbEntityList = queryManualNumberListByPid(pid);
                nbrlConditionSetaEntity.setNbrl_manual_number_set(nbrlManualNumberSetbEntityList);
                nbrlConditionFormulaSetbEntityList = queryConditionFormulaListByPid(pid);
                if(null != nbrlConditionFormulaSetbEntityList){
                    nbrlConditionSetaEntity.setNbrl_condition_formula_set(nbrlConditionFormulaSetbEntityList);
                    //条件公式集
                    List<NbrlNbrlFormulacEntity> formulacEntityList ;
                    for (NbrlNbrlConditionFormulaSetbEntity nbrlNbrlConditionFormulaSetbEntity : nbrlConditionFormulaSetbEntityList) {
                        pid = nbrlNbrlConditionFormulaSetbEntity.getId();
                        formulacEntityList = queryFormulacListByPid(pid);
                        nbrlNbrlConditionFormulaSetbEntity.setNbrl_formula(formulacEntityList);
                    }
                }
                if(null != nbrlItemSetbEntityList && nbrlItemSetbEntityList.size() > 0){
                    //时间集
                    List<NbrlNbrlTimeSetcEntity> nbrlTimeSetcEntityList ;
                    //文本集
                    List<NbrlNbrlTextSetcEntity> nbrlTextSetcEntityList ;
                    //流水号集
                    List<NbrlNbrlSerialSetcEntity> nbrlSerialSetcEntityList ;
                    //参数集
                    List<NbrlNbrlParamSetcEntity> nbrlParamSetcEntityList ;
                    //属性集
                    List<NbrlNbrlPropertyTypecEntity> nbrlPropertyTypecEntityList ;
                    for(NbrlNbrlItemSetbEntity nbrlItemSetbEntity: nbrlItemSetbEntityList){
                        pid = nbrlItemSetbEntity.getId();
                        nbrlTimeSetcEntityList = queryTimeSetListByPid(pid);
                        nbrlTextSetcEntityList = queryTextSetListByPid(pid);
                        nbrlSerialSetcEntityList = querySerialSetListByPid(pid);
                        nbrlParamSetcEntityList = queryParamSetListByPid(pid);
                        nbrlPropertyTypecEntityList = queryPropertyTypeListByPid(pid);
                        nbrlItemSetbEntity.setNbrl_time_set(nbrlTimeSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_text_set(nbrlTextSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_serial_set(nbrlSerialSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_param_set(nbrlParamSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_property_type(nbrlPropertyTypecEntityList);
                    }
                }
            }
        }
        return numberRulesVO;
    }

    private List<NbrlItemSetVO> setItemAttributeSets(List<NbrlNbrlItemSetbEntity> nbrlItemSetbEntityList) throws Exception {
        List<NbrlItemSetVO> itemSetVOList = new ArrayList<>(nbrlItemSetbEntityList.size());
        for(NbrlNbrlItemSetbEntity nbrlItemSetbEntity: nbrlItemSetbEntityList){
            NbrlItemSetVO itemSetVO = new NbrlItemSetVO();
            EntityConvertVOUtil.assignmentOfTheSameField(nbrlItemSetbEntity,itemSetVO);
            if(null != nbrlItemSetbEntity.getNbrl_time_set() && nbrlItemSetbEntity.getNbrl_time_set().size()>0){
                timeEntity2TimeVO(itemSetVOList, itemSetVO);
            }
            if(null != nbrlItemSetbEntity.getNbrl_text_set() && nbrlItemSetbEntity.getNbrl_text_set().size()>0){
                textEntity2textVO(itemSetVOList, itemSetVO);
            }
            if(null != nbrlItemSetbEntity.getNbrl_serial_set() && nbrlItemSetbEntity.getNbrl_serial_set().size()>0){
                serialEntity2serialVO(itemSetVOList, itemSetVO);
            }
            if(null != nbrlItemSetbEntity.getNbrl_param_set() && nbrlItemSetbEntity.getNbrl_param_set().size()>0){
                paramEntity2paramVO(itemSetVOList, itemSetVO);
            }
            if(null != nbrlItemSetbEntity.getNbrl_property_type() && nbrlItemSetbEntity.getNbrl_property_type().size()>0){
                propertyEntity2propertyVO(itemSetVOList, itemSetVO);
            }
        }
        return itemSetVOList;
    }

    private void propertyEntity2propertyVO(List<NbrlItemSetVO> itemSetVOList, NbrlItemSetVO itemSetVO) throws Exception {
        List<NbrlNbrlPropertyTypecEntity> nbrlPropertyTypecEntityList;
        nbrlPropertyTypecEntityList = queryPropertyTypeListByPid(itemSetVO.getId());
        List<NbrlPropertyVO> propertyVOS = new ArrayList<>(nbrlPropertyTypecEntityList.size());
        for (NbrlNbrlPropertyTypecEntity propertyTypecEntity : nbrlPropertyTypecEntityList) {
            NbrlPropertyVO propertyVO = new NbrlPropertyVO();
            EntityConvertVOUtil.assignmentOfTheSameField(propertyTypecEntity, propertyVO);
//            propertyVO.setModUserName(Utils.getUserNameByUserId(propertyVO.getModuser(),ormService));
            propertyVOS.add(propertyVO);
        }
        itemSetVO.setNbrl_property_type(propertyVOS);
        itemSetVOList.add(itemSetVO);
    }

    private void paramEntity2paramVO(List<NbrlItemSetVO> itemSetVOList, NbrlItemSetVO itemSetVO) throws Exception {
        List<NbrlNbrlParamSetcEntity> nbrlParamSetcEntityList;
        nbrlParamSetcEntityList =  queryParamSetListByPid(itemSetVO.getId());
        List<NbrlParamVO> paramVOS = new ArrayList<>(nbrlParamSetcEntityList.size());
        for (NbrlNbrlParamSetcEntity paramSetcEntity : nbrlParamSetcEntityList) {
            NbrlParamVO paramVO = new NbrlParamVO();
            EntityConvertVOUtil.assignmentOfTheSameField(paramSetcEntity, paramVO);
//            paramVO.setModUserName(Utils.getUserNameByUserId(paramVO.getModuser(),ormService));
            paramVOS.add(paramVO);
        }
        itemSetVO.setNbrl_param_set(paramVOS);
        itemSetVOList.add(itemSetVO);
    }

    /**
     * serialEntity转serialVO
     * @param itemSetVOList 将全部ItemEntity转为ItemVO的集合
     * @param itemSetVO 将itemEntity数据复制到itemSetVo
     * @throws Exception 异常处理
     */
    private void serialEntity2serialVO(List<NbrlItemSetVO> itemSetVOList, NbrlItemSetVO itemSetVO) throws Exception {
        List<NbrlNbrlSerialSetcEntity> nbrlSerialSetcEntityList;
        nbrlSerialSetcEntityList = querySerialSetListByPid(itemSetVO.getId());
        List<NbrlSerialVO> serialVOS = new ArrayList<>(nbrlSerialSetcEntityList.size());
        for (NbrlNbrlSerialSetcEntity serialSetcEntity : nbrlSerialSetcEntityList) {
            NbrlSerialVO serialVO = new NbrlSerialVO();
            EntityConvertVOUtil.assignmentOfTheSameField(serialSetcEntity,serialVO);
//            serialVO.setModUserName(Utils.getUserNameByUserId(serialVO.getModuser(),ormService));
            serialVOS.add(serialVO);
        }
        itemSetVO.setNbrl_serial_set(serialVOS);
        itemSetVOList.add(itemSetVO);
    }

    /**
     * textEntity转textVO
     * @param itemSetVOList 将全部ItemEntity转为ItemVO的集合
     * @param itemSetVO 将itemEntity数据复制到itemSetVo
     * @throws Exception 异常处理
     */
    private void textEntity2textVO(List<NbrlItemSetVO> itemSetVOList,  NbrlItemSetVO itemSetVO) throws Exception {
        List<NbrlNbrlTextSetcEntity> nbrlTextSetcEntityList;
        nbrlTextSetcEntityList = queryTextSetListByPid(itemSetVO.getId());
        List<NbrlTextVO> textVOS = new ArrayList<>(nbrlTextSetcEntityList.size());
        for (NbrlNbrlTextSetcEntity textSetcEntity : nbrlTextSetcEntityList) {
            NbrlTextVO textVO = new NbrlTextVO();
            EntityConvertVOUtil.assignmentOfTheSameField(textSetcEntity,textVO);
//            textVO.setModUserName(Utils.getUserNameByUserId(textVO.getModuser(),ormService));
            textVOS.add(textVO);
        }
        itemSetVO.setNbrl_text_set(textVOS);
        itemSetVOList.add(itemSetVO);
    }

    /**
     * timeEntity转TimeVO
     * @param itemSetVOList 将全部ItemEntity转为ItemVO的集合
     * @param itemSetVO 将itemEntity数据复制到itemSetVo
     * @throws Exception 异常处理
     */
    private void timeEntity2TimeVO(List<NbrlItemSetVO> itemSetVOList,  NbrlItemSetVO itemSetVO) throws Exception {
        List<NbrlNbrlTimeSetcEntity> nbrlTimeSetcEntityList = queryTimeSetListByPid(itemSetVO.getId());
        //创建timeVOList
        List<NbrlTimeVO> timeVOS = new ArrayList<>(nbrlTimeSetcEntityList.size());
        for (NbrlNbrlTimeSetcEntity timeSetcEntity : nbrlTimeSetcEntityList) {
            NbrlTimeVO timeVO = new NbrlTimeVO();
            EntityConvertVOUtil.assignmentOfTheSameField(timeSetcEntity,timeVO);
//            timeVO.setModUserName(Utils.getUserNameByUserId(timeVO.getModuser(),ormService));
            timeVOS.add(timeVO);
        }
        itemSetVO.setNbrl_time_set(timeVOS);
        itemSetVOList.add(itemSetVO);
    }

    /**
     * 查询编号使用情况
     * @param nbrlCode 规则代码
     * @return  返回分页数据集合
     * @throws Exception 抛出异常
     */
    @Override
    public Pagination<NbrlNbrlCodeUsedbEntity> queryCodeUsed(String nbrlCode,String nbrlCuCode, int pageNum, int pageSize)throws Exception{
        OrmParam ormParam = new OrmParam();
        List<String> strlist = Arrays.asList("id","nbrl_code","nbrl_name");
        List<String> columnList = new ArrayList<>(strlist);
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("nbrl_code", nbrlCode));
        ormParam.setWhereExp(whereExp);
        //根据nbrlCode查询 编号规则
        List<NumberrulesEntity> numberrulesEntityList = ormService.selectBeanList(NumberrulesEntity.class,ormParam);
        //编号使用集
        Pagination<NbrlNbrlCodeUsedbEntity> pagination = null;
        if(null != numberrulesEntityList && numberrulesEntityList.size()>0){
            String numberrulesEntityId = numberrulesEntityList.get(0).getId();
            List<String> list = Arrays.asList(NbrlConditionSetConst.NBRL_CONDITION_ORDER,NbrlConditionSetConst.NBRL_IS_USED,NbrlConditionSetConst.NBRL_CURRENT_SERIAL,NbrlConditionSetConst.NBRL_DESC,NbrlConditionSetConst.NBRL_IS_MANUAL_NUMBER,NbrlConditionSetConst.NBRL_CODE_EPSN,NbrlConditionSetConst.NBRL_TAKENO_DATE);
            List<String> comditionColumnList = new ArrayList<>(list);
            setBaseProperties(columnList);
            OrmParam ormParam1 = setQueryConditionByPid(comditionColumnList,numberrulesEntityId);
            //根据pid查询规则条件集
            List<NbrlNbrlConditionSetaEntity> conditionSetaEntityList = ormService.selectBeanList(NbrlNbrlConditionSetaEntity.class,ormParam1);
            if(null != conditionSetaEntityList && conditionSetaEntityList.size()>0){
                String[] pids = new String[conditionSetaEntityList.size()];
                for (int i=0;i<conditionSetaEntityList.size();i++){
                    pids[i] = conditionSetaEntityList.get(i).getId();
                }
                OrmParam ormParam2 = new OrmParam();
                List<String> columnList2 = new ArrayList<>(Arrays.asList("id","pid","nbrl_cu_code","nbrl_cu_desc","moduser","creuser","cretime","modtime"));
                // 设置查询条件
                ormParam2.setColumns(columnList2);
                List<String> params = new ArrayList<>();
                //模糊查询nbrl_cu_code
                params.add(ormParam2.getMatchMiddleXML("nbrl_cu_code",nbrlCuCode));
                //pid in pids
                params.add(ormParam2.getInXML("pid",pids));
                String whereExp1 = OrmParam.and(params);
                ormParam2.setWhereExp(whereExp1);
                ormParam2.setPageNo(pageNum);
                ormParam2.setPageSize(pageSize);
                pagination  = ormService.selectPagedBeanList(NbrlNbrlCodeUsedbEntity.class, ormParam2);
            }
        }
        return pagination;
    }

    /**
     * 规则编号修改
     * @param numberrulesEntity——修改之后的实体
     */
    @Override
    @Transactional
    public Result update(String curentUserId, NumberrulesEntity numberrulesEntity,String token, String authorization) throws Exception{
        String id = numberrulesEntity.getId();
        Result result = new Result();
        String errMsg = "";
        //查询数据库中保存的实体
        NumberRulesVO numberrulesDB = getNumberRule(numberrulesEntity.getId());
        //规则代码重复校验
        if(!numberrulesEntity.getNbrl_code().equals(numberrulesDB.getNbrl_code())){
            boolean codeExisted = isCodeExisted(numberrulesEntity.getNbrl_code());
            if(codeExisted){
                errMsg = "规则代码已被使用";
            }
        }
        //规则名称重复校验
        if(!numberrulesEntity.getNbrl_name().equals(numberrulesDB.getNbrl_name())){
            boolean nameExisted = isNameExisted(numberrulesEntity.getNbrl_name());
            if(nameExisted){
                errMsg = "规则名称已被使用";
            }
        }
        if(!"".equals(errMsg)){
            result.setErrMsg(errMsg);
            result.setRetCode(Result.RECODE_ERROR);
            return result;
        }

        if(!equalsObject(numberrulesEntity, numberrulesDB)){
            numberrulesEntity.setModuser(curentUserId);
            ormService.updateSelective(numberrulesEntity);
        }
        if(null != numberrulesEntity.getNbrl_condition_set() && numberrulesEntity.getNbrl_condition_set().size()> 0){
            EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class, numberrulesEntity, numberrulesEntity.getNbrl_condition_set(), SQLCurdEnum.INSERT);
        }
        Map<String, List> conditionSetMp = toOperateList(numberrulesEntity.getNbrl_condition_set(), numberrulesDB.getNbrl_condition_set());
        //对规则条件集的操作
        updateEntity(curentUserId, conditionSetMp);
        //对规则条件集的属性集的操作
        updateConditionAttributeSet(curentUserId, numberrulesEntity, numberrulesDB.getNbrl_condition_set());
        //对最底层属性集的操作
        Map<String ,List> entityMap = setChildrenAttributeSetPid(curentUserId, numberrulesEntity.getNbrl_condition_set());
        Map<String ,List> DBMap = setChildrenAttributeSetPid(curentUserId, numberrulesDB.getNbrl_condition_set());
        updateChildrenAttributeSet(curentUserId, entityMap,DBMap);
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(id);
        //添加手工编号
        if (!StringUtil.isNullOrEmpty(token)) {
            nbrlManualNumberSetService.redisSynchronizeToMysql(token, authorization);
        }

        return result;
    }

    /**
     * 设置公式集的pid，并返回
     * @param conditionSetaEntityList 规则条件集
     * @return  返回map——包含最底层的待修改数据集合
     * @param curentUserId 当前登录用户id
     * @throws Exception 抛出异常
     */
    private Map<String,List> setChildrenAttributeSetPid(String curentUserId,List<NbrlNbrlConditionSetaEntity> conditionSetaEntityList)throws Exception{
        List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbEntityList = new ArrayList<>();
        List<NbrlNbrlItemSetbEntity> itemSetbEntityList = new ArrayList<>();

        List<NbrlNbrlFormulacEntity> formulacEntityList = new ArrayList<>();
        List<NbrlNbrlTimeSetcEntity> timeSetcEntityList = new ArrayList<>();
        List<NbrlNbrlTextSetcEntity> textSetcEntityList = new ArrayList<>();
        List<NbrlNbrlSerialSetcEntity> serialSetcEntityList = new ArrayList<>();
        List<NbrlNbrlPropertyTypecEntity> propertyTypecEntityList = new ArrayList<>();
        List<NbrlNbrlParamSetcEntity> paramSetcEntityList = new ArrayList<>();
        if(null != conditionSetaEntityList && conditionSetaEntityList.size() >0){
            for (NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : conditionSetaEntityList) {
                List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbEntitys = nbrlConditionSetaEntity.getNbrl_condition_formula_set();
                if(null != conditionFormulaSetbEntitys && conditionFormulaSetbEntitys.size() > 0){
                    conditionFormulaSetbEntityList.addAll(conditionFormulaSetbEntitys);
                }
                List<NbrlNbrlItemSetbEntity> itemSetbEntities = nbrlConditionSetaEntity.getNbrl_item_set();
                if(null != itemSetbEntities&& itemSetbEntities.size() > 0){
                    itemSetbEntityList.addAll(itemSetbEntities);
                }
            }
            if (conditionFormulaSetbEntityList.size() > 0){
                for (NbrlNbrlConditionFormulaSetbEntity nbrlNbrlConditionFormulaSetbEntity : conditionFormulaSetbEntityList) {
                    List<NbrlNbrlFormulacEntity> formulacEntits = nbrlNbrlConditionFormulaSetbEntity.getNbrl_formula();
                    if(null != formulacEntits && formulacEntits.size() >0){
                        EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class, nbrlNbrlConditionFormulaSetbEntity, formulacEntits, SQLCurdEnum.INSERT);
                        for (NbrlNbrlFormulacEntity formulacEntit : formulacEntits) {
                            formulacEntit.setModuser(curentUserId);
                        }
                        formulacEntityList.addAll(formulacEntits);
                    }
                }
            }
            if(itemSetbEntityList.size() >0){
                for (NbrlNbrlItemSetbEntity nbrlNbrlItemSetbEntity : itemSetbEntityList) {
                    List<NbrlNbrlTimeSetcEntity> timeSetcEntitys = nbrlNbrlItemSetbEntity.getNbrl_time_set();
                    List<NbrlNbrlTextSetcEntity> textSetcEntitys = nbrlNbrlItemSetbEntity.getNbrl_text_set();
                    List<NbrlNbrlSerialSetcEntity> serialSetcEntitys = nbrlNbrlItemSetbEntity.getNbrl_serial_set();
                    List<NbrlNbrlPropertyTypecEntity> propertyTypecEntitys = nbrlNbrlItemSetbEntity.getNbrl_property_type();
                    List<NbrlNbrlParamSetcEntity> paramSetcEntitys = nbrlNbrlItemSetbEntity.getNbrl_param_set();
                    if(null != timeSetcEntitys && timeSetcEntitys.size() > 0){
                        EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class, nbrlNbrlItemSetbEntity, timeSetcEntitys, SQLCurdEnum.INSERT);
                        timeSetcEntityList.addAll(timeSetcEntitys);
                    }
                    if(null != textSetcEntitys && textSetcEntitys.size() > 0){
                        EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class, nbrlNbrlItemSetbEntity, textSetcEntitys, SQLCurdEnum.INSERT);
                        textSetcEntityList.addAll(textSetcEntitys);
                    }
                    if(null != serialSetcEntitys && serialSetcEntitys.size() > 0){
                        EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class, nbrlNbrlItemSetbEntity, serialSetcEntitys, SQLCurdEnum.INSERT);
                        serialSetcEntityList.addAll(serialSetcEntitys);
                    }
                    if(null != propertyTypecEntitys && propertyTypecEntitys.size() > 0){
                        EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class, nbrlNbrlItemSetbEntity, propertyTypecEntitys, SQLCurdEnum.INSERT);
                        propertyTypecEntityList.addAll(propertyTypecEntitys);
                    }
                    if(null != paramSetcEntitys && paramSetcEntitys.size() > 0){
                        EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class, nbrlNbrlItemSetbEntity, paramSetcEntitys, SQLCurdEnum.INSERT);
                        paramSetcEntityList.addAll(paramSetcEntitys);
                    }
                }
            }
        }
        Map<String, List> map = new HashMap<>();
        map.put(FORMULAC_ENTITY_LIST, formulacEntityList);
        map.put(TIMESTEC_ENTITY_LIST, timeSetcEntityList);
        map.put(TEXTSETC_ENTITY_LIST, textSetcEntityList);
        map.put(SERIALSETC_ENTITY_LIST, serialSetcEntityList);
        map.put(PROPERTY_TYPEC_ENTITY_LIST, propertyTypecEntityList);
        map.put(PARAMSETC_ENTITY_LIST, paramSetcEntityList);
        return map;
    }

    /**
     * 最底层属性集的数据操作
     * @param entityMap 前端传参
     * @param DBMap 数据库存储数据
     * @param curentUserid 当前登录用户id
     * @throws Exception 抛出异常
     */
    @SuppressWarnings("unchecked")
    private void updateChildrenAttributeSet(String curentUserid, Map<String ,List> entityMap, Map<String, List> DBMap)throws Exception{
        List<NbrlNbrlFormulacEntity> formulacEntityList = (List<NbrlNbrlFormulacEntity>)entityMap.get(FORMULAC_ENTITY_LIST);
        List<NbrlNbrlFormulacEntity> formulacDBList = (List<NbrlNbrlFormulacEntity>)DBMap.get(FORMULAC_ENTITY_LIST);
        Map formulacSetMap = toOperateList(formulacEntityList, formulacDBList);
        updateEntity(curentUserid, formulacSetMap);

        List<NbrlNbrlTimeSetcEntity> timeEntityList = entityMap.get(TIMESTEC_ENTITY_LIST);
        List<NbrlNbrlTimeSetcEntity> timeDBList = DBMap.get(TIMESTEC_ENTITY_LIST);
        Map<String ,List> timeSetMap = toOperateList(timeEntityList,timeDBList);
        updateEntity(curentUserid, timeSetMap);

        List<NbrlNbrlTextSetcEntity> textEnttityList = entityMap.get(TEXTSETC_ENTITY_LIST);
        List<NbrlNbrlTextSetcEntity> textDBList = DBMap.get(TEXTSETC_ENTITY_LIST);
        Map<String ,List> textSetMap = toOperateList(textEnttityList,textDBList);
        updateEntity(curentUserid, textSetMap);

        List<NbrlNbrlSerialSetcEntity> serialEntityList = entityMap.get(SERIALSETC_ENTITY_LIST);
        List<NbrlNbrlSerialSetcEntity> serialDBList = DBMap.get(SERIALSETC_ENTITY_LIST);
        Map<String ,List> serialSetMap = toOperateList(serialEntityList,serialDBList);
        updateEntity(curentUserid, serialSetMap);

        List<NbrlNbrlPropertyTypecEntity> propertyEntityList = entityMap.get(PROPERTY_TYPEC_ENTITY_LIST);
        List<NbrlNbrlPropertyTypecEntity> propertyDBList = DBMap.get(PROPERTY_TYPEC_ENTITY_LIST);
        Map<String ,List> propertySetMap = toOperateList(propertyEntityList,propertyDBList);
        updateEntity(curentUserid, propertySetMap);

        List<NbrlNbrlParamSetcEntity> paramEntityList = entityMap.get(PARAMSETC_ENTITY_LIST);
        List<NbrlNbrlParamSetcEntity> paramDBList = DBMap.get(PARAMSETC_ENTITY_LIST);
        Map<String ,List> paramSetMap = toOperateList(paramEntityList,paramDBList);
        updateEntity(curentUserid, paramSetMap);
    }

    /**
     * 对规则条件集的属性集的操作
     * @param numberrulesEntity 前端传送参数—更新数据
     * @param conditionSetaDBList  数据库保存的NbrlNbrlConditionSetaEntity集合
     * @param curentUserid 当前登录用户id
     * @throws Exception 抛出异常
     */
    @SuppressWarnings("unchecked")
    private void updateConditionAttributeSet(String curentUserid, NumberrulesEntity numberrulesEntity, List<NbrlNbrlConditionSetaEntity> conditionSetaDBList)throws Exception{
        List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbEntityList = null;
        List<NbrlNbrlItemSetbEntity> itemSetbEntityList = null;
        List<NbrlNbrlCodeUsedbEntity> codeUsedbEntityList = null;
        List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbDBList = null;
        List<NbrlNbrlItemSetbEntity> itemSetbDBList = null;
        List<NbrlNbrlCodeUsedbEntity> codeUsedbDBList = null;
        if(null != numberrulesEntity.getNbrl_condition_set() && numberrulesEntity.getNbrl_condition_set().size()> 0){
            Map<String ,List> attributeEntityMap = setConditionAttributeSetPid(numberrulesEntity.getNbrl_condition_set());
            conditionFormulaSetbEntityList = attributeEntityMap.get(CONDITION_FORMULASETB_ENTITY_LIST);
            itemSetbEntityList = attributeEntityMap.get(ITEMSETB_ENTITY_LIST);
            codeUsedbEntityList = attributeEntityMap.get(CODEUSEDB_ENTITY_LIST);
        }
        if(null != conditionSetaDBList && conditionSetaDBList.size() > 0){
            Map<String ,List> attributeDBMap = setConditionAttributeSetPid(conditionSetaDBList);
            conditionFormulaSetbDBList = attributeDBMap.get(CONDITION_FORMULASETB_ENTITY_LIST);
            itemSetbDBList = attributeDBMap.get(ITEMSETB_ENTITY_LIST);
            codeUsedbDBList = attributeDBMap.get(CODEUSEDB_ENTITY_LIST);
        }
        Map<String, List> conditionFormulaMap = toOperateList(conditionFormulaSetbEntityList, conditionFormulaSetbDBList);
        updateEntity(curentUserid, conditionFormulaMap);
        Map<String, List> itemMap = toOperateList(itemSetbEntityList, itemSetbDBList);
        updateEntity(curentUserid, itemMap);
        Map<String, List> codeUsedMap = toOperateList(codeUsedbEntityList, codeUsedbDBList);
        updateEntity(curentUserid, codeUsedMap);

    }

    /**
     * 设置规则条件集的属性集的pid，并返回所有待操作的对象集合
     * @param list 规则条件集
     * @return  返回map—包含规则条件集的属性集
     * @throws Exception 抛出异常
     */
    private Map<String, List> setConditionAttributeSetPid(List<NbrlNbrlConditionSetaEntity> list) throws Exception{
        Map<String, List> map = new HashMap<>();
        List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbEntityList = new ArrayList<>();
        List<NbrlNbrlItemSetbEntity> itemSetbEntityList = new ArrayList<>();
        List<NbrlNbrlCodeUsedbEntity> codeUsedbEntityList = new ArrayList<>();
        for (NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : list) {
            List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbEntitys = nbrlConditionSetaEntity.getNbrl_condition_formula_set();
            if(null != conditionFormulaSetbEntitys && conditionFormulaSetbEntitys.size()>0){
                EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlConditionSetaEntity,conditionFormulaSetbEntitys,SQLCurdEnum.INSERT);
                conditionFormulaSetbEntityList.addAll(conditionFormulaSetbEntitys);
            }
            List<NbrlNbrlItemSetbEntity> itemSetbEntities = nbrlConditionSetaEntity.getNbrl_item_set();
            if(null != itemSetbEntities && itemSetbEntities.size() > 0){
                EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlConditionSetaEntity,itemSetbEntities,SQLCurdEnum.INSERT);
                itemSetbEntityList.addAll(itemSetbEntities);
            }
            List<NbrlNbrlCodeUsedbEntity> codeUsedbEntities = nbrlConditionSetaEntity.getNbrl_code_used();
            if(null != codeUsedbEntities && codeUsedbEntities.size() > 0){
                EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlConditionSetaEntity,codeUsedbEntities,SQLCurdEnum.INSERT);
                codeUsedbEntityList.addAll(codeUsedbEntities);
            }
        }
        map.put(CONDITION_FORMULASETB_ENTITY_LIST,conditionFormulaSetbEntityList);
        map.put(ITEMSETB_ENTITY_LIST,itemSetbEntityList);
        map.put(CODEUSEDB_ENTITY_LIST,codeUsedbEntityList);
        return map;
    }


    /**
     * 添加、修改、删除
     * @param map 封装待操作（增删改）的数据
     * @throws Exception 抛出异常
     */
    @SuppressWarnings("unchecked")
    private void updateEntity(String curentUserid,Map<String, List> map) throws Exception{
        if(null != map.get(TO_ADD_LIST) && map.get(TO_ADD_LIST).size()>0){
            List<BaseEntity> addList = (List<BaseEntity>)map.get(TO_ADD_LIST);
            for (BaseEntity baseEntity : addList) {
                baseEntity.setCreuser(curentUserid);
                baseEntity.setModuser(curentUserid);
            }
            ormService.insert(addList);
        }
        if(null != map.get(TO_DELETE_LIST)&& map.get(TO_DELETE_LIST).size()>0){
            String[] ids = new String[map.get(TO_DELETE_LIST).size()];
            List<? extends BaseEntity> list = (List<? extends BaseEntity>)map.get(TO_DELETE_LIST);
            for(int i=0; i<list.size(); i++){
                list.get(i).setModuser(curentUserid);
                ids[i] = list.get(i).getId();
            }
            OrmParam ormParam1 = new OrmParam();
            String whereExp1 = OrmParam.and(ormParam1.getInXML("id",ids));
            ormParam1.setWhereExp(whereExp1);
            ormService.delete(list.get(0).getClass(), ormParam1);
        }
        if(null != map.get(TO_UPDATE_LIST)&& map.get(TO_UPDATE_LIST).size()>0){
            List<BaseEntity> updateList = (List<BaseEntity>)map.get(TO_UPDATE_LIST);
            for (BaseEntity baseEntity : updateList) {
                baseEntity.setModuser(curentUserid);
                ormService.update(baseEntity);
            }
        }
    }

    /**
     * 处理集合，判断集合中数据的增删改
     * @param entityList 前端参数
     * @param DBList    数据库中存储数据
     * @return 返回map—封装待操作（增删改）的属性集
     * @throws Exception 抛出异常
     */
    private Map<String ,List> toOperateList(List<? extends BaseEntity> entityList, List<? extends BaseEntity> DBList)throws Exception{
        Map<String ,List> map = new HashMap<>();
        //numberrulesDB中存在属性集Nbrl_use_set
        if(null != DBList && DBList.size()>0){
            //entityList为空则删除,不为空则比较两个属性集
            if(null != entityList && entityList.size() > 0){
                map = equalsList(entityList, DBList);
            }else{
                map.put(TO_DELETE_LIST,DBList);
            }
        }else{
            if(null != entityList && entityList.size()>0){
                map.put(TO_ADD_LIST,entityList);
            }
        }
        return map;
    }

    /**
     * 比较两个对象是否相等
     * @param obj1  前端传参
     * @param obj2  数据库存储参数
     * @return 两个实体相同则返回true
     * @throws Exception 抛出异常
     */
    private  boolean equalsObject(Object obj1,Object obj2)throws Exception{
        Class clazz1 = obj1.getClass();
        Class clazz2 = obj2.getClass();
        Method[] m1 = clazz1.getDeclaredMethods();

        Method[] m2 = clazz2.getDeclaredMethods();
        for (Method method : m1) {
            if(method.getName().startsWith(METHOD_TYPE_GET)){
                for (Method method2 : m2) {
                    if(method2.getName().startsWith(METHOD_TYPE_GET)){
                        if(method2.invoke(obj2) instanceof List&&(method.invoke(obj1) instanceof List)){
                            break;
                        }
                        if(method.getName().equals(method2.getName())){
                            if(null != method.invoke(obj1)&&null != method2.invoke(obj2)){
                                if(method.invoke(obj1).equals(method2.invoke(obj2))){
                                    break;
                                }else {
                                    return false;
                                }
                            }else if (null == method.invoke(obj1)&&null == method2.invoke(obj2)){
                                break;
                            }else if((null == method.invoke(obj1)&&null != method2.invoke(obj2))||
                                    (null != method.invoke(obj1)&&null == method2.invoke(obj2))){
                                return false;
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    /**
     * 比较两个集合，返回不同部分，相同则返回null'
     * @param list1     前端传参
     * @param list2     数据库存储数据
     * @return 返回map—封装待操作的属性集
     * @throws Exception 抛出异常
     */
    private Map<String, List> equalsList(List<? extends BaseEntity> list1, List<? extends BaseEntity> list2)throws Exception{
        Map<String, List> map = new HashMap();
        List<Object> toAddList = new ArrayList<>();
        List<Object> toUpdateList = new ArrayList<>();
        List<Object> toDeleteList = new ArrayList<>();
        boolean flag ;
        for (Object obj2 : list2) {
            flag = false;
            for (Object obj1 : list1) {
                //id相同
                if(equalsID(obj1,obj2)){
                    //实体不同
                    if(!equalsObject(obj1,obj2)){
                        toUpdateList.add(obj1);
                    }
                    flag = true;
                    break;
                }
            }
            if(!flag){
                toDeleteList.add(obj2);
            }
        }
        boolean toAdd ;
        for (Object obj1 : list1) {
            toAdd = false;
            for (Object obj2 : list2) {
                //id相同
                if(equalsID(obj1,obj2)){
                    toAdd = true;
                    break;
                }
            }
            if(!toAdd){
                toAddList.add(obj1);
            }
        }
        map.put(TO_ADD_LIST,toAddList);
        map.put(TO_UPDATE_LIST,toUpdateList);
        map.put(TO_DELETE_LIST,toDeleteList);
        return map;
    }

    /**
     * 比较两个对象id是否相等
     * @param obj1  前端传参
     * @param obj2  数据库存储数据
     * @return  两实体id相同返回true
     * @throws Exception 抛出异常
     */
    private boolean equalsID(Object obj1,Object obj2)throws Exception{
        Class clazz1 = obj1.getClass();
        Class clazz2 = obj2.getClass();
        Method[] methodsF1 = clazz1.getMethods();
        Method[] methodsF2 = clazz2.getMethods();
        for (Method method : methodsF1) {
            if(method.getName().startsWith(METHOD_NAME_GETID)){
                for (Method method1 : methodsF2) {
                    if(method1.getName().startsWith(METHOD_NAME_GETID)){
                        return null!= method.invoke(obj1) && "" != method.invoke(obj1)&&method.invoke(obj1).equals(method1.invoke(obj2));
                    }
                }
            }
        }
        return false;
    }

    @Override
    public boolean isCodeExisted(String nbrlCode)throws Exception{
        OrmParam ormParam = new OrmParam();
        List<String> columnList = new ArrayList<>(Arrays.asList("id","nbrl_code","nbrl_name","nbrl_serial_increase","is_del"));
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("nbrl_code", nbrlCode));
        ormParam.setWhereExp(whereExp);
        List<NumberrulesEntity> numberrulesEntityList = ormService.selectBeanList(NumberrulesEntity.class,ormParam);
        return null!= numberrulesEntityList && numberrulesEntityList.size()>0;
    }

    @Override
    public boolean isNameExisted(String nbrlName) throws Exception{
        OrmParam ormParam = new OrmParam();
        List<String> columnList = new ArrayList<>(Arrays.asList("id","nbrl_code","nbrl_name","nbrl_serial_increase","is_del"));
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("nbrl_name", nbrlName));
        ormParam.setWhereExp(whereExp);
        List<NumberrulesEntity> numberrulesEntityList = ormService.selectBeanList(NumberrulesEntity.class,ormParam);
        //numberrulesEntity不存在返回false
        return null != numberrulesEntityList && numberrulesEntityList.size() >0;
    }

    /**
     * 设置新增对象（NumberRulesEntity）的属性集的属性集
     * @param nbrlConditionSetList 前端参数中的NbrlNbrlConditionSetaEntity集合
     * @param curentUserName 当前登录用户名
     * @throws Exception 抛出异常
     */
    private Map<String, List> setThirdSubattributeSet(String curentUserName, List<NbrlNbrlConditionSetaEntity> nbrlConditionSetList) throws Exception{
        Map<String, List> map = new HashMap<>();
        //规则条件公式集
        List<NbrlNbrlConditionFormulaSetbEntity> nbrlConditionFormulaSetbEntityList = new ArrayList<>();
        //规则项集
        List<NbrlNbrlItemSetbEntity> nbrlItemSetbEntityList = new ArrayList<>();
        for(NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity: nbrlConditionSetList){
            List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaList = nbrlConditionSetaEntity.getNbrl_condition_formula_set();
            if(null != conditionFormulaList && conditionFormulaList.size() > 0){
                //setPropertyBaseEntitiesSysColumns  根据操作的模式为属性集添加上属性集特有的系统信息 pid classname creuser moduser
                EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlConditionSetaEntity, conditionFormulaList, SQLCurdEnum.INSERT);
                setPublicProperties(curentUserName, conditionFormulaList);
                nbrlConditionFormulaSetbEntityList.addAll(conditionFormulaList);
            }
            List<NbrlNbrlItemSetbEntity> itemList = nbrlConditionSetaEntity.getNbrl_item_set();
            //未使用手工编号、itemList!=null
            if(nbrlConditionSetaEntity.getNbrl_is_manual_number().equals(Constants.UNUSE) && null != itemList && itemList.size() > 0){
                setPublicProperties(curentUserName, itemList);
                EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlConditionSetaEntity, itemList, SQLCurdEnum.INSERT);
                nbrlItemSetbEntityList.addAll(itemList);
            }
        }
        map.put("nbrlConditionFormulaSetbEntityList", nbrlConditionFormulaSetbEntityList);
        map.put("nbrlItemSetbEntityList", nbrlItemSetbEntityList);
        return map;
    }

    /**
     * 设置新增对象（NumberRulesEntity）第四层的属性集
     * @param itemSetbEntityList 前端参数中NbrlNbrlItemSetbEntity集合
     * @throws Exception 抛出异常
     */
    @SuppressWarnings("unchecked")
    private Map<String, List> setFourthSubattributeSet(String curentUserid, List<NbrlNbrlItemSetbEntity> itemSetbEntityList) throws Exception{
        Map<String ,List>  map = new HashMap<>();
        //时间集
        List<NbrlNbrlTimeSetcEntity> nbrlTimeSetcEntityList = new ArrayList<>();
        //文本集
        List<NbrlNbrlTextSetcEntity> nbrlTextSetcEntityList = new ArrayList<>();
        //流水号集
        List<NbrlNbrlSerialSetcEntity> nbrlSerialSetcEntityList = new ArrayList<>();
        //参数集
        List<NbrlNbrlParamSetcEntity> nbrlParamSetcEntityList = new ArrayList<>();
        //属性集
        List<NbrlNbrlPropertyTypecEntity> nbrlPropertyTypecEntityList = new ArrayList<>();
        if(null != itemSetbEntityList && itemSetbEntityList.size() > 0){
            for (NbrlNbrlItemSetbEntity nbrlNbrlItemSetbEntity : itemSetbEntityList) {
                List<NbrlNbrlTextSetcEntity> textList = nbrlNbrlItemSetbEntity.getNbrl_text_set();
                if(null != textList && textList.size() > 0){
                    EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlNbrlItemSetbEntity, textList, SQLCurdEnum.INSERT);
                    setPublicProperties(curentUserid, textList);
                    nbrlTextSetcEntityList.addAll(textList);
                }
                List<NbrlNbrlTimeSetcEntity> timeList = nbrlNbrlItemSetbEntity.getNbrl_time_set();
                if(null != timeList && timeList.size() > 0){
                    EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlNbrlItemSetbEntity, timeList, SQLCurdEnum.INSERT);
                    setPublicProperties(curentUserid, timeList);
                    nbrlTimeSetcEntityList.addAll(timeList);
                }

                List<NbrlNbrlSerialSetcEntity> serialList = nbrlNbrlItemSetbEntity.getNbrl_serial_set();
                if (null != serialList && serialList.size() > 0){
                    EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlNbrlItemSetbEntity, serialList, SQLCurdEnum.INSERT);
                    setPublicProperties(curentUserid, serialList);
                    nbrlSerialSetcEntityList.addAll(serialList);
                }
                List<NbrlNbrlParamSetcEntity> paramList = nbrlNbrlItemSetbEntity.getNbrl_param_set();
                if(null != paramList && paramList.size() > 0){
                    EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlNbrlItemSetbEntity, paramList, SQLCurdEnum.INSERT);
                    setPublicProperties(curentUserid, paramList);
                    nbrlParamSetcEntityList.addAll(paramList);
                }
                List<NbrlNbrlPropertyTypecEntity> propertyList = nbrlNbrlItemSetbEntity.getNbrl_property_type();
                if(null != propertyList && propertyList.size() > 0){
                    EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlNbrlItemSetbEntity, propertyList, SQLCurdEnum.INSERT);
                    setPublicProperties(curentUserid, propertyList);
                    nbrlPropertyTypecEntityList.addAll(propertyList);
                }
            }
            map.put("nbrlTextSetcEntityList", nbrlTextSetcEntityList);
            map.put("nbrlTimeSetcEntityList", nbrlTimeSetcEntityList);
            map.put("nbrlSerialSetcEntityList" ,nbrlSerialSetcEntityList);
            map.put("nbrlParamSetcEntityList", nbrlParamSetcEntityList);
            map.put("nbrlPropertyTypecEntityList", nbrlPropertyTypecEntityList);
        }
        return map;
    }

    /**
     * 设置条件公式集，获取所有的条件公式
     * @param conditionFormulaSetbEntityList 规则条件公式集
     * @return conditionFormulaSetbEntityList 内包含的所有公式集
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlFormulacEntity> setFormualacSet(List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbEntityList) throws Exception{
        List<NbrlNbrlFormulacEntity> nbrlFormulacEntityList = new ArrayList<>();
        //遍历规则条件公式集
        for (NbrlNbrlConditionFormulaSetbEntity nbrlNbrlConditionFormulaSetbEntity : conditionFormulaSetbEntityList) {
            List<NbrlNbrlFormulacEntity> formulacEntityList = nbrlNbrlConditionFormulaSetbEntity.getNbrl_formula();
            if(null != formulacEntityList && formulacEntityList.size()>0){
                EdmUtil.setPropertyBaseEntitiesSysColumns(NumberrulesEntity.class,nbrlNbrlConditionFormulaSetbEntity,formulacEntityList,SQLCurdEnum.INSERT);
                nbrlFormulacEntityList.addAll(formulacEntityList);
            }
        }
        return nbrlFormulacEntityList;
    }

    /**
     * 根据pid查询——规则条件集
     * @param pid numberRules 的 id
     * @return 返回根据pid查询的所有NbrlNbrlConditionSetaEntity集合
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlConditionSetaEntity> queryNbrlConditionSetListByPid(String pid) throws Exception{
        List<String> list = Arrays.asList(NbrlConditionSetConst.NBRL_CONDITION_ORDER,NbrlConditionSetConst.NBRL_IS_USED,NbrlConditionSetConst.NBRL_CURRENT_SERIAL,NbrlConditionSetConst.NBRL_DESC,NbrlConditionSetConst.NBRL_IS_MANUAL_NUMBER,NbrlConditionSetConst.NBRL_CODE_EPSN,NbrlConditionSetConst.NBRL_TAKENO_DATE);
        List<String> columnList = new ArrayList<>(list);
        setBaseProperties(columnList);
        OrmParam ormParam = setOrderQueryConditionByPid(columnList,pid, NbrlConditionSetConst.NBRL_CONDITION_ORDER,SQLSortEnum.ASC);
        return ormService.selectBeanList(NbrlNbrlConditionSetaEntity.class,ormParam);
    }

    /**
     * 根据pid查询——规则条件公式集合
     * @param pid 规则条件id
     * @return 返回根据pid查询的所有NbrlNbrlConditionFormulaSetbEntity集合
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlConditionFormulaSetbEntity> queryConditionFormulaListByPid(String pid) throws Exception{
        List<String> list = Arrays.asList(NbrlConditionFormulaSetConst.NBRL_NBRL_CFORMULA_ORDER,NbrlConditionFormulaSetConst.NBRL_CONDITION_FORMULA,NbrlConditionFormulaSetConst.NBRL_CFORMULA_ID,NbrlConditionFormulaSetConst.NBRL_CFORMULA_TYPE,NbrlConditionFormulaSetConst.NBRL_CLASS);;
        List<String> columnList = new ArrayList<>(list);
        setBaseProperties(columnList);
        OrmParam ormParam = setOrderQueryConditionByPid(columnList,pid, NbrlConditionFormulaSetConst.NBRL_NBRL_CFORMULA_ORDER,SQLSortEnum.ASC);
        return ormService.selectBeanList(NbrlNbrlConditionFormulaSetbEntity.class,ormParam);
    }

    /**
     * 根据pid查询条件公式集
     * @param pid 规则条件公式id
     * @return 返回查询到的NbrlNbrlFormulacEntity集合
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlFormulacEntity> queryFormulacListByPid(String pid) throws Exception{
        List<String> list = Arrays.asList(NbrlFormulacConst.NBRL_FMLA_ORDER,NbrlFormulacConst.NBRL_BRACKET_LEFT,NbrlFormulacConst.NBRL_BRACKET_RIGHT,NbrlFormulacConst.NBRL_FMLA_LOGIC,NbrlFormulacConst.NBRL_FMLA_OPRT,NbrlFormulacConst.NBRL_FMLA_PARAM,NbrlFormulacConst.NBRL_FMLA_VALUE);
        List<String> columnList = new ArrayList<>(list);
        setBaseProperties(columnList);
        OrmParam ormParam = setOrderQueryConditionByPid(columnList,pid, NbrlFormulacConst.NBRL_FMLA_ORDER , SQLSortEnum.ASC);
        return ormService.selectBeanList(NbrlNbrlFormulacEntity.class, ormParam);
    }
    /**
     * 根据pid查询——规则项集合
     * @param pid 规则条件公式id
     * @return 返回查询到的NbrlNbrlItemSetbEntity集合
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlItemSetbEntity> queryItemSetListByPid(String pid)throws Exception{
        List<String> list = Arrays.asList(NbrlItemSetConst.NBRL_NBRL_ITEM_ORDER,NbrlItemSetConst.NBRL_NBRL_ITEM_TYPE,NbrlItemSetConst.NBRL_ITEM_DESC);
        List<String> columnList = new ArrayList<>(list);
        setBaseProperties(columnList);
        // 设置查询条件
        OrmParam ormParam = setOrderQueryConditionByPid(columnList,pid, NbrlItemSetConst.NBRL_NBRL_ITEM_ORDER , SQLSortEnum.ASC);
        return ormService.selectBeanList(NbrlNbrlItemSetbEntity.class,ormParam);
    }
    /**
     * 根据pid查询——手工编号集合
     * @param pid 规则条件公式id
     * @return 返回查询到的NbrlNbrlManualNumberSetbEntity集合
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlManualNumberSetbEntity> queryManualNumberListByPid(String pid)throws Exception{
        List<String> list = Arrays.asList(NbrlManualNumberSetConst.NBRL_IS_USE_TB,NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_TB,NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_ORDER_TB);
        List<String> columnList = new ArrayList<>(list);
        setBaseProperties(columnList);
        // 设置查询条件
        OrmParam ormParam = setOrderQueryConditionByPid(columnList,pid, NbrlManualNumberSetConst.NBRL_MANUAL_NUMBER_ORDER_TB , SQLSortEnum.ASC);
        return ormService.selectBeanList(NbrlNbrlManualNumberSetbEntity.class,ormParam);
    }

    public void setBaseProperties(List<String> columnList){
        columnList.add(BasicConst.ID);
        columnList.add(BasicConst.PID);
        columnList.add(BasicConst.CRETIME);
        columnList.add(BasicConst.MODTIME);
        columnList.add(BasicConst.CREUSER);
        columnList.add(BasicConst.MODUSER);
    }
    /**
     * 根据pid查询——时间集
     * @param pid 规则项id
     * @return 返回List<NbrlNbrlTimeSetcEntity>
     * @throws Exception 异常
     */
    private List<NbrlNbrlTimeSetcEntity> queryTimeSetListByPid(String pid) throws Exception{
        List<String> columnList = new ArrayList<>(Arrays.asList("id","pid","moduser","creuser","modtime","cretime","nbrl_time_type","nbrl_time_length"));
        OrmParam ormParam = setQueryConditionByPid(columnList,pid);
        return ormService.selectBeanList(NbrlNbrlTimeSetcEntity.class,ormParam);
    }
    /**
     * 根据pid查询——文本集
     * @param pid 文本集pId
     * @return List<NbrlNbrlTextSetcEntity>
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlTextSetcEntity> queryTextSetListByPid(String pid) throws Exception{
        List<String> columnList = new ArrayList<>(Arrays.asList("id","pid","moduser","creuser","modtime","cretime","nbrl_test_content"));
        OrmParam ormParam = setQueryConditionByPid(columnList,pid);
        return ormService.selectBeanList(NbrlNbrlTextSetcEntity.class,ormParam);
    }
    /**
     * 根据pid查询——流水号集
     * @param pid 流水号集pId
     * @return List<NbrlNbrlSerialSetcEntity>
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlSerialSetcEntity> querySerialSetListByPid(String pid) throws Exception{
        List<String> columnList = new ArrayList<>(Arrays.asList("id","pid","moduser","creuser","modtime","cretime","nbrl_serial_length","nbrl_serial_reset_condition","nbrl_serial_step","nbrl_serial_reset_number","nbrl_serial_rule"));
        OrmParam ormParam = setQueryConditionByPid(columnList,pid);
        return ormService.selectBeanList(NbrlNbrlSerialSetcEntity.class,ormParam);
    }
    /**
     * 根据pid查询——参数集
     * @param pid 规则项id
     * @return List<NbrlNbrlParamSetcEntity>
     * @throws Exception 抛出异常
     */
    private  List<NbrlNbrlParamSetcEntity> queryParamSetListByPid(String pid) throws Exception{
        List<String> columnList = new ArrayList<>(Arrays.asList("id","pid","moduser","creuser","modtime","cretime","nbrl_param","nbrl_param_type","nbrl_param_start_position","nbrl_param_intercept_count"));
        OrmParam ormParam = setQueryConditionByPid(columnList, pid);
        return ormService.selectBeanList(NbrlNbrlParamSetcEntity.class,ormParam);
    }
    /**
     * 根据pid查询——属性集
     * @param pid 规则项id
     * @return  List<NbrlNbrlPropertyTypecEntity>
     * @throws Exception 抛出异常
     */
    private List<NbrlNbrlPropertyTypecEntity> queryPropertyTypeListByPid(String pid) throws Exception{
        List<String> columnList = new ArrayList<>(Arrays.asList("id","pid","nbrl_property","nbrl_property_intercept_type","nbrl_property_intercept_start","nbrl_property_intercept_count","nbrl_property_class","creuser","moduser","cretime","modtime"));
        OrmParam ormParam = setQueryConditionByPid(columnList,pid);
        return ormService.selectBeanList(NbrlNbrlPropertyTypecEntity.class,ormParam);
    }



    /**
     * 设置查询条件
     * @param columnList 查询列
     * @param id 查询条件
     * @return 异常处理
     */
    public OrmParam setQueryConditionByPid(List<String> columnList, String id) throws Exception{
        // 设置查询条件
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("pid", id));
        ormParam.setWhereExp(whereExp);
        return ormParam;
    }

    /**
     * 设置查询条件——排序
     * @param id 查询条件
     * @param columnList 查询列
     * @param orderBy 排序字段
     * @param sqlSortEnum 排序方式
     * @return OrmParam 查询参数
     */
    public OrmParam setOrderQueryConditionByPid(List<String> columnList, String id, String orderBy, SQLSortEnum sqlSortEnum) throws Exception{
        // 设置查询条件
        // 设置查询条件
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("pid", id));
        ormParam.setWhereExp(whereExp);
        ormParam.addOrderExpElement(sqlSortEnum, orderBy);
        return ormParam;
    }

    /**
     * 设置查询条件——排序
     * @param columnList 查询列
     * @param id 查询条件
     * @param orderBy 排序字段
     * @param sqlSortEnum 排序方式
     * @param numberEnable 规则条件状态
     * @return OrmParam 查询参数
     */
    private List<NbrlNbrlConditionSetaEntity> qryOrderQueryConditionByPid(List<String> columnList, String id, String orderBy, SQLSortEnum sqlSortEnum, String numberEnable) throws Exception{
        // 设置查询条件
        // 设置查询条件
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columnList);
        List<String> params = new ArrayList<>();
        params.add(ormParam.getEqualXML("pid", id));
        params.add(ormParam.getEqualXML(NbrlConditionSetConst.NBRL_IS_USED,numberEnable));
        String whereExp = OrmParam.and(params);
        ormParam.setWhereExp(whereExp);
        ormParam.addOrderExpElement(sqlSortEnum, orderBy);
        return ormService.selectBeanList(NbrlNbrlConditionSetaEntity.class,ormParam);
    }


    /**
     * 设置公共属性
     * @param list 待操作集合
     * @param curentUser 当前登录用户
     */
    private  <T extends BaseEntity> void setPublicProperties(String curentUser, List<T> list) throws Exception{
        if(null != list && list.size() > 0){
            for (Object obj : list) {
                Class clazz = obj.getClass();
                Method[] method = clazz.getMethods();
                //写数据
                for(Method m :method) {
                    String methodName = m.getName();
                    if("setCreuser".equals(methodName)){
                        m.invoke(obj, curentUser);
                    }
                    if("setModuser".equals(methodName)){
                        m.invoke(obj, curentUser);
                    }
                }
            }
        }
    }

    /**
     * 判断nbrlCode，nbrlName是否为空
     * @param nbrlCode 规则代码
     * @param nbrlName 规则名称
     * @return 返回字符串
     */
    @Override
    public String isCodeOrNameEmpty(String nbrlCode, String nbrlName){
        String errMsg = "";
        if(StringUtil.isNullOrEmpty(nbrlCode)){
            errMsg =  "规则代码不能为空";
        }else if(StringUtil.isNullOrEmpty(nbrlName)){
            errMsg = "规则名称不能为空";
        }
        return errMsg;
    }

    @Override
    public boolean isUseItemOrManualnumber(NumberrulesEntity numberrulesEntity) {
        List<NbrlNbrlConditionSetaEntity> conditionSetaEntityList = numberrulesEntity.getNbrl_condition_set();
        if(null == conditionSetaEntityList || conditionSetaEntityList.size() == 0){
            return true;
        }
        boolean flag = false;
        for (NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : conditionSetaEntityList) {
            if(null == nbrlConditionSetaEntity.getNbrl_manual_number_set()||nbrlConditionSetaEntity.getNbrl_manual_number_set().size() == 0){
                if(null == nbrlConditionSetaEntity.getNbrl_item_set() || nbrlConditionSetaEntity.getNbrl_item_set().size() == 0){
                    flag = true;
                    break;
                }
            }
        }
        return flag;
    }

    @Override
    public List<NbrlNbrlItemSetbEntity> getDefaultItems()throws Exception{
        List<NbrlNbrlItemSetbEntity> itemSetbEntityList = new ArrayList<>();

        setItemPropertyText(itemSetbEntityList);

        setItemPropertyTime(itemSetbEntityList);


        setItemPrpertySerial(itemSetbEntityList);

        return itemSetbEntityList;
    }

    @Override
    public boolean isUseSerial(NumberrulesEntity numberrulesEntity){
        boolean flag = true;
        List<NbrlNbrlConditionSetaEntity> conditionSetaEntityList = numberrulesEntity.getNbrl_condition_set();
        if(null != conditionSetaEntityList && conditionSetaEntityList.size() > 0){
            for (NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : conditionSetaEntityList) {
                if(nbrlConditionSetaEntity.getNbrl_is_manual_number().equals(Constants.UNUSE)){
                    flag = false;
                    for (NbrlNbrlItemSetbEntity itemSetbEntity : nbrlConditionSetaEntity.getNbrl_item_set()) {
                        if(null != itemSetbEntity.getNbrl_serial_set() && itemSetbEntity.getNbrl_serial_set().size() > 0){
                            flag = true;
                            break;
                        }
                    }
                    return flag;
                }
            }
        }
        return flag;
    }

    private void setItemPrpertySerial(List<NbrlNbrlItemSetbEntity> itemSetbEntityList) {
        NbrlNbrlItemSetbEntity itemSetbEntity4 = new NbrlNbrlItemSetbEntity();
        setItemEntetyProperty(itemSetbEntity4, 4 ,"serial");
        itemSetbEntity4.setNbrl_item_desc("4位，按月重置，步长1，开始值为1，进位为0~9");
        List<NbrlNbrlSerialSetcEntity> serialSetcEntityList = new ArrayList<>();
        NbrlNbrlSerialSetcEntity serialSetcEntity = new NbrlNbrlSerialSetcEntity();
        serialSetcEntity.setNbrl_serial_length(4);
        serialSetcEntity.setNbrl_serial_reset_condition("month");
        serialSetcEntity.setNbrl_serial_reset_number("1");
        serialSetcEntity.setNbrl_serial_rule("10");
        serialSetcEntity.setNbrl_serial_step(1);
        serialSetcEntityList.add(serialSetcEntity);
        itemSetbEntity4.setNbrl_serial_set(serialSetcEntityList);
        itemSetbEntityList.add(itemSetbEntity4);
    }

    private void setItemPropertyTime(List<NbrlNbrlItemSetbEntity> itemSetbEntityList) {
        NbrlNbrlItemSetbEntity itemSetbEntity2 = new NbrlNbrlItemSetbEntity();
        setItemEntetyProperty(itemSetbEntity2, 2 ,"time");
        itemSetbEntity2.setNbrl_item_desc("2位，YY");
        List<NbrlNbrlTimeSetcEntity> timeSetcEntityList = new ArrayList<>();
        NbrlNbrlTimeSetcEntity yearTimeSetcEntity = new NbrlNbrlTimeSetcEntity();
        yearTimeSetcEntity.setNbrl_time_length(2);
        yearTimeSetcEntity.setNbrl_time_type("year");
        timeSetcEntityList.add(yearTimeSetcEntity);
        itemSetbEntity2.setNbrl_time_set(timeSetcEntityList);
        itemSetbEntityList.add(itemSetbEntity2);

        NbrlNbrlItemSetbEntity itemSetbEntity3 = new NbrlNbrlItemSetbEntity();
        setItemEntetyProperty(itemSetbEntity3, 3 ,"time");
        itemSetbEntity3.setNbrl_item_desc("2位，MM");
        List<NbrlNbrlTimeSetcEntity> timeSetcEntityList1 = new ArrayList<>();
        NbrlNbrlTimeSetcEntity monthTimeSetcEntity = new NbrlNbrlTimeSetcEntity();
        monthTimeSetcEntity.setNbrl_time_length(2);
        monthTimeSetcEntity.setNbrl_time_type("month");
        timeSetcEntityList1.add(monthTimeSetcEntity);
        itemSetbEntity3.setNbrl_time_set(timeSetcEntityList1);
        itemSetbEntityList.add(itemSetbEntity3);
    }

    private void setItemPropertyText(List<NbrlNbrlItemSetbEntity> itemSetbEntityList) {
        NbrlNbrlItemSetbEntity itemSetbEntity1 = new NbrlNbrlItemSetbEntity();
        setItemEntetyProperty(itemSetbEntity1, 1 ,"text");
        itemSetbEntity1.setNbrl_item_desc("-");
        List<NbrlNbrlTextSetcEntity> textSetcEntityList = new ArrayList<>();
        NbrlNbrlTextSetcEntity textSetcEntity = new NbrlNbrlTextSetcEntity();
        textSetcEntity.setNbrl_test_content("-");
        textSetcEntityList.add(textSetcEntity);
        itemSetbEntity1.setNbrl_text_set(textSetcEntityList);
        itemSetbEntityList.add(itemSetbEntity1);
    }

    private void setItemEntetyProperty(NbrlNbrlItemSetbEntity itemSetbEntity, int order, String type) {
        itemSetbEntity.setNbrl_item_order(order);
        itemSetbEntity.setNbrl_item_type(type);
        itemSetbEntity.setId(StringUtil.generateUUID());
    }

    private NumberRulesVO getEnableNumberrulesBycode(OrmParam ormParam) throws Exception {
        String pid ;
        List<NumberrulesEntity> numberrulesEntityList = ormService.selectBeanList(NumberrulesEntity.class,ormParam);
        if(null == numberrulesEntityList || numberrulesEntityList.size() == 0){
            return null;
        }
        NumberRulesVO numberRulesVO = new NumberRulesVO();
        NumberrulesEntity numberrulesEntity = numberrulesEntityList.get(0);
        //entity转VO
        EntityConvertVOUtil.assignmentOfTheSameField(numberrulesEntity, numberRulesVO);

        pid = numberrulesEntity.getId();
        List<String> columnList = new ArrayList<>(Arrays.asList(NbrlConditionSetConst.NBRL_CONDITION_ORDER,NbrlConditionSetConst.NBRL_IS_USED,NbrlConditionSetConst.NBRL_CURRENT_SERIAL,NbrlConditionSetConst.NBRL_DESC,NbrlConditionSetConst.NBRL_IS_MANUAL_NUMBER,NbrlConditionSetConst.NBRL_CODE_EPSN,NbrlConditionSetConst.NBRL_TAKENO_DATE));
        setBaseProperties(columnList);
        //规则条件集
        List<NbrlNbrlConditionSetaEntity> nbrlConditionSetaEntityList = qryOrderQueryConditionByPid(columnList,pid,NbrlConditionSetConst.NBRL_CONDITION_ORDER ,SQLSortEnum.ASC, Constants.ENABLE);
        numberRulesVO.setNbrl_condition_set(nbrlConditionSetaEntityList);
        if(null != nbrlConditionSetaEntityList && nbrlConditionSetaEntityList.size() > 0){
            //规则项集合
            List<NbrlNbrlItemSetbEntity> nbrlItemSetbEntityList ;
            //规则条件公式集合
            List<NbrlNbrlConditionFormulaSetbEntity> nbrlConditionFormulaSetbEntityList ;
            //手工编号集
            List<NbrlNbrlManualNumberSetbEntity> nbrlManualNumberSetbEntityList ;
            for(NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : nbrlConditionSetaEntityList){
                pid = nbrlConditionSetaEntity.getId();
                nbrlItemSetbEntityList = queryItemSetListByPid(pid);
                nbrlConditionSetaEntity.setNbrl_item_set(nbrlItemSetbEntityList);
                nbrlManualNumberSetbEntityList = queryManualNumberListByPid(pid);
                nbrlConditionSetaEntity.setNbrl_manual_number_set(nbrlManualNumberSetbEntityList);
                nbrlConditionFormulaSetbEntityList = queryConditionFormulaListByPid(pid);
                if(null != nbrlConditionFormulaSetbEntityList){
                    nbrlConditionSetaEntity.setNbrl_condition_formula_set(nbrlConditionFormulaSetbEntityList);
                    //条件公式集
                    List<NbrlNbrlFormulacEntity> formulacEntityList ;
                    for (NbrlNbrlConditionFormulaSetbEntity nbrlNbrlConditionFormulaSetbEntity : nbrlConditionFormulaSetbEntityList) {
                        pid = nbrlNbrlConditionFormulaSetbEntity.getId();
                        formulacEntityList = queryFormulacListByPid(pid);
                        nbrlNbrlConditionFormulaSetbEntity.setNbrl_formula(formulacEntityList);
                    }
                }
                if(null != nbrlItemSetbEntityList && nbrlItemSetbEntityList.size() > 0){
                    //时间集
                    List<NbrlNbrlTimeSetcEntity> nbrlTimeSetcEntityList ;
                    //文本集
                    List<NbrlNbrlTextSetcEntity> nbrlTextSetcEntityList ;
                    //流水号集
                    List<NbrlNbrlSerialSetcEntity> nbrlSerialSetcEntityList ;
                    //参数集
                    List<NbrlNbrlParamSetcEntity> nbrlParamSetcEntityList ;
                    //属性集
                    List<NbrlNbrlPropertyTypecEntity> nbrlPropertyTypecEntityList ;
                    for(NbrlNbrlItemSetbEntity nbrlItemSetbEntity: nbrlItemSetbEntityList){
                        pid = nbrlItemSetbEntity.getId();
                        nbrlTimeSetcEntityList = queryTimeSetListByPid(pid);
                        nbrlTextSetcEntityList = queryTextSetListByPid(pid);
                        nbrlSerialSetcEntityList = querySerialSetListByPid(pid);
                        nbrlParamSetcEntityList = queryParamSetListByPid(pid);
                        nbrlPropertyTypecEntityList = queryPropertyTypeListByPid(pid);
                        nbrlItemSetbEntity.setNbrl_time_set(nbrlTimeSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_text_set(nbrlTextSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_serial_set(nbrlSerialSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_param_set(nbrlParamSetcEntityList);
                        nbrlItemSetbEntity.setNbrl_property_type(nbrlPropertyTypecEntityList);
                    }
                }
            }
        }
        return numberRulesVO;
    }

    @Override
    public NumberVO numberruleEntityAttribute2VO(NumberRulesVO numberRulesVO)throws Exception{
        return conditionEntity2VO(numberRulesVO);
    }

    private NumberVO conditionEntity2VO(NumberRulesVO numberRulesVO) throws Exception{
        NumberVO numberVO = new NumberVO();
        EntityConvertVOUtil.assignmentOfTheSameField(numberRulesVO,numberVO);
        List<NbrlConditionSetVO> conditionSetVOS = new ArrayList<>(numberRulesVO.getNbrl_condition_set().size());
        if(null != numberRulesVO.getNbrl_condition_set() && numberRulesVO.getNbrl_condition_set().size()>0){
            for (NbrlNbrlConditionSetaEntity nbrlConditionSetaEntity : numberRulesVO.getNbrl_condition_set()) {
                NbrlConditionSetVO conditionSetVO = new NbrlConditionSetVO();
                EntityConvertVOUtil.assignmentOfTheSameField(nbrlConditionSetaEntity,conditionSetVO);
                conditionSetVO.setModUserName(Utils.getUserNameByUserId(conditionSetVO.getModuser(),ormService));
                conditionSetVOS.add(conditionSetVO);
                if(null != nbrlConditionSetaEntity.getNbrl_item_set() && nbrlConditionSetaEntity.getNbrl_item_set().size() >0){
                    List<NbrlItemSetVO> itemSetVOS = setItemAttributeSets(nbrlConditionSetaEntity.getNbrl_item_set());
                    conditionSetVO.setNbrl_item_set(itemSetVOS);
                }
                if(null != nbrlConditionSetaEntity.getNbrl_condition_formula_set() && nbrlConditionSetaEntity.getNbrl_condition_formula_set().size()>0){
                    List<NbrlNbrlConditionFormulaSetbVO> conditionFormulaSetbVOS = setConditionFormulaAttributes(nbrlConditionSetaEntity.getNbrl_condition_formula_set());
                    conditionSetVO.setNbrl_condition_formula_set(conditionFormulaSetbVOS);
                }
                if(null != nbrlConditionSetaEntity.getNbrl_manual_number_set() && nbrlConditionSetaEntity.getNbrl_manual_number_set().size()>0){
                    List<NbrlNbrlManualNumberSetbVO> manualNumberSetbVOS = new ArrayList<>(nbrlConditionSetaEntity.getNbrl_manual_number_set().size());
                    for (NbrlNbrlManualNumberSetbEntity nbrlNbrlManualNumberSetbEntity : nbrlConditionSetaEntity.getNbrl_manual_number_set()) {
                        NbrlNbrlManualNumberSetbVO manualNumberSetbVO = new NbrlNbrlManualNumberSetbVO();
                        EntityConvertVOUtil.assignmentOfTheSameField(nbrlNbrlManualNumberSetbEntity,manualNumberSetbVO);
                        manualNumberSetbVOS.add(manualNumberSetbVO);
                    }
                }
            }
        }
        numberVO.setNbrl_condition_set(conditionSetVOS);
        numberVO.setModUserName(Utils.getUserNameByUserId(numberVO.getModuser(),ormService));
        return numberVO;
    }

    private List<NbrlNbrlConditionFormulaSetbVO> setConditionFormulaAttributes(List<NbrlNbrlConditionFormulaSetbEntity> conditionFormulaSetbEntities)throws Exception{
        List<NbrlNbrlConditionFormulaSetbVO> conditionFormulaSetbVOS = new ArrayList<>(conditionFormulaSetbEntities.size());
        for (NbrlNbrlConditionFormulaSetbEntity conditionFormulaSetbEntity : conditionFormulaSetbEntities) {
            NbrlNbrlConditionFormulaSetbVO conditionFormulaSetbVO = new NbrlNbrlConditionFormulaSetbVO();
            EntityConvertVOUtil.assignmentOfTheSameField(conditionFormulaSetbEntity,conditionFormulaSetbVO);
            conditionFormulaSetbVOS.add(conditionFormulaSetbVO);
        }
        return conditionFormulaSetbVOS;
    }

    /**
     * 根据nbrl_code查询
     * @param nbrlCode 规则代码
     * @return 返回NumberRulesVO
     * @throws Exception 抛出异常
     */
    public NumberRulesVO getNumberRuleByCode(String nbrlCode) throws Exception{
        // 设置查询条件
        OrmParam ormParam = new OrmParam();
        List<String> columnList = new ArrayList<>(Arrays.asList("id","nbrl_code","nbrl_name","nbrl_serial_increase","is_del"));
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML("nbrl_code", nbrlCode));
        ormParam.setWhereExp(whereExp);
        return getEnableNumberrulesBycode(ormParam);
    }

    /**
     * 修改上次取号时间
     * @param id 规则条件公式id
     * @return 返回更新记录条数
     */
    @Transactional
    public Integer updatTakenoDate(String id, String nbrlCurrentSerial) throws Exception{
        NbrlNbrlConditionSetaEntity conditionSetaEntity = new NbrlNbrlConditionSetaEntity();
        conditionSetaEntity.setNbrl_takeno_date(new Date());
        conditionSetaEntity.setNbrl_current_serial(nbrlCurrentSerial);
        OrmParam ormParam = new OrmParam();
        String whereExp = OrmParam.and(ormParam.getEqualXML("id", id));
        ormParam.setWhereExp(whereExp);
        return  ormService.updateSelective(conditionSetaEntity,ormParam);
    }
}
