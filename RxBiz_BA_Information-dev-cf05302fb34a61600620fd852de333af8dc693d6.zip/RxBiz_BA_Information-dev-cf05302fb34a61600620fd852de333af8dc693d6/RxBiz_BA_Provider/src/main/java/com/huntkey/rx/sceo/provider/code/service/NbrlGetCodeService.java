package com.huntkey.rx.sceo.provider.code.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.code.NbrlManualNumberSet;

import java.util.List;
import java.util.Map;

/**
 * @author zoulj
 * @create 2017/11/27 9:20
 **/
public interface NbrlGetCodeService {

    public Result callByActive(String nbrlCode, List<String> params);

/*    public String callByPassive(String nbrlCode,List<String> params,Map<String,String> properties);*/
}
