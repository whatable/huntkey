package com.huntkey.rx.sceo.provider.code.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.NbrlNbrlManualNumberSetbEntity;
import com.huntkey.rx.sceo.common.model.code.QryNumberRulesDto;
import com.huntkey.rx.sceo.common.model.code.VO.NumberRulesVO;

import java.util.List;

/**
 * @author zoulj
 * @create 2017/11/27 9:20
 **/
public interface NbrlManualNumberSetService {

    /**
     * 分页查询手工编号列表数据，支持模糊查询
     *
     * @param nbrlManualNumber
     * @param nbrlIsUse
     * @param pageNum
     * @param pageSize
     * @return
     */
    Pagination<NbrlNbrlManualNumberSetbEntity> list(String nbrlManualNumber, String nbrlIsUse, String pid, String authorization, String token, int pageNum, int pageSize) throws Exception;

    /**
     * 添加手工编号
     *
     * @param nbrlNbrlManualNumberSetbEntity
     * @return
     */
    String insert(NbrlNbrlManualNumberSetbEntity nbrlNbrlManualNumberSetbEntity,String authorization) throws Exception;

    /**
     * 编码规则管理列表查询
     *
     * @param dto
     * @return
     */
    Pagination<NumberRulesVO> qryNumberRules(QryNumberRulesDto dto) throws Exception;

    /**
     * 以集合的方式添加
     *
     * @param nbrlManualNumberSets
     * @return
     */
    int insert(List<NbrlNbrlManualNumberSetbEntity> nbrlManualNumberSets,String authorization,String token) throws Exception;

    /**
     * 查询指定手工编号存在的条数
     *
     * @param manualNumber
     * @param token
     * @return
     */
    int qryManualNumberCount(String manualNumber, String pid, String token) throws Exception;

    /**
     * 查询指定手工编号存在的条数
     *
     * @param manualNumber
     * @return
     */
    int qryManualNumberCount(String manualNumber, String pid) throws Exception;

    int delete(String manualNumber) throws Exception;

    /**
     * 排序上移下移更新
     *
     * @param nbs
     * @return
     * @throws Exception
     */
    String updateList(List<NbrlNbrlManualNumberSetbEntity> nbs) throws Exception;

    /**
     * 删除编码规则
     *
     * @param id
     * @return
     * @throws Exception
     */
    int deleteNumberRule(String id) throws Exception;

    /**
     * 添加手工编号到redis
     *
     * @param manualNumberCodes
     * @return
     */
    String addToRedis(String manualNumberCodes,String pid, String token) throws Exception;

    /**
     * 从redis中删除手工编号
     *
     * @param ManualNumberCodes
     * @return
     */
    String removeToRedis(List<String> ManualNumberCodes,String token,String pid) throws Exception;

    public String redisSynchronizeToMysql(String token, String authorization) throws Exception;

}
