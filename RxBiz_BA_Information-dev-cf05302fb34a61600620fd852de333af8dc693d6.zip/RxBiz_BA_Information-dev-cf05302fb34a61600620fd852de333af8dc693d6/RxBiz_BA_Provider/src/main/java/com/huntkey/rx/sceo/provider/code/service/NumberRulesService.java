package com.huntkey.rx.sceo.provider.code.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.NbrlNbrlCodeUsedbEntity;
import com.huntkey.rx.edm.entity.NbrlNbrlItemSetbEntity;
import com.huntkey.rx.edm.entity.NumberrulesEntity;
import com.huntkey.rx.sceo.common.model.code.VO.NumberRulesVO;
import com.huntkey.rx.sceo.common.model.code.VO.NumberVO;

import java.util.List;

/**
 * @author liucs
 * @date 2017-11-24 13:48:37
 */
public interface NumberRulesService {
    /**
     * 插入规则编号
     * @param curentUserid 当前登录用户id
     * @param numberrulesEntity
     *@param token  @return
     */
    String addNumberRules(String curentUserid, NumberrulesEntity numberrulesEntity, String authorization, String token) throws Exception;

    /**
     * 根据规则代码查询规则编号信息
     * @param nbrlCode——规则代码
     * @return
     */
    NumberRulesVO getNumberRule(String nbrlCode) throws Exception;

    /**
     * 启用、禁用
     * @param id
     * @return
     */
    int enableOrNot(String id, String currentUserId) throws Exception;

    /**
     * nbrlCode——规则代码是否存在
     * @param nbrlCode
     * @return
     */
    boolean isCodeExisted(String nbrlCode)throws Exception;

    /**
     *nbrlname——规则名称是否存在
     * @param nbrlName
     * @return
     */
    boolean isNameExisted(String nbrlName) throws Exception;

    /**
     * 查询编号使用情况——分页模糊查询
     * @param nbrlCode
     * @param nbrlCuCode
     * @param pageNum
     * @param pageSize
     * @return
     * @throws Exception
     */
    Pagination<NbrlNbrlCodeUsedbEntity> queryCodeUsed(String nbrlCode,String nbrlCuCode, int pageNum, int pageSize)throws Exception;

    Result update(String curentUserId, NumberrulesEntity numberrulesEntity, String token, String authorization)throws Exception;

    /**
     * 判断nbrlCode，nbrlName是否为空
     * @param nbrlCode
     * @param nbrlName
     * @return
     */
    String isCodeOrNameEmpty(String nbrlCode, String nbrlName);

    /**
     * 验证是否使用手工编号或规则项
     * @param numberrulesEntity
     * @return
     */
    boolean isUseItemOrManualnumber(NumberrulesEntity numberrulesEntity);

    /**
     * 获取默认规则项列表
     * @return
     */
    List<NbrlNbrlItemSetbEntity> getDefaultItems() throws Exception;

    /**
     * 检验适用规则项的情况下是否使用了流水号
     * @param numberrulesEntity
     * @return 返回boolean
     */
    boolean isUseSerial(NumberrulesEntity numberrulesEntity);

    NumberVO numberruleEntityAttribute2VO(NumberRulesVO numberRulesVO) throws Exception;
}
