package com.huntkey.rx.sceo.provider.currency.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.method.register.plugin.entity.ProgramCate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;
import com.huntkey.rx.sceo.common.model.order.vo.CurrRateSetOrderVO;
import com.huntkey.rx.sceo.provider.currency.service.CurrRateService;
import com.huntkey.rx.sceo.provider.utils.Utils;

/**
 * @author liucs
 * @date 2018-4-3 10:27:42
 */
@RestController
@RequestMapping("/currRate")
public class CurrRateController {
	private static Logger logger = LoggerFactory.getLogger(CurrRateController.class);
	@Autowired
	private CurrRateService currRateService;

	/**
	 * 通过单据id加载单据
	 * @param orderId
	 * @return
	 */
	@RequestMapping(value = "/loadOrder/{orderId}", method = RequestMethod.GET)
	public Result loadOrder(@PathVariable(value = "orderId")String orderId){
		Result result = new Result();
		try {
			result.setData(currRateService.loadOrder(orderId));
		} catch (Exception e) {
			logger.info("approve fail :" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg("通过审批失败 :" + e.getMessage());
		}
		return result;
	}

	/**
	 * 删除
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param id
	 *            对象id
	 * @return 返回删除数量
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public Result delete(@RequestParam("authorization") String authorization, @RequestParam("id") String id) {
		String currentUserId = Utils.getCurentUserId(authorization);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currRateService.delete(currentUserId, id));
		} catch (Exception e) {
			logger.error("currRate/delete:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 根据id查询
	 * 
	 * @param id
	 *            对象id
	 * @return 返回对象
	 */
	@RequestMapping(value = "/queryById/{id}", method = RequestMethod.GET)
	public Result queryById(@PathVariable("id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currRateService.queryById(id));
		} catch (Exception e) {
			logger.error("currRate/queryById:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 根据pid查询汇率列表
	 * 
	 * @param currConvCurr
	 *            换算币别代码
	 * @param pid
	 *            币别id
	 * @param currRateEnable
	 *            启用/禁用
	 * @param pageSize
	 *            每页数据量
	 * @param pageNum
	 *            当前页数
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public Result list(@RequestParam(required = false,value = "currConvCurr")String currConvCurr,
					   @RequestParam(required = false,value = "pid")String pid,
					   @RequestParam(required = false,value = "currRateEnable")String currRateEnable,
					   @RequestParam(required = false,value = "currBeg")String currBeg,
					   @RequestParam(required = false,value = "currEnd")String currEnd,
					   @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
					   @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		CurrCurrRateSetaEntity entity = new CurrCurrRateSetaEntity();
		entity.setPid(pid);
		entity.setCurr_conv_curr(currConvCurr);
		entity.setCurr_rate_enable(currRateEnable);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			if(!StringUtil.isNullOrEmpty(currBeg)){
				entity.setCurr_beg(simpleDateFormat.parse(currBeg));
			}
			if(!StringUtil.isNullOrEmpty(currEnd)){
				entity.setCurr_end(simpleDateFormat.parse(currEnd));
			}
			result.setData(currRateService.list(entity, pageSize, pageNum));
		} catch (Exception e) {
			logger.error("currRate/list:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 综合查询汇率信息 --公共接口
	 * 
	 * @param currRateEnable
	 *            1、启用，0、禁用
	 * @param exchangeDate
	 *            汇率有效日期
	 * @param originCurrId
	 *            币别id
	 * @param targetCurrId
	 *            兑换目标币别id
	 * @return
	 */
	@RequestMapping(value = "/v1/objects", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "currency", methodDesc = "综合查询汇率信息", methodCate =
	// "表单通用方法", getReqParamsNameNoPathVariable = {
	// "currRateEnable", "exchangeDate", "originCurrId", "targetCurrId" })
	@Deprecated
	public Result queryCurrRateObjects(@RequestParam(value = "currRateEnable", required = false) String currRateEnable,
			@RequestParam(value = "exchangeDate") Long exchangeDate,
			@RequestParam(value = "originCurrId") String originCurrId,
			@RequestParam(value = "targetCurrId") String targetCurrId) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		Date effitiveDate = null;
		if (exchangeDate != null) {
			effitiveDate = new Date(exchangeDate);
		}
		try {
			result.setData(
					currRateService.queryCurrRateObjects(currRateEnable, effitiveDate, originCurrId, targetCurrId));
		} catch (Exception e) {
			logger.error("currRate/v1/objects:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 查询汇率单据集合
	 * @param ordeStatus 单据状态
	 * @param pageSize
	 * @param pageNum
	 * @return
	 */
	@RequestMapping(value = "/currRateAuditList", method = RequestMethod.GET)
	public Result currRateAuditList(@RequestParam(value = "ordeStatus")String ordeStatus,
									@RequestParam(required = false, defaultValue = "50", value = "pageSize")Integer pageSize,
									@RequestParam(required = false, defaultValue = "1", value = "pageNum")Integer pageNum){
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currRateService.currRateAuditList(ordeStatus,pageSize,pageNum));
		} catch (Exception e) {
			logger.error("currRate/currRateAuditList:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}
}
