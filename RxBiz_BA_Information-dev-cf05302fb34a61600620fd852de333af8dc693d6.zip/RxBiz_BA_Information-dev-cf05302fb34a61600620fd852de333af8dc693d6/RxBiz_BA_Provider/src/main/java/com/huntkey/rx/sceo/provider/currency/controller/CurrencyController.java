package com.huntkey.rx.sceo.provider.currency.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrencyVO;
import com.huntkey.rx.sceo.provider.currency.service.CurrencyService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author liucs
 * @date 2018-4-2 17:25:55
 */
@RestController
@RequestMapping("/currency")
public class CurrencyController {
	private static Logger logger = LoggerFactory.getLogger(CurrencyController.class);
	@Autowired
	private CurrencyService currencyService;

    /**
     * 新增
     * @param authorization 用户登录认证
     * @param entity 对象
     * @return 返回对象id
     */
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(@RequestParam("authotization")String authorization, @RequestBody CurrencyVO entity){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        String currentUserId = Utils.getCurentUserId(authorization);
        entity.setCreuser(currentUserId);
        try {
            result.setData(currencyService.insert(entity));
        }catch (Exception e){
            logger.error("currency/insert:"+e.getMessage());
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

	/**
	 * 删除
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param id
	 *            对象id
	 * @return 返回删除数量
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public Result delete(@RequestParam("authorization") String authorization, @RequestParam("id") String id) {
		String currentUserId = Utils.getCurentUserId(authorization);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currencyService.delete(currentUserId, id));
		} catch (Exception e) {
			logger.error("currency/delete:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 修改
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param entity
	 *            统计对象
	 * @return 返回修改记录条数
	 */
	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public Result update(@RequestParam("authorization") String authorization, @RequestBody CurrencyVO entity) {
		String currentUserId = Utils.getCurentUserId(authorization);
		entity.setModuser(currentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currencyService.update(entity));
		} catch (Exception e) {
			logger.error("currency/update:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 根据id查询
	 * 
	 * @param id
	 *            对象id
	 * @return 返回对象
	 */
	@RequestMapping(value = "/queryById/{id}", method = RequestMethod.GET)
	public Result queryById(@PathVariable("id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currencyService.queryById(id));
		} catch (Exception e) {
			logger.error("currency/queryById:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 分页、模糊查询币别列表
	 * 
	 * @param currCode
	 *            代码
	 * @param currSysCode
	 *            名称
	 * @param currEnable
	 *            启用/禁用
	 * @param currName
	 *            名称
	 * @param pageSize
	 *            每页数据量
	 * @param pageNum
	 *            当前页数
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public Result list(@RequestParam(required = false, value = "currCode") String currCode,
			@RequestParam(required = false, value = "currSysCode") String currSysCode,
			@RequestParam(required = false, value = "currName") String currName,
			@RequestParam(required = false, value = "currEnable") String currEnable,
			@RequestParam(required = false, value = "pageSize", defaultValue = "10") Integer pageSize,
			@RequestParam(required = false, value = "pageNum", defaultValue = "1") Integer pageNum) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currencyService.list(currCode, currSysCode, currName, currEnable, pageSize, pageNum));
		} catch (Exception e) {
			logger.error("currency/list:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 查询所有币别
	 * @return
	 */
	@RequestMapping(value = "/allCurrencies", method = RequestMethod.GET)
	public Result allCurrencies(){
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currencyService.allCurrencies());
		} catch (Exception e) {
			logger.error("currency/allCurrencies:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 
	 * 查询币别列表 -公共接口
	 * 
	 * @return
	 */
	@RequestMapping(value = "/v1/objects", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "currency", methodDesc = "查询币别列表", methodCate =
	// "表单通用方法", getReqParamsNameNoPathVariable = {
	// "currEnable", "currName" })
	@Deprecated
	public Result queryObjects(@RequestParam(value = "currEnable", required = false) String currEnable,
			@RequestParam(value = "currName") String currName) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currencyService.queryObjects(currEnable, currName));
		} catch (Exception e) {
			logger.error("currency/v1/objects:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 根据id查询汇率 ——公共接口
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/v1/objects/{id}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "currency", methodDesc = "根据id查询汇率", methodCate =
	// "表单通用方法")
	@Deprecated
	public Result queryObjectById(@PathVariable(value = "id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(currencyService.queryById(id));
		} catch (Exception e) {
			logger.error("currency/v1/objects/{id}:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 仅用于币别文件上传，并且需保证文件名称和币别描述相同
	 * 暂不确定前端页面是否需要图片上传功能
	 * @param files
	 * @return
	 */
	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST)
	public Result uploadFile(@RequestParam("file") MultipartFile...files){
		Result result = new Result();
		if(files.length == 0) {
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg("请选择上传文件！");
			return result;
		}
		String count = null;
		try {
			count = currencyService.uploadImage(files);
		} catch (Exception e) {
			e.printStackTrace();
		}
		result.setRetCode(Result.RECODE_SUCCESS);
		result.setData(count);
		return result;
	}
}
