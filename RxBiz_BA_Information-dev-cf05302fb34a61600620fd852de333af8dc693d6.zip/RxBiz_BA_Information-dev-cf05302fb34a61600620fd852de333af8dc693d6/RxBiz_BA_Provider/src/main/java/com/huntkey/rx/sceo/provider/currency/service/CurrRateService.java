package com.huntkey.rx.sceo.provider.currency.service;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrRateVO;
import com.huntkey.rx.sceo.common.model.order.vo.CurrRateSetOrderVO;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author liucs
 * @date 2018-4-3 10:36:55
 */
public interface CurrRateService {
    /**
     * 創建匯率維護單
     * @param vo 对象
     * @return 返回对象id
     * @throws Exception 抛出异常
     */
    Map<String ,Object> creCurrRateOrder(HttpServletRequest request, CurrRateSetOrderVO vo)throws Exception;

    void audit(HttpServletRequest request,JSONObject auditSet);

    void approve(HttpServletRequest request,String orderId, String handlerType);

    /**
     * 通过单据id查询单据
     * @param orderid
     * @return
     * @throws Exception
     */
    CurrRateSetOrderVO loadOrder(String orderid)throws Exception;

    String insert(CurrRateSetOrderVO vo)throws Exception;

    /**
     * 删除
     * @param id 对象id
     * @param currentUserId 当前登录用户id
     * @return 返回删除数量
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 修改
     * @param entity 对象
     * @return 返回修改数量
     * @throws Exception 抛出异常
     */
    int update(CurrRateVO entity)throws Exception;

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     * @throws Exception 抛出异常
     */
    CurrRateVO queryById(String id)throws Exception;

    /**
     * 根据pid查询汇率列表
     * @param entity 对象——封装查询参数
     * @param pageSize 每页大小
     * @param pageNum 当前页
     * @return 返回币别列表
     * @throws Exception 抛出异常
     */
    Pagination<CurrRateVO> list(CurrCurrRateSetaEntity entity, Integer pageSize, Integer pageNum)throws Exception;

    /**
     * 综合查询汇率信息
     * @param currId
     * @param currConvCurr
     * @return
     * @throws Exception
     */
    List<CurrRateVO> queryObjects(String currId,String currConvCurr)throws Exception;

    /**
     * 当提交流程发生异常时，手动撤销提交的数据
     * @param orderId
     * @throws Exception
     */
    void revokeOrder(String orderId)throws Exception;

    /**
     *      * 综合查询汇率信息
     * @param currRateEnable 1、启用，0、禁用
     * @param effitiveDate 汇率有效日期
     * @param originCurrId  币别id
     * @param targetCurrId 兑换目标币别id
     * @return
     * @throws Exception
     */
    List<CurrRateVO> queryCurrRateObjects(String currRateEnable, Date effitiveDate,String originCurrId,String targetCurrId)throws Exception;


    /**
     * 查询汇率单据集合
     * @throws Exception
     */
    Pagination<CurrRateSetOrderVO> currRateAuditList(String ordeStatus,Integer pageSize,Integer pageNum)throws Exception;
}
