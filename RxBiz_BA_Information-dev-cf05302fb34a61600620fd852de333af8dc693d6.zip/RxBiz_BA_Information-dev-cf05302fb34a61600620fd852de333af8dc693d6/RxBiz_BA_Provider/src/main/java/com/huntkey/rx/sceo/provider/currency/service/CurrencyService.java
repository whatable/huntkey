package com.huntkey.rx.sceo.provider.currency.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.CurrencyEntity;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrencyVO;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 17:25:55
 */
public interface CurrencyService {
    /**
     * 新增
     * @param entity 对象
     * @return 返回对象id
     * @throws Exception 抛出异常
     */
    String insert(CurrencyVO entity)throws Exception;

    /**
     * 删除
     * @param id 对象id
     * @param currentUserId 当前登录用户id
     * @return 返回删除数量
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 修改
     * @param entity 对象
     * @return 返回修改数量
     * @throws Exception 抛出异常
     */
    int update(CurrencyVO entity)throws Exception;

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     * @throws Exception 抛出异常
     */
    CurrencyVO queryById(String id)throws Exception;

    /**
     * 分页模糊查询币别列表
     * @param currCode 代码
     * @param currSysCode 系统代码
     * @param currEnable 启用/禁用
     * @param currName 名称
     * @param pageSize 每页大小
     * @param pageNum 当前页
     * @return 返回币别列表
     * @throws Exception 抛出异常
     */
    Pagination<CurrencyVO> list(String currCode,String currSysCode,String currName,String currEnable, Integer pageSize, Integer pageNum)throws Exception;

    /**
     * 查询所有币别
     * @return
     * @throws Exception
     */
    List<CurrencyVO> allCurrencies()throws Exception;

    /**
     * 根据name精确查询币别
     * @param name
     * @return
     * @throws Exception
     */
    CurrencyVO queryObjectByName(String name)throws Exception;

    /**
     * 查询币别列表
     * @return
     * @throws Exception
     */
    List<CurrencyVO> queryObjects(String currEnable,String currName)throws Exception;

    /**
     * 仅用于币别文件上传，并且需保证文件名称和币别描述相同
     * @param files
     * @return
     * @throws Exception
     */
    String uploadImage(MultipartFile...files) throws Exception;
}
