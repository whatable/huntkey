package com.huntkey.rx.sceo.provider.currency.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.redis.RedisClusterUtils;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.*;
import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.edm.service.OrderRegService;
import com.huntkey.rx.edm.service.PeopleRegService;
import com.huntkey.rx.sceo.common.model.basic.WorkFlowConstants;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.currency.CurrRateConstant;
import com.huntkey.rx.sceo.common.model.currency.CurrencyConstant;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrRateVO;
import com.huntkey.rx.sceo.common.model.order.OrderConstants;
import com.huntkey.rx.sceo.common.model.order.vo.CrsoOrdeSetVO;
import com.huntkey.rx.sceo.common.model.order.vo.CurrRateSetOrderVO;
import com.huntkey.rx.sceo.method.register.plugin.entity.ParamsVo;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.NbrlGetCodeService;
import com.huntkey.rx.sceo.provider.currency.service.CurrRateService;
import com.huntkey.rx.sceo.provider.utils.OrderUtils;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

@Service
@Transactional(readOnly = true,rollbackFor = Exception.class)
public class CurrRateServiceImpl implements CurrRateService {
    @Autowired
    private OrmService ormService;
    @Autowired
    private NbrlGetCodeService nbrlGetCodeService;
    @Autowired
    private PeopleRegService peopleRegService;
    @Autowired
    private OrderRegService orderRegService;
    @Override
    @Transactional(propagation=Propagation.NOT_SUPPORTED,rollbackFor = Exception.class)
    public Map<String,Object> creCurrRateOrder(HttpServletRequest request, CurrRateSetOrderVO vo) throws Exception {
        //移除无效数据数量
        int repeatCount = 0;
        List<CrsoOrdeSetVO> voList = vo.getCrsoOrdeSetVOS();
        // 集合初始大小
        int listSize = voList.size();
        // 判断集合中是否存在相同的汇率（币别和兑换币别都一致），
        if(isRepeatCrsoOrde(voList)){
            throw new RuntimeException("数据重复");
        }
        //获取用户登录认证
        String authorization = request.getHeader("Authorization");
        String creUserId = Utils.getCurentUserId(authorization);
        Iterator it = voList.iterator();
        while (it.hasNext()){
            CrsoOrdeSetVO ordeSetVO = (CrsoOrdeSetVO) it.next();
            //若生效日期无效——则移除该条记录
            if(!isBegEffective(ordeSetVO, vo.getOperaOrderType())){
                it.remove();
                repeatCount++;
            }else{
                //判断是否存在未审核单据，如果存在待审单据则移除该记录
                if(isExistCurrRateOrder(ordeSetVO)){
                    it.remove();
                    repeatCount++;
                }
            }
            //添加时不允许出现相同汇率——币别、兑换币别、生效日期同时相同
            //若汇率表中存在相同汇率，则移除该记录
            if(isExistCurrRate(ordeSetVO,vo.getOperaOrderType())){
                it.remove();
                repeatCount++;
            }
            //校验用户是否修改了生效日期或失效日期,若修改了生效或失效日期，则移除该记录
            if(isUpdateBegOrEnd(ordeSetVO, vo.getOperaOrderType())){
                it.remove();
                repeatCount++;
            };
        }
        if(listSize != voList.size()){
            throw new RuntimeException("无效数据["+repeatCount+"]条，请重新提交!");
        }
        vo.setCreuser(creUserId);
        List<CrsoCrsoOrdeSetaEntity> crsoOrdeSetaEntities = JSONObject.parseArray(JSONObject.toJSONString(voList),CrsoCrsoOrdeSetaEntity.class);
        //vo —> entity
        CurrratesetorderEntity orderEntity = JSONObject.parseObject(JSONObject.toJSONString(vo),CurrratesetorderEntity.class);
        orderEntity.setCrso_orde_set(crsoOrdeSetaEntities);
        //設置員工相關信息
//        setOrderInfo(authorization,orderEntity);
        //生成单号
        Result result = nbrlGetCodeService.callByActive(OrderConstants.CRSO_ORDENBR_PREFIX, null);
        if(result.getData() == null){
            throw new RuntimeException("生成单据号码失败！");
        }
        //单据号
        String orderNbr =  result.getData().toString();
        orderEntity.setOrde_nbr(orderNbr);
        orderEntity.setOrde_status(OrderConstants.ORDE_STATUS_2);
        //单据id
        String orderId = ormService.insert(orderEntity).toString();
        //设置pid、classname、creuser
        for (CrsoCrsoOrdeSetaEntity crsoOrdeSetaEntity : crsoOrdeSetaEntities) {
            crsoOrdeSetaEntity.setId("");
            crsoOrdeSetaEntity.setPid(orderId);
            crsoOrdeSetaEntity.setCrsoo_rate_enable(1);
            crsoOrdeSetaEntity.setClassName("CurrratesetorderEntity");
            //设置创建用户
            crsoOrdeSetaEntity.setCreuser(creUserId);
            crsoOrdeSetaEntity.setCrsoo_beg(new Date(crsoOrdeSetaEntity.getCrsoo_beg().getTime()));
        }
        if(!StringUtil.isNullOrEmpty(orderId)){
            ormService.insert(crsoOrdeSetaEntities);
        }else{
            throw new RuntimeException("提交流程失败!");
        }
        //提交流程
        OrderUtils.submitWorkFlow(orderRegService,authorization,orderEntity.getOrde_rode_obj(),orderId);
        Map<String,Object> map = new HashMap<>(3);
        map.put("orderNbr",orderNbr);
        map.put("orderId",orderId);
        map.put("repeatCount",repeatCount);
        return map;
    }

    @Override
    public void audit(HttpServletRequest request,JSONObject auditSet) {
        RedisClusterUtils redisClusterUtils = new RedisClusterUtils(Constants.REDIS_NODES);
        String auditKey = auditSet.getString(WorkFlowConstants.PARAM_AUDITKEY);
        String formState = auditSet.getString(WorkFlowConstants.PARAM_FORMSTATE);
        String actInstanceId = auditSet.getString(WorkFlowConstants.PARAM_ACT_INSTANCE_ID);
        String opinion = auditSet.getString(WorkFlowConstants.PARAM_OPINION);
        opinion = StringUtil.isNullOrEmpty(opinion) ? "" : opinion;
        LinkedHashMap auditMsg = (LinkedHashMap) auditSet.get(WorkFlowConstants.PARAM_ORDER_OBJ);
        List<LinkedHashMap> mapList = (List<LinkedHashMap>) auditMsg.get("crsoOrdeSetVOS");
        for (LinkedHashMap linkedHashMap : mapList) {
            redisClusterUtils.setValue(linkedHashMap.get(BasicConst.ID).toString(), linkedHashMap.get("crsoOperStatus").toString());
        }
        if (StringUtil.isNullOrEmpty(auditKey)) {
            throw new RuntimeException("请传入参数" + WorkFlowConstants.PARAM_AUDITKEY);
        } else if (StringUtil.isNullOrEmpty(formState)) {
            throw new RuntimeException("请传入参数" + WorkFlowConstants.PARAM_FORMSTATE);
        } else if (StringUtil.isNullOrEmpty(actInstanceId)) {
            throw new RuntimeException("请传入参数" + WorkFlowConstants.PARAM_ACT_INSTANCE_ID);
        }

        // 调用流程
        OrderUtils.audit(orderRegService, request, actInstanceId, opinion, auditKey);
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public void approve(HttpServletRequest request,String orderId, String handlerType) {
        String authorization = request.getHeader("Authorization");
        try {
            CurrratesetorderEntity orderEntity = ormService.load(CurrratesetorderEntity.class,orderId);
            if (orderEntity == null){
                throw new RuntimeException("查询汇率维护单错误 单据id：" + orderId);
            }
            //设置登录人的信息
//           setOrderInfo(authorization,orderEntity);
            // 根据请求方式的不同进行不同的处理逻辑
            // 通过
            if (OrderConstants.PASS.equals(handlerType)) {
                OrmParam ormParam = new OrmParam();
                ormParam.setWhereExp(ormParam.getEqualXML(BasicConst.PID,orderEntity.getId()));
                List<CrsoCrsoOrdeSetaEntity> ordeSetaEntities = ormService.selectBeanList(CrsoCrsoOrdeSetaEntity.class,ormParam);
                orderEntity.setCrso_orde_set(ordeSetaEntities);
                Integer orderType = orderEntity.getCrso_orde_type();
                if (OrderConstants.ADD.equals(String.valueOf(orderType))) {
                    // 新增
                    this.addCurrRate(orderEntity);
                } else if (OrderConstants.UPDATE.equals(String.valueOf(orderType))) {
                    // 修改
                    this.updateCurrRate(orderEntity);
                }
                // 完成：修改单据状态为完成(5)
                updateOrderStatus(orderEntity, OrderConstants.ORDE_STATUS_5);
            }
            // 撤销：修改单据状态为临时(1)
            else if (OrderConstants.REVOKE.equals(handlerType)) {
                updateOrderStatus(orderEntity, OrderConstants.ORDE_STATUS_1);
            }
            // 退回: 修改单据状态为退回(6)
            else if (OrderConstants.RETURN_BACK.equals(handlerType)) {
                updateOrderStatus(orderEntity, OrderConstants.ORDE_STATUS_6);
            }
        } catch (Exception e) {
            throw new RuntimeException("汇率维护单批准通过出错:" + e.getMessage());
        }
    }

    @Override
    public CurrRateSetOrderVO loadOrder(String orderid) throws Exception {
        CurrratesetorderEntity orderEntity = ormService.load(CurrratesetorderEntity.class,orderid);
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(BasicConst.PID, orderEntity.getId()));
        List<CrsoCrsoOrdeSetaEntity> crsoEntities = ormService.selectBeanList(CrsoCrsoOrdeSetaEntity.class,ormParam);
        CurrRateSetOrderVO orderVO = JSONObject.parseObject(JSONObject.toJSONString(orderEntity),CurrRateSetOrderVO.class);
        List<CrsoOrdeSetVO> crsoOrdeSetVOS = JSONObject.parseArray(JSONObject.toJSONString(crsoEntities),CrsoOrdeSetVO.class);
        for (CrsoOrdeSetVO crsoOrdeSetVO : crsoOrdeSetVOS) {
            CurrencyEntity currName = ormService.load(CurrencyEntity.class,crsoOrdeSetVO.getCrsoCurrId());
            CurrencyEntity currConvName = ormService.load(CurrencyEntity.class,crsoOrdeSetVO.getCrsoConvCurr());
            crsoOrdeSetVO.setCrsoName(currName.getCurr_name());
            crsoOrdeSetVO.setCrsoConvName(currConvName.getCurr_name());
        }
        orderVO.setCrsoOrdeSetVOS(crsoOrdeSetVOS);
        return orderVO;
    }

    @Override
    public String insert(CurrRateSetOrderVO vo)throws Exception{
        CurrCurrRateSetaEntity entity = JSONObject.parseObject(JSONObject.toJSONString(vo),CurrCurrRateSetaEntity.class);
        return ormService.insert(entity).toString();
    }

    @Override
    @Deprecated
    public int delete(String currentUserId, String id) throws Exception {
        CurrCurrRateSetaEntity entity = new CurrCurrRateSetaEntity();
        entity.setId(id);
        entity.setModuser(currentUserId);
        ormService.updateSelective(entity);
        return ormService.delete(CurrCurrRateSetaEntity.class,id);
    }
    @Override
    @Deprecated
    public int update(CurrRateVO entity) throws Exception {
        return ormService.update(entity);
    }

    @Override
    public CurrRateVO queryById(String id) throws Exception {
        CurrCurrRateSetaEntity entity = ormService.load(CurrCurrRateSetaEntity.class,id);
        if(entity == null){
            return null;
        }
        CurrRateVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity),CurrRateVO.class);
        vo.setCreUserName(Utils.getUserNameByUserId(entity.getCreuser(),ormService));
        vo.setModUserName(Utils.getUserNameByUserId(entity.getModuser(),ormService));
        return vo;
    }

    @Override
    public Pagination<CurrRateVO> list(CurrCurrRateSetaEntity entity, Integer pageSize, Integer pageNum) throws Exception {
        OrmParam ormParam = setQueryConditioiin(entity);
        ormParam.setPageSize(pageSize);
        ormParam.setPageNo(pageNum);
        ormParam.setOrderExp(SQLSortEnum.DESC,CurrCurrRateSetaProperty.CURR_BEG);
        Pagination<CurrCurrRateSetaEntity> pagination = ormService.selectPagedBeanList(CurrCurrRateSetaEntity.class,ormParam);
        if(pagination == null || pagination.getTotal() == 0){
            return null;
        }
        List<CurrRateVO> voList = JSONObject.parseArray(JSONObject.toJSONString(pagination.getList()),CurrRateVO.class);
        for (CurrRateVO currRateVO : voList) {
            currRateVO.setCreUserName(Utils.getUserNameByUserId(entity.getCreuser(),ormService));
            currRateVO.setModUserName(Utils.getUserNameByUserId(entity.getModuser(),ormService));
            if(!StringUtil.isNullOrEmpty(currRateVO.getCurrConvCurr()) && !StringUtil.isNullOrEmpty(currRateVO.getCurrId())){
                //设置币别名称
                CurrencyEntity curr = ormService.load(CurrencyEntity.class,currRateVO.getCurrId());
                if(curr!=null){
                    currRateVO.setCurrName(curr.getCurr_name());
                }
                //设置换算币别名称
                CurrencyEntity currConv = ormService.load(CurrencyEntity.class,currRateVO.getCurrConvCurr());
                if(currConv != null){
                    currRateVO.setCurrConvName(currConv.getCurr_name());
                }
                // 查询汇率是否待审
                ormParam.reset();
                ormParam.setOrderExp(SQLSortEnum.DESC, BasicConst.CRETIME);
                ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(CrsoCrsoOrdeSetaProperty.CRSOO_CURR_ID,currRateVO.getCurrId()),
                        ormParam.getEqualXML(CrsoCrsoOrdeSetaProperty.CRSOO_CONV_CURR,currRateVO.getCurrConvCurr()),
                        ormParam.getEqualXML(CrsoCrsoOrdeSetaProperty.CRSOO_BEG,currRateVO.getCurrBeg())));
                List<CrsoCrsoOrdeSetaEntity> ordeSetaEntities = ormService.selectBeanList(CrsoCrsoOrdeSetaEntity.class,ormParam);
                if(ordeSetaEntities!=null && ordeSetaEntities.size() > 0){
                    CurrratesetorderEntity order = ormService.load(CurrratesetorderEntity.class,ordeSetaEntities.get(0).getPid());
                    if(order != null && order.getOrde_status().equals(OrderConstants.ORDE_STATUS_2)){
                        currRateVO.setIsAudit("1");
                    }
                }else{
                    currRateVO.setIsAudit("0");
                }
            }
        }
        return new Pagination<CurrRateVO>(voList,pageNum,pageSize,voList.size());
    }



    @Override
    public List<CurrRateVO> queryObjects(String currId, String currConvCurr) throws Exception {
        List<String> columns = new ArrayList<>(Arrays.asList(CurrRateConstant.CURR_CONV_CURR,CurrRateConstant.CURR_CONV_UNIT,
                CurrRateConstant.CURR_RATE,CurrRateConstant.CURR_BEG,CurrRateConstant.CURR_END,CurrRateConstant.CURR_REMARK));
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columns);
        StringBuilder whereExp = new StringBuilder();
        whereExp.append(" and ").append(ormParam.getEqualXML(CurrRateConstant.CURR_CONV_CURR,currConvCurr));
        whereExp.append(" and ").append(ormParam.getEqualXML(BasicConst.PID,currId));
        ormParam.setWhereExp(whereExp.toString());
        List<CurrCurrRateSetaEntity> entityList = ormService.selectBeanList(CurrCurrRateSetaEntity.class,ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        List<CurrRateVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),CurrRateVO.class);
        for (CurrRateVO currRateVO : voList) {
            currRateVO.setCreUserName(Utils.getUserNameByUserId(currRateVO.getCreuser(),ormService));
            currRateVO.setModUserName(Utils.getUserNameByUserId(currRateVO.getModuser(),ormService));
        }
        return voList;
    }

    @Override
    public void revokeOrder(String orderId) throws Exception {
        //删除汇率单
        ormService.delete(CurrratesetorderEntity.class,orderId);
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(BasicConst.PID,orderId));
        //删除汇率单属性集
        ormService.delete(CrsoCrsoOrdeSetaEntity.class,ormParam);
    }

    @Override
    public List<CurrRateVO> queryCurrRateObjects(String currRateEnable, Date effitiveDate,String originCurrId,String targetCurrId)throws Exception{
        CurrCurrRateSetaEntity rateEntity = new CurrCurrRateSetaEntity();
        rateEntity.setCurr_rate_enable(currRateEnable);
//        rateEntity.setCurr_beg(effitiveDate);
//        rateEntity.setCurr_end(effitiveDate);
        rateEntity.setPid(originCurrId);
        rateEntity.setCurr_conv_curr(targetCurrId);
        OrmParam ormParam = setQueryConditioiin(rateEntity);
        List<CurrCurrRateSetaEntity> entityList = ormService.selectBeanList(CurrCurrRateSetaEntity.class,ormParam);
        if(entityList == null || entityList.size()==0){
            return null;
        }
        Iterator it = entityList.iterator();
        while (it.hasNext()){
            CurrCurrRateSetaEntity entity = (CurrCurrRateSetaEntity) it.next();
            if(entity.getCurr_beg().getTime() > effitiveDate.getTime()){
                it.remove();
            }
            if(entity.getCurr_end()!=null&&entity.getCurr_end().getTime()<effitiveDate.getTime()){
                it.remove();
            }
        }
        List<CurrRateVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),CurrRateVO.class);
        for (CurrRateVO currRateVO : voList) {
            currRateVO.setCreUserName(Utils.getUserNameByUserId(currRateVO.getCreuser(),ormService));
            currRateVO.setModUserName(Utils.getUserNameByUserId(currRateVO.getModuser(),ormService));
        }
        return voList;
    }

    @Override
    public Pagination<CurrRateSetOrderVO> currRateAuditList(String ordeStatus, Integer pageSize, Integer pageNum) throws Exception {
        OrmParam ormParam = new OrmParam();
        if(!StringUtil.isNullOrEmpty(ordeStatus)){
            ormParam.setWhereExp(ormParam.getEqualXML(OrderProperty.ORDE_STATUS, ordeStatus));
        }
        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);
        ormParam.setOrderExp(SQLSortEnum.DESC,BasicConst.CRETIME);
        Pagination<CurrratesetorderEntity> list = ormService.selectPagedBeanList(CurrratesetorderEntity.class, ormParam);
        if(list == null || list.getTotal()==0){
            return null;
        }
        List<CurrRateSetOrderVO> voList = JSONObject.parseArray(JSONObject.toJSONString(list.getList()), CurrRateSetOrderVO.class);
        // 查询制单人相关中文信息
        qryAddUserZHInfo(voList);
        return new Pagination<CurrRateSetOrderVO>(voList,pageNum,pageSize,list.getTotal());
    }

    /**
     * 是否存在未完成审核单据
     * @param vo
     * @return
     * @throws Exception
     */
     private boolean isExistCurrRateOrder(CrsoOrdeSetVO vo) throws Exception{
         OrmParam ormParam = new OrmParam();
         //拼接查询条件
         String whereExe = OrmParam.and(ormParam.getEqualXML(CrsoCrsoOrdeSetaProperty.CRSOO_CONV_CURR,vo.getCrsoConvCurr()),
                 ormParam.getEqualXML(CrsoCrsoOrdeSetaProperty.CRSOO_CURR_ID,vo.getCrsoCurrId()));
         ormParam.setWhereExp(whereExe);
         List<CrsoCrsoOrdeSetaEntity> entityList = ormService.selectBeanList(CrsoCrsoOrdeSetaEntity.class,ormParam);
         for (CrsoCrsoOrdeSetaEntity crsoCrsoOrdeSetaEntity : entityList) {
             CurrratesetorderEntity orderEntity = ormService.load(CurrratesetorderEntity.class,crsoCrsoOrdeSetaEntity.getPid());
             if(orderEntity != null && (orderEntity.getOrde_status().equals(OrderConstants.ORDE_STATUS_2)||orderEntity.getOrde_status().equals(OrderConstants.ORDE_STATUS_3)||orderEntity.getOrde_status().equals(OrderConstants.ORDE_STATUS_4))){
                 return true;
             }
         }
         return false;
     }

     private void setOrderInfo(String authorization,CurrratesetorderEntity orderEntity){
         ParamsVo paramsVo = new ParamsVo();
         paramsVo.setAuthorization(authorization);
         //查詢員工信息
         Result sessionResult = peopleRegService.getEcosystemSession(paramsVo);
         Map resultMap = (Map) sessionResult.getData();
         if(resultMap == null){
             throw new RuntimeException("登录过期!");
         }
         Map currentStatusMap = (Map) resultMap.get("currentStatus");
         if(currentStatusMap == null){
             throw new RuntimeException("登录过期!");
         }
         Map employeeMap = (Map) currentStatusMap.get("currentStaff");
         if(employeeMap == null){
             throw new RuntimeException("登录过期!");
         }
         Map deptMap = (Map) currentStatusMap.get("depttreeEntity");
         if(deptMap == null){
             throw new RuntimeException("登录过期!");
         }
         Map enterpriseMap = (Map) currentStatusMap.get("currentEnterprise");
         if(enterpriseMap == null){
             throw new RuntimeException("登录过期!");
         }
         //orde_dept 制單部門、orde_date 制單時間、orde_status 單據狀態
         String orde_dept = deptMap.get("id").toString();
         //orde_applicant 製單人
         String orde_adduser = employeeMap.get("id").toString();
         //orde_duty 制單人崗位、
         String orde_duty = employeeMap.get("remp_post").toString();
         orderEntity.setOrde_dept(orde_dept);
         orderEntity.setOrde_duty(orde_duty);
         orderEntity.setOrde_adduser(orde_adduser);
         orderEntity.setOrde_applicant(orde_adduser);
         orderEntity.setOrde_applicant_post(orde_duty);
         orderEntity.setOrde_date(new Date());
         orderEntity.setOrde_status(OrderConstants.ORDE_STATUS_2);
         orderEntity.setEdmd_ente(enterpriseMap.get("id").toString());
         orderEntity.setCreuser(orde_adduser);
         orderEntity.setModuser(orde_adduser);
     }

    /**
     * 修改单据状态
     * @param orderEntity
     * @param orderStatus
     * @throws Exception
     */
     private void updateOrderStatus(CurrratesetorderEntity orderEntity, String orderStatus) throws Exception{
        orderEntity.setOrde_status(orderStatus);
        ormService.updateSelective(orderEntity);
     }

    /**
     * 审核完成后——添加
     * @param orderEntity 单据对象
     * @throws Exception
     */
     @Transactional(rollbackFor = Exception.class)
     public void addCurrRate(CurrratesetorderEntity orderEntity)throws Exception{
         if(null == orderEntity){
             return;
         }
         Calendar calendar = Calendar.getInstance();
         calendar.setTime(new Date());
         calendar.add(Calendar.DATE, 1);
         // 审核通过日期+1
         Date passDate = calendar.getTime();
         //创建CurrCurrRateSetaEntity集合，用于接收单据审核通过提交的数据
        List<CurrCurrRateSetaEntity> rateSetaEntities = new ArrayList<>();
        setRateEntityProperties(rateSetaEntities,orderEntity);
         //根据 币别、兑换币别查询审核通过的汇率集合
        if(rateSetaEntities.size() > 0){
            for (CurrCurrRateSetaEntity rateSetaEntity : rateSetaEntities) {
                Date now = new Date();
                //如果审核通过日期大于生效日期，则生效日期置为审核通过日期+1
                if(now.after(rateSetaEntity.getCurr_beg())){
                    rateSetaEntity.setCurr_beg(passDate);
                }
                // ①查询是否存在（A->B）的汇率——按生效日期倒序排序
                List<CurrCurrRateSetaEntity> oldRateEntities = qeuryOldCurrRate(rateSetaEntity);
                if (oldRateEntities != null && oldRateEntities.size() > 0){
                    //记录最后一个生效日期大于当前记录生效日期的汇率的位置
                    int moreThanCurrent = -1;
                    for (int i=0; i<oldRateEntities.size();i++) {
                        //④同时查询生效日期大于当前记录生效日期,若存在则取生效日期时间差最小的汇率，并置当前记录的结束时间为其生效日期
                        // 逻辑暂时改动-----------------------------------------
//                        if(oldRateEntities.get(i).getCurr_beg().getTime()>rateSetaEntity.getCurr_beg().getTime()){
//                            moreThanCurrent = i;
//                            continue;
//                        }
                        // 如果已经存在生效日期等于或晚于当前这条马上要生效的，那么要把之前存在的删除掉
                        if(oldRateEntities.get(i).getCurr_beg().getTime()>=rateSetaEntity.getCurr_beg().getTime()){
                            moreThanCurrent = i;
                            continue;
                        }
                        //③若存在则查询生效日期小于当前记录生效日期，则取生效日期时间差最小的汇率，,并置其结束日期为当前记录的生效日期
                        if (oldRateEntities.get(i).getCurr_beg().getTime()<rateSetaEntity.getCurr_beg().getTime()){
                            CurrCurrRateSetaEntity oldEntity = oldRateEntities.get(i);
                            oldEntity.setCurr_end(rateSetaEntity.getCurr_beg());
                            ormService.updateSelective(oldEntity);
                            //由于集合按生效日期 倒序排序，所以找到的第一个小于当前记录生效日期的数据就是在时间轴上最近的，所以不用继续循环
                            break;
                        }
                    }
                    // 逻辑暂时改动-----------------------------------------
//                    if(moreThanCurrent != -1){
//                        rateSetaEntity.setCurr_end(oldRateEntities.get(moreThanCurrent).getCurr_beg());
//                    }
                    if(moreThanCurrent != -1){
                        ormService.delete(CurrCurrRateSetaEntity.class, oldRateEntities.get(moreThanCurrent).getId());
                    }
                    ormService.insert(rateSetaEntity);
                }else{
                    //②若不存在则直接添加，不做其他处理；
                    ormService.insert(rateSetaEntity);
                }
            }
        }
     }



    /**
     * 审核完成后——修改
     * @param orderEntity
     * @throws Exception
     */
     @Transactional(rollbackFor = Exception.class)
     public void updateCurrRate(CurrratesetorderEntity orderEntity)throws Exception{
         if(null == orderEntity || orderEntity.getCrso_orde_set() == null || orderEntity.getCrso_orde_set().size() == 0){
             return;
         }
         List<CurrCurrRateSetaEntity> rateEntities = new ArrayList<>();
         setRateEntityProperties(rateEntities,orderEntity);
//          todo 判断生效日期是否小于当前，且失效日期大于当前
//          todo 是：new CurrCurrRateSetaEntity();
//             todo 修改当前汇率的失效日期为当日（或次日）
//             todo 判断是否存在生效日期大于当前日期的汇率
//             todo 是：设置新建汇率的失效日期为——生效日期大于当前汇率生效日期且紧邻汇率的生效日期前
//
//          todo 否：判断生效日期是否大于当前日期
//             todo 否：new RuntimeException("不能修改已生效汇率！")
//          todo 修改操作

         OrmParam ormParam = new OrmParam();
         SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
         // 获取当前日期
         Date now = format.parse(format.format(new Date()));
         Calendar calendar = Calendar.getInstance();
         calendar.setTime(now);
         calendar.add(Calendar.DATE, 1);
         // 审核通过日期
         Date passDate = calendar.getTime();
         for (CurrCurrRateSetaEntity rateEntity : rateEntities) {
             // 判断失效日期是否小于当前，即已经失效
//             if (rateEntity.getCurr_end() != null && rateEntity.getCurr_end().before(now)) {
//                 throw new RuntimeException("汇率已失效！");
//             }
             // 失效日期不为空，则不允许修改
             if (rateEntity.getCurr_end() != null) {
                 throw new RuntimeException("请勿修改生效汇率！");
             }
             String whereExp = OrmParam.and(ormParam.getEqualXML(BasicConst.PID,rateEntity.getPid()),
                     ormParam.getEqualXML(CurrRateConstant.CURR_CONV_CURR,rateEntity.getCurr_conv_curr()),
                     ormParam.getEqualXML(CurrRateConstant.CURR_BEG,rateEntity.getCurr_beg()));
             ormParam.setWhereExp(whereExp);
//             判断生效日期是否小于当前，且失效日期为空,即当前生效的汇率
             if (rateEntity.getCurr_beg().before(now) && rateEntity.getCurr_end() == null) {
                 // 查询当前正在修改的汇率
                 List<CurrCurrRateSetaEntity> list = ormService.selectBeanList(CurrCurrRateSetaEntity.class, ormParam);
                 if(list == null || list.size() == 0){
                     throw new RuntimeException("系统异常！");
                 }
                 CurrCurrRateSetaEntity current = list.get(0);
                 current.setCurr_end(passDate);
                 rateEntity.setCurr_beg(passDate);
                 ormService.insert(rateEntity);
                 ormService.updateSelective(current);

                 //    否则判断生效日期是否大于当前日期，即尚未生效
             }else if(rateEntity.getCurr_beg().after(now)){
                 ormService.updateSelective(rateEntity, ormParam);
             }
         }
     }

    /**
     * 设置汇率属性
     * @param rateSetaEntities
     * @param orderEntity
     */
     private void setRateEntityProperties(List<CurrCurrRateSetaEntity> rateSetaEntities,CurrratesetorderEntity orderEntity){
         RedisClusterUtils redisClusterUtils = new RedisClusterUtils(Constants.REDIS_NODES);
         if(orderEntity.getCrso_orde_set() != null && orderEntity.getCrso_orde_set().size() > 0){
             List<CrsoCrsoOrdeSetaEntity> voList = orderEntity.getCrso_orde_set();
             if(voList == null || voList.size() == 0){
                 return;
             }
             for (CrsoCrsoOrdeSetaEntity entity : voList) {
                 if(Integer.valueOf(redisClusterUtils.getValue(entity.getId())).equals(OrderConstants.OPERA_STATUS_PASS)) {
                     CurrCurrRateSetaEntity rateEntity = new CurrCurrRateSetaEntity();
                     rateEntity.setClassName("currency");
                     rateEntity.setCreuser(entity.getCreuser());
                     rateEntity.setModuser(entity.getModuser());
                     rateEntity.setCurr_conv_curr(entity.getCrsoo_conv_curr());
                     rateEntity.setCurr_beg(entity.getCrsoo_beg());
                     rateEntity.setCurr_conv_unit(entity.getCrsoo_conv_unit());
                     rateEntity.setCurr_end(entity.getCrsoo_end());
                     rateEntity.setCurr_rate(entity.getCrsoo_rate());
                     rateEntity.setCurr_rate_enable(String.valueOf(entity.getCrsoo_rate_enable()));
                     rateEntity.setCurr_remark(entity.getCrsoo_remark());
                     rateEntity.setPid(entity.getCrsoo_curr_id());
                     rateSetaEntities.add(rateEntity);
                 }
             }
         }
     }

    /**
     * 校验生效时间是否有效——生效时间大于今天
     * @param vo
     * @return
     */
    private boolean isBegEffective(CrsoOrdeSetVO vo, String operaType) {
         if(vo.getCrsoBeg() == null){
             return false;
         }
         //如果生效日期和失效日期都不为空，且生效日期大于失效日期，返回false
         if(vo.getCrsoEnd() != null && vo.getCrsoBeg().after(vo.getCrsoEnd())){
            return false;
         }
         // 新增时校验生效时间是否大于当前日期，否则不做生效日期的校验
         if (operaType.equals(OrderConstants.ADD)) {
            return new Date().before(vo.getCrsoBeg());
         }else {
             return true;
         }
         //如果 当前日期小于生效日期返回true
//         return new Date().before(vo.getCrsoBeg()) && operaType.equals(OrderConstants.ADD);
    }

    /**
     * 根据币别、兑换币别查询已经审核通过的汇率集合
     * @param rateSetaEntity
     * @return
     * @throws Exception
     */
    private List<CurrCurrRateSetaEntity> qeuryOldCurrRate(CurrCurrRateSetaEntity rateSetaEntity) throws Exception {
        List<String> columns = Arrays.asList(BasicConst.ID,BasicConst.CLASSNAME,BasicConst.PID,CurrRateConstant.CURR_CONV_CURR,CurrRateConstant.CURR_CONV_UNIT,
                CurrRateConstant.CURR_RATE,CurrRateConstant.CURR_BEG,CurrRateConstant.CURR_END,CurrRateConstant.CURR_REMARK);
        columns = new ArrayList<>(columns);
        OrmParam ormParam = new OrmParam();
        String whereExp = OrmParam.and(ormParam.getEqualXML(BasicConst.PID,rateSetaEntity.getPid()));
        if(StringUtils.isNotEmpty(rateSetaEntity.getCurr_conv_curr())){
            whereExp = OrmParam.and(ormParam.getEqualXML(CurrRateConstant.CURR_CONV_CURR,rateSetaEntity.getCurr_conv_curr()),whereExp);
        }
        ormParam.setColumns(columns);
        ormParam.setWhereExp(whereExp);
        ormParam.setOrderExp(SQLSortEnum.DESC,CurrRateConstant.CURR_BEG);
        List<CurrCurrRateSetaEntity> oldRateEntities = ormService.selectBeanList(CurrCurrRateSetaEntity.class,ormParam);
        return oldRateEntities;
    }

    /**
     * 拼接查询条件
     * @param entity
     * @return
     */
    private OrmParam setQueryConditioiin(CurrCurrRateSetaEntity entity) {
//        List<String> columns = new ArrayList<>(Arrays.asList(CurrRateConstant.CURR_CONV_CURR,CurrRateConstant.CURR_CONV_UNIT,
//                CurrRateConstant.CURR_RATE,CurrRateConstant.CURR_BEG,CurrRateConstant.CURR_END,CurrRateConstant.CURR_REMARK));
//        Utils.setBaseQueryColums(columns);
        OrmParam ormParam = new OrmParam();
//        ormParam.setColumns(columns);
        String whereExp = "";
        if(StringUtils.isNotEmpty(entity.getPid())){
            whereExp = OrmParam.and(ormParam.getEqualXML(BasicConst.PID,entity.getPid()),whereExp);
        }
        if(StringUtils.isNotEmpty(entity.getCurr_conv_curr())){
            whereExp = OrmParam.and(ormParam.getEqualXML(CurrRateConstant.CURR_CONV_CURR,entity.getCurr_conv_curr()),whereExp);
        }
        if(!StringUtil.isNullOrEmpty(entity.getCurr_rate_enable())){
            whereExp = OrmParam.and(ormParam.getEqualXML(CurrRateConstant.CURR_RATE_ENABLE,entity.getCurr_rate_enable()),whereExp);
        }
        if(entity.getCurr_beg() != null){
            whereExp = OrmParam.and(ormParam.getGreaterThanAndEqualXML(CurrRateConstant.CURR_BEG,entity.getCurr_beg()),whereExp);
        }
        if(entity.getCurr_end() != null){
            whereExp = OrmParam.and(ormParam.getLessThanAndEqualXML(CurrRateConstant.CURR_END,entity.getCurr_end()),whereExp);
        }
        ormParam.setWhereExp(whereExp);
        return ormParam;
    }

    /**
     *
     * @param vo 待提交的数据
     * @param operaType 操作类型（新增、修改、删除）
     * @return
     */
    private boolean isExistCurrRate(CrsoOrdeSetVO vo,String operaType) throws Exception {
        OrmParam ormParam = new OrmParam();
        String whereExp = OrmParam.and(ormParam.getEqualXML(BasicConst.PID,vo.getCrsoCurrId()));
        whereExp = OrmParam.and(ormParam.getEqualXML(CurrCurrRateSetaProperty.CURR_CONV_CURR,vo.getCrsoConvCurr()),whereExp);
        whereExp = OrmParam.and(ormParam.getEqualXML(CurrCurrRateSetaProperty.CURR_BEG,vo.getCrsoBeg()),whereExp);
        ormParam.setWhereExp(whereExp);
        long count = ormService.count(CurrCurrRateSetaEntity.class,ormParam);
        return count > 0 && operaType.equals(OrderConstants.ADD);
    }

    /**
     *
     * @param ordeSetVO
     * @param operaType
     * @return
     * @throws Exception
     */
    private boolean isUpdateBegOrEnd(CrsoOrdeSetVO ordeSetVO ,String operaType)throws Exception {
        if (operaType.equals(OrderConstants.UPDATE)){
            CurrCurrRateSetaEntity entity = ormService.load(CurrCurrRateSetaEntity.class,ordeSetVO.getId());
            if(entity == null ){
                return false;
            }
            if(entity.getCurr_beg().equals(ordeSetVO.getCrsoBeg()) && entity.getCurr_end().equals(ordeSetVO.getCrsoEnd())){
                return true;
            }
        }
        return false;
    }

    /**
     * 移除集合中的重复汇率（币别和兑换币别同时一致）的数据
     * @param voList
     */
    private boolean isRepeatCrsoOrde(List<CrsoOrdeSetVO> voList){
        // 临时记录
        List<Integer> indexList = new ArrayList<>(voList.size());
        for(int i=0; i<voList.size();i++){
            for (CrsoOrdeSetVO ordeSetVO : voList) {
                if(voList.get(i).getCrsoCurrId().equals(ordeSetVO.getCrsoCurrId()) ){
                    if(voList.get(i).getCrsoConvCurr().equals(ordeSetVO.getCrsoConvCurr())){
                        indexList.add(i);
                    }
                }
            }
        }
        return indexList.size() > voList.size();
    }

    /**
     * 查询制单人相关中文信息
     * @param voList
     */
    private void qryAddUserZHInfo(List<CurrRateSetOrderVO> voList) throws Exception {
        // 临时存储 制单人id
        HashSet<String> addUserIdList = new HashSet<>();
        // 临时存储制单人部门id
        HashSet<String> addUserDeptIdList = new HashSet<>();
        // 临时存储制单人岗位id
        HashSet<String> addUserDutyIdList = new HashSet<>();

        for (CurrRateSetOrderVO parameterOrderVO : voList) {
            addUserIdList.add(parameterOrderVO.getOrdeAdduser());
            addUserDeptIdList.add(parameterOrderVO.getOrdeDept());
            addUserDutyIdList.add(parameterOrderVO.getOrdeDuty());
        }
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(Arrays.asList(BasicConst.ID,EmployeeProperty.REMP_NAME));
        ormParam.setWhereExp(ormParam.getInXML(BasicConst.ID, addUserIdList.toArray()));
        // 员工
        List<EmployeeEntity> employeeEntityList = ormService.selectBeanList(EmployeeEntity.class,ormParam);
        // 岗位
        OrmParam ormParam1 = new OrmParam();
        ormParam1.setColumns(Arrays.asList(BasicConst.ID,JobpositionProperty.RPOS_NAME));
        ormParam1.setWhereExp(ormParam1.getInXML(BasicConst.ID, addUserDutyIdList.toArray()));
        List<JobpositionEntity> jobpositionEntityList = ormService.selectBeanList(JobpositionEntity.class, ormParam1);
        // 部门
        OrmParam ormParam2 = new OrmParam();
        ormParam2.setColumns(Arrays.asList(BasicConst.ID,DepttreeProperty.MDEP_NAME));
        ormParam2.setWhereExp(ormParam2.getInXML(BasicConst.ID, addUserDeptIdList.toArray()));
        List<DepttreeEntity> depttreeEntities = ormService.selectBeanList(DepttreeEntity.class, ormParam2);
        for (CurrRateSetOrderVO parameterOrderVO : voList) {
            if(employeeEntityList != null && employeeEntityList.size() > 0){
                for (EmployeeEntity employeeEntity : employeeEntityList) {
                    if(StringUtil.isEqual(parameterOrderVO.getOrdeAdduser(), employeeEntity.getId())){
                        parameterOrderVO.setOrdeAdduserName(employeeEntity.getRemp_name());
                    }
                }
            }
            if (jobpositionEntityList != null && jobpositionEntityList.size() > 0){
                for (JobpositionEntity jobpositionEntity : jobpositionEntityList) {
                    if (StringUtil.isEqual(parameterOrderVO.getOrdeDuty(), jobpositionEntity.getId())) {
                        parameterOrderVO.setOrdeDutyName(jobpositionEntity.getRpos_name());
                    }
                }
            }
            if (depttreeEntities != null && depttreeEntities.size() > 0){
                for (DepttreeEntity depttreeEntity : depttreeEntities) {
                    if(StringUtil.isEqual(parameterOrderVO.getOrdeDept(), depttreeEntity.getId())){
                        parameterOrderVO.setOrdeDeptName(depttreeEntity.getMdep_name());
                    }
                }
            }
        }
    }
}
