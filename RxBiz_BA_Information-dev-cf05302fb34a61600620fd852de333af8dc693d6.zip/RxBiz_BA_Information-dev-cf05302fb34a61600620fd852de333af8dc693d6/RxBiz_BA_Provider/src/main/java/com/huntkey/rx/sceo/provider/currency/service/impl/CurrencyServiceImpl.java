package com.huntkey.rx.sceo.provider.currency.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.github.tobato.fastdfs.domain.MateData;
import com.github.tobato.fastdfs.domain.StorePath;
import com.github.tobato.fastdfs.service.DefaultFastFileStorageClient;
import com.github.tobato.fastdfs.service.FastFileStorageClient;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.CurrencyProperty;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.edm.entity.CurrCurrRateSetaEntity;
import com.huntkey.rx.edm.entity.CurrencyEntity;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.currency.CurrencyConstant;
import com.huntkey.rx.sceo.common.model.currency.vo.CurrencyVO;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.currency.service.CurrencyService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.swing.text.html.parser.Entity;
import java.io.IOException;
import java.io.InputStream;
import java.util.*;
import java.util.concurrent.*;

/**
 * @author liucs
 * @date 2018-4-2 17:25:55
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class CurrencyServiceImpl implements CurrencyService {
    @Autowired
    private OrmService ormService;
    @Autowired
    private ParameterService parameterService;
    @Autowired
    private FastFileStorageClient defaultFastFileStorageClient;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String insert(CurrencyVO entity) throws Exception {
        // 判断是否标准系统
        boolean isStandardSystem = parameterService.isStandardSystem();
        if (!isStandardSystem) {
            entity.setCurrIsStandard(Constants.NOT_STANDARD);
        }
        //货币代码必填
        if(StringUtil.isNullOrEmpty(entity.getCurrCode())){
            throw new RuntimeException("货币代码为空");
        }
        if(StringUtil.isNullOrEmpty(entity.getCurrSymbol())){
            throw new RuntimeException("货币符号为空");
        }
        //系统编码和名称必填、唯一
        if(StringUtil.isNullOrEmpty(entity.getCurrSysCode().trim())){
            throw new RuntimeException("系统编码为空");
        }
        if(StringUtil.isNullOrEmpty(entity.getCurrName().trim())){
            throw new RuntimeException("货币名称为空");
        }
        if(isExistSysCode(entity)){
            throw new RuntimeException("系统代码重复!");
        }
        if(isExisCurrName(entity)){
            throw new RuntimeException("币别名称重复!");
        }
        CurrencyEntity currencyEntity = JSONObject.parseObject(JSONObject.toJSONString(entity), CurrencyEntity.class);
        return ormService.insert(currencyEntity).toString();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(String currentUserId, String id) throws Exception {
        //修改主表以及子表对应数据的维护人信息
        CurrencyEntity cEntity = new CurrencyEntity();
        cEntity.setModuser(currentUserId);
        cEntity.setId(id);
        ormService.updateSelective(cEntity);
        CurrCurrRateSetaEntity crsEntity = new CurrCurrRateSetaEntity();
        crsEntity.setModuser(currentUserId);
        crsEntity.setPid(id);
        OrmParam crsOrmparm = new OrmParam();
        String crsWhereExp = OrmParam.and(crsOrmparm.getEqualXML(BasicConst.PID,id));
        crsOrmparm.setWhereExp(crsWhereExp);
        ormService.updateSelective(crsEntity,crsOrmparm);
        //删除主表以及子表对应的数据
        ormService.delete(CurrCurrRateSetaEntity.class,crsWhereExp);
        return ormService.delete(CurrencyEntity.class,id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(CurrencyVO entity) throws Exception {
        //货币代码必填
        if(StringUtil.isNullOrEmpty(entity.getCurrCode())){
            throw new RuntimeException("货币代码为空");
        }
        if(StringUtil.isNullOrEmpty(entity.getCurrSymbol())){
            throw new RuntimeException("货币符号为空");
        }
        //系统编码和名称必填、唯一
        if(StringUtil.isNullOrEmpty(entity.getCurrSysCode().trim())){
            throw new RuntimeException("系统编码为空");
        }
        if(StringUtil.isNullOrEmpty(entity.getCurrName().trim())){
            throw new RuntimeException("货币名称为空");
        }
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(CurrencyConstant.CURR_SYS_CODE,entity.getCurrSysCode().trim()));
        List<CurrencyEntity> entityList = ormService.selectBeanList(CurrencyEntity.class, ormParam);
        if(entityList != null && entityList.size() > 0){
            if(entityList.size() > 1 || !entityList.get(0).getId().equals(entity.getId())){
                throw new RuntimeException("系统编码重复!");
            }
        }
        ormParam.reset();
        ormParam.setWhereExp(ormParam.getEqualXML(CurrencyConstant.CURR_NAME,entity.getCurrName().trim()));
        entityList = ormService.selectBeanList(CurrencyEntity.class, ormParam);
        if(entityList != null && entityList.size() > 0){
            if(entityList.size() > 1 || !entityList.get(0).getId().equals(entity.getId())){
                throw new RuntimeException("币别名称重复!");
            }
        }
        CurrencyEntity currencyEntity = JSONObject.parseObject(JSONObject.toJSONString(entity), CurrencyEntity.class);
        return ormService.update(currencyEntity);
    }

    @Override
    public CurrencyVO queryById(String id) throws Exception {
        CurrencyEntity entity = ormService.load(CurrencyEntity.class,id);
        if(entity == null){
            return null;
        }
        CurrencyVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity),CurrencyVO.class);
        vo.setCreUserName(Utils.getUserNameByUserId(entity.getCreuser(),ormService));
        vo.setModUserName(Utils.getUserNameByUserId(entity.getModuser(),ormService));
        return vo;
    }

    @Override
    public Pagination<CurrencyVO> list(String currCode,String currSysCode,String currName,String currEnable, Integer pageSize, Integer pageNum) throws Exception {
        OrmParam ormParam = setQueryCondition(currCode,currSysCode,currName,currEnable);
        ormParam.setPageSize(pageSize);
        ormParam.setPageNo(pageNum);
        Pagination<CurrencyEntity> pagination = ormService.selectPagedBeanList(CurrencyEntity.class,ormParam);
        if(pagination == null || pagination.getTotal() == 0){
            return null;
        }
        List<CurrencyVO> voList = JSONObject.parseArray(JSONObject.toJSONString(pagination.getList()),CurrencyVO.class);
        for (CurrencyVO currencyVO : voList) {
            currencyVO.setModUserName(Utils.getUserNameByUserId(currencyVO.getModuser(),ormService));
            currencyVO.setCreUserName(Utils.getUserNameByUserId(currencyVO.getCreuser(),ormService));
        }
        return new Pagination<CurrencyVO>(voList,pageNum,pageSize,pagination.getTotal());
    }

    /**
     * 查询所有币别
     * @return
     * @throws Exception
     */
    @Override
    public List<CurrencyVO> allCurrencies() throws Exception {
        OrmParam ormParam = setQueryCondition(null,null,null,null);
        List<CurrencyEntity> entityList = ormService.selectBeanList(CurrencyEntity.class,ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        List<CurrencyVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),CurrencyVO.class);
        return voList;
    }

    @Override
    public CurrencyVO queryObjectByName(String name) throws Exception {
        //查询列名
        List<String> columns = new ArrayList<String>(Arrays.asList(CurrencyConstant.CURR_CODE,CurrencyConstant.CURR_NAME,CurrencyConstant.CURR_DESC));
        Utils.setBaseQueryColums(columns);
        columns.remove("pid");
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columns);
        String whereEpx = OrmParam.and(ormParam.getEqualXML(CurrencyConstant.CURR_NAME,name));
        ormParam.setWhereExp(whereEpx);
        List<CurrencyEntity> entityList = ormService.selectBeanList(CurrencyEntity.class,ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        CurrencyVO currencyVO = JSONObject.parseObject(JSONObject.toJSONString(entityList.get(0)),CurrencyVO.class);
        currencyVO.setModUserName(Utils.getUserNameByUserId(currencyVO.getModuser(),ormService));
        currencyVO.setCreUserName(Utils.getUserNameByUserId(currencyVO.getCreuser(),ormService));
        return currencyVO;
    }

    @Override
    public List<CurrencyVO> queryObjects(String currEnable,String currName) throws Exception {
        OrmParam ormParam = setQueryCondition(null,null,currName,currEnable);

        List<CurrencyEntity> entityList = ormService.selectBeanList(CurrencyEntity.class,ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        List<CurrencyVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),CurrencyVO.class);
        for (CurrencyVO currencyVO : voList) {
            currencyVO.setModUserName(Utils.getUserNameByUserId(currencyVO.getModuser(),ormService));
            currencyVO.setCreUserName(Utils.getUserNameByUserId(currencyVO.getCreuser(),ormService));
        }
        return voList;
    }

    /**
     * 仅用于币别文件上传，并且需保证文件名称和币别描述相同
     * 建议单文件长传，多文件可能会出现异常
     * @param files
     * @return
     * @throws Exception
     */
    @Override
    @Transactional
    public String uploadImage(MultipartFile... files) throws Exception {
        ExecutorService singleThreadExecutor = Executors.newFixedThreadPool(10);
        List<CurrencyEntity> list = new ArrayList<>(files.length);
        CurrencyEntity entity ;
        for (MultipartFile file : files) {
            String fullName = file.getOriginalFilename();
            OrmParam ormParam = new OrmParam();
            ormParam.setWhereExp(ormParam.getEqualXML(CurrencyProperty.CURR_DESC, fullName.substring(0,fullName.lastIndexOf("."))));
            List<CurrencyEntity> entityList = ormService.selectBeanList(CurrencyEntity.class, ormParam);
            if(entityList!=null && entityList.size()>0&& StringUtils.isEmpty(entityList.get(0).getCurr_flag_icon())){
                String path = upload(file).getFullPath();
                if(path!=null ){
                    entity = new CurrencyEntity();
                    entity.setCurr_flag_icon(path);
                    entity.setCurr_desc(fullName.substring(0,fullName.lastIndexOf(".")));
                    list.add(entity);
                }
            }
        }
//        singleThreadExecutor.shutdown();
        int count=0;
        OrmParam ormParam = new OrmParam();
        if(list == null || list.size() ==0){
            return "0";
        }
        for (CurrencyEntity currencyEntity : list) {
            ormParam.setWhereExp(ormParam.getEqualXML(CurrencyProperty.CURR_DESC, currencyEntity.getCurr_desc()));
            count += ormService.updateSelective(currencyEntity, ormParam);
        }
        return Integer.toString(count);
    }



    public StorePath upload(MultipartFile upLoadFile) {
        InputStream inputStream = null;
        try {
            inputStream = upLoadFile.getInputStream();
            long fileSize = inputStream.available();
            String fileExtName = "jpg";
            Set<MateData> metaDataSet = new HashSet<MateData>();
            metaDataSet.add(new MateData("width", "800"));
            metaDataSet.add(new MateData("bgcolor", "FFFFFF"));
            metaDataSet.add(new MateData("author", "FirstMateData"));
            StorePath path = defaultFastFileStorageClient.uploadImageAndCrtThumbImage(inputStream, fileSize, fileExtName, metaDataSet);
            return path;
        } catch (IOException e) {
            throw new RuntimeException(e);
        }finally {
            try {
                inputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    /**
     * 拼接查询参数
     * @param currCode 代码
     * @param currSysCode 名称
     * @param currEnable 启用/禁用
     * @param currName 名称
     * @return 返回ormparm
     */
    private OrmParam setQueryCondition(String currCode,String currSysCode,String currName, String currEnable){
        //查询列名
        List<String> columns = new ArrayList<>(Arrays.asList(CurrencyConstant.CURR_CODE,CurrencyConstant.CURR_NAME,CurrencyConstant.CURR_DESC,CurrencyConstant.CURR_ENABLE,CurrencyConstant.CURR_SYMBOL,CurrencyConstant.CURR_SYS_CODE,CurrencyConstant.CURR_IS_STANDARD, CurrencyProperty.CURR_FLAG_ICON));
        Utils.setBaseQueryColums(columns);
        columns.remove("pid");
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columns);
        String whereExp = "";
        if(StringUtils.isNotEmpty(currCode) && StringUtils.isNotEmpty(currCode.trim())){
            whereExp = OrmParam.or(ormParam.getMatchMiddleXML(CurrencyConstant.CURR_CODE, currCode.trim()));
        }
        if(StringUtils.isNotEmpty(currEnable)){
            whereExp = OrmParam.and(ormParam.getEqualXML(CurrencyConstant.CURR_ENABLE,currEnable.trim()),whereExp);
        }
        if(StringUtils.isNotEmpty(currSysCode) && StringUtils.isNotEmpty(currSysCode.trim())){
            whereExp = OrmParam.and(ormParam.getMatchMiddleXML(CurrencyConstant.CURR_SYS_CODE,currSysCode.trim()),whereExp);
        }
        if(StringUtils.isNotEmpty(currName) && StringUtils.isNotEmpty(currName.trim())){
            whereExp = OrmParam.and(ormParam.getMatchMiddleXML(CurrencyConstant.CURR_NAME,currName.trim()),whereExp);
        }
        ormParam.setWhereExp(whereExp);
        ormParam.setOrderExp(SQLSortEnum.ASC, CurrencyProperty.CURR_SYS_CODE);
        return ormParam;
    }

    /**
     * 币别代码重复校验
     * @param vo
     * @return
     */
    private boolean isExistSysCode(CurrencyVO vo) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(CurrencyConstant.CURR_SYS_CODE,vo.getCurrSysCode().trim()));
        long count = ormService.count(CurrencyEntity.class,ormParam);
        return count > 0;
    }

    /**
     * 币别名称重复校验
     * @param vo
     * @return
     * @throws Exception
     */
    private boolean isExisCurrName(CurrencyVO vo) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(CurrencyConstant.CURR_NAME,vo.getCurrName().trim()));
        long count = ormService.count(CurrencyEntity.class,ormParam);
        return count > 0;
    }
}
