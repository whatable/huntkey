package com.huntkey.rx.sceo.provider.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.provider.feign.hystrix.FormulaHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Created by  licj on 2017/7/20.
 */
@FeignClient(value = "formula-provider",url="10.3.98.153:4772", fallback = FormulaHystrix.class)
//@FeignClient(value = "formula-provider", fallback = FormulaHystrix.class)
public interface FormulaProvider {


    /**
     * 解析属性公式
     * @param
     * @return
     */

    @RequestMapping(value = "/relatedConditions/relCondConfDataByPrplIdForClass/{prplId}/{dataId}", method = RequestMethod.GET)
    Result relCondConfDataByPrplIdForClass(@PathVariable(value = "prplId")String prplId,@PathVariable(value = "dataId")String dataId);

    @RequestMapping(value = "/formula/calcPPI",  method = RequestMethod.POST)
    Result calcPPI(@RequestBody Map<String,Object> params);


}
