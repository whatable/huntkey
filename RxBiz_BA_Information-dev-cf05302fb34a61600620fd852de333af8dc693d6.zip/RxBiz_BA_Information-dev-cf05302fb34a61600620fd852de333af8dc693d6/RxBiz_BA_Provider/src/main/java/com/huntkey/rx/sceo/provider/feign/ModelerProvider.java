package com.huntkey.rx.sceo.provider.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.provider.feign.hystrix.ModelerHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author zhoucj
 * @date 2017/11/20
 */
//@FeignClient(value = "modeler-provider", url = "10.3.98.154:2002", fallback = ModelerHystrix.class)
@FeignClient(value = "modeler-provider", fallback = ModelerHystrix.class)
@Service
public interface ModelerProvider {
    @RequestMapping(value = "/classes/getIdByEdmcCode",method = RequestMethod.GET)
    Result getIdByEdmcCode(@RequestParam(value = "edmcCode") String edmcCode);

    @RequestMapping(value = "/classes/{id}", method = RequestMethod.GET)
    Result getClassById(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/classes/{id}/properties", method = RequestMethod.GET)
    Result getProperties(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/classes/{id}/fatherProperties", method = RequestMethod.GET)
    Result getFatherProperties(@PathVariable(value = "id") String id);

    @RequestMapping(value = "/classes/{id}/propsAndParentProps", method = RequestMethod.GET)
    Result getPropsAndParentProps(@PathVariable(value = "id") String id);

    /**
     * 根据类id获取类名，多个类id用逗号隔开
     * @param ids
     * @return
     */
    @RequestMapping(value = "/classes/classNames", method = RequestMethod.GET)
    Result getClassNamesByIds(@RequestParam(value = "ids") String ids);

    /**
     * 根据属性的数据类型获取属性的类id
     * @param dataType
     * @return
     */
    @RequestMapping(value = "/properties/edmcIds/{dataType}", method = RequestMethod.GET)
    Result getEdmcIdsByDataType(@PathVariable(value = "dataType") String dataType);

    /**
     * 根据类名获取枚举属性的数据类型，多个数据类型间用逗号隔开
     * @param className
     * @return
     */
    @RequestMapping(value = "/properties/edmpDataTypes/{className}", method = RequestMethod.GET)
    Result getInfoCodes(@PathVariable(value = "className") String className);

    /**
     * 根据id获取属性
     * @param id
     * @return
     */
    @RequestMapping(value = "/properties/{id}", method = RequestMethod.GET)
    Result getProperty(@PathVariable(value = "id") String id);


    /**
     * 根据属性名模糊查询属性id集合
     * @param edmpName
     * @return
     */
    @RequestMapping(value = "/properties/edmpIds", method = RequestMethod.GET)
    Result selectEdmpIdsByEdmpName(@RequestParam(value = "edmpName") String edmpName);

    /**
     * 根据类名模糊查询类id集合
     * @param className
     * @return
     */
    @RequestMapping(value = "/classes/classIds", method = RequestMethod.GET)
    public Result selectClassIdsByClassName(@RequestParam(value = "className") String className);
}
