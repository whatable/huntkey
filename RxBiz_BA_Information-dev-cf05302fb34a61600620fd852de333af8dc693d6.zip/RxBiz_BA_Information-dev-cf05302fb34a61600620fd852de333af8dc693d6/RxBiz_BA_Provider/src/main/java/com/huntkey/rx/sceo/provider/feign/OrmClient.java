package com.huntkey.rx.sceo.provider.feign;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.provider.feign.hystrix.OrmHystrix;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author licj
 * @date 2017/7/20
 */
@FeignClient(value = "serviceCenter-provider", url = "10.3.98.155:2008", fallback = OrmHystrix.class)
public interface OrmClient {

    @RequestMapping(value = "/servicecenter/find", method = RequestMethod.POST)
    Result find(@RequestBody String data);

    @RequestMapping(value = "/servicecenter/load", method = RequestMethod.POST)
    Result load(@RequestBody String data);

    @RequestMapping(value = "/servicecenter/update",method = RequestMethod.POST)
    Result update(@RequestBody String data);

    @RequestMapping(value = "/servicecenter/add", method = RequestMethod.POST)
    Result add(@RequestBody String data);

    @RequestMapping(value = "/servicecenter/delete", method = RequestMethod.POST)
    Result delete(@RequestBody String data);

    @RequestMapping(value = "/servicecenter/count", method = RequestMethod.POST)
    Result count(@RequestBody String data);
}
