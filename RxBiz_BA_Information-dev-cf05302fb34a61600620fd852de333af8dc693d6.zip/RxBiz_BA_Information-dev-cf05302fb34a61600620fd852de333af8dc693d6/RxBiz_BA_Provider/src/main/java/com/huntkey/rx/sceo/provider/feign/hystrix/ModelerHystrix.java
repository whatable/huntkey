package com.huntkey.rx.sceo.provider.feign.hystrix;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import org.springframework.stereotype.Service;

/**
 * Created by zhoucj on 2017/11/20.
 */
@Service
public class ModelerHystrix implements ModelerProvider {

    @Override
    public Result getIdByEdmcCode(String edmcCode){
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getClassNamesByIds(String ids) {
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getEdmcIdsByDataType(String dataType) {
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getInfoCodes(String className) {
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getProperty(String id) {
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result selectEdmpIdsByEdmpName(String edmpName) {
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result selectClassIdsByClassName(String className) {
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getClassById(String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getFatherProperties(String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getProperties(String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }

    @Override
    public Result getPropsAndParentProps(String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_ERROR);
        result.setErrMsg("Modeler-Provider调用服务降级处理逻辑！");
        return result;
    }
}
