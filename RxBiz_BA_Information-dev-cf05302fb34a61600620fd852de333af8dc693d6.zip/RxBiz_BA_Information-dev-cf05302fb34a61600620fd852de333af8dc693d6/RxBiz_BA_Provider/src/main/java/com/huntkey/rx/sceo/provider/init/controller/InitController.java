package com.huntkey.rx.sceo.provider.init.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.provider.init.service.InitService;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController()
@RequestMapping(value = "/init")
public class InitController {
    private static Logger logger = LoggerFactory.getLogger(InitController.class);
    @Autowired
    private InitService initService;

    @RequestMapping(value = "/initEnterprise", method = RequestMethod.POST)
    public Result initParkInfo(@RequestBody Map<String,Object> map){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            initService.initEnterprise(map);
        }catch (Exception e){
            logger.info("init/initEnterprise:", e.getMessage());
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }
}
