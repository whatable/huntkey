package com.huntkey.rx.sceo.provider.init.service;

import java.util.Map;

public interface InitService {

    void initEnterprise(Map<String, Object> map)throws Exception;
}
