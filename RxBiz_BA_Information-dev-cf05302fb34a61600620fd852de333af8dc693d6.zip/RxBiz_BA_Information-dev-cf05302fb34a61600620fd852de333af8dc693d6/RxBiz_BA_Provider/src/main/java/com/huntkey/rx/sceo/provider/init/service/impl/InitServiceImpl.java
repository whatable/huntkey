package com.huntkey.rx.sceo.provider.init.service.impl;

import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.EnterpriseProperty;
import com.huntkey.rx.edm.constant.ParkProperty;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.init.service.InitService;
import com.huntkey.rx.sceo.provider.period.service.PeriodGeneratingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class InitServiceImpl implements InitService {
    private static Logger logger = LoggerFactory.getLogger(InitServiceImpl.class);
   @Autowired
   private PeriodGeneratingService periodGeneratingService;
    @Autowired
    private OrmService ormService;
    @Override
    public void initEnterprise(Map<String, Object> map) throws Exception {
        // 初始化园区信息
        initPark(map);
        // 初始化周期前删除所有周期数据
//        String sql = "delete from period";
//        ormService.getDataBySql(sql);
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML("is_del", 0));
        logger.info("准备清理周期表数据。。。");
        ormService.delete(PeriodEntity.class, ormParam);
        // 初始化周期
        logger.info("准备进行周期信息初始化。。。");
        periodGeneratingService.generate(map.get("login_user").toString(),2000,100,2,null,null,null,null,null,null,null,null);
    }

    /**
     * 初始化园区信息
     */
    private void initPark(Map<String, Object> map) throws Exception {
        String rpakName = map.get(EnterpriseProperty.ENTE_NAME_CN) == null ? null : map.get(EnterpriseProperty.ENTE_NAME_CN).toString();
        String rpakCode = map.get(ParkProperty.RPAK_CODE) == null ? null : map.get(ParkProperty.RPAK_CODE).toString();
        String rpakProv = map.get(EnterpriseProperty.ENTE_ADDRP) == null ? null : map.get(EnterpriseProperty.ENTE_ADDRP).toString();
        String rpakCity = map.get(EnterpriseProperty.ENTE_ADDRC) == null ? null : map.get(EnterpriseProperty.ENTE_ADDRC).toString();
        String rpakDist = map.get(EnterpriseProperty.ENTE_ADDRL) == null ? null : map.get(EnterpriseProperty.ENTE_ADDRL).toString();
        String rpakAddr = map.get(EnterpriseProperty.ENTE_ADDR) == null ? null : map.get(EnterpriseProperty.ENTE_ADDR).toString();
        String loginUser = map.get("login_user") == null ? null : map.get("login_user").toString();
        if(StringUtil.isNullOrEmpty(rpakName) || StringUtil.isNullOrEmpty(rpakProv)
                || StringUtil.isNullOrEmpty(rpakCity) || StringUtil.isNullOrEmpty(rpakAddr)){
            throw new RuntimeException("缺失初始化信息！");
        }
        if(StringUtil.isNullOrEmpty(rpakCode)){
            rpakCode = "DPK";
        }
        ParkEntity parkEntity = new ParkEntity();
        parkEntity.setEdmd_class("park");
        parkEntity.setCreuser(loginUser);
        parkEntity.setModuser(loginUser);
        parkEntity.setRpak_name(rpakName);
        parkEntity.setRpak_code(rpakCode);
        parkEntity.setRpak_addr_prov(rpakProv);
        parkEntity.setRpak_addr_city(rpakCity);
        parkEntity.setRpak_addr_dist(rpakDist);
        parkEntity.setRpak_addr(rpakAddr);
        parkEntity.setRpak_seq(1);
        parkEntity.setRpak_isdefault(1);
        logger.info("插入初始化园区信息==》", parkEntity);
        ormService.insertSelective(parkEntity);
    }
}
