package com.huntkey.rx.sceo.provider.measureunit.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.MeasureunitEntity;
import com.huntkey.rx.sceo.provider.measureunit.service.MeasureunitManageService;

/**
 *
 * @author zhoucj
 * @date 2017/12/5
 */
@RestController
@RequestMapping(value = "/measureunit")
public class MeasureunitmanageController {
	@Autowired
	private MeasureunitManageService measureunitManageService;

	/**
	 * 保存计量对象和计量单位
	 *
	 * @param measureunitEntity
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST)
	public Result save(@RequestBody MeasureunitEntity measureunitEntity) throws Exception {
		Result result = new Result();

		String retStr = measureunitManageService.objNameCheck(measureunitEntity.getMeas_obj(),
				measureunitEntity.getId());
		if (!StringUtil.isNullOrEmpty(retStr)) {
			result.setRetCode(Result.RECODE_VALIDATE_ERROR);
			result.setData(retStr);
			return result;
		}

		retStr = measureunitManageService.unitCheck(measureunitEntity.getMeas_define_set());
		if (!StringUtil.isNullOrEmpty(retStr)) {
			result.setRetCode(Result.RECODE_VALIDATE_ERROR);
			result.setData(retStr);
			return result;
		}

		result.setData(measureunitManageService.save(measureunitEntity));
		return result;
	}

	/**
	 * 删除计量单位
	 *
	 * @param ids
	 *            计量单位id，多个id用逗号隔开
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/unit", method = RequestMethod.DELETE)
	public Result deleteUnit(@RequestParam String ids) throws Exception {
		Result result = new Result();
		if (!StringUtil.isNullOrEmpty(ids)) {
			result.setData(measureunitManageService.delete(ids.split(",")));
		}
		return result;
	}

	/**
	 * 删除计量对象
	 *
	 * @param id
	 *            计量对象id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/object/{id}", method = RequestMethod.DELETE)
	public Result delete(@PathVariable(value = "id") String id) throws Exception {
		Result result = new Result();
		result.setData(measureunitManageService.delete(id));
		return result;
	}

	/**
	 * 查询接口
	 *
	 * @param symbol
	 *            单位符号
	 * @param objName
	 *            计量对象名称
	 * @param baseName
	 *            基准单位名称
	 * @param isStand
	 *            是否标准单位
	 * @param enable
	 *            状态
	 * @param pageNum
	 *            起始页
	 * @param pageSize
	 *            每页条数
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET)
	public Result select(@RequestParam(required = false, value = "symbol") String symbol,
			@RequestParam(required = false, value = "obj_name") String objName,
			@RequestParam(required = false, value = "base_name") String baseName,
			@RequestParam(required = false, value = "is_stand") Integer isStand,
			@RequestParam(required = false, value = "enable") Integer enable,
			@RequestParam(required = false, value = "page_num", defaultValue = "1") Integer pageNum,
			@RequestParam(required = false, value = "page_size", defaultValue = "15") Integer pageSize)
			throws Exception {
		Result result = new Result();
		result.setData(measureunitManageService.select(symbol, objName, baseName, isStand, enable, pageNum, pageSize));
		return result;
	}

	/**
	 * 根据计量对象id获取计量单位
	 *
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/{id}/units", method = RequestMethod.GET)
	public Result getUnits(@PathVariable(value = "id") String id) throws Exception {
		Result result = new Result();
		result.setData(measureunitManageService.getUnitsById(id));
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 单位换算
	 *
	 * @param groupId
	 *            单位组id
	 * @param originalUnit
	 *            原始单位
	 * @param resultUnit
	 *            换算单位
	 * @param originalValue
	 *            原始值
	 * @return result的data包含换算后的值
	 */
	@RequestMapping(value = "/conversion", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "measureunit", methodCate = "modeler方法",
	// programCate = ProgramCate.Java, getReqParamsNameNoPathVariable = {
	// "groupId", "originalUnit", "resultUnit",
	// "originalValue" }, methodType = MethodType.ConnectMethod, methodExecType =
	// MethodExecType.SyncMethod, methodStatus = MethodStatus.Enable, methodDesc =
	// "单位换算")
	@Deprecated
	public Result convert(@RequestParam(value = "groupId") String groupId,
			@RequestParam(value = "originalUnit") String originalUnit,
			@RequestParam(value = "resultUnit") String resultUnit,
			@RequestParam(value = "originalValue") BigDecimal originalValue) throws Exception {
		Result result = new Result();
		result.setData(measureunitManageService.convert(groupId, originalUnit, resultUnit, originalValue));
		return result;
	}

	/**
	 * 验证单位组名称是否唯一
	 * 
	 * @param measName
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/check", method = RequestMethod.GET)
	public Result checkObjName(@RequestParam(value = "meas_name") String measName) throws Exception {
		Result result = new Result();
		result.setData(measureunitManageService.objNameCheck(measName, ""));
		return result;
	}

	@RequestMapping(value = "/enable/{groupId}/{status}", method = RequestMethod.PUT)
	public Result changeStatus(@PathVariable(value = "groupId") String groupId,
			@PathVariable(value = "status") Integer status) throws Exception {
		Result result = new Result();
		result.setData(measureunitManageService.changeStatus(groupId, status));
		return result;
	}
}
