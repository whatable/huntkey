package com.huntkey.rx.sceo.provider.measureunit.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.MeasMeasDefineSetaEntity;
import com.huntkey.rx.edm.entity.MeasureunitEntity;
import com.huntkey.rx.sceo.common.model.measureunit.MeasureunitInfo;

import java.math.BigDecimal;
import java.util.List;

/**
 * Created by zhoucj on 2017/12/5.
 */
public interface MeasureunitManageService {
    String delete(String[] ids) throws Exception;

    Pagination<MeasureunitInfo> select(String symbol, String objName, String baseName, Integer isStand,
                                       Integer enable, Integer pageNum, Integer pageSize) throws Exception;

    String delete(String id) throws Exception;

    List<MeasMeasDefineSetaEntity> getUnitsById(String id) throws Exception;

    MeasureunitEntity save(MeasureunitEntity measureunitEntity) throws Exception;

    String objNameCheck(String objName, String id) throws Exception;

    String unitCheck(List<MeasMeasDefineSetaEntity> measDefineSetaEntities);

    BigDecimal convert(String groupId, String originalUnit, String resultUnit, BigDecimal originalValue) throws Exception;

    int changeStatus(String groupId, Integer status) throws Exception;
}
