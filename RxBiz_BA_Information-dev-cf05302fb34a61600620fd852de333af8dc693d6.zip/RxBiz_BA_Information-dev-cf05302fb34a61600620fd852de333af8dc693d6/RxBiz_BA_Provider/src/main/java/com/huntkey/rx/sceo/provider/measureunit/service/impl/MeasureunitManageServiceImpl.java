package com.huntkey.rx.sceo.provider.measureunit.service.impl;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.MeasMeasDefineSetaEntity;
import com.huntkey.rx.edm.entity.MeasureunitEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.measureunit.MeasureunitInfo;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLCurdEnum;
import com.huntkey.rx.sceo.orm.common.util.EdmUtil;
import com.huntkey.rx.sceo.orm.common.util.PersistentUtil;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.measureunit.service.MeasureunitManageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.util.*;

import static java.math.BigDecimal.ROUND_HALF_DOWN;

/**
 *
 * @author zhoucj
 * @date 2017/12/5
 */
@Service
public class MeasureunitManageServiceImpl implements MeasureunitManageService {
    @Autowired
    private OrmService ormService;
    @Autowired
    private ParameterService parameterService;

    private final static Logger log = LoggerFactory.getLogger(MeasureunitManageServiceImpl.class);

    @Override
    @Transactional(readOnly = false)
    public MeasureunitEntity save(MeasureunitEntity measureunitEntity) throws Exception {
        if (measureunitEntity == null) { return null; }
        // 判断是否标准系统
        boolean isStandardSystem = parameterService.isStandardSystem();
        List<MeasMeasDefineSetaEntity> measMeasDefineSetaEntitys = measureunitEntity.getMeas_define_set();
        List<MeasMeasDefineSetaEntity> insertList = new ArrayList<>();
        List<MeasMeasDefineSetaEntity> updateList = new ArrayList<>();
        if (measMeasDefineSetaEntitys != null && measMeasDefineSetaEntitys.size() > 0) {
            for (MeasMeasDefineSetaEntity measMeasDefineSetaEntity : measMeasDefineSetaEntitys) {
                if (measMeasDefineSetaEntity == null) { continue; }
                if (StringUtil.isNullOrEmpty(measMeasDefineSetaEntity.getId())) {
                    measMeasDefineSetaEntity.setCreuser("admin");
                    // 新增时若系统为非标系统，则新增数据为非标数据
                    if (!isStandardSystem) {
                        measMeasDefineSetaEntity.setMeas_disstand(Integer.valueOf(Constants.NOT_STANDARD));
                    }
                    insertList.add(measMeasDefineSetaEntity);
                } else {
                    // 修改前数据
                    MeasureunitEntity updateBefore = ormService.load(MeasureunitEntity.class, measureunitEntity.getId());
                    /**
                     * 1、标准系统下， 任意节点由标准—>非标，则其所有子节点—>非标
                     */
                    if(isStandardSystem){
                        if (!StringUtil.isNullOrEmpty(measureunitEntity.getId())) {
                            if(updateBefore.getMeas_isstand() == 1 && measureunitEntity.getMeas_isstand() == 0){
                                measMeasDefineSetaEntity.setMeas_disstand(Integer.valueOf(Constants.NOT_STANDARD));
                            }
                        }
                    }
                    measMeasDefineSetaEntity.setModuser("admin");
                    updateList.add(measMeasDefineSetaEntity);
                }
                if (measMeasDefineSetaEntity.getMeas_dbase() == 1) {
                    measureunitEntity.setMeas_name(measMeasDefineSetaEntity.getMeas_dname());
                }
            }
        }

        if (StringUtil.isNullOrEmpty(measureunitEntity.getId())) {
            measureunitEntity.setCreuser("admin");
            insertMeasureunitEntity(measureunitEntity);
            // 新增时若系统为非标系统，则新增数据为非标数据
            if (!isStandardSystem) {
                measureunitEntity.setMeas_isstand(Integer.valueOf(Constants.NOT_STANDARD));
            }
        } else {
            measureunitEntity.setModuser("admin");
            updateMeasureunitEntity(measureunitEntity);
        }
        EdmUtil.setPropertyBaseEntitiesSysColumns(MeasureunitEntity.class, measureunitEntity,
                insertList, SQLCurdEnum.INSERT);
        EdmUtil.setPropertyBaseEntitiesSysColumns(MeasureunitEntity.class, measureunitEntity,
                updateList, SQLCurdEnum.UPDATE);
        insertMeasMeasDefineSetaEntities(insertList);
        updateMeasMeasDefineSetaEntities(updateList);

        //获取插入和更新的数据id
        List<String> ids = new ArrayList<>();
        for (MeasMeasDefineSetaEntity measMeasDefineSetaEntity : insertList) {
            ids.add(measMeasDefineSetaEntity.getId());
        }
        for (MeasMeasDefineSetaEntity measMeasDefineSetaEntity : updateList) {
            ids.add(measMeasDefineSetaEntity.getId());
        }
        deleteUnitIdNotIn(measureunitEntity.getId(), ids.toArray());

        measureunitEntity.setMeas_define_set(measMeasDefineSetaEntitys);
        return measureunitEntity;
    }

    /**
     * 删除单位组中id不在ids集合中的单位
     * @param pid
     * @param ids
     * @throws Exception
     */
    private void deleteUnitIdNotIn(String pid, Object[] ids) throws Exception {
        OrmParam ormParam = new OrmParam();
        String exp = ormParam.getEqualXML("pid", pid) +
                " AND " + ormParam.getNotInXML("id", ids);
        ormParam.setWhereExp(exp);
        ormService.delete(MeasMeasDefineSetaEntity.class, ormParam);
    }

    @Override
    @Transactional(readOnly = false)
    public String delete(String[] ids) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getInXML("id", ids));
        int i = ormService.delete(MeasMeasDefineSetaEntity.class, ids);
        return String.valueOf(i);
    }

    @Override
    @Transactional(readOnly = false)
    public String delete(String id) throws Exception {
        List<MeasMeasDefineSetaEntity> units = getUnits(id);

        List<String> ids = new ArrayList<>();
        if (units != null && units.size() > 0) {
            for (MeasMeasDefineSetaEntity unit : units) {
                if (!StringUtil.isNullOrEmpty(unit.getId())) {
                    ids.add(unit.getId());
                }
            }
        }
        delete(ids.toArray(new String[]{}));

        int i = ormService.delete(MeasureunitEntity.class, id);

        return String.valueOf(i);
    }

    /**
     * 获取单位组中的所有单位
     * @param id 单位组id
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(readOnly = true)
    public List<MeasMeasDefineSetaEntity> getUnitsById(String id) throws Exception {
        List<MeasMeasDefineSetaEntity> measDefineSetaEntities = getUnits(id);

        if (measDefineSetaEntities != null && measDefineSetaEntities.size() > 0) {

        }
        return measDefineSetaEntities;
    }

    @Override
    @Transactional(readOnly = true)
    public Pagination<MeasureunitInfo> select(String symbol, String objName, String baseName, Integer isStand,
                                        Integer enable, Integer pageNum, Integer pageSize) throws Exception {
        OrmParam ormParam = new OrmParam();
        StringBuilder sb = new StringBuilder();
        sb.append("1 = 1");

        if (!StringUtil.isNullOrEmpty(symbol)) {
            List<String> ids = getMeasureunitIdBySymbol(symbol);
            if (ids == null) {
                sb.append(" AND ").append(ormParam.getEqualXML("id", ""));
            } else {
                sb.append(" AND ").append(ormParam.getInXML("id", ids.toArray()));
            }
        }

        if (!StringUtil.isNullOrEmpty(objName)) {
            sb.append(" AND ").append(ormParam.getMatchMiddleXML("meas_obj", objName));
        }
        
        if (!StringUtil.isNullOrEmpty(baseName)) {
            sb.append(" AND ").append(ormParam.getMatchMiddleXML("meas_name", baseName));
        }
        
        if (!StringUtil.isNullOrEmpty(isStand)) {
            sb.append(" AND ").append(ormParam.getEqualXML("meas_isstand", isStand));
        }
        
        if (!StringUtil.isNullOrEmpty(enable)) {
            sb.append(" AND ").append(ormParam.getEqualXML("meas_enable", enable));
        }

        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);
        ormParam.setWhereExp(sb.toString());

        Pagination<MeasureunitEntity> pagination = ormService.selectPagedBeanList(MeasureunitEntity.class, ormParam);
        List<MeasureunitEntity> measureunitEntityList = null;
        List<MeasureunitInfo> measureunitInfoList = new ArrayList<>();
        Pagination<MeasureunitInfo> retPagination = null;
        if (pagination == null) {
            retPagination = new Pagination<>(measureunitInfoList, pageNum, pageSize, 0);
        } else {
            measureunitEntityList = pagination.getList();
            if (measureunitEntityList != null && measureunitEntityList.size() > 0) {
                for (MeasureunitEntity measureunitEntity : measureunitEntityList) {
                    MeasureunitInfo measureunitInfo = entityToInfo(measureunitEntity);
                    measureunitInfoList.add(measureunitInfo);
                }
            }
            retPagination = new Pagination<>(measureunitInfoList, pageNum, pageSize, pagination.getTotal());
        }

        return retPagination;
    }


    /**
     * 计量对象名名称验证
     * @param objName 计量对象名称
     * @param id 单位组id
     * @return
     */
    @Override
    public String objNameCheck(String objName, String id) throws Exception {
        String retStr = "";
        if (StringUtil.isNullOrEmpty(objName)) {
            return "单位组名称不可为空";
        }
        OrmParam ormParam = new OrmParam();
        StringBuilder exp = new StringBuilder();
        if (StringUtil.isNullOrEmpty(id)) {
            exp.append(ormParam.getEqualXML("meas_obj", objName));
        } else {
            exp.append(ormParam.getEqualXML("meas_obj", objName))
                    .append("AND id != ").append("\"").append(id).append("\"");
        }
        ormParam.setWhereExp(exp.toString());
        long count = ormService.count(MeasureunitEntity.class, ormParam);

        if (count > 0) {
            retStr = "单位组名称重复";
        }

        return retStr;
    }

    /**
     * 计量单位名称、符号、基准单位验证
     * @param measDefineSetaEntities
     * @return
     */
    @Override
    public String unitCheck(List<MeasMeasDefineSetaEntity> measDefineSetaEntities) {
        String retStr = "";
        if (measDefineSetaEntities != null && measDefineSetaEntities.size() > 0) {
            int baseUnitNum = 0;
            Set<String> nameSet = new HashSet<>(100);
            Set<String> symbolSet = new HashSet<>(100);
            for (MeasMeasDefineSetaEntity entity : measDefineSetaEntities) {
                if (entity.getMeas_dbase() == 1) {
                    baseUnitNum++;
                }
                if (StringUtil.isNullOrEmpty(entity.getMeas_dname())) {
                    return "计量单位名称不能为空";
                }
                if (!nameSet.contains(entity.getMeas_dname())) {
                    nameSet.add(entity.getMeas_dname());
                } else {
                    return "计量单位名称重复";
                }
                if (StringUtil.isNullOrEmpty(entity.getMeas_dsymbol())) {
                    return "计量单位符号不能为空";
                }
                if (!symbolSet.contains(entity.getMeas_dsymbol())) {
                    symbolSet.add(entity.getMeas_dsymbol());
                } else {
                    return "计量单位符号重复";
                }
            }

            if (baseUnitNum != 1) {
                return "基准单位有且仅有一个";
            }
        }

        return retStr;
    }

    @Override
    public BigDecimal convert(String groupId, String originalUnit, String resultUnit, BigDecimal originalValue) throws Exception {
        BigDecimal resultValue = null;
        MeasMeasDefineSetaEntity original = getUnitBySymbolAndGroupId(originalUnit, groupId);
        MeasMeasDefineSetaEntity result = getUnitBySymbolAndGroupId(resultUnit, groupId);

        if (original != null && result != null) {
            resultValue = result.getMeas_drate()
                    .divide(original.getMeas_drate(), 32, BigDecimal.ROUND_HALF_UP)
                    .multiply(originalValue);

            return resultValue.setScale(result.getMeas_dradix_num(), Integer.valueOf(result.getMeas_dradix_put()));
        }

        return resultValue;
    }

    @Override
    public int changeStatus(String groupId, Integer status) throws Exception {
        /**
         * 任意节点由启用—> 禁用，择期所有子节点—> 禁用
         */
        if(status == 0){
            OrmParam ormParam = new OrmParam();
            ormParam.setWhereExp(ormParam.getEqualXML(BasicConst.PID, groupId));
            List<MeasMeasDefineSetaEntity> childs = ormService.selectBeanList(MeasMeasDefineSetaEntity.class, ormParam);
            if(childs != null && childs.size() > 0){
                for (MeasMeasDefineSetaEntity child : childs) {
                    child.setMeas_denable(Integer.valueOf(Constants.DISABLE));
                    ormService.updateSelective(child);
                }
            }
        }
        MeasureunitEntity measureunitEntity = new MeasureunitEntity();
        measureunitEntity.setId(groupId);
        measureunitEntity.setMeas_enable(status);
        return ormService.updateSelective(measureunitEntity);
    }

    private MeasureunitInfo entityToInfo(MeasureunitEntity measureunitEntity) throws Exception {
        MeasureunitInfo measureunitInfo = new MeasureunitInfo();
        measureunitInfo.setModtime(measureunitEntity.getModtime());
        measureunitInfo.setModuser(measureunitEntity.getModuser());
        measureunitInfo.setId(measureunitEntity.getId());
        measureunitInfo.setMeas_obj(measureunitEntity.getMeas_obj());
        measureunitInfo.setMeas_enable(measureunitEntity.getMeas_enable());
        measureunitInfo.setMeas_isstand(measureunitEntity.getMeas_isstand());
        measureunitInfo.setMeas_name(measureunitEntity.getMeas_name());
        measureunitInfo.setCreuser(measureunitEntity.getCreuser());
        measureunitInfo.setGroup(getGroup(measureunitEntity.getId()));
        measureunitInfo.setSymbol(getSymbol(measureunitEntity.getId()));

        return measureunitInfo;
    }

    /**
     * 获取计量单位组
     * @param id 单位组id
     * @return
     */
    private String getGroup(String id) throws Exception {
        List<MeasMeasDefineSetaEntity> units = getUnits(id);
        StringBuilder group = new StringBuilder();

        if (units != null && units.size() > 0) {
            for (MeasMeasDefineSetaEntity entity : units) {
                group.append(entity.getMeas_dname()).append(",");
            }
        }
        //去掉尾部逗号
        if (!StringUtil.isNullOrEmpty(group)) {
            group.delete(group.length() - 1, group.length());
        }

        return group.toString();
    }

    /**
     * 获取基准单位的单位符号
     * @param id 单位组id
     * @return
     */
    private String getSymbol(String id) throws Exception {
        String symbol = "";
        MeasMeasDefineSetaEntity entity = getBaseUnit(id);
        if (entity != null) {
            symbol = entity.getMeas_dsymbol();
        }
        return symbol;
    }

    /**
     * 根据单位组id获取基准计量单位
     * @param id 单位组id
     * @return
     * @throws Exception
     */
    private MeasMeasDefineSetaEntity getBaseUnit(String id) throws Exception {
        MeasMeasDefineSetaEntity entity = null;

        OrmParam ormParam = new OrmParam();
        String exp = ormParam.getEqualXML("pid", id);
        exp = exp.concat(" AND ").concat("meas_dbase = 1");
        ormParam.setWhereExp(exp);

        List<MeasMeasDefineSetaEntity> entities = ormService.selectBeanList(MeasMeasDefineSetaEntity.class, ormParam);
        if (entities != null && entities.size() > 0) {
            entity = entities.get(0);
        }
        return entity;
    }

    /**
     * 根据id获取计量单位集合
     * @param id 单位组id
     * @return
     */
    private List<MeasMeasDefineSetaEntity> getUnits(String id) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML("pid", id));
        return ormService.selectBeanList(MeasMeasDefineSetaEntity.class, ormParam);
    }

    /**
     * 根据单位符号和单位组id获取单位
     * @param symbol 单位符号
     * @param groupId 单位组id
     * @return 单位
     * @throws Exception
     */
    private MeasMeasDefineSetaEntity getUnitBySymbolAndGroupId(String symbol, String groupId) throws Exception {
        MeasMeasDefineSetaEntity entity = null;

        OrmParam ormParam = new OrmParam();
        String exp = ormParam.getEqualXML("pid", groupId) +
                " AND " + ormParam.getEqualXML("meas_dsymbol", symbol);
        ormParam.setWhereExp(exp);

        List<MeasMeasDefineSetaEntity> entities = ormService.selectBeanList(MeasMeasDefineSetaEntity.class, ormParam);
        if (entities != null && entities.size() > 0) {
            entity = entities.get(0);
        }

        return entity;
    }


    /**
     * 根据基准单位符号模糊查询计量对象id集合
     * @param symbol 基准单位符号
     * @return
     * @throws Exception
     */
    private List<String> getMeasureunitIdBySymbol(String symbol) throws Exception {
        OrmParam ormParam = new OrmParam();
        String exp = ormParam.getMatchMiddleXML("meas_dsymbol", symbol) +
                " AND " + ormParam.getEqualXML("meas_dbase", "1");
        ormParam.setWhereExp(exp);

        List<String> ids = new ArrayList<>();
        List<MeasMeasDefineSetaEntity> entitys = ormService.selectBeanList(MeasMeasDefineSetaEntity.class, ormParam);
        if (entitys != null && entitys.size() > 0) {
            for (MeasMeasDefineSetaEntity entity : entitys) {
                ids.add(entity.getPid());
            }
        }

        return ids;
    }

    private void insertMeasureunitEntity(MeasureunitEntity measureunitEntity)
            throws Exception {
        // 判断是否标准系统
        boolean isStandardSystem = parameterService.isStandardSystem();
        if (!isStandardSystem) {
            measureunitEntity.setMeas_isstand(Integer.valueOf(Constants.NOT_STANDARD));
        }
        ormService.insert(measureunitEntity);
    }

    private void insertMeasMeasDefineSetaEntities(List<MeasMeasDefineSetaEntity> measMeasDefineSetaEntities)
            throws Exception {
        ormService.insert(measMeasDefineSetaEntities);
    }

    private void updateMeasureunitEntity(MeasureunitEntity measureunitEntity)
            throws Exception {
        ormService.updateSelective(measureunitEntity);
    }

    private void updateMeasMeasDefineSetaEntity(MeasMeasDefineSetaEntity measMeasDefineSetaEntity)
            throws Exception {
        ormService.updateSelective(measMeasDefineSetaEntity);
    }

    private void updateMeasMeasDefineSetaEntities(List<MeasMeasDefineSetaEntity> measMeasDefineSetaEntities)
            throws Exception {
        for (MeasMeasDefineSetaEntity measMeasDefineSetaEntity : measMeasDefineSetaEntities) {
            updateMeasMeasDefineSetaEntity(measMeasDefineSetaEntity);
        }
    }
}
