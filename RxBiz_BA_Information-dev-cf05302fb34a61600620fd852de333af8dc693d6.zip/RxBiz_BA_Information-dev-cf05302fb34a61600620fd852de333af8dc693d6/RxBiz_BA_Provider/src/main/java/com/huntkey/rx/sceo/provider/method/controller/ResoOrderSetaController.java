package com.huntkey.rx.sceo.provider.method.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.provider.method.service.ResoOrderSetaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


/**
 * @author liucs
 * @date 2017-11-22 11:52:46
 */
@RestController
@RequestMapping("/resoOrder")
public class ResoOrderSetaController {

    @Autowired
    private ResoOrderSetaService resoOrderSetaService;

    @RequestMapping(value = "/addBill/{edmcCode}&{objId}",method = RequestMethod.GET)
    public Result addBill(@PathVariable String edmcCode,
                          @PathVariable String objId){
        Result result = null;
        try {
            result = resoOrderSetaService.addBill(edmcCode, objId);
        }catch(Exception e){
            result.setErrMsg(e.getMessage());
            result.setRetCode(Result.RECODE_ERROR);
        }
        return result;
    }
}
