package com.huntkey.rx.sceo.provider.method.service;

import com.huntkey.rx.commons.utils.rest.Result;

public interface ResoOrderSetaService {
    /**
     *
     * @param edmcCode
     * @param objId
     * @return
     */
    Result addBill(String edmcCode, String objId)throws Exception;
}
