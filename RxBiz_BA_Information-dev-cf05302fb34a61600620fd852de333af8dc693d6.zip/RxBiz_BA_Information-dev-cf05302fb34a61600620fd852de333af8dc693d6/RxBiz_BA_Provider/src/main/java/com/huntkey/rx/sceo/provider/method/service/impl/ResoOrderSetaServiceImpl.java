package com.huntkey.rx.sceo.provider.method.service.impl;

import com.alibaba.fastjson.JSON;
import com.huntkey.rx.commons.utils.datetime.DateUtil;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.commons.utils.uuid.UuidCreater;
import com.huntkey.rx.edm.entity.ResoResoOrderSetaEntity;
import com.huntkey.rx.sceo.common.model.reso.ResoOrderSeta;
import com.huntkey.rx.sceo.common.model.reso.ResoOrderSetaConst;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import com.huntkey.rx.sceo.provider.feign.OrmClient;
import com.huntkey.rx.sceo.provider.method.service.ResoOrderSetaService;
import com.huntkey.rx.sceo.serviceCenter.common.model.FullInputArgument;
import com.huntkey.rx.sceo.serviceCenter.common.model.MergeParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;

/**
 * @author liucs
 * @date 2017-11-22 12:08:44
 */
@Service
public class ResoOrderSetaServiceImpl implements ResoOrderSetaService{
    @Autowired
    private OrmService ormService;
    @Autowired
    private ModelerProvider modelerProvider;
    @Override
    public Result addBill(String edmcCode ,String objId) throws  Exception{
        String errorStr = null;
        //类id
        String classId = null;
        String edmcName = null;
        //根据demcCode 查询 edm_class id 和 edmc_name
        Result result = modelerProvider.getIdByEdmcCode(edmcCode);
        Map<String,String> resultData = (Map<String, String>) result.getData();
        //查询数据不为空并且key(edmcName)对应的value不为空，插入单据
        if(!StringUtil.isNullOrEmpty(resultData)&&!StringUtil.isNullOrEmpty(resultData.get("edmcName"))
                &&!StringUtil.isNullOrEmpty(resultData.get("id"))){
            classId = (String)resultData.get("id");
            edmcName = (String)resultData.get("edmcName");
            ResoResoOrderSetaEntity reso = new ResoResoOrderSetaEntity();
            reso.setPid(classId);
            reso.setClassName(edmcName);
            reso.setReso_orderobj(objId);
            reso.setCretime(new Date());
            reso.setCreuser("admin");
            reso.setModuser("admin");
            String  id = ormService.insert(reso).toString();
            resultData.put("id",id);
            return result;
        }
        result.setData(null);
        return result;
    }
}
