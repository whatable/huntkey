package com.huntkey.rx.sceo.provider.parameter.controller;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.sceo.common.model.paramter.ParamterDto;
import com.huntkey.rx.sceo.common.model.paramter.VO.ParameterVO;
import com.huntkey.rx.sceo.common.model.paramter.VO.TipVO;
import com.huntkey.rx.sceo.provider.parameter.service.ParameterService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author liucs
 * @date 2018-1-8 09:46:42
 */
@RestController
@RequestMapping("/parameter")
public class ParameterController {
    @Autowired
    private ParameterService parameterService;

    /**
     *分页查询参数列表，支持模糊查询
     * dto 封装参数
     * @return 返回Result
     */
    @RequestMapping(value="/list", method = RequestMethod.GET)
    public Result list(@RequestParam(required = false, value = "parm_no")String parm_no,
                       @RequestParam(required = false, value = "parm_type")String parm_type,
                       @RequestParam(required = false, value = "parm_name")String parm_name,
                       @RequestParam(required = false, value = "parm_form_name")String parm_form_name,
                       @RequestParam(required = false, value = "pageNum",defaultValue = "1")Integer pageNum,
                       @RequestParam(required = false, value = "pageSize",defaultValue = "15")Integer pageSize){
        ParamterDto dto = new ParamterDto();
        dto.setPageNum(pageNum);
        dto.setPageSize(pageSize);
        dto.setParm_form_name(parm_form_name);
        dto.setParm_name(parm_name);
        dto.setParm_type(parm_type);
        dto.setParm_no(parm_no);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            Pagination<ParameterVO> voPagination =  parameterService.list(dto);
            result.setData(voPagination);
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 根据id查询参数
     * @param id 参数id
     * @return result
     */
    @RequestMapping(value="/getParameter/{id}", method = RequestMethod.GET)
    public Result getParameter(@PathVariable(value = "id") String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(parameterService.getParameter(id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 删除参数
     * @param authorization 用户权限
     * @param id 参数id
     * @return result
     */
    @RequestMapping(value="/delete/{id}", method = RequestMethod.DELETE)
    public Result delete(@RequestParam("authorization")String authorization,@PathVariable(value = "id")String id){
        String currentUserId = Utils.getCurentUserId(authorization);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(parameterService.delete(currentUserId,id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 保存参数
     * @param parameterEntity
     * @return
     */
    @RequestMapping(value="/insert",method=RequestMethod.POST)
    public Result insert(@RequestParam("authorization")String authorization,@RequestBody ParameterEntity parameterEntity){
        String currentUserId = Utils.getCurentUserId(authorization);
        parameterEntity.setCreuser(currentUserId);
        parameterEntity.setModuser(currentUserId);
        Result result = new Result();
        parameterService.insert(parameterEntity);
        return result;
    }

    /**
     * 修改参数
     * @param parameterEntity
     * @return
     */
    @RequestMapping(value="/modify",method=RequestMethod.POST)
    public Result modify(@RequestParam("authorization")String authorization,@RequestBody ParameterEntity parameterEntity){
        String currentUserId = Utils.getCurentUserId(authorization);
        parameterEntity.setModuser(currentUserId);
        Result result = new Result();
         parameterEntity = parameterService.modify(parameterEntity);
        result.setData(parameterEntity);
        return result;
    }

    /**
     * 上下移
     * @param parameterEntities
     * @return
     */
    @RequestMapping(value = "/updateList", method = RequestMethod.PUT)
    public Result updateList(@RequestBody List<ParameterEntity> parameterEntities){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(parameterService.updateList(parameterEntities));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }


    /**
     * 查询启用提示
     * @param className
     * @param value
     * @param text
     * @param tip
     * @return
     */
    @RequestMapping(value="/getTips",method=RequestMethod.GET)
    public Result getTips(@RequestParam("className")String className,
                          @RequestParam("value")String value,
                          @RequestParam("text")String text,
                          @RequestParam("tip")String tip){
        Result result = new Result();
        List<TipVO> map = parameterService.getTip(className,value,text,tip);
        result.setData(map);
        return result;
    }


    @RequestMapping(value="/checkParamNo",method=RequestMethod.GET)
    public Result checkParamNo(@RequestParam("paramNo")String paramMo){
        Result result = new Result();
        String flag = parameterService.checkParamNo(paramMo);
        result.setData(flag);
        return result;
    }

    @RequestMapping(value="/checkParamName",method=RequestMethod.GET)
    public Result checkParamName(@RequestParam("paramName")String paramName){
        Result result = new Result();
        String flag = parameterService.checkParamName(paramName);
        result.setData(flag);
        return result;
    }

    /**
     * 根据pid查询参数值集
     * @param id 参数id
     * @return
     */
    @RequestMapping(value = "/queryValuesSet/{id}", method = RequestMethod.GET)
    public Result queryValuesSetByPid(@PathVariable(value="id") String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(parameterService.queryValuesSetByPid(id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 查询参数设置列表
     * @param pageCode 使用页面编号
     * @param parmType 参数类型
     * @param parmName 参数名称
     * @return
     */
    @RequestMapping(value = "/qryParmSetting", method = RequestMethod.GET)
    public Result qryParmSetting(@RequestParam(value = "pageCode")String pageCode,
                                 @RequestParam(required = false, value = "parmType")String parmType,
                                 @RequestParam(required = false, value = "parmName")String parmName){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(parameterService.qryParmSetting(pageCode, parmType, parmName));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 查询参数单据
     * @param orderId
     * @return
     */
    @RequestMapping(value = "/loadOrder/{orderId}",method = RequestMethod.GET)
    public Result loadOrder(@PathVariable(value = "orderId")String orderId){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(parameterService.loadOrder(orderId));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 查询参数单据列表
     * @param ordeStatus
     * @param pageSize
     * @param pageNum
     * @return
     */
    @RequestMapping(value = "/parameterOrderList", method = RequestMethod.GET)
    public Result parameterOrderList(@RequestParam(value = "ordeStatus")String ordeStatus,
                                     @RequestParam(required = false, defaultValue = "50", value = "pageSize")Integer pageSize,
                                     @RequestParam(required = false, defaultValue = "1", value = "pageNum")Integer pageNum){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(parameterService.parameterOrderList(ordeStatus, pageSize, pageNum));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }
}

