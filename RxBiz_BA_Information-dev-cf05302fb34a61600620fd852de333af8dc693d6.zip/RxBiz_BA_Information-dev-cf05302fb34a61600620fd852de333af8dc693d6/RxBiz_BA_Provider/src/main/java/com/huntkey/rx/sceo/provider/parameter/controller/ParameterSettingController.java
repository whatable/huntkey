package com.huntkey.rx.sceo.provider.parameter.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.sceo.common.model.paramter.VO.ParameterVO;
import com.huntkey.rx.sceo.common.model.paramter.VO.TreeVO;
import com.huntkey.rx.sceo.method.register.plugin.annotation.MethodRegister;
import com.huntkey.rx.sceo.provider.parameter.service.ParameterSettingService;
import feign.Body;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * @author zoulj
 * @create 2018/1/8 10:36
 **/
@RestController
@RequestMapping("/parameterSetting")
public class ParameterSettingController {

	@Autowired
	private ParameterSettingService parameterSettingService;

	@RequestMapping(value = "/qryParameValueByParamType", method = RequestMethod.GET)
	public Result qryParameValueByParamType(@RequestParam String pageCode) throws Exception {
		Result result = new Result();
		Map<String, List<ParameterEntity>> map = this.parameterSettingService.qryParametersGroupByParamType(pageCode,
				"");
		result.setData(map);
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * @param pageCode
	 * @param paramNo
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/qryParam/{pageCode}/{paramNo}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "parameter", methodDesc = "查询参数信息", methodCate =
	// "表单通用方法")
	@Deprecated
	public Result qryParam(@PathVariable(value = "pageCode") String pageCode,
			@PathVariable(value = "paramNo") String paramNo) throws Exception {
		Result result = new Result();
		Map<String, List<ParameterEntity>> map = this.parameterSettingService.qryParametersGroupByParamType(pageCode,
				paramNo);
		result.setData(map);
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 查询参数值
	 * 
	 * @param paramNo
	 *            参数唯一编号
	 * @return
	 */
	@RequestMapping(value = "/qryParam/{paramNo}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "parameter", methodDesc = "根据参数编号查询参数值集",
	// methodCate = "表单通用方法")
	@Deprecated
	public Result qryParamValues(@PathVariable(value = "paramNo") String paramNo) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(this.parameterSettingService.qryParamValues(paramNo));
		} catch (Exception e) {
			result.setErrMsg(e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
		}
		return result;
	}

	@RequestMapping(value = "/updataParameValues", method = RequestMethod.POST)
	public Result updataParameValues(@RequestBody Map<String, List<ParameterEntity>> map) throws Exception {
		Result result = new Result();
		int ret = this.parameterSettingService.updataParameValues(map);
		result.setData(ret);
		return result;
	}

	@RequestMapping(value = "/updataParameValue", method = RequestMethod.POST)
	public Result updataParameValue(@RequestBody ParameterEntity entity) throws Exception {
		Result result = new Result();
		int ret = this.parameterSettingService.updataParameValue(entity);
		result.setData(ret);
		return result;
	}

	@RequestMapping(value = "/qryTree", method = RequestMethod.GET)
	public Result qryTree(@RequestParam(value = "classId") String classId,
			@RequestParam(value = "valueId") String valueId, @RequestParam(value = "textId") String textId,
			@RequestParam(value = "pId") String pId) throws Exception {
		Result result = new Result();
		List<TreeVO> tree = this.parameterSettingService.qryTree(classId, valueId, textId, pId);
		result.setData(tree);
		return result;
	}
}
