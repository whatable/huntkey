package com.huntkey.rx.sceo.provider.parameter.service;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.edm.entity.ParameterorderEntity;
import com.huntkey.rx.edm.entity.ParmParmValueSetaEntity;
import com.huntkey.rx.sceo.common.model.order.vo.parameter.ParameterOrderVO;
import com.huntkey.rx.sceo.common.model.paramter.ParamterDto;
import com.huntkey.rx.sceo.common.model.paramter.VO.ParameterVO;
import com.huntkey.rx.sceo.common.model.paramter.VO.TipVO;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

/**
 * @author liucs
 * @date 2018-1-8 10:19:42
 */
public interface ParameterService {
    /**
     * 分页查询参数列表，支持模糊查询
     * dto 参数封装
     * @return  返回分页查询结果
     * @throws Exception 抛出异常
     */
    Pagination<ParameterVO> list(ParamterDto dto) throws Exception;

    /**
     * 根据id查询ParameterEntity实体
     * @param id ParameterEntity对象id
     * @return 返回ParameterEntity实体
     * @throws Exception 抛出异常
     */
    ParameterVO getParameter(String id) throws Exception;

    /**
     *
     * @param currentUserId 当前登录用户id
     * @param id 待删除的目标对象id
     * @return
     * @throws Exception
     */
    int delete(String currentUserId,String id)throws Exception;

    int insert(ParameterEntity parameterEntity);

    ParameterEntity modify(ParameterEntity parameterEntity);

    /**
     * 参数上下移
     * @param parameterEntities 参数集合
     * @return 返回提示信息
     * @throws Exception 抛出异常
     */
    String updateList(List<ParameterEntity> parameterEntities) throws Exception;

    List<TipVO> getTip(String className, String value, String text, String tip);

    String checkParamNo(String paramNo);

    String checkParamName(String paramName);

    /**
     * 根据pid查询ParmParmValueSetaEntity
     * @param pid
     * @return
     */
    List<ParmParmValueSetaEntity> queryValuesSetByPid(String pid)throws Exception;

    /**
     * 参数提交流程
     * @param request
     * @param orderVO
     * @return
     * @throws Exception
     */
    Map<String ,String> creParamOrder(HttpServletRequest request, ParameterOrderVO orderVO)throws Exception;

    void audit(HttpServletRequest request,JSONObject auditSet);

    void approve(HttpServletRequest request,String orderId, String handlerType);
    /**
     * 查询参数设置
     * @param pageCode
     * @param parmType
     * @param parmName
     * @return
     * @throws Exception
     */
    List<Map<String,Object>> qryParmSetting(String pageCode, String parmType, String parmName)throws Exception;

    /**
     * 查询参数单据
     * @param orderId 单据id
     * @return
     * @throws Exception
     */
    ParameterorderEntity loadOrder(String orderId)throws Exception;

    /**
     * 查询参数单据列表
     * @return
     * @throws Exception
     */
    Pagination<ParameterOrderVO> parameterOrderList(String ordeStatus, Integer pageSize, Integer pageNum)throws Exception;
}
