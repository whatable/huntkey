package com.huntkey.rx.sceo.provider.parameter.service;

import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.edm.entity.ParmParmValueSetaEntity;
import com.huntkey.rx.sceo.common.model.paramter.VO.TreeVO;

import java.util.List;
import java.util.Map;

/**
 * @author zoulj
 * @create 2018/1/8 10:37
 **/
public interface ParameterSettingService {


    /**
     * 以参数类型分类查询所有参数
     * @return
     * @param pageCode
     */
    Map<String,List<ParameterEntity>> qryParametersGroupByParamType(String pageCode,String paramsNo) throws Exception;

    /**
     * 批量设置参数
     * @param map
     * @return
     */
    int updataParameValues(Map<String, List<ParameterEntity>> map) throws Exception;

    /**
     * 修改单个参数参数
     * @param entity
     * @return
     */
    int updataParameValue(ParameterEntity entity) throws Exception;

    /**
     * 查询树的数据
     * @param classId
     * @param valueId
     * @param textId
     * @param pId
     * @return
     */
    List<TreeVO> qryTree(String classId, String valueId, String textId, String pId);

    /**
     * 查询参数值
     * @param paramNo 参数编号
     * @return
     * @throws Exception
     */
    List<ParmParmValueSetaEntity> qryParamValues(String paramNo)throws Exception;
}
