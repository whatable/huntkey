package com.huntkey.rx.sceo.provider.parameter.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.redis.RedisClusterUtils;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.*;
import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.edm.service.OrderRegService;
import com.huntkey.rx.sceo.common.model.basic.WorkFlowConstants;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.order.OrderConstants;
import com.huntkey.rx.sceo.common.model.order.vo.parameter.ParameterOrderVO;
import com.huntkey.rx.sceo.common.model.order.vo.parameter.ParoOrdeVO;
import com.huntkey.rx.sceo.common.model.paramter.ParamterDto;
import com.huntkey.rx.sceo.common.model.paramter.VO.ParameterVO;
import com.huntkey.rx.sceo.common.model.paramter.VO.TipVO;
import com.huntkey.rx.sceo.common.model.paramter.constant.ParameterConstant;
import com.huntkey.rx.sceo.common.model.paramter.constant.ParmFormConstant;
import com.huntkey.rx.sceo.common.model.paramter.constant.ParmValueConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLCurdEnum;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.common.util.EdmUtil;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.Impl.NbrlGetCodeImpl;
import com.huntkey.rx.sceo.provider.code.service.Impl.NumberRulesSereviceImpl;
import com.huntkey.rx.sceo.provider.code.service.NbrlGetCodeService;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import com.huntkey.rx.sceo.provider.parameter.service.ParameterService;
import com.huntkey.rx.sceo.provider.utils.EntityConvertVOUtil;
import com.huntkey.rx.sceo.provider.utils.OrderUtils;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Array;
import java.util.*;

/**
 * @author liucs
 * @date 2018-1-8 10:24:38
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class ParameterServiceImpl implements ParameterService {
    @Autowired
    private OrmService ormService;

    @Autowired
    private NumberRulesSereviceImpl numberRulesSereviceImpl;

    @Autowired
    private ModelerProvider modelerProvider;

    @Autowired
    private NbrlGetCodeService nbrlGetCodeService;

    @Autowired
    private OrderRegService orderRegService;

    private static Logger log = LoggerFactory.getLogger(NbrlGetCodeImpl.class);

    @Override
    public Pagination<ParameterVO> list(ParamterDto dto)throws Exception{
        List<String> columnList = new ArrayList<>(Arrays.asList(ParmFormConstant.PARM_FORM_NAME,ParmFormConstant.PARM_FORM_CODE));
        numberRulesSereviceImpl.setBaseProperties(columnList);
        //返回结果
        Pagination<ParameterVO> voPagination = null;
        //List<ParameterEntity>转List<ParameterVO>,并设置使用页面名称
        List<ParameterVO> parameterVOList = new ArrayList<>();

        if(StringUtil.isNullOrEmpty(dto.getParm_form_name())){
            //模糊查询参数列表——分页
            Pagination<ParameterEntity> paginationParam = getParameterPageList(dto.getParm_type(), dto.getParm_no(), dto.getParm_name(), dto.getPageNum(), dto.getPageSize());
            //封装属性集及扩展部分属性值
            if(null != paginationParam.getList() && paginationParam.getList().size() > 0){
                parameterVOList = entityListConvertVOList(paginationParam.getList());
            }
            voPagination = new Pagination<>(parameterVOList,dto.getPageNum(),dto.getPageSize(),paginationParam.getTotal());
        }else{
            String[] parmFormName = dto.getParm_form_name().trim().replaceAll(",","，").split("，");
            //根据表单名称查询表单集合——支持模糊查询
            String[] ids = getParameteridInParmFormPid(columnList, parmFormName);
            if(null == ids || ids.length <= 0){
                return new Pagination<>(parameterVOList,dto.getPageNum(),dto.getPageSize(),0);
            }
            //模糊查询参数列表——不分页
            List<ParameterEntity> parameterEntityList = getParameterList(dto.getParm_type(), dto.getParm_no(), dto.getParm_name(),ids);
            if(null != parameterEntityList && parameterEntityList.size() > 0){
                //entity转vo
                parameterVOList = entityListConvertVOList(parameterEntityList);
                //删除不满足条件的数据
                parameterVOList = removeNotMeetCondition(dto, parameterVOList);
            }
            voPagination = new Pagination<>(parameterVOList,dto.getPageNum(),dto.getPageSize(),parameterVOList.size());
        }
        return voPagination;
    }

    private List<ParameterVO> removeNotMeetCondition(ParamterDto dto, List<ParameterVO> parameterVOList) {
        List<ParameterVO> parameterVOS = new ArrayList<>();
        String[] formName = dto.getParm_form_name().trim().replaceAll(",","，").split("，");
        for (ParameterVO parameterVO : parameterVOList) {
            boolean flag = false;
            for (String s : formName) {
                if(!parameterVO.getUsePageName().replaceAll(",","，").contains(s.trim())){
                    flag = false;
                    break;
                }
                flag = true;
            }
            if(flag){
                parameterVOS.add(parameterVO);
            }
        }
        return parameterVOS;
    }

    private List<ParameterVO> entityListConvertVOList(List<ParameterEntity> parameterEntityList) throws Exception{
        String[] ids = new String[parameterEntityList.size()];
        int i=0;
        for (ParameterEntity parameterEntity : parameterEntityList) {
            ids[i] = parameterEntity.getId();
            i++;
        }
        List<String> formColumnList = new ArrayList<>(Arrays.asList(ParmFormConstant.PARM_FORM_CODE,ParmFormConstant.PARM_FORM_NAME,ParmFormConstant.CLASSNAME));
        //根据pid查询ParmParmFormSetaEntity集合
        List<ParmParmFormSetaEntity> formSetaEntities = ormService.selectBeanList(ParmParmFormSetaEntity.class,selectByPid(formColumnList,ids));

        for (ParameterEntity parameterEntity : parameterEntityList) {
            //属性集临时存储集合
            List<ParmParmFormSetaEntity> formSetaEntityList = new ArrayList<>();
           if(null != formSetaEntities && formSetaEntities.size() > 0){
               for (ParmParmFormSetaEntity formSetaEntity : formSetaEntities) {
                   if(parameterEntity.getId().equals(formSetaEntity.getPid())){
                       formSetaEntityList.add(formSetaEntity);
                   }
               }
           }
            parameterEntity.setParm_form_set(formSetaEntityList);
        }
        List<ParameterVO> parameterVOList = new ArrayList<>(parameterEntityList.size());
        for (ParameterEntity parameterEntity : parameterEntityList) {
            parameterVOList.add(getUsePageName(parameterEntity));
        }
        return parameterVOList;
    }

    private String[] getParameteridInParmFormPid(List<String> columnList, String[] parmFormName) throws Exception {
        List<ParmParmFormSetaEntity> parmFormSetaEntities  = qryParmFOrmByFormName(columnList, ParmFormConstant.PARM_FORM_NAME,parmFormName);
        //parameter类id
        String[] ids = null;
        int i = 0;
        if(null != parmFormSetaEntities && parmFormSetaEntities.size() > 0){
            ids  = new String[parmFormSetaEntities.size()];
            for (ParmParmFormSetaEntity parmFormSetaEntity : parmFormSetaEntities) {
                if(!Arrays.asList(ids).contains(parmFormSetaEntity.getPid())){
                    ids[i] = parmFormSetaEntity.getPid();
                    i++;
                }
            }
        }
        return ids;
    }

    @Override
    public ParameterVO getParameter(String id)throws Exception{
        OrmParam ormParam = new OrmParam();
        //设置查询参数
        setQryParamById(id, ormParam);
        //根据主键查询参数
        List<ParameterEntity> parameterEntityList = ormService.selectBeanList(ParameterEntity.class,ormParam);
        if(null == parameterEntityList || parameterEntityList.size()==0){
            return null;
        }
        return getParameterVOS(parameterEntityList.get(0));
    }

    private void setQryParamById(String id, OrmParam ormParam) {
        List<String> list = Arrays.asList(ParameterConstant.PARAM_NO, ParameterConstant.PARAM_NAME, ParameterConstant.PARAM_VALUES, ParameterConstant.PARAM_DESC, ParameterConstant.PARAM_SEQ,
                ParameterConstant.PARAM_IS_VISIBLE, ParameterConstant.PARAM_IS_MODIFY, ParameterConstant.PARAM_CONTROL_TYPE, ParameterConstant.PARAM_CONTROL_VALUE, ParameterConstant.PARAM_TYPE);
        List<String> columnList = new ArrayList<>(list);
        numberRulesSereviceImpl.setBaseProperties(columnList);
        columnList.remove(columnList.indexOf("pid"));
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getEqualXML(BasicConst.ID,id));
        ormParam.setWhereExp(whereExp);
    }

    private OrmParam getParmFormOrmParam(String id) throws Exception {
        List<String> columnList = new ArrayList<>(Arrays.asList(ParmFormConstant.PARM_FORM_NAME,ParmFormConstant.PARM_FORM_CODE,ParmFormConstant.CLASSNAME));
        numberRulesSereviceImpl.setBaseProperties(columnList);
        //封装查询参数
        return numberRulesSereviceImpl.setQueryConditionByPid(columnList,id);
    }

    private OrmParam getParmValueOrmParam(String id) throws Exception {
        List<String> columnList = new ArrayList<>(Arrays.asList(ParmValueConstant.PARM_ONE,ParmValueConstant.PARM_TWO,ParmValueConstant.PARM_THREE,ParmValueConstant.PARM_FOUR,ParmValueConstant.PARM_FIVE,ParmValueConstant.PARM_VALUE_SEQ,ParmValueConstant.CLASSNAME));
        numberRulesSereviceImpl.setBaseProperties(columnList);
        //封装查询参数
        return numberRulesSereviceImpl.setOrderQueryConditionByPid(columnList,id, ParmValueConstant.PARM_VALUE_SEQ, SQLSortEnum.ASC);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(String currentUserId, String id) throws Exception{
        int count = 0;
        List<String> formColumnList = new ArrayList<>(Arrays.asList(ParmFormConstant.PARM_FORM_CODE,ParmFormConstant.PARM_FORM_NAME,ParmFormConstant.CLASSNAME));
        //设置ormparam批量删除参数（pid == #{id}）
        OrmParam formOrmParam = selectByPid(formColumnList,new String[]{id});
        //根据pid查询ParmParmFormSetaEntity属性集
        List<ParmParmFormSetaEntity> formSetaEntities = ormService.selectBeanList(ParmParmFormSetaEntity.class,formOrmParam);
        if(null != formSetaEntities && formSetaEntities.size() > 0){
            for (ParmParmFormSetaEntity formSetaEntity : formSetaEntities) {
                //修改维护人信息
                formSetaEntity.setModuser(currentUserId);
                ormService.update(formSetaEntity);
            }
        }
        List<String> valueColumnList = new ArrayList<>(Arrays.asList(ParmValueConstant.PARM_VALUE_SEQ,ParmValueConstant.PARM_ONE,ParmValueConstant.PARM_TWO,ParmValueConstant.PARM_THREE,ParmValueConstant.PARM_FOUR,ParmValueConstant.PARM_FIVE,ParmValueConstant.CLASSNAME));
        //设置ormparam批量删除参数（pid == #{id}）
        OrmParam valueVrmParam = selectByPid(valueColumnList,new String[]{id});
        //根据pid查询ParmParmValueSetaEntity属性集
        List<ParmParmValueSetaEntity> valueSetaEntities = ormService.selectBeanList(ParmParmValueSetaEntity.class,valueVrmParam);
        if(null != valueSetaEntities && valueSetaEntities.size() > 0){
            for (ParmParmValueSetaEntity valueSetaEntity : valueSetaEntities) {
                //修改维护人信息
                valueSetaEntity.setModuser(currentUserId);
                ormService.update(valueSetaEntity);
            }
        }
        ParameterEntity parameterEntity = new ParameterEntity();
        parameterEntity.setId(id);
        parameterEntity.setModuser(currentUserId);
        ormService.updateSelective(parameterEntity);
        count += ormService.delete(ParmParmFormSetaEntity.class, formOrmParam);
        count += ormService.delete(ParmParmValueSetaEntity.class, valueVrmParam);
        count += ormService.delete(ParameterEntity.class, id);
        return count;
    }

    /**
     * 设置sql  where参数
     * @param columnList 列名
     * @param ids 主类id
     * @return 返回ormParam
     */
    private OrmParam selectByPid(List<String> columnList,String[] ids) {
        numberRulesSereviceImpl.setBaseProperties(columnList);
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columnList);
        String whereExp = OrmParam.and(ormParam.getInXML(BasicConst.PID, ids));
        ormParam.setWhereExp(whereExp);
        return ormParam;
    }

    private String getParmValueString(List<ParmParmValueSetaEntity> parmValueSetaEntityList) {
        StringBuilder sb = new StringBuilder();
        for (ParmParmValueSetaEntity parmValueSetaEntity : parmValueSetaEntityList) {
            sb.append(parmValueSetaEntity.getParm_one()).
                    append(parmValueSetaEntity.getParm_two()).
                    append(parmValueSetaEntity.getParm_three()).
                    append(parmValueSetaEntity.getParm_four()).
                    append(parmValueSetaEntity.getParm_five()).append(";");
        }
        return sb.toString().substring(0,sb.toString().length()-1);
    }

    private ParameterVO getParameterVOS(ParameterEntity parameterEntity) throws Exception {
        OrmParam formOrmParam = getParmFormOrmParam(parameterEntity.getId());
        //根据pid查询使用页面集
        List<ParmParmFormSetaEntity> parmFormSetaEntities = ormService.selectBeanList(ParmParmFormSetaEntity.class,formOrmParam);
        //根据pid查询参数值集
        OrmParam valueOrmParam = getParmValueOrmParam(parameterEntity.getId());
        List<ParmParmValueSetaEntity> parmValueSetaEntityList = ormService.selectBeanList(ParmParmValueSetaEntity.class,valueOrmParam);
        parameterEntity.setParm_form_set(parmFormSetaEntities);
        parameterEntity.setParm_value_set(parmValueSetaEntityList);
        return getUsePageName(parameterEntity);
    }

    /**
     * 查询参数列表（不分页）-支持模糊查询
     * @param parmType  参数类型
     * @param parmNo    参数编号
     * @param parmName  参数名称
     * @return  List<ParameterEntity>
     * @throws Exception    抛出异常
     */
    private List<ParameterEntity> getParameterList(String parmType, String parmNo, String parmName,String[] ids) throws  Exception{
        OrmParam ormParam = new OrmParam();
        setParametersOrmParam(ormParam ,parmType,parmNo,parmName,ids);
        return ormService.selectBeanList(ParameterEntity.class, ormParam);
    }

    /**
     * 分页查询参数列表——支持模糊查询
     * @param parmType  参数类型
     * @param parmNo    参数编号
     * @param parmName  参数名称
     * @param pageNum   分页参数
     * @param pageSize  分页
     * @return  Pagination<ParameterEntity>
     * @throws Exception 抛出异常
     */
    private Pagination<ParameterEntity> getParameterPageList(String parmType, String parmNo, String parmName, int pageNum, int pageSize) throws Exception {
        OrmParam parameterOrmParam = new OrmParam();
        //查询参数列表——参数设置
        setParameterPageOrmParam(parameterOrmParam, pageNum, pageSize, parmType, parmNo, parmName);
        return  ormService.selectPagedBeanList(ParameterEntity.class,parameterOrmParam);
    }

    /**
     * 根据pid和使用页面名称查询 使用页面集
     * @param columnList 查询列
     * @param fieldName 属性名
     * @param fieldValues  属性值
     * @return 返回list集合
     * @throws Exception 抛出异常
     */
    private List<ParmParmFormSetaEntity> qryParmFOrmByFormName(List<String> columnList, String fieldName, String[] fieldValues) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columnList);
        List<String> params = new ArrayList<>(fieldValues.length);
        if(fieldValues.length > 0){
            for (String fieldValue : fieldValues) {
                params.add(ormParam.getMatchMiddleXML(fieldName,fieldValue));
            }
        }
        String whereExp = OrmParam.or(params);
        ormParam.setWhereExp(whereExp);
         return ormService.selectBeanList(ParmParmFormSetaEntity.class, ormParam);
    }



    /**
     * 拼接使用页面名称，并使用逗号隔开
     *
     * @return  返回List<ParameterVO>
     * @throws Exception 抛出异常
     */
    private ParameterVO getUsePageName(ParameterEntity parameterEntity) throws Exception {
        ParameterVO parameterVO = new ParameterVO();
        if(null == parameterEntity){
            return parameterVO;
        }
        StringBuilder usePageName = new StringBuilder();
        if(null != parameterEntity.getParm_form_set() && parameterEntity.getParm_form_set().size() > 0){
            for (ParmParmFormSetaEntity parmFormSetaEntity : parameterEntity.getParm_form_set()) {
                if(parameterEntity.getId().equals(parmFormSetaEntity.getPid())&& !StringUtil.isNullOrEmpty(parmFormSetaEntity.getParm_form_name())){
                    usePageName.append(parmFormSetaEntity.getParm_form_name()).append("，");
                }
            }
        }
        EntityConvertVOUtil.assignmentOfTheSameField(parameterEntity, parameterVO);
        String pageName = "";
        if(usePageName.toString().length() > 0){
            pageName = usePageName.toString().substring(0,usePageName.toString().length()-1);
        }
        String modUserName = Utils.getUserNameByUserId(parameterVO.getModuser(),ormService);
        parameterVO.setModUserName(modUserName);
        parameterVO.setUsePageName(pageName);
        return parameterVO;
    }


    /**
     * 设置分页查询参数
     * @param ormParam ormParam
     * @param parmType 查询参数_参数类型
     * @param parmNo 查询参数_参数编号
     * @param parmName 查询参数_参数名称
     * @param pageNum 分页参数
     * @param pageSize 分页参数
     */
    private void setParameterPageOrmParam(OrmParam ormParam, int pageNum, int pageSize, String parmType, String parmNo, String parmName) {
        //设置ormParam参数
        setParametersOrmParam(ormParam, parmType, parmNo, parmName,new String[]{});
        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);
    }

    /**
     * 设置不分页查询参数
     * @param ormParam OrmParam 对象
     * @param parmType 查询参数_参数类型
     * @param parmNo 查询参数_参数编号
     * @param parmName 查询参数_参数名称
     * @param ids parameter类id
     */
    private void setParametersOrmParam(OrmParam ormParam, String parmType, String parmNo, String parmName,String[] ids) {
        List<String> list = Arrays.asList(ParameterConstant.PARAM_NO, ParameterConstant.PARAM_NAME, ParameterConstant.PARAM_VALUES, ParameterConstant.PARAM_DESC, ParameterConstant.PARAM_SEQ,
                ParameterConstant.PARAM_IS_VISIBLE, ParameterConstant.PARAM_IS_MODIFY, ParameterConstant.PARAM_CONTROL_TYPE, ParameterConstant.PARAM_CONTROL_VALUE, ParameterConstant.PARAM_TYPE);
        List<String> columnList = new ArrayList<>(list);
        numberRulesSereviceImpl.setBaseProperties(columnList);
        columnList.remove(columnList.indexOf("pid"));
        List<String> params = new ArrayList<>();
        if(!StringUtil.isNullOrEmpty(parmType)){
            params.add(ormParam.getEqualXML(ParameterConstant.PARAM_TYPE,parmType));
        }
        if(!StringUtil.isNullOrEmpty(parmNo)){
            params.add(ormParam.getMatchMiddleXML(ParameterConstant.PARAM_NO, parmNo));
        }
        if(!StringUtil.isNullOrEmpty(parmName)){
            params.add(ormParam.getMatchMiddleXML(ParameterConstant.PARAM_NAME, parmName));
        }
        if(null != ids && ids.length>0){
           params.add(ormParam.getInXML(BasicConst.ID,ids));
        }
        String whereExp = OrmParam.and(params);
        ormParam.setWhereExp(whereExp);
        ormParam.addOrderExpElement(SQLSortEnum.DESC,ParameterConstant.PARAM_SEQ);
    }

    /**
     * 添加
     * @param parameterEntity
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public int insert(ParameterEntity parameterEntity){
        int sucess =0;
        String parameterId = StringUtil.generateUUID();
        parameterEntity.setId(parameterId);
        parameterEntity.setCretime(new Date());
        int seq = getSeq();
        parameterEntity.setParm_seq(seq);
        List<ParmParmFormSetaEntity> parmParmFormSetaEntityList = parameterEntity.getParm_form_set();
        if(parmParmFormSetaEntityList==null){
            parmParmFormSetaEntityList=new ArrayList<>();
        }
        if(parmParmFormSetaEntityList.size()>0){
            for (ParmParmFormSetaEntity parmParmFormSetaEntityTemp:
                    parmParmFormSetaEntityList) {
                parmParmFormSetaEntityTemp.setId(StringUtil.generateUUID());
                parmParmFormSetaEntityTemp.setPid(parameterId);
                parmParmFormSetaEntityTemp.setClassName("parmParmFormSetaEntity");
                parmParmFormSetaEntityTemp.setCreuser(parameterEntity.getCreuser());
                parmParmFormSetaEntityTemp.setCretime(new Date());
            }

        }

        try {
            if (parmParmFormSetaEntityList.size()>0){
                ormService.insert(parmParmFormSetaEntityList);
            }
            ormService.insert(parameterEntity);
        } catch (Exception e) {

            log.error("数据插入失败",e);
            return 0;
        }
        return 0;
    }

    /**
     * 修改
     * @param parameterEntity
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public ParameterEntity modify(ParameterEntity parameterEntity){
        parameterEntity.setModtime(new Date());
        String pid = parameterEntity.getId();
        //当前数据库中存储的对象
        ParameterEntity parameterDB = null;
        try {
            parameterDB = ormService.load(ParameterEntity.class,pid);
        }catch (Exception e){
            log.error("查询异常",e);
        }
        parameterEntity.setParm_values("");
        List<ParmParmFormSetaEntity> parmParmFormSetaEntityList = parameterEntity.getParm_form_set();

        List<ParmParmValueSetaEntity> parmParmValueSetaEntityList = parameterEntity.getParm_value_set();
        if(!parameterDB.getParm_control_value().equals(parameterEntity.getParm_control_value())){
            if(parmParmValueSetaEntityList!=null){
                if(parmParmValueSetaEntityList.size()>0){
                    try {
                        OrmParam ormParam =  new OrmParam();
                        ormParam.setWhereExp(ormParam.getEqualXML("pid",pid));
                        ormService.delete(ParmParmValueSetaEntity.class,ormParam);
                    } catch (Exception e) {
                        log.error("删除失败",e);
                    }
                }
            }
            parameterEntity.setParm_value_set(new ArrayList<>());
        }
        if(parmParmFormSetaEntityList==null){
            parmParmFormSetaEntityList=new ArrayList<>();
        }else {
            try {
                OrmParam ormParam =  new OrmParam();
                ormParam.setWhereExp(ormParam.getEqualXML("pid",pid));
                ormService.delete(ParmParmFormSetaEntity.class,ormParam);
            } catch (Exception e) {
                log.error("删除失败",e);
            }
        }
        int seq = getSeq();
        parameterEntity.setParm_seq(seq);
        if(parmParmFormSetaEntityList.size()>0){
            for (ParmParmFormSetaEntity parmParmFormSetaEntityTemp:
                    parmParmFormSetaEntityList) {
                parmParmFormSetaEntityTemp.setClassName("parmParmFormSetaEntity");
                parmParmFormSetaEntityTemp.setCreuser(parameterEntity.getCreuser());
                parmParmFormSetaEntityTemp.setCretime(new Date());
                parmParmFormSetaEntityTemp.setId(StringUtil.generateUUID());
                parmParmFormSetaEntityTemp.setPid(pid);
            }

        }
        try {
            if (parmParmFormSetaEntityList.size()>0){
                ormService.insert(parmParmFormSetaEntityList);
            }
            ormService.update(parameterEntity);
        } catch (Exception e) {

            log.error("数据更新失败",e);
            return parameterEntity;
        }
        return parameterEntity;
    }

    /**
     * 获取系统最大编号
     * @return
     */
    private int getSeq() {
        int seq = 0;
        try{
            List<Map<String, Object>> list = ormService.getDataBySql("SELECT MAX(parm_seq) parm_seq FROM parameter;");
            if(list!=null&&list.size()>0){
                Map<String,Object> maps = list.get(0);
                String parmSeq = String.valueOf(maps.get("parm_seq"));
                seq = Integer.valueOf(parmSeq)+1;
            }
        }catch (Exception e){
            log.error("获取最大值失败");
//            return 0;
        }
        return seq;
    }

    /**
     * 匹配属性
     * @param classId
     * @param valueId
     * @param textId
     * @param tip
     * @return
     */
    @Override
    public List<TipVO> getTip(String classId,String valueId,String textId,String tip){
        // 根据属性id，获取属性
        String value = "";
        String text = "";
        String className ="";
        String propertyId = "";
        String propertyName ="";
        Result resultClass = modelerProvider.getClassById(classId);
        Result resultValue = modelerProvider.getProperty(valueId);
        Result resultText = modelerProvider.getProperty(textId);
        Object dataValue = resultValue.getData();
        Object dataText = resultText.getData();
        Object dataClass = resultClass.getData();
        if(dataValue!=null){
            Map<String,String> valueMap = (Map<String, String>) dataValue;
            if(valueMap!=null){
                value = valueMap.get("edmpCode");
                propertyId = valueMap.get("edmpParentId");
            }
        }
        if(!StringUtil.isNullOrEmpty(propertyId)){
            Result propertyResult = modelerProvider.getProperty(propertyId);
            Object dataProperty = propertyResult.getData();

            if(dataProperty!=null){
                Map<String,String> propertyMap = (Map<String, String>) dataProperty;
                if(propertyMap!=null){
                    propertyName = propertyMap.get("tablename");
                }
            }
        }
        if(dataText!=null){
            Map<String,String> textMap = (Map<String, String>) dataText;
            if(textMap!=null){
                text = textMap.get("edmpCode");
            }
        }
        if(dataClass!=null){
            Map<String,String> classMap = (Map<String, String>) dataClass;
            if(dataClass!=null){
                className = classMap.get("edmcCode");
            }
        }

        List<Map<String,Object>> maps = new ArrayList<>();
        if(StringUtil.isNullOrEmpty(tip)){
            try {
                if(!StringUtil.isNullOrEmpty(propertyName)){
                    className = propertyName;
                }
                maps = ormService.getDataBySql("SELECT id, "+value+","+text+" FROM "+className + " WHERE IS_DEL='0'  LIMIT 50");
            }catch (Exception e){
                log.error("",e);
                return  null;
            }
        }else{

            try {
                if(!StringUtil.isNullOrEmpty(propertyName)){
                    className = propertyName;
                }
                maps = ormService.getDataBySql("SELECT id, "+value+","+text+" FROM "+className+" WHERE "+ text +" like "+"'%"+tip+"%'"+ " AND IS_DEL='0'  LIMIT 50");
            }catch (Exception e){
                return  null;
            }
        }
        List<TipVO> list = new ArrayList<>();
        for(Map<String,Object> map : maps){
            TipVO vo = new TipVO();
            vo.setId((String)map.get("id"));
            vo.setValues(String.valueOf(map.get(value)));
            vo.setText(String.valueOf(map.get(text)));
            list.add(vo);
        }
        return  list;
    }
    /**
     * 参数上下移
     * @param parameterEntities 参数集合
     * @return 返回执行状态
     * @throws Exception 抛出异常
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String updateList(List<ParameterEntity> parameterEntities) throws Exception{
        //临时存放集合的排序值
        List<Integer> parmSeqs = new ArrayList<>(parameterEntities.size());
        for (ParameterEntity parameterEntity : parameterEntities) {
            parmSeqs.add(parameterEntity.getParm_seq());
        }
        //parmSeqs按照排序值parm_seq倒序排列
        Collections.sort(parmSeqs);
        //parameterEntities集合索引
        int index = (parameterEntities.size()-1);
        int lenth = parameterEntities.size();
        for (ParameterEntity parameterEntity : parameterEntities) {
            parameterEntity.setParm_seq(parmSeqs.get(index--));
            lenth -= ormService.update(parameterEntity);
        }
        if(lenth == 0){
            return "success";
        }
        return "warning";
    }

    /**
     * 校验编号
     * @param paramNo
     * @return
     */
    @Override
    public String checkParamNo(String paramNo){
        String flag = "0";
        OrmParam ormParam = new OrmParam();
        List<String> columns = new ArrayList<>();
        columns.add("id");
        ormParam.setColumns(columns);
        ormParam.setWhereExp(ormParam.getEqualXML("parm_no",paramNo));
        try {
            List<ParameterEntity> parameterEntityList = ormService.selectBeanList(ParameterEntity.class,ormParam);
            if (parameterEntityList.size()>0){
                flag = "1";
            }
        }catch (Exception e){
            return "0";
        }
        return flag;
    }

    /**
     * 校验名称
     * @param paramName
     * @return
     */
    @Override
    public String checkParamName(String paramName){
        String flag = "0";
        OrmParam ormParam = new OrmParam();
        List<String> columns = new ArrayList<>();
        columns.add("id");
        ormParam.setColumns(columns);
        ormParam.setWhereExp(ormParam.getEqualXML("parm_name",paramName));
        try {
            List<ParameterEntity> parameterEntityList = ormService.selectBeanList(ParameterEntity.class,ormParam);
            if (parameterEntityList.size()>0){
                flag = "1";
            }
        }catch (Exception e){
            return "0";
        }
        return flag;
    }

    @Override
    public  List<ParmParmValueSetaEntity> queryValuesSetByPid(String pid)throws Exception{
        if(StringUtil.isNullOrEmpty(pid)){
            return new ArrayList<>();
        }
        List<String> valueColumnList = new ArrayList<>(Arrays.asList(ParmValueConstant.PARM_VALUE_SEQ,ParmValueConstant.PARM_ONE,
        ParmValueConstant.PARM_TWO,ParmValueConstant.PARM_THREE,ParmValueConstant.PARM_FOUR,ParmValueConstant.PARM_FIVE,
        ParmValueConstant.CLASSNAME,ParmValueConstant.PARM_ONE_VIEW,ParmValueConstant.PARM_TWO_VIEW,ParmValueConstant.PARM_THREE_VIEW,
        ParmValueConstant.PARM_FOUR_VIEW,ParmValueConstant.PARM_FIVE_VIEW));
        //根据pid查询ParmParmValueSetaEntity集合
        OrmParam ormParam = selectByPid(valueColumnList,new String[]{pid});
        ormParam.addOrderExpElement(SQLSortEnum.ASC,ParmValueConstant.PARM_VALUE_SEQ);
        List<ParmParmValueSetaEntity> valueSetaEntities = ormService.selectBeanList(ParmParmValueSetaEntity.class,ormParam);
        return valueSetaEntities;
    }

    @Override
    @Transactional(rollbackFor = Exception.class,propagation= Propagation.NOT_SUPPORTED)
    public Map<String, String> creParamOrder(HttpServletRequest request, ParameterOrderVO orderVO) throws Exception {
        List<ParoOrdeVO> paroOrdeVOS = orderVO.getParo_orde_set();
        /**
         * 校验是否存在待审单据
         */
        if(paroOrdeVOS != null && paroOrdeVOS.size() >0){
            List<String> parmNos = new ArrayList<>(paroOrdeVOS.size());
            for (ParoOrdeVO paroOrdeVO : paroOrdeVOS) {
                parmNos.add(paroOrdeVO.getParm_no());
            }
            OrmParam ormParam = new OrmParam();
            ormParam.setOrderExp(SQLSortEnum.DESC,BasicConst.CRETIME);
            ormParam.setWhereExp(ormParam.getInXML(ParoParoOrdeSetaProperty.PAROO_NO,parmNos.toArray()));
            List<ParoParoOrdeSetaEntity> paroParoOrdeSetaEntities = ormService.selectBeanList(ParoParoOrdeSetaEntity.class, ormParam);

            if(paroParoOrdeSetaEntities != null && paroParoOrdeSetaEntities.size() > 0) {
                OrmParam orm = new OrmParam();
                String orderId = paroParoOrdeSetaEntities.get(0).getPid();
                System.out.println(orderId);
                orm.setWhereExp(OrmParam.and(orm.getEqualXML(BasicConst.ID,orderId),orm.getInXML(OrderConstants.ORDE_STATUS,new String[]{OrderConstants.ORDE_STATUS_2,OrderConstants.ORDE_STATUS_3,OrderConstants.ORDE_STATUS_4})));
                List<ParameterorderEntity> parameterorderEntities = ormService.selectBeanList(ParameterorderEntity.class, orm);
                if(parameterorderEntities.size()>0){
                    throw new RuntimeException("已存在待审单据");
                }
            }
        }
        ParameterorderEntity orderEntity = JSONObject.parseObject(JSONObject.toJSONString(orderVO),ParameterorderEntity.class);
        // 获取用户登录认证
        // todo 维护人信息暂时取自然人
        String authorization = request.getHeader("Authorization");
        String creuser = Utils.getCurentUserId(authorization);
        //生成单据号码
        Result result = nbrlGetCodeService.callByActive(OrderConstants.PARO_ORDENBR_PREFIX, null);
        if(result == null || result.getData() == null){
            throw new RuntimeException("生成单据号码失败!");
        }
        // 单据号码
        String ordeNbr = result.getData().toString();

        orderEntity.setOrde_nbr(ordeNbr);
        orderEntity.setCreuser(creuser);
        orderEntity.setModuser(creuser);
        orderEntity.setOrde_status(OrderConstants.ORDE_STATUS_2);
        String orderId = ormService.insert(orderEntity).toString();

        if(StringUtil.isNullOrEmpty(orderId) && paroOrdeVOS != null && paroOrdeVOS.size()> 0){
            throw new RuntimeException("单据提交失败");
        }else{
            List<ParoParoOrdeSetaEntity> paroOrdeEntityList = JSONObject.parseArray(JSONObject.toJSONString(paroOrdeVOS),ParoParoOrdeSetaEntity.class);
//            List<ParoParooValueSetbEntity> orderValueEntityList = new ArrayList<>();
            for (ParoParoOrdeSetaEntity paroParoOrdeSetaEntity : paroOrdeEntityList) {
                paroParoOrdeSetaEntity.setPid(orderId);
                paroParoOrdeSetaEntity.setClassName("parameterorder");
                paroParoOrdeSetaEntity.setCreuser(orderVO.getOrdeAdduser());
//                EdmUtil.setPropertyBaseEntitiesSysColumns(ParoParoOrdeSetaEntity.class,paroParoOrdeSetaEntity, paroParoOrdeSetaEntity.getParoo_value_set(), SQLCurdEnum.INSERT);
//                orderValueEntityList.addAll(paroParoOrdeSetaEntity.getParoo_value_set());
            }
            //插入参数集
            ormService.insert(paroOrdeEntityList);
            //插入参数值集
//            ormService.insert(orderValueEntityList);
        }
        //提交流程
        OrderUtils.submitWorkFlow(orderRegService,authorization,orderEntity.getOrde_rode_obj(),orderId);
        Map<String,String> map = new HashMap<>(3);
        map.put("orderNbr",ordeNbr);
        map.put("orderId",orderId);
        return map;

//
    }

    @Override
    public void audit(HttpServletRequest request, JSONObject auditSet) {
        RedisClusterUtils redisClusterUtils = new RedisClusterUtils(Constants.REDIS_NODES);
        System.out.println(JSONObject.toJSONString(auditSet));
        String auditKey = auditSet.getString(WorkFlowConstants.PARAM_AUDITKEY);
        String formState = auditSet.getString(WorkFlowConstants.PARAM_FORMSTATE);
        String actInstanceId = auditSet.getString(WorkFlowConstants.PARAM_ACT_INSTANCE_ID);
        String opinion = auditSet.getString(WorkFlowConstants.PARAM_OPINION);
        opinion = StringUtil.isNullOrEmpty(opinion) ? "" : opinion;
        LinkedHashMap auditMsg = (LinkedHashMap) auditSet.get(WorkFlowConstants.PARAM_ORDER_OBJ);
        List<LinkedHashMap> mapList = (List<LinkedHashMap>) auditMsg.get("paroOrdeSet");
        for (LinkedHashMap linkedHashMap : mapList) {
            redisClusterUtils.setValue(linkedHashMap.get(BasicConst.ID).toString(), linkedHashMap.get(ParoParoOrdeSetaProperty.PAROO_OPER_STATUS).toString());
        }
        if (StringUtil.isNullOrEmpty(auditKey)) {
            throw new RuntimeException("请传入参数" + WorkFlowConstants.PARAM_AUDITKEY);
        } else if (StringUtil.isNullOrEmpty(formState)) {
            throw new RuntimeException("请传入参数" + WorkFlowConstants.PARAM_FORMSTATE);
        } else if (StringUtil.isNullOrEmpty(actInstanceId)) {
            throw new RuntimeException("请传入参数" + WorkFlowConstants.PARAM_ACT_INSTANCE_ID);
        }

        // 调用流程
        OrderUtils.audit(orderRegService, request, actInstanceId, opinion, auditKey);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void approve(HttpServletRequest request, String orderId, String handlerType) {
        String authorization = request.getHeader("Authorization");
        try {
            ParameterorderEntity orderEntity = ormService.load(ParameterorderEntity.class,orderId);
            if (orderEntity == null){
                throw new RuntimeException("查询参数维护单错误 单据id：" + orderId);
            }
            //设置登录人的信息
//           setOrderInfo(authorization,orderEntity);
            // 根据请求方式的不同进行不同的处理逻辑
            // 通过
            if (OrderConstants.PASS.equals(handlerType)) {
                OrmParam ormParam = new OrmParam();
                ormParam.setWhereExp(ormParam.getEqualXML(BasicConst.PID,orderEntity.getId()));
                List<ParoParoOrdeSetaEntity> ordeSetaEntities = ormService.selectBeanList(ParoParoOrdeSetaEntity.class,ormParam);
                orderEntity.setParo_orde_set(ordeSetaEntities);
                //删除原有参数值集
                deleteOldValues(ordeSetaEntities);
                //新增修改后的参数值集
                insertNewValues(ordeSetaEntities,orderEntity.getOrde_adduser());
                // 修改parameter参数值
                updateParmValues(ordeSetaEntities, orderEntity.getModuser());
                // 完成：修改单据状态为完成(5)
                updateOrderStatus(orderEntity, OrderConstants.ORDE_STATUS_5);
            }
            // 撤销：修改单据状态为临时(1)
            else if (OrderConstants.REVOKE.equals(handlerType)) {
                updateOrderStatus(orderEntity, OrderConstants.ORDE_STATUS_1);
            }
            // 退回: 修改单据状态为退回(6)
            else if (OrderConstants.RETURN_BACK.equals(handlerType)) {
                updateOrderStatus(orderEntity, OrderConstants.ORDE_STATUS_6);
            }
        } catch (Exception e) {
            throw new RuntimeException("参数维护单批准通过出错:" + e.getMessage());
        }
    }

    @Override
    public List<Map<String, Object>> qryParmSetting(String pageCode, String parmType, String parmName) throws Exception {
        sqlValidate(parmName,pageCode,parmName);
        // 根据参数查询数据
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT p.id,p.parm_type,p.parm_desc ,p.parm_values ,p.parm_no,p.parm_control_type ,p.parm_name , p.parm_control_value, p.parm_is_visible, p.parm_is_modify  from parameter p LEFT JOIN parm_parm_form_seta pf on p.id = pf.pid ");
        sql.append("where pf.parm_form_code like '%").append(pageCode).append("%' ");
        if(StringUtils.isNotEmpty(parmType)){
            sql.append(" and p.parm_type= '").append(parmType).append("'");
        }
        if(StringUtils.isNotEmpty(parmName)){
            sql.append(" and p.parm_name like'%").append(parmName).append("%' ");
        }
        sql.append(" and p.is_del=0 and pf.is_del=0");
        String sqlStr = sql.toString();
        StringEscapeUtils.escapeSql(sqlStr);
        List<Map<String,Object>> mapLsit = ormService.getDataBySql(sqlStr);
        if (mapLsit != null && mapLsit.size() > 0){
            for (Map<String, Object> objectMap : mapLsit) {
                OrmParam ormParam = new OrmParam();
                ormParam.setOrderExp(SQLSortEnum.DESC,BasicConst.CRETIME);
                ormParam.setWhereExp(ormParam.getEqualXML(ParoParoOrdeSetaProperty.PAROO_NO, objectMap.get(ParameterProperty.PARM_NO)));
                List<ParoParoOrdeSetaEntity> paroParoOrdeSetaEntities = ormService.selectBeanList(ParoParoOrdeSetaEntity.class,ormParam);
                if(paroParoOrdeSetaEntities != null && paroParoOrdeSetaEntities.size() > 0){
                    ParameterorderEntity parameterorderEntity = ormService.load(ParameterorderEntity.class, paroParoOrdeSetaEntities.get(0).getPid());
                    if (parameterorderEntity != null && parameterorderEntity.getOrde_status().equals(OrderConstants.ORDE_STATUS_2)){
                        objectMap.put("isAudit", 1);
                    }
                }else{
                    objectMap.put("isAudit", "0");
                }
            }
        }
        return mapLsit;
    }

    @Override
    public ParameterorderEntity loadOrder(String orderId) throws Exception {
        // 参数单据
        ParameterorderEntity parameterorderEntity = ormService.load(ParameterorderEntity.class,orderId);
        // 查询参数参数单据类子集
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(BasicConst.PID, parameterorderEntity.getId()));
        List<ParoParoOrdeSetaEntity> paroOrdeEntityList = ormService.selectBeanList(ParoParoOrdeSetaEntity.class, ormParam);
        parameterorderEntity.setParo_orde_set(paroOrdeEntityList);
        return parameterorderEntity;
    }

    @Override
    public Pagination<ParameterOrderVO> parameterOrderList(String ordeStatus, Integer pageSize, Integer pageNum) throws Exception {
        OrmParam ormParam = new OrmParam();
        if(!StringUtil.isNullOrEmpty(ordeStatus)){
            ormParam.setWhereExp(ormParam.getEqualXML(OrderProperty.ORDE_STATUS, ordeStatus));
        }
        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);
        ormParam.setOrderExp(SQLSortEnum.DESC,BasicConst.CRETIME);
        Pagination<ParameterorderEntity> list = ormService.selectPagedBeanList(ParameterorderEntity.class, ormParam);
        if(list == null || list.getTotal()==0){
            return null;
        }
        List<ParameterOrderVO> voList = JSONObject.parseArray(JSONObject.toJSONString(list.getList()), ParameterOrderVO.class);
        // 查询制单人相关中文信息
        qryAddUserZHInfo(voList);
        return new Pagination<ParameterOrderVO>(voList,pageNum,pageSize,list.getTotal());
    }

    /**
     * 修改单据状态
     * @param orderEntity
     * @param orderStatus
     * @throws Exception
     */
    private void updateOrderStatus(ParameterorderEntity orderEntity, String orderStatus) throws Exception{
        orderEntity.setOrde_status(orderStatus);
        ormService.updateSelective(orderEntity);
    }

    /**
     * 删除所有提交的参数单据对应的参数值集
     * @param ordeSetaEntities
     * @throws Exception
     */
    private void deleteOldValues(List<ParoParoOrdeSetaEntity> ordeSetaEntities)throws Exception{
        if(ordeSetaEntities==null || ordeSetaEntities.size() == 0){
            return;
        }
        // 临时存储id参数
        List<String> ids = new ArrayList<>(ordeSetaEntities.size());
        List<Map<String, Object>> mapList = qryIdsByNames(ordeSetaEntities);
        if(mapList != null && mapList.size() > 0){
            for (Map<String, Object> stringObjectMap : mapList) {
                ids.add(stringObjectMap.get("id").toString());
            }
        }
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getInXML(BasicConst.PID,ids.toArray()));
        ormService.delete(ParmParmValueSetaEntity.class,ormParam);
    }



    private void insertNewValues(List<ParoParoOrdeSetaEntity> ordeSetaEntities,String creUser)throws Exception{
        if(ordeSetaEntities==null || ordeSetaEntities.size() == 0){
            return;
        }
        List<ParmParmValueSetaEntity> parmValueSetaEntityList = new ArrayList<>();
        List<Map<String, Object>> mapList = qryIdsByNames(ordeSetaEntities);
        if(mapList == null || mapList.size() == 0) {
            return;
        }
        for (Map<String, Object> map : mapList) {
            for (ParoParoOrdeSetaEntity ordeSetaEntity : ordeSetaEntities) {
                if(map.get(ParameterProperty.PARM_NAME).toString().equals(ordeSetaEntity.getParoo_name().toString())){
                    List<ParmParmValueSetaEntity> valueSetaEntities = parseParmValue(ordeSetaEntity.getParoo_values(),map.get(BasicConst.ID).toString(),creUser);
                    parmValueSetaEntityList.addAll(valueSetaEntities);
                }
            }
        }
        ormService.insert(parmValueSetaEntityList);
    }

    /**
     * 根据名称 查询 id
     * @param ordeSetaEntities
     * @return
     * @throws Exception
     */
    private List<Map<String, Object>> qryIdsByNames(List<ParoParoOrdeSetaEntity> ordeSetaEntities) throws Exception {
        RedisClusterUtils redisClusterUtils = new RedisClusterUtils(Constants.REDIS_NODES);

        //临时存储参数名
        List<String> parmNames = new ArrayList<>(ordeSetaEntities.size());
        for (ParoParoOrdeSetaEntity ordeSetaEntity : ordeSetaEntities) {
            if(Integer.valueOf(redisClusterUtils.getValue(ordeSetaEntity.getId())).equals(OrderConstants.OPERA_STATUS_PASS)){
                parmNames.add(ordeSetaEntity.getParoo_name());
            }
        }
        if(parmNames.size() == 0){
            return null;
        }
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(Arrays.asList("id","parm_name"));
        ormParam.setWhereExp(ormParam.getInXML(ParameterProperty.PARM_NAME, parmNames.toArray()));
        List<Map<String, Object>> mapList = ormService.selectMapList(ParameterEntity.class, ormParam);
//        String sql = "select id,parm_name name from parameter where parm_name in ("+parmNames.toArray()+")";
        return  mapList;
    }

    /**
     * 解析参数值
     * @param parmValues
     * @param parameterId
     * @return
     */
    private List<ParmParmValueSetaEntity> parseParmValue(String parmValues,String parameterId, String creuser) {
        List<ParmParmValueSetaEntity> valueSetaEntities = new ArrayList<>();
        String[] parm_values = parmValues.split(";");
        int parmSeq = 1;
        for (String value : parm_values) {
            String[] values = value.split(",");
            ParmParmValueSetaEntity parmValueSetaEntity = new ParmParmValueSetaEntity();
            parmValueSetaEntity.setPid(parameterId);
            parmValueSetaEntity.setClassName("parameter");
            parmValueSetaEntity.setCreuser(creuser);
            if(values.length >= 1){
                parmValueSetaEntity.setParm_one(values[0]);
                parmValueSetaEntity.setParm_one_view(values[0]);
            }
            if(values.length >= 2){
                parmValueSetaEntity.setParm_two(values[1]);
                parmValueSetaEntity.setParm_two_view(values[1]);
            }
            if(values.length >= 3){
                parmValueSetaEntity.setParm_three(values[2]);
                parmValueSetaEntity.setParm_three_view(values[2]);
            }
            if(values.length >= 4){
                parmValueSetaEntity.setParm_four(values[3]);
                parmValueSetaEntity.setParm_four_view(values[3]);
            }
            if(values.length == 5){
                parmValueSetaEntity.setParm_five(values[4]);
                parmValueSetaEntity.setParm_five_view(values[4]);
            }
            parmValueSetaEntity.setParm_value_seq(parmSeq);
            parmSeq++;
            valueSetaEntities.add(parmValueSetaEntity);
        }
        return valueSetaEntities;
    }

    /**
     * 修改parameter参数值
     * @param ordeSetaEntities
     */
    private void updateParmValues(List<ParoParoOrdeSetaEntity> ordeSetaEntities, String moduser) throws Exception{
        RedisClusterUtils redisClusterUtils = new RedisClusterUtils(Constants.REDIS_NODES);
        if(ordeSetaEntities==null || ordeSetaEntities.size() == 0){
            return;
        }
        List<ParameterEntity> parameterEntityList = new ArrayList<>(ordeSetaEntities.size());
        for (ParoParoOrdeSetaEntity ordeSetaEntity : ordeSetaEntities) {
            if(Integer.valueOf(redisClusterUtils.getValue(ordeSetaEntity.getId())).equals(OrderConstants.OPERA_STATUS_PASS)){
                ParameterEntity parameterEntity = new ParameterEntity();
                parameterEntity.setParm_values(ordeSetaEntity.getParoo_values());
                parameterEntity.setParm_no(ordeSetaEntity.getParoo_no());
                parameterEntity.setModuser(moduser);
                parameterEntityList.add(parameterEntity);
            }
        }
        OrmParam ormParam = new OrmParam();
        for (ParameterEntity parameterEntity : parameterEntityList) {
            ormParam.setWhereExp(ormParam.getEqualXML(ParameterProperty.PARM_NO, parameterEntity.getParm_no()));
            ormService.updateSelective(parameterEntity,ormParam);
            ormParam.reset();
        }
    }

    /**
     * sql注入校验
     * @param str
     */
    private void sqlValidate(String...str) {
        //过滤掉的sql关键字，可以手动添加
        String badStr = "'|and|exec|execute|insert|select|delete|update|count|drop|%|chr|mid|master|truncate|" +
                "char|declare|sitename|net user|xp_cmdshell|;|or|+|,|like'|and|exec|execute|insert|create|drop|" +
                "table|from|grant|use|group_concat|column_name|" +
                "information_schema.columns|table_schema|union|where|select|delete|update|order|by|count|" +
                "chr|mid|master|truncate|char|declare|or|;|--|+|,|like|//|/|%|#|>|>=|<|<=";
        String[] badStrs = badStr.split("\\|");
        for (int i = 0; i < badStrs.length; i++) {
            for (String s : str) {
                if (s.indexOf(badStrs[i]) >= 0) {
                    throw new RuntimeException("查询参数存在非法字符["+badStrs[i]+"]");
                }
            }
        }
    }

    /**
     * 查询制单人相关中文信息
     * @param voList
     */
    private void qryAddUserZHInfo(List<ParameterOrderVO> voList) throws Exception {
        // 临时存储 制单人id
        HashSet<String> addUserIdList = new HashSet<>();
        // 临时存储制单人部门id
        HashSet<String> addUserDeptIdList = new HashSet<>();
        // 临时存储制单人岗位id
        HashSet<String> addUserDutyIdList = new HashSet<>();

        for (ParameterOrderVO parameterOrderVO : voList) {
            addUserIdList.add(parameterOrderVO.getOrdeAdduser());
            addUserDeptIdList.add(parameterOrderVO.getOrdeDept());
            addUserDutyIdList.add(parameterOrderVO.getOrdeDuty());
        }
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(Arrays.asList(BasicConst.ID,EmployeeProperty.REMP_NAME));
        ormParam.setWhereExp(ormParam.getInXML(BasicConst.ID, addUserIdList.toArray()));
        // 员工
        List<EmployeeEntity> employeeEntityList = ormService.selectBeanList(EmployeeEntity.class,ormParam);
        // 岗位
        OrmParam ormParam1 = new OrmParam();
        ormParam1.setColumns(Arrays.asList(BasicConst.ID,JobpositionProperty.RPOS_NAME));
        ormParam1.setWhereExp(ormParam1.getInXML(BasicConst.ID, addUserDutyIdList.toArray()));
        List<JobpositionEntity> jobpositionEntityList = ormService.selectBeanList(JobpositionEntity.class, ormParam1);
        // 部门
        OrmParam ormParam2 = new OrmParam();
        ormParam2.setColumns(Arrays.asList(BasicConst.ID,DepttreeProperty.MDEP_NAME));
        ormParam2.setWhereExp(ormParam2.getInXML(BasicConst.ID, addUserDeptIdList.toArray()));
        List<DepttreeEntity> depttreeEntities = ormService.selectBeanList(DepttreeEntity.class, ormParam2);
        for (ParameterOrderVO parameterOrderVO : voList) {
            if(employeeEntityList != null && employeeEntityList.size() > 0){
                for (EmployeeEntity employeeEntity : employeeEntityList) {
                    if(StringUtil.isEqual(parameterOrderVO.getOrdeAdduser(), employeeEntity.getId())){
                        parameterOrderVO.setOrdeAdduserName(employeeEntity.getRemp_name());
                    }
                }
            }
            if (jobpositionEntityList != null && jobpositionEntityList.size() > 0){
                for (JobpositionEntity jobpositionEntity : jobpositionEntityList) {
                    if (StringUtil.isEqual(parameterOrderVO.getOrdeDuty(), jobpositionEntity.getId())) {
                        parameterOrderVO.setOrdeDutyName(jobpositionEntity.getRpos_name());
                    }
                }
            }
            if (depttreeEntities != null && depttreeEntities.size() > 0){
                for (DepttreeEntity depttreeEntity : depttreeEntities) {
                    if(StringUtil.isEqual(parameterOrderVO.getOrdeDept(), depttreeEntity.getId())){
                        parameterOrderVO.setOrdeDeptName(depttreeEntity.getMdep_name());
                    }
                }
            }
        }
    }
}
