package com.huntkey.rx.sceo.provider.parameter.service.impl;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.ParameterEntity;
import com.huntkey.rx.edm.entity.ParmParmFormSetaEntity;
import com.huntkey.rx.edm.entity.ParmParmValueSetaEntity;
import com.huntkey.rx.sceo.common.model.paramter.VO.TreeVO;
import com.huntkey.rx.sceo.common.model.paramter.constant.ParameterConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import com.huntkey.rx.sceo.provider.parameter.service.ParameterSettingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * @author zoulj
 * @create 2018/1/8 10:38
 **/
@Service
public class ParameterSettingServiceImpl implements ParameterSettingService {

    @Autowired
    private OrmService ormService;

    @Autowired
    private ModelerProvider modelerProvider;

    @Override
    public Map<String, List<ParameterEntity>> qryParametersGroupByParamType(String pageCode,String paramNo) throws Exception {
        OrmParam ormParam = new OrmParam();
        List<String> list = new ArrayList<>();
        List<String> parameterIds = new ArrayList<>();
        if(!pageCode.equals("all")){
            list = new ArrayList<>(Arrays.asList("pid","parm_form_code","parm_form_name"));
            ormParam.setColumns(list);

            ormParam.setWhereExp(ormParam.getEqualXML("parm_form_code",pageCode));
            List<ParmParmFormSetaEntity> formSetaEntities = ormService.selectBeanList(ParmParmFormSetaEntity.class, ormParam);
            for(ParmParmFormSetaEntity entity:formSetaEntities){
                parameterIds.add(entity.getPid());
            }
        }
        Map<String, List<ParameterEntity>> map = new HashMap<>();
        list.clear();
        ormParam.reset();
        list = new ArrayList<>(Arrays.asList("id", ParameterConstant.PARAM_NO, ParameterConstant.PARAM_NAME, ParameterConstant.PARAM_VALUES, ParameterConstant.PARAM_DESC, ParameterConstant.PARAM_SEQ,
                ParameterConstant.PARAM_IS_VISIBLE, ParameterConstant.PARAM_IS_MODIFY, ParameterConstant.PARAM_CONTROL_TYPE, ParameterConstant.PARAM_CONTROL_VALUE, ParameterConstant.PARAM_TYPE));
        ormParam.setColumns(list);
        if(!pageCode.equals("all")){
            List<String> params = new ArrayList<>();
            if(!StringUtil.isNullOrEmpty(paramNo)){
                params.add(ormParam.getEqualXML("parm_no",paramNo));
            }
            params.add(ormParam.getInXML("id",parameterIds.toArray()));
            String whereExp = OrmParam.and(params);
            ormParam.setWhereExp(whereExp);
        }

        ormParam.setOrderExp(SQLSortEnum.DESC,ParameterConstant.PARAM_SEQ);
        List<ParameterEntity> parameterEntities = ormService.selectBeanList(ParameterEntity.class, ormParam);

        for (ParameterEntity entity : parameterEntities) {
            list.clear();

            String[] paramValue = {"id", "pid", "classname", "parm_one", "parm_two", "parm_three", "parm_four", "parm_five", "parm_one_view", "parm_two_view", "parm_three_view", "parm_four_view", "parm_five_view", "parm_value_seq"};
            list.addAll(Arrays.asList(paramValue));
            ormParam.reset();
            ormParam.setColumns(list);
            ormParam.setWhereExp(ormParam.getEqualXML("pid", entity.getId()));
            ormParam.addOrderExpElement(SQLSortEnum.ASC, "parm_value_seq");
            entity.setParm_value_set(ormService.selectBeanList(ParmParmValueSetaEntity.class, ormParam));
            List<ParameterEntity> temp;
            if (map.get(entity.getParm_type()) == null) {
                temp = new ArrayList<>();
            } else {
                temp = map.get(entity.getParm_type());
            }
            temp.add(entity);
            map.put(entity.getParm_type(), temp);
        }
        return map;
    }

    @Override
    public int updataParameValues(Map<String, List<ParameterEntity>> map) throws Exception {
        int succ = 0;
        for (String key : map.keySet()) {
            List<ParameterEntity> list = map.get(key);
            for (ParameterEntity entity : list) {
                succ += updataParameValue(entity);
            }
        }
        return succ;
    }

    @Override
    @Transactional
    public int updataParameValue(ParameterEntity entity) throws Exception {
        ParameterEntity db = ormService.load(ParameterEntity.class, entity.getId());
        OrmParam ormParam = new OrmParam();
        List<String> list = new ArrayList<>();
        String[] paramValue = {"id", "parm_one", "parm_two", "parm_three", "parm_four", "parm_five", "parm_one_view", "parm_two_view", "parm_three_view", "parm_four_view", "parm_five_view", "parm_value_seq"};
        list.addAll(Arrays.asList(paramValue));
        ormParam.setColumns(list);
        ormParam.setWhereExp(ormParam.getEqualXML("pid", db.getId()));
        Map<String, ParmParmValueSetaEntity> parm_value_setdb = listToMap(ormService.selectBeanList(ParmParmValueSetaEntity.class, ormParam));

        db.setParm_values(entity.getParm_values());
        db.setModtime(new Date());

        List<ParmParmValueSetaEntity> parm_value_set = entity.getParm_value_set();
        for (ParmParmValueSetaEntity entity1 : parm_value_set) {
            if (parm_value_setdb.get(entity1.getId()) == null) {
                entity1.setPid(db.getId());
                entity1.setClassName("ParmParmValueSetaEntity");
                entity1.setCreuser(db.getCreuser());
                entity1.setModuser(db.getModuser());
                entity1.setCretime(new Date());
                entity1.setModtime(new Date());
                ormService.insert(entity1);
            } else {
                entity1.setModuser(db.getModuser());
                entity1.setModtime(new Date());
                ormService.updateSelective(entity1);
            }
            parm_value_setdb.remove(entity1.getId());
        }
        Set s = parm_value_setdb.keySet();
        if (s.size() > 0) {
            ormParam.reset();
            ormParam.setWhereExp(ormParam.getInXML("id", s.toArray()));
            ormService.delete(ParmParmValueSetaEntity.class, ormParam);
        }
        return ormService.update(db);
    }

    private Map<String, ParmParmValueSetaEntity> listToMap(List<ParmParmValueSetaEntity> list) {
        Map<String, ParmParmValueSetaEntity> map = new HashMap<>();
        if (list == null) {
            list = new ArrayList<>();
        }
        for (ParmParmValueSetaEntity entity : list) {
            map.put(entity.getId(), entity);
        }
        return map;
    }

    @Override
    public List<TreeVO> qryTree(String classId, String valueId, String textId, String pId) {
        // 根据属性id，获取属性
        String value = "";
        String text = "";
        String className = "";
        String pName = "";
        Result resultClass = modelerProvider.getClassById(classId);
        Result resultValue = modelerProvider.getProperty(valueId);
        Result resultText = modelerProvider.getProperty(textId);
        Result resultPId = modelerProvider.getProperty(pId);
        Object dataValue = resultValue.getData();
        Object dataText = resultText.getData();
        Object dataClass = resultClass.getData();
        Object dataPName = resultPId.getData();
        if (dataValue != null) {
            Map<String, String> valueMap = (Map<String, String>) dataValue;
            if (valueMap != null) {
                value = valueMap.get("edmpCode");
            }
        }
        if (dataText != null) {
            Map<String, String> textMap = (Map<String, String>) dataText;
            if (textMap != null) {
                text = textMap.get("edmpCode");
            }
        }
        if (dataClass != null) {
            Map<String, String> classMap = (Map<String, String>) dataClass;
            if (classMap != null) {
                className = classMap.get("edmcCode");
            }
        }
        if (dataPName != null) {
            Map<String, String> pNameMap = (Map<String, String>) dataPName;
            if (pNameMap != null) {
                pName = pNameMap.get("edmpCode");
            }
        }

        List<Map<String, Object>> maps = new ArrayList<>();
        try {
            maps = ormService.getDataBySql("SELECT id, " + value + "," + pName + "," + text + " FROM " + className);
        } catch (Exception e) {
            return new ArrayList<>();
        }
        Map<String,TreeVO> idMap = new HashMap<>();
        List<TreeVO> listTemp = new ArrayList<>();
        for (Map<String, Object> mapValue : maps) {
            TreeVO vo = new TreeVO();
            vo.setId((String)mapValue.get("id"));
            if(StringUtil.isNullOrEmpty((String)mapValue.get(value)) || StringUtil.isNullOrEmpty((String)mapValue.get(text))){
                continue;
            }
            vo.setPid((String)mapValue.get(pName));
            vo.setText((String)mapValue.get(text));
            vo.setValues((String)mapValue.get(value));
            idMap.put(vo.getId(),vo);
            listTemp.add(vo);
        }

        return getTree(idMap,listTemp);
    }

    @Override
    public List<ParmParmValueSetaEntity> qryParamValues(String paramNo) throws Exception {
        OrmParam ormParam = new OrmParam();
        List<String> list = new ArrayList<>(Arrays.asList("id", ParameterConstant.PARAM_NO, ParameterConstant.PARAM_NAME, ParameterConstant.PARAM_VALUES, ParameterConstant.PARAM_DESC, ParameterConstant.PARAM_SEQ,
                ParameterConstant.PARAM_IS_VISIBLE, ParameterConstant.PARAM_IS_MODIFY, ParameterConstant.PARAM_CONTROL_TYPE, ParameterConstant.PARAM_CONTROL_VALUE, ParameterConstant.PARAM_TYPE));
        ormParam.setColumns(list);
        String whereExp = "";
        if(!StringUtil.isNullOrEmpty(paramNo)){
           whereExp = ormParam.getEqualXML("parm_no",paramNo);
        }
        ormParam.setWhereExp(whereExp);

        ormParam.setOrderExp(SQLSortEnum.DESC,ParameterConstant.PARAM_SEQ);
        List<ParameterEntity> parameterEntities = ormService.selectBeanList(ParameterEntity.class, ormParam);
        ParameterEntity entity = parameterEntities.get(0);
        list.clear();

        String[] paramValue = {"id", "pid", "classname", "parm_one", "parm_two", "parm_three", "parm_four", "parm_five", "parm_one_view", "parm_two_view", "parm_three_view", "parm_four_view", "parm_five_view", "parm_value_seq"};
        list.addAll(Arrays.asList(paramValue));
        ormParam.reset();
        ormParam.setColumns(list);
        ormParam.setWhereExp(ormParam.getEqualXML("pid", entity.getId()));
        ormParam.addOrderExpElement(SQLSortEnum.ASC, "parm_value_seq");
        List<ParmParmValueSetaEntity> parmValues = ormService.selectBeanList(ParmParmValueSetaEntity.class, ormParam);
        entity.setParm_value_set(ormService.selectBeanList(ParmParmValueSetaEntity.class, ormParam));
        return parmValues;
    }

    private List<TreeVO> getTree(Map<String,TreeVO> idMap,List<TreeVO> listTemp) {
        List<TreeVO> fatherNodes = new ArrayList<>();
        List<TreeVO> tree = new ArrayList<>();
        for (TreeVO vo : listTemp) {
            if(StringUtil.isNullOrEmpty(idMap.get(vo.getPid()))){
                vo.setChildren(new ArrayList<>());
                fatherNodes.add(vo);
            }else{
                TreeVO treeVO = idMap.get(vo.getPid());
                List<TreeVO> children = treeVO.getChildren();
                if(children==null){
                    children = new ArrayList<>();
                }
                children.add(vo);
                treeVO.setChildren(children);
                idMap.put(vo.getPid(),treeVO);
            }
        }
        for(TreeVO fatherNode : fatherNodes){
            tree.add(idMap.get(fatherNode.getId()));
        }
        return tree;
    }
}
