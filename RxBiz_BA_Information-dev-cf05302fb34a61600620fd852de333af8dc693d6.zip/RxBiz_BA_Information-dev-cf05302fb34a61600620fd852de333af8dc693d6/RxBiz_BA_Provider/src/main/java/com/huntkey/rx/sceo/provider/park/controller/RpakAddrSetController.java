package com.huntkey.rx.sceo.provider.park.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;
import com.huntkey.rx.sceo.common.model.park.vo.RpakAddrVO;
import com.huntkey.rx.sceo.provider.park.service.RpakAddrService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author liucs
 * @date 2018-4-2 16:04:47
 */
@RestController
@RequestMapping("/addr")
public class RpakAddrSetController {
    @Autowired
    private RpakAddrService addrService;

    /**
     * 新增
     * @param authorization 用户登录认证
     * @param entity 对象
     * @return 返回对象id
     */
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(@RequestParam("authorization")String authorization, @RequestBody RpakAddrVO entity){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        String currentUserId = Utils.getCurentUserId(authorization);
        entity.setCreuser(currentUserId);
        try {
            result.setData(addrService.insert(entity));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 删除
     * @param authorization 登录用户认证
     * @param id 对象id
     * @return 返回删除数量
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id){
        String currentUserId = Utils.getCurentUserId(authorization);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(addrService.delete(currentUserId,id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 修改
     * @param authorization 登录用户认证
     * @param entity 对象
     * @return 返回修改记录条数
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public Result update(@RequestParam("authorization")String authorization,@RequestBody RpakAddrVO entity){
        String currentUserId = Utils.getCurentUserId(authorization);
        entity.setModuser(currentUserId);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(addrService.update(entity));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     */
    @RequestMapping(value = "/queryById/{id}",method = RequestMethod.GET)
    public Result queryById(@PathVariable("id")String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(addrService.queryById(id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 交货地址列表
     * @return
     */
    @RequestMapping(value = "/list/{pid}",method = RequestMethod.GET)
    public Result list(@PathVariable("pid")String pid){
        Result result = new Result();
        if(StringUtils.isEmpty(pid)){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg("请选择园区！");
            return result;
        }
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(addrService.list(pid));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }
}
