package com.huntkey.rx.sceo.provider.park.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.sceo.common.model.park.vo.ParkVO;

import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 14:20:44
 */
public interface ParkService {

    /**
     * 新增
     * @param entity 对象
     * @return 返回对象id
     * @throws Exception 抛出异常
     */
    String insert(ParkVO entity)throws Exception;

    /**
     * 删除
     * @param id 对象id
     * @param currentUserId 当前登录用户id
     * @return 返回删除数量
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 修改
     * @param entity 对象
     * @return 返回修改数量
     * @throws Exception 抛出异常
     */
    int update(ParkVO entity)throws Exception;

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回园区对象
     * @throws Exception 抛出异常
     */
    ParkVO queryById(String id)throws Exception;

    /**
     * 分页模糊查询园区列表
     * @param vo 查询条件
     * @return 返回区域列表
     * @throws Exception 抛出异常
     */
    List<ParkVO> list(ParkVO vo)throws Exception;


    /**
     * 园区排序
     * @param authorization
     * @param voList
     * @return
     * @throws Exception
     */
    String updateList(String authorization,List<ParkVO> voList)throws Exception;

    /**
     * 查询园区列表
     * @return
     * @throws Exception
     */
    List<ParkVO> objects(String parkEnable,String rpakName)throws Exception;

    /**
     * 根据id查询园区
     * @param id
     * @return
     * @throws Exception
     */
    ParkVO queryObject(String id)throws Exception;
}
