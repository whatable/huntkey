package com.huntkey.rx.sceo.provider.park.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;
import com.huntkey.rx.sceo.common.model.park.vo.RpakAddrVO;

import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 16:04:47
 */
public interface RpakAddrService {

    /**
     * 新增
     * @param entity 对象
     * @return 返回对象id
     * @throws Exception 抛出异常
     */
    String insert(RpakAddrVO entity)throws Exception;

    /**
     * 删除
     * @param id 对象id
     * @param currentUserId 当前登录用户id
     * @return 返回删除数量
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 修改
     * @param entity 对象
     * @return 返回修改数量
     * @throws Exception 抛出异常
     */
    int update(RpakAddrVO entity)throws Exception;

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     * @throws Exception 抛出异常
     */
    RpakAddrVO queryById(String id)throws Exception;

    /**
     * 查询交货地址列表
     * @return 返回区域列表
     * @throws Exception 抛出异常
     */
    List<RpakAddrVO> list(String pid)throws Exception;
}
