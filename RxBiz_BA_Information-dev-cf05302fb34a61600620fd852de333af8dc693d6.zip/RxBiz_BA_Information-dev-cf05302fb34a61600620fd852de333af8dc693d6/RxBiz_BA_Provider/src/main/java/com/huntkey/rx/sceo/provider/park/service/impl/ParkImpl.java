package com.huntkey.rx.sceo.provider.park.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.AreaProperty;
import com.huntkey.rx.edm.constant.RpakRpakAddrSetaProperty;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.park.ParkConstant;
import com.huntkey.rx.sceo.common.model.park.RpakAddrConstant;
import com.huntkey.rx.sceo.common.model.park.vo.ParkVO;
import com.huntkey.rx.sceo.orm.common.constant.Constant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.park.service.ParkService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author liucs
 * @date 2018-4-2 14:20:44
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class ParkImpl implements ParkService {
    @Autowired
    private OrmService ormService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String insert(ParkVO entity) throws Exception {
        // 属性非空校验
        notNullValid(entity);
        if(StringUtils.isNotEmpty(entity.getRpakCode()) && isExistParkCode(entity)){
            throw new RuntimeException("园区代码重复！");
        }
        if(isExistParkName(entity)){
            throw new RuntimeException("园区名称重复！");
        }
        ParkEntity parkEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),ParkEntity.class);
        String sql = "select max(rpak_seq) maxSeq from park where is_del=0";
        List<Map<String,Object>> maxSeq = ormService.getDataBySql(sql);
        parkEntity.setRpak_seq(Integer.parseInt(maxSeq.get(0).get("maxSeq").toString())+1);
        parkEntity.setRpak_is_standard(Integer.parseInt(Constants.NOT_STANDARD));
        /**
         * 如果新增园区是默认园区
         * 则修改原默认园区为非默认园区
         */
        if(entity.getRpakIsdefault().equals(ParkConstant.IS_DEFAULT_PARK)){
            //查询条件为空，查询所有园区
            OrmParam ormParam = setQeuryCondition(new ParkVO());
            List<ParkEntity> entities = ormService.selectBeanList(ParkEntity.class,ormParam);
            ParkEntity oldDefaultPark = null;
            for (ParkEntity entity1 : entities) {
                if(entity1.getRpak_isdefault().equals(ParkConstant.IS_DEFAULT_PARK)){
                    oldDefaultPark = entity1;
                    break;
                }
            }
            if(oldDefaultPark != null){
                oldDefaultPark.setRpak_isdefault(ParkConstant.NOT_DEFAULT_PARK);
                ormService.updateSelective(oldDefaultPark);
            }
        }
        return ormService.insert(parkEntity).toString();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(String currentUserId, String id) throws Exception {
        //修改维护人信息
        ParkEntity entity = new ParkEntity();
        entity.setModuser(currentUserId);
        entity.setId(id);
        ormService.updateSelective(entity);
        RpakRpakAddrSetaEntity rpakEntity = new RpakRpakAddrSetaEntity();
        rpakEntity.setModuser(currentUserId);
        rpakEntity.setPid(id);
        OrmParam rpakOrmParam = new OrmParam();
        String rpakWhereExp = OrmParam.and(rpakOrmParam.getEqualXML(BasicConst.PID,id));
        rpakOrmParam.setWhereExp(rpakWhereExp);
        ormService.updateSelective(rpakEntity,rpakOrmParam);
        //删除主表以及对应子表数据
        ormService.delete(RpakRpakAddrSetaEntity.class,rpakOrmParam);
        return ormService.delete(ParkEntity.class,id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(ParkVO entity) throws Exception {
        // 属性非空校验
        notNullValid(entity);
        OrmParam ormParam = new OrmParam();
        List<ParkEntity> entities;
        if(StringUtils.isNotEmpty(entity.getRpakCode())){
            ormParam.setWhereExp(ormParam.getEqualXML(ParkConstant.RPAK_CODE,entity.getRpakCode().trim()));
            entities = ormService.selectBeanList(ParkEntity.class,ormParam);
            if(entities != null && entities.size() > 0){
                if(entities.size() > 1 || !entities.get(0).getId().equals(entity.getId())){
                    throw new RuntimeException("园区代码重复!");
                }
            }
        }
        ormParam.setWhereExp(ormParam.getEqualXML(ParkConstant.RPAK_NAME,entity.getRpakName().trim()));
        entities = ormService.selectBeanList(ParkEntity.class, ormParam);
        if(entities != null && entities.size() > 0){
            if(entities.size() > 1 && !entities.get(0).getId().equals(entity.getId())){
                throw new RuntimeException("园区名称重复!");
            }
        }
        ParkEntity parkEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),ParkEntity.class);
        //更新交货地址省、市、县信息
        resetRpakAddr(parkEntity);
        //修改默认园区
        updateDefaultPark(parkEntity);
        return ormService.updateSelective(parkEntity);
    }



    @Override
    public ParkVO queryById(String id) throws Exception {
        ParkEntity entity = ormService.load(ParkEntity.class,id);
        if(entity == null){
            return null;
        }
        ParkVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity),ParkVO.class);
        vo.setModUserName(Utils.getUserNameByUserId(entity.getModuser(),ormService));
        vo.setCreUserName(Utils.getUserNameByUserId(entity.getCreuser(),ormService));
        return vo;
    }

    @Override
    public List<ParkVO> list(ParkVO vo) throws Exception {
        OrmParam ormParam = setQeuryCondition(vo);
        List<ParkEntity> entityList = ormService.selectBeanList(ParkEntity.class,ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        List<ParkVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),ParkVO.class);
        setParkAreaNames(voList);
        //设置部分属性信息
        setListProperties(voList);
        return voList;
    }

    private void setParkAreaNames(List<ParkVO> voList) throws Exception {
        for (ParkVO parkVO : voList) {
            if(!StringUtil.isNullOrEmpty(parkVO.getRpakAddrProv())){
                AreaEntity prov = ormService.load(AreaEntity.class,parkVO.getRpakAddrProv());
                if(prov != null){
                    parkVO.setRpakAddrProvName(prov.getArea_name());
                }
            }
            if(!StringUtil.isNullOrEmpty(parkVO.getRpakAddrCity())){
                AreaEntity city = ormService.load(AreaEntity.class,parkVO.getRpakAddrCity());
                if(city != null){
                    parkVO.setRpakAddrCityName(city.getArea_name());
                }
            }
            if(!StringUtil.isNullOrEmpty(parkVO.getRpakAddrDist())){
                AreaEntity dist = ormService.load(AreaEntity.class,parkVO.getRpakAddrDist());
                if(dist != null){
                    parkVO.setRpakAddrDistName(dist.getArea_name());
                }
            }
        }
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public String updateList(String authorization, List<ParkVO> voList) throws Exception {
        String userId = Utils.getCurentUserId(authorization);
        for (ParkVO parkVO : voList) {
            parkVO.setModuser(userId);
        }
        List<ParkEntity> list = JSONObject.parseArray(JSONObject.toJSONString(voList),ParkEntity.class);
        Integer seq_first = list.get(0).getRpak_seq();
        Integer seq_second = list.get(1).getRpak_seq();
        list.get(0).setRpak_seq(seq_second);
        list.get(1).setRpak_seq(seq_first);
//        //临时集合,记录排序值
//        List<Integer> parkSeqs = new ArrayList<>(voList.size());
//        for (ParkEntity entity : list) {
//            parkSeqs.add(entity.getRpak_seq());
//        }
//        //排序
//        Collections.sort(parkSeqs);
//        int index = 0;
//        int len = voList.size();
//        for (ParkEntity entity : list) {
//            entity.setRpak_seq(parkSeqs.get(index++));
//            len -= ormService.updateSelective(entity);
//        }
        int count = 0;
        for (ParkEntity parkEntity : list) {
            count += ormService.updateSelective(parkEntity);
        }
        if(count == 2){
            return "success";
        }
        return "warning";
    }

    @Override
    public List<ParkVO> objects(String parkEnable,String rpakName) throws Exception {
        ParkVO vo = new ParkVO();
        vo.setRpakEnable(parkEnable);
        vo.setRpakName(rpakName);
        OrmParam ormParam = setQeuryCondition(vo);
        List<ParkEntity> entities = ormService.selectBeanList(ParkEntity.class,ormParam);
        List<ParkVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entities),ParkVO.class);
        setListProperties(voList);
        return voList;
    }


    @Override
    public ParkVO queryObject(String id) throws Exception {
        ParkEntity entity = ormService.load(ParkEntity.class,id);
        ParkVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity),ParkVO.class);
        vo.setCreUserName(Utils.getUserNameByUserId(vo.getCreuser(),ormService));
        vo.setModUserName(Utils.getUserNameByUserId(vo.getModuser(),ormService));
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(BasicConst.PID,id)));
        long deliveryAddrCount = ormService.count(RpakRpakAddrSetaEntity.class,ormParam);
        vo.setDeliveryAddrCount((int) deliveryAddrCount);
        return vo;
    }

    /**
     * 设置查询参数
     * @param vo
     * @return
     */
    private OrmParam setQeuryCondition(ParkVO vo){
        OrmParam ormParam = new OrmParam();
        List<String> columnList = new ArrayList<>(Arrays.asList(ParkConstant.RPAK_ADDR,ParkConstant.RPAK_ADDR_CITY,
                ParkConstant.RPAK_ADDR_DIST,ParkConstant.RPAK_ADDR_PROV,ParkConstant.RPAK_CODE,ParkConstant.RPAK_NAME,
                ParkConstant.RPAK_SEQ,ParkConstant.RPAK_ENABLE,ParkConstant.RPAK_ISDEFAULT,ParkConstant.RPAK_IS_STANDARD));
        Utils.setBaseQueryColums(columnList);
        columnList.remove(columnList.indexOf("pid"));
        ormParam.setColumns(columnList);
        StringBuilder whereExp = new StringBuilder("1=1");
        if(StringUtils.isNotEmpty(vo.getRpakName()) && StringUtils.isNotEmpty(vo.getRpakName().trim())){
            whereExp.append(" and ").append(ormParam.getMatchMiddleXML(ParkConstant.RPAK_NAME,vo.getRpakName().trim()));
        }
        if(StringUtils.isNotEmpty(vo.getRpakAddrProv())){
            whereExp.append(" and ").append(ormParam.getEqualXML(ParkConstant.RPAK_ADDR_PROV,vo.getRpakAddrProv()));
        }
        if(StringUtils.isNotEmpty(vo.getRpakAddrCity())){
            whereExp.append(" and ").append(ormParam.getEqualXML(ParkConstant.RPAK_ADDR_CITY,vo.getRpakAddrCity()));
        }
        if(StringUtils.isNotEmpty(vo.getRpakAddrDist())){
            whereExp.append(" and ").append(ormParam.getEqualXML(ParkConstant.RPAK_ADDR_DIST,vo.getRpakAddrDist()));
        }
        if(StringUtils.isNotEmpty(vo.getRpakEnable())){
            whereExp.append(" and ").append(ormParam.getEqualXML(ParkConstant.RPAK_ENABLE,vo.getRpakEnable()));
        }
        ormParam.setWhereExp(whereExp.toString());
        ormParam.setOrderExp(SQLSortEnum.ASC,ParkConstant.RPAK_SEQ);
        return ormParam;
    }

    /**
     * 园区代码 重复校验
     * @param vo
     * @return
     */
    private boolean isExistParkCode(ParkVO vo)throws Exception{
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(ParkConstant.RPAK_CODE,vo.getRpakCode().trim()));
        long count = ormService.count(ParkEntity.class,ormParam);
        return count>0;
    }

    /**
     * 园区名称重复校验
     * @return
     * @throws Exception
     */
    private boolean isExistParkName(ParkVO vo)throws Exception{
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(ParkConstant.RPAK_NAME,vo.getRpakName().trim()));
        long count = ormService.count(ParkEntity.class,ormParam);
        return count>0;
    }

    /**
     * 设置部分属性信息
     * @param voList
     * @throws Exception
     */
    private void setListProperties(List<ParkVO> voList) throws Exception {
        OrmParam ormParam = new OrmParam();
        for (ParkVO vo : voList) {
            vo.setCreUserName(Utils.getUserNameByUserId(vo.getCreuser(),ormService));
            vo.setModUserName(Utils.getUserNameByUserId(vo.getModuser(),ormService));
            ormParam.setWhereExp(ormParam.getEqualXML(BasicConst.PID,vo.getId()));
            //查询交货地址数量
            long deliveryAddrCount = ormService.count(RpakRpakAddrSetaEntity.class,ormParam);
            vo.setDeliveryAddrCount((int) deliveryAddrCount);
        }
    }

    /**
     * 修改默认园区
     * @param newEntity 待修改园区
     * @throws Exception
     */
    private void updateDefaultPark(ParkEntity newEntity) throws Exception {
        //设置查询条件为空——查询所有园区
        OrmParam ormParam = setQeuryCondition(new ParkVO());
        List<ParkEntity> entities = ormService.selectBeanList(ParkEntity.class,ormParam);
        if(entities == null || entities.size() == 0){
            return ;
        }
        //旧的默认园区
        ParkEntity oldEntity = null;
        for (ParkEntity entity : entities) {
            if(entity.getRpak_isdefault().equals(ParkConstant.IS_DEFAULT_PARK)){
                oldEntity = entity;
                break;
            }
        }
        /**
         * 如果之前有默认园区，且待修改园区为默认园区，且之前的默认园区和待修改园区id不同
         * 则修改之前的默认园区为非默认园区
         */
        if(oldEntity != null && newEntity.getRpak_isdefault().equals(ParkConstant.IS_DEFAULT_PARK)&&
                !oldEntity.getId().equals(newEntity.getId())){
            oldEntity.setRpak_isdefault(ParkConstant.NOT_DEFAULT_PARK);
            ormService.updateSelective(oldEntity);
        }
    }

    /**
     * 如果园区所在区域改动，则同时更新交货地址信息
     * @param parkEntity
     * @throws Exception
     */
    private void resetRpakAddr(ParkEntity parkEntity) throws Exception {
        ParkEntity oldEntity = ormService.load(ParkEntity.class,parkEntity.getId());
        RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity = new RpakRpakAddrSetaEntity();
        rpakRpakAddrSetaEntity.setRpak_addrp(parkEntity.getRpak_addr_prov());
        rpakRpakAddrSetaEntity.setRpak_addrc(parkEntity.getRpak_addr_city());
        rpakRpakAddrSetaEntity.setRpak_addrl(parkEntity.getRpak_addr_dist());
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(BasicConst.PID,parkEntity.getId())));
        ormService.updateSelective(rpakRpakAddrSetaEntity,ormParam);
    }

    /**
     * 园区属性非空校验
     * @param vo
     * @throws Exception
     */
    private void notNullValid(ParkVO vo) throws Exception{
        if(StringUtil.isNullOrEmpty(vo.getRpakName())) {
            throw new RuntimeException("园区名称必填");
        }
        if(StringUtil.isNullOrEmpty(vo.getRpakCode())){
            throw new RuntimeException("园区代码必填");
        }
        if(StringUtil.isNullOrEmpty(vo.getRpakAddrProv())){
            throw new RuntimeException("所在省份必填");
        }
        if(StringUtil.isNullOrEmpty(vo.getRpakAddrCity())){
            throw new RuntimeException("所在城市必填");
        }
        if(StringUtil.isNullOrEmpty(vo.getRpakAddrDist())){
            String city = vo.getRpakAddrCity();
            OrmParam ormParam = new OrmParam();
            ormParam.setWhereExp(ormParam.getEqualXML(AreaProperty.AREA_PARENT_AREA,city));
            long count = ormService.count(AreaEntity.class,ormParam);
            if(count > 0){
                throw new RuntimeException("所在区县必填");
            }
        }
        if(StringUtil.isNullOrEmpty(vo.getRpakAddr())){
            throw new RuntimeException("详细地址必填");
        }
    }
}
