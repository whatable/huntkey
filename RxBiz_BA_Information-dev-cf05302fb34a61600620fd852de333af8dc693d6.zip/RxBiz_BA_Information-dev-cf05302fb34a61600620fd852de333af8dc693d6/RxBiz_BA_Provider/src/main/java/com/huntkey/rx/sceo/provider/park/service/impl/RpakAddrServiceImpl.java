package com.huntkey.rx.sceo.provider.park.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.AreaProperty;
import com.huntkey.rx.edm.constant.RpakRpakAddrSetaProperty;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.edm.entity.ParkEntity;
import com.huntkey.rx.edm.entity.RpakRpakAddrSetaEntity;
import com.huntkey.rx.sceo.common.model.basic.RpakRpakAddrSetaVO;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.park.RpakAddrConstant;
import com.huntkey.rx.sceo.common.model.park.vo.RpakAddrVO;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.park.service.RpakAddrService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 16:04:47
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class RpakAddrServiceImpl implements RpakAddrService{
    @Autowired
    private OrmService ormService;
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String insert(RpakAddrVO entity) throws Exception {
        // 属性非空校验
        propertyValidate(entity);

        RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),RpakRpakAddrSetaEntity.class);
//        ParkEntity parkEntity = ormService.load(ParkEntity.class,entity.getPid());
//        if(parkEntity != null){
//            rpakRpakAddrSetaEntity.setRpak_addrp(parkEntity.getRpak_addr_prov());
//            rpakRpakAddrSetaEntity.setRpak_addrc(parkEntity.getRpak_addr_city());
//            rpakRpakAddrSetaEntity.setRpak_addrl(parkEntity.getRpak_addr_dist());
//        }
        rpakRpakAddrSetaEntity.setClassName("park");

        return ormService.insert(rpakRpakAddrSetaEntity).toString();
    }

    @Override
    public int delete(String currentUserId, String id) throws Exception {
        RpakRpakAddrSetaEntity entity = new RpakRpakAddrSetaEntity();
        entity.setModuser(currentUserId);
        entity.setId(id);
        ormService.updateSelective(entity);
        return ormService.delete(RpakRpakAddrSetaEntity.class,id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(RpakAddrVO entity) throws Exception {
        // 属性非空校验
        propertyValidate(entity);
        RpakRpakAddrSetaEntity rpakRpakAddrSetaEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),RpakRpakAddrSetaEntity.class);
        return ormService.update(rpakRpakAddrSetaEntity);
    }

    @Override
    public RpakAddrVO queryById(String id) throws Exception {
        RpakRpakAddrSetaEntity entity = ormService.load(RpakRpakAddrSetaEntity.class,id);
        if(entity == null){
            return null;
        }
        RpakAddrVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity),RpakAddrVO.class);
        vo.setCreUserName(Utils.getUserNameByUserId(entity.getCreuser(),ormService));
        vo.setModUserName(Utils.getUserNameByUserId(entity.getModuser(),ormService));
        return vo;
    }

    @Override
    public List<RpakAddrVO> list(String pid) throws Exception {
        List<String> columns = new ArrayList<>(Arrays.asList(RpakAddrConstant.RPAK_DADDR,RpakAddrConstant.RPAK_CONTACT,RpakAddrConstant.RPAK_CWAY,
                BasicConst.CLASSNAME,RpakAddrConstant.REAK_ADDR_ENABLE,BasicConst.PID, RpakRpakAddrSetaProperty.RPAK_ADDRP,RpakRpakAddrSetaProperty.RPAK_ADDRC,RpakRpakAddrSetaProperty.RPAK_ADDRL));
        Utils.setBaseQueryColums(columns);
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columns);
        String whereExp = OrmParam.and(ormParam.getEqualXML(BasicConst.PID,pid));
        ormParam.setWhereExp(whereExp);
        List<RpakRpakAddrSetaEntity> entities = ormService.selectBeanList(RpakRpakAddrSetaEntity.class,ormParam);
        if(entities == null || entities.size() == 0){
            return null;
        }
        List<RpakAddrVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entities),RpakAddrVO.class);
        for (RpakAddrVO rpakAddrVO : voList) {
            rpakAddrVO.setCreUserName(Utils.getUserNameByUserId(rpakAddrVO.getCreuser(),ormService));
            rpakAddrVO.setModUserName(Utils.getUserNameByUserId(rpakAddrVO.getModuser(),ormService));
        }
        return voList;
    }

    /**
     * 属性非空检验
     * @param vo
     */
    private void propertyValidate(RpakAddrVO vo) throws Exception {
        if(StringUtil.isNullOrEmpty(vo.getRpakDaddr().trim())){
            throw new RuntimeException("交货地址必填");
        }
        if (StringUtil.isNullOrEmpty(vo.getRpakContact().trim())){
            throw new RuntimeException("联系人必填");
        }
        if(StringUtil.isNullOrEmpty(vo.getRpakCway().trim())) {
            throw new RuntimeException("联系方式必填");
        }
        if (StringUtil.isNullOrEmpty(vo.getRpakAddrp())) {
            throw new RuntimeException("所在省份必填");
        }
        if (StringUtil.isNullOrEmpty(vo.getRpakAddrc())) {
            throw new RuntimeException("所在城市必填");
        }
        if (StringUtil.isNullOrEmpty(vo.getRpakAddrl())) {
            String city = vo.getRpakAddrc();
            OrmParam ormParam = new OrmParam();
            ormParam.setWhereExp(ormParam.getEqualXML(AreaProperty.AREA_PARENT_AREA,city));
            long count = ormService.count(AreaEntity.class,ormParam);
            if(count > 0){
                throw new RuntimeException("所在区县必填");
            }
        }
    }
}
