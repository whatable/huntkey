package com.huntkey.rx.sceo.provider.period.controller;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.period.vo.PeriodVO;
import com.huntkey.rx.sceo.profile.common.service.PeriodService.PeriodType;
import com.huntkey.rx.sceo.provider.period.service.PeriodService;
import com.huntkey.rx.sceo.provider.utils.RestResultHelper;
import com.huntkey.rx.sceo.provider.utils.Utils;

/**
 * 周期
 * 
 * @author liucs
 * @date 2018-3-27 16:51:43
 */
@RestController
@RequestMapping(value = "/period")
public class PeriodController {
	private static Logger logger = LoggerFactory.getLogger(PeriodController.class);
	@Autowired
	private PeriodService periodService;

	/**
	 * 初始化周期
	 * 
	 * @param initDate
	 *            财年起始日期
	 * @param yearPeriodStr
	 *            年模式字符串
	 * @param quarterPeriodStr
	 *            季模式字符串
	 * @param monthPerionStr
	 *            月模式字符串
	 * @return
	 */
	@Deprecated
	@RequestMapping(value = "/initPeriod", method = RequestMethod.POST)
	public Result initPeriod(@RequestParam(value = "authorization") String authorization,
			@RequestParam(value = "initDate") Integer initDate,
			@RequestParam(value = "yearPeriodStr") String yearPeriodStr,
			@RequestParam(value = "quarterPeriodStr") String quarterPeriodStr,
			@RequestParam(value = "monthPerionStr") String monthPerionStr) {
		return RestResultHelper.error("不再支持这个API，请查阅公共接口API清单：标准edm方法period.generate()");
	}

	/**
	 * 分页、模糊查询周期列表
	 * 
	 * @param peidFyr
	 *            查询条件
	 * @param peidName
	 *            开始时间
	 * @param peidProid
	 *            结束时间
	 * @param peidEnable
	 *            启用/禁用
	 * @param pageSize
	 *            每页大小
	 * @param pageNum
	 *            当前页数
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public Result list(@RequestParam(required = false, value = "peidFyr") String peidFyr,
			@RequestParam(required = false, value = "peidName") String peidName,
			@RequestParam(required = false, value = "peidProid") Integer peidProid,
			@RequestParam(required = false, value = "peidEnable") String peidEnable,
			@RequestParam(required = false, value = "pageSize", defaultValue = "10") Integer pageSize,
			@RequestParam(required = false, value = "pageNum", defaultValue = "1") Integer pageNum) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(periodService.list(peidFyr, peidName, peidProid, peidEnable, pageNum, pageSize));
		} catch (Exception e) {
			logger.error("period/list:" + e.getMessage());
			result.setErrMsg(e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
		}
		return result;
	}

	/**
	 * 根据id查询周期
	 * 
	 * @param id
	 *            对象id
	 * @return 返回结果
	 */
	@RequestMapping(value = "/queryById", method = RequestMethod.GET)
	public Result queryById(@RequestParam("id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(periodService.queryById(id));
		} catch (Exception e) {
			logger.error("period/queryById:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 修改周期
	 * 
	 * @param entity
	 *            周期对象
	 * @return 人会re返回lt
	 */
	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public Result update(@RequestParam("authorization") String authorization, @RequestBody PeriodVO entity) {
		String curentUserId = Utils.getCurentUserId(authorization);
		entity.setModuser(curentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(periodService.update(entity));
		} catch (Exception e) {
			logger.error("period/update:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 删除周期
	 * 
	 * @param id
	 *            对象id
	 * @return
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public Result delete(@RequestParam("authorization") String authorization, @RequestParam("id") String id) {
		String currentUserId = Utils.getCurentUserId(authorization);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(periodService.delete(id, currentUserId));
		} catch (Exception e) {
			logger.error("period/delete:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 添加周期
	 * 
	 * @param authorization
	 *            登录用户
	 * @param entity
	 *            周期对象
	 * @return
	 */
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public Result insert(@RequestParam("authorization") String authorization, @RequestBody PeriodVO entity) {
		// 获取当前登录用户id
		String currentUserId = Utils.getCurentUserId(authorization);
		entity.setModuser(currentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(periodService.insert(entity));
		} catch (Exception e) {
			logger.error("period/insert:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	@RequestMapping(value = "/queryPeriodEnum", method = RequestMethod.GET)
	public Result queryPeriodEnum() {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			PeriodType[] types = PeriodType.values();
			List<Map<String, String>> mapList = new LinkedList<>();
			for (PeriodType t : types) {
				Map<String, String> map = new LinkedHashMap<>();
				map.put("key", t.name());
				map.put("name", t.zhName());
				mapList.add(map);
			}
			result.setData(mapList);
		} catch (Exception e) {
			logger.error("period/queryPeriodEnum:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 综合查询周期信息
	 * 
	 * @param fyr
	 *            财年
	 * @param name
	 *            名称
	 * @param proid
	 *            期次
	 * @return
	 */
	@RequestMapping(value = "/v1/objects", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "period",methodDesc = "综合查询周期信息",methodCate =
	// "表单通用方法",
	// getReqParamsNameNoPathVariable =
	// {"fyr","name","enable","proid","sdate","edate"})
	public Result objects(@RequestParam(value = "fyr", required = false) String fyr,
			@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "enable", required = false) String enable,
			@RequestParam(value = "proid", required = false) Integer proid,
			@RequestParam(value = "sdate", required = false) Long sdate,
			@RequestParam(value = "edate", required = false) Long edate) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		Date starDate = null;
		Date endDate = null;
		if (sdate != null) {
			starDate = new Date(sdate);
		}
		if (edate != null) {
			endDate = new Date(edate);
		}

		try {
			result.setData(periodService.objects(fyr, name, enable, proid, starDate, endDate));
		} catch (Exception e) {
			logger.error("period/v1/objects:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/v1/objects/{id}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "period", methodDesc = "综合查询周期信息", methodCate =
	// "表单通用方法")
	@Deprecated
	public Result queryObjectById(@PathVariable(value = "id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(periodService.queryById(id));
		} catch (Exception e) {
			logger.error("period/v1/objects/{id}:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}
}
