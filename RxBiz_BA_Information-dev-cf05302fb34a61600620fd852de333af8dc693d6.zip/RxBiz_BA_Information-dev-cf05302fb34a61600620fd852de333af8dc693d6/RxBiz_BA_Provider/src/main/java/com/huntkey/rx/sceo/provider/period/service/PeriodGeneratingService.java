package com.huntkey.rx.sceo.provider.period.service;

public interface PeriodGeneratingService {
	/**
	 * 系统初始化时调用，生成从start算起共offset年的周期数据
	 * 
	 * @param userId
	 * @param start
	 * @param offset
	 * @param fyearPattern
	 * @param yearPattern
	 * @param fquaterPattern
	 * @param quarterPattern
	 * @param fmonthPattern
	 * @param monthPattern
	 * @param fweekPattern
	 * @param weekPattern
	 * @return -1:上一个处理线程仍在执行，不要重复执行；0:已启动，正常返回（异步）
	 */
	int generate(String userId, int start, int offset, int inception, String fyearPattern, String yearPattern,
			String fquaterPattern, String quarterPattern, String fmonthPattern, String monthPattern,
			String fweekPattern, String weekPattern);

}
