package com.huntkey.rx.sceo.provider.period.service;

import java.util.Date;
import java.util.List;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.sceo.common.model.period.vo.PeriodVO;

/**
 * @author liucs
 * @date 2018-3-27 17:02:37
 */
public interface PeriodService {

	/**
	 * * 查询周期列表
	 * 
	 * @param peidFyr
	 *            财年
	 * @param peidName
	 *            周期名
	 * @param peidProid
	 *            期次
	 * @param peidEnable
	 *            启用/禁用
	 * @param pageNum
	 *            当前页数
	 * @param pageSize
	 *            每页数据量
	 * @return 返回周期集合
	 * @throws Exception
	 */
	Pagination<PeriodVO> list(String peidFyr, String peidName, Integer peidProid, String peidEnable, Integer pageNum,
			Integer pageSize) throws Exception;

	/**
	 * 根据id查询周期
	 * 
	 * @param id
	 *            对象id
	 * @return 返回对象
	 */
	PeriodVO queryById(String id) throws Exception;

	/**
	 * 修改周期
	 * 
	 * @param entity
	 *            周期对象
	 * @return 返回修改记录条数
	 * @throws Exception
	 */
	int update(PeriodVO entity) throws Exception;

	/**
	 * 删除周期
	 * 
	 * @param id
	 *            周期id
	 * @return 返回删除记录条数
	 * @throws Exception
	 */
	int delete(String id, String currentUserId) throws Exception;

	/**
	 * 添加周期
	 * 
	 * @param entity
	 *            周期对象
	 * @return 返回对象id
	 * @throws Exception
	 *             抛出异常
	 */
	String insert(PeriodVO entity) throws Exception;

	List<PeriodVO> objects(String fyr, String name, String enable, Integer proid, Date sdate, Date edate)
			throws Exception;
}
