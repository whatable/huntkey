package com.huntkey.rx.sceo.provider.period.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.PeriodService.PeriodType;
import com.huntkey.rx.sceo.profile.common.util.OrmException;
import com.huntkey.rx.sceo.provider.period.service.PeriodGeneratingService;
import com.huntkey.rx.sceo.provider.utils.PeriodGenerator;

@Service
@Transactional(readOnly = true, rollbackFor = OrmException.class)
public class PeriodGeneratingServiceImpl implements PeriodGeneratingService {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private OrmService orm;

	private static final Collection<Thread> RUNNING = new ArrayList<>(1);

	@Override
	@Transactional(readOnly = false, rollbackFor = OrmException.class)
	public int generate(String userId, int start, int offset, int inception, String fiscalYearPattern,
			String yearPattern, String fiscalQuarterPattern, String quarterPattern, String fiscalMonthPattern,
			String monthPattern, String fiscalWeekPattern, String weekPattern) {

		final List<PeriodEntity> list = new LinkedList<>();

		PeriodGenerator.Inception s = PeriodGenerator.Inception.valueOf("Q" + inception);// 根据输入参数，生成generator需要的参数，用来表示财年起点
		PeriodGenerator g = new PeriodGenerator(s, start, offset) {
			@Override
			protected void item(Date head, Date tail, PeriodType type, int fy, String name, String calendarName,
					int seq) {
				PeriodEntity e = new PeriodEntity();
				e.setEdmd_class("period");
				e.setCreuser(userId);
				e.setCretime(new Date());
				e.setPeid_enable("1");
				e.setPeid_is_standard(0);
				e.setPeid_name(type.toString());// 实际是类型
				e.setPeid_fina_name(name);
				e.setPeid_cale_name(calendarName);
				e.setPeid_proid(seq);
				e.setPeid_fyr(Integer.toString(fy));
				e.setPeid_sdate(head);
				e.setPeid_edate(tail);
				list.add(e);
			}
		};
		if (weekPattern != null) {
			g.setWeekPattern(weekPattern);
		}
		if (fiscalWeekPattern != null) {
			g.setFiscalWeekPattern(fiscalWeekPattern);
		}
		if (monthPattern != null) {
			g.setMonthPattern(monthPattern);
		}
		if (fiscalMonthPattern != null) {
			g.setFiscalMonthPattern(fiscalMonthPattern);
		}
		if (quarterPattern != null) {
			g.setMonthPattern(quarterPattern);
		}
		if (fiscalQuarterPattern != null) {
			g.setFiscalMonthPattern(fiscalQuarterPattern);
		}
		if (yearPattern != null) {
			g.setYearPattern(yearPattern);
		}
		if (fiscalYearPattern != null) {
			g.setFiscalYearPattern(fiscalYearPattern);
		}
		g.go();

		// 总计近万条数据插入，为避免数据库卡死和http响应超时，特开到线程中分批执行
		// 这里暂时确信请求的频率较低，不会产生同步问题，所以暂不加同步锁；后期若场景变化，出现同步问题，请加同步控制
		if (RUNNING.size() > 0) {
			return -1;// 上一个处理线程仍在执行
		}
		new Thread() {
			@Override
			public void run() {
				RUNNING.add(this);
				long t = System.currentTimeMillis();
				logger.debug("Period generating process starts at {}", new Date());
				try {
					List<PeriodEntity> toSaved = new ArrayList<>(1000);
					for (int i = 0; i < list.size(); i++) {
						toSaved.add(list.get(i));
						if (toSaved.size() == 1000) {
							orm.insert(toSaved);
							toSaved.clear();
							try {
								Thread.sleep(200);
							} catch (InterruptedException e2) {
							}
						}
					}
					if (toSaved.size() > 0) {
						orm.insert(toSaved);
					}
				} catch (Exception e) {
					throw new OrmException(e);
				} finally {
					RUNNING.remove(this);
					logger.debug("Period generating process completes at {}, time spends {}(ms)", new Date(),
							System.currentTimeMillis() - t);
				}
			}
		}.start();
		return 0;
	}

}
