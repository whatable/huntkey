package com.huntkey.rx.sceo.provider.period.service.impl;

import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.PeriodProperty;
import com.huntkey.rx.edm.entity.PeriodEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.period.PeriodConstant;
import com.huntkey.rx.sceo.common.model.period.PeriodInitDateEnum;
import com.huntkey.rx.sceo.common.model.period.vo.PeriodVO;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.PeriodService.PeriodType;
import com.huntkey.rx.sceo.provider.period.service.PeriodService;
import com.huntkey.rx.sceo.provider.utils.Utils;

@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class PeriodServiceImpl implements PeriodService {

	@Autowired
	private OrmService ormService;

	// @Override
	@Deprecated
	@Transactional(readOnly = false, rollbackFor = Exception.class)
	public String initPeriod(String authorization, Integer initDate, String yearPeriodStr, String quarterPeriodStr,
			String monthPerionStr) throws Exception {
		// 当前登录用户id
		String creUserId = Utils.getCurentUserId(authorization);
		// 临时存储财年
		List<PeriodEntity> fiscalYearEntityList = new LinkedList<>();
		// 临时存储财季
		List<PeriodEntity> fiscalQuarterEntityList = new LinkedList<>();
		// 临时存储财月
		List<PeriodEntity> fiscalMonthEntityList = new LinkedList<>();
		// 起始时间
		StringBuilder sdate = new StringBuilder();
		// 结束时间
		StringBuilder endDate = new StringBuilder();
		SimpleDateFormat sdf;
		if (yearPeriodStr.contains("%Y")) {
			sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		} else {
			sdf = new SimpleDateFormat("yy-MM-dd hh:mm:ss");
		}
		for (int year = 2000; year < 2100; year++) {
			// 初始化财年
			initPeriodYear(initDate, yearPeriodStr, sdf, fiscalYearEntityList, sdate, endDate, year, creUserId);
			// 初始化财季
			initPeriodQuarter(initDate, quarterPeriodStr, fiscalQuarterEntityList, sdate, endDate, sdf, year,
					creUserId);
			// 初始化财月
			initPeriodMonth(initDate, monthPerionStr, fiscalMonthEntityList, sdate, endDate, sdf, year, creUserId);

		}
		ormService.insert(fiscalYearEntityList);
		ormService.insert(fiscalQuarterEntityList);
		ormService.insert(fiscalMonthEntityList);
		return "success";
	}

	@Override
	public Pagination<PeriodVO> list(String peidFyr, String peidName, Integer peidProid, String peidEnable,
			Integer pageNum, Integer pageSize) throws Exception {
		// 拼接查询字段，并按创建时间倒序排序
		OrmParam ormParam = setQueryCondition(peidFyr, peidName, peidProid, peidEnable);

		ormParam.setPageSize(pageSize);
		ormParam.setPageNo(pageNum);
		Pagination<PeriodEntity> pagination = ormService.selectPagedBeanList(PeriodEntity.class, ormParam);
		if (pagination == null || pagination.getTotal() == 0) {
			return null;
		}
		List<PeriodVO> voList = JSONObject.parseArray(JSONObject.toJSONString(pagination.getList()), PeriodVO.class);
		for (PeriodVO periodVO : voList) {
			periodVO.setCreUserName(Utils.getUserNameByUserId(periodVO.getCreuser(), ormService));
			periodVO.setModUserName(Utils.getUserNameByUserId(periodVO.getModuser(), ormService));
			// PeriodEnum periodEnum = PeriodEnum.valueOf(periodVO.getPeidName());
			periodVO.setPeidTypeName(PeriodType.valueOf(periodVO.getPeidName()).zhName());
		}
		return new Pagination<>(voList, pageNum, pageSize, pagination.getTotal());
	}

	@Override
	public PeriodVO queryById(String id) throws Exception {
		PeriodEntity entity = ormService.load(PeriodEntity.class, id);
		if (entity == null) {
			return null;
		}
		PeriodVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity), PeriodVO.class);
		vo.setModUserName(Utils.getUserNameByUserId(entity.getModuser(), ormService));
		vo.setCreUserName(Utils.getUserNameByUserId(entity.getCreuser(), ormService));
		return vo;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public int update(PeriodVO entity) throws Exception {
		PeriodEntity periodEntity = JSONObject.parseObject(JSONObject.toJSONString(entity), PeriodEntity.class);
		return ormService.updateSelective(periodEntity);
	}

	@Override
	public int delete(String id, String currentUserId) throws Exception {
		PeriodEntity entity = new PeriodEntity();
		entity.setId(id);
		entity.setModuser(currentUserId);
		entity.setModtime(new Date());
		// 删除前修改维护人、维护时间
		ormService.updateSelective(entity);
		return ormService.delete(PeriodEntity.class, id);
	}

	@Override
	public String insert(PeriodVO entity) throws Exception {
		PeriodEntity periodEntity = JSONObject.parseObject(JSONObject.toJSONString(entity), PeriodEntity.class);
		Serializable id = ormService.insertSelective(periodEntity);
		return id.toString();
	}

	@Override
	public List<PeriodVO> objects(String fyr, String name, String enable, Integer proid, Date sdate, Date edate)
			throws Exception {
		OrmParam ormParam = setQueryCondition(fyr, name, proid, enable);
		String whereExp = ormParam.getWhereExp();
		if (sdate != null) {
			whereExp = OrmParam.and(ormParam.getGreaterThanAndEqualXML(PeriodConstant.PEID_SDATE, sdate), whereExp);
		}
		if (edate != null) {
			whereExp = OrmParam.and(ormParam.getLessThanAndEqualXML(PeriodConstant.PEID_EDATE, edate), whereExp);
		}
		ormParam.setWhereExp(whereExp);
		List<PeriodEntity> entityList = ormService.selectBeanList(PeriodEntity.class, ormParam);
		if (entityList == null || entityList.size() == 0) {
			return null;
		}
		List<PeriodVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList), PeriodVO.class);
		for (PeriodVO vo : voList) {
			vo.setModUserName(Utils.getUserNameByUserId(vo.getModuser(), ormService));
			vo.setCreUserName(Utils.getUserNameByUserId(vo.getCreuser(), ormService));
		}
		return voList;
	}

	/**
	 * 封装查询条件,并按创建时间倒序排序
	 * 
	 * @param peidFyr
	 *            查询条件
	 * @param peidName
	 *            开始时间
	 * @param peidProid
	 *            结束时间
	 * @param peidEnable
	 *            启用/禁用
	 * @return
	 */
	private OrmParam setQueryCondition(String peidFyr, String peidName, Integer peidProid, String peidEnable) {
		OrmParam ormParam = new OrmParam();
		List<String> columnList = new ArrayList<>(Arrays.asList(BasicConst.ID, PeriodConstant.PEID_ENABLE,
				PeriodConstant.PEID_NAME, PeriodConstant.PEID_SDATE, PeriodConstant.PEID_EDATE,
				PeriodConstant.PEID_PROID, PeriodConstant.PEID_FYR, PeriodConstant.PEID_IS_STANDARD,
				PeriodConstant.PEID_FINA_NAME, PeriodConstant.PEID_CALE_NAME));
		// 设置查询基础列
		Utils.setBaseQueryColums(columnList);
		columnList.remove(columnList.indexOf("pid"));
		ormParam.setColumns(columnList);
		String whereExp = "";
		// 拼接查询条件
		if (StringUtils.isNotEmpty(peidName)) {
			whereExp = OrmParam.and(ormParam.getEqualXML(PeriodConstant.PEID_NAME, peidName));
		}
		if (StringUtils.isNotEmpty(peidFyr) && !StringUtil.isNullOrEmpty(peidFyr.trim())) {
			whereExp = OrmParam.and(ormParam.getEqualXML(PeriodConstant.PEID_FYR, peidFyr.trim()), whereExp);
		}
		if (null != peidProid) {
			whereExp = OrmParam.and(ormParam.getEqualXML(PeriodConstant.PEID_PROID, peidProid), whereExp);
		}
		if (!StringUtil.isNullOrEmpty(peidEnable)) {
			whereExp = OrmParam.and(ormParam.getEqualXML(PeriodConstant.PEID_ENABLE, peidEnable), whereExp);
		}
		ormParam.setWhereExp(whereExp);
		// 设置排序方式
		ormParam.addOrderExpElement(SQLSortEnum.ASC, PeriodProperty.PEID_FYR);
		ormParam.addOrderExpElement(SQLSortEnum.ASC, PeriodProperty.PEID_SDATE);
		return ormParam;
	}

	/**
	 *
	 * @param initDate
	 *            初始月份
	 * @param monthPerionStr
	 *            财月模式串
	 * @param monthEntityList
	 *            周期集合——暂时存放“财月”类型周期
	 * @param sdate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param sdf
	 *            日期转换格式
	 * @param year
	 *            当前年份
	 * @throws ParseException
	 */
	@Deprecated
	private void initPeriodMonth(Integer initDate, String monthPerionStr, List<PeriodEntity> monthEntityList,
			StringBuilder sdate, StringBuilder endDate, SimpleDateFormat sdf, int year, String creUserId)
			throws ParseException {
		// 开始时间月份
		StringBuilder sMonth = new StringBuilder();
		for (int month = 0; month < 12; month++) {
			sMonth.append(month * 1 + initDate);
			PeriodEntity vo = new PeriodEntity();
			vo.setCreuser(creUserId);
			vo.setEdmd_class("period");
			vo.setPeid_enable("1");
			vo.setPeid_fyr(String.valueOf(year));
			vo.setPeid_proid(month + 1);
			vo.setPeid_name(PeriodType.MONTH.name());// PeriodEnum.MONTH.getType());
			if (month < 9) {
				vo.setPeid_fina_name(
						year + monthPerionStr.replace("%M", "0" + (month + 1)).replaceAll("%m", "0" + (month + 1)));
				vo.setPeid_cale_name(
						year + monthPerionStr.replace("%M", "0" + (month + 1)).replaceAll("%m", "0" + (month + 1)));
			} else {
				vo.setPeid_fina_name(
						year + monthPerionStr.replace("%M", "" + (month + 1)).replaceAll("%m", "" + (month + 1)));
				vo.setPeid_cale_name(
						year + monthPerionStr.replace("%M", "" + (month + 1)).replaceAll("%m", "" + (month + 1)));
			}
			if (Integer.parseInt(sMonth.toString()) > 12) {
				sdate.append(year + 1).append("-0").append(Integer.parseInt(sMonth.toString()) - 12)
						.append(PeriodConstant.SDATE_SUFFIX);
				endDate.append(year + 1).append("-0").append(Integer.parseInt(sMonth.toString()) - 12)
						.append(getEndDateTime(Integer.parseInt(sMonth.toString()), year));
			} else {
				if (Integer.parseInt(sMonth.toString()) < 10) {
					sdate.append(year).append("-0").append(sMonth.toString()).append(PeriodConstant.SDATE_SUFFIX);
					endDate.append(year).append("-0").append(sMonth.toString())
							.append(getEndDateTime(Integer.parseInt(sMonth.toString()), year));
				} else {
					sdate.append(year).append("-").append(sMonth.toString()).append(PeriodConstant.SDATE_SUFFIX);
					endDate.append(year).append("-").append(sMonth.toString())
							.append(getEndDateTime(Integer.parseInt(sMonth.toString()), year));
				}
			}
			vo.setPeid_sdate(sdf.parse(sdate.toString()));
			vo.setPeid_edate(sdf.parse(endDate.toString()));
			monthEntityList.add(vo);
			sMonth.setLength(0);
			sdate.setLength(0);
			endDate.setLength(0);
		}
	}

	/**
	 *
	 * @param initDate
	 *            初始月份
	 * @param quarterPeriodStr
	 *            财季模式串
	 * @param quarterEntityList
	 *            周期集合——暂时存放—财季—类型周期
	 * @param sdate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param sdf
	 *            时间格式转换
	 * @param year
	 *            当前自然年
	 * @throws ParseException
	 */
	@Deprecated
	private void initPeriodQuarter(Integer initDate, String quarterPeriodStr, List<PeriodEntity> quarterEntityList,
			StringBuilder sdate, StringBuilder endDate, SimpleDateFormat sdf, int year, String creUserId)
			throws ParseException {
		// 开始时间月份
		StringBuilder sMonth = new StringBuilder();
		// 结束时间月份
		StringBuilder eMonth = new StringBuilder();
		for (int quarter = 0; quarter < 4; quarter++) {
			PeriodEntity vo = new PeriodEntity();
			vo.setPeid_enable("1");
			vo.setEdmd_class("period");
			vo.setCreuser(creUserId);
			vo.setPeid_fyr(String.valueOf(year));
			sMonth.append(initDate + 3 * quarter);
			eMonth.append(initDate + 2 + 3 * quarter);
			// 拼接起始时间
			if (sMonth.toString().length() > 1) {
				if (Integer.parseInt(sMonth.toString()) > 12) {
					sdate.append(year + 1).append("-0").append(Integer.parseInt(sMonth.toString()) - 12)
							.append(PeriodConstant.SDATE_SUFFIX);
				} else {
					sdate.append(year).append("-").append(sMonth).append(PeriodConstant.SDATE_SUFFIX);
				}
			} else {
				sdate.append(year).append("-0").append(sMonth).append(PeriodConstant.SDATE_SUFFIX);
			}
			// 拼接结束时间
			if (eMonth.toString().length() > 1) {
				if (Integer.parseInt(eMonth.toString()) > 12) {
					endDate.append(year + 1).append("-").append("0").append(Integer.parseInt(eMonth.toString()) - 12)
							.append(getEndDateTime(Integer.parseInt(eMonth.toString()), year));
				} else {
					endDate.append(year).append("-").append(eMonth)
							.append(getEndDateTime(Integer.parseInt(eMonth.toString()), year));
				}
			} else {
				endDate.append(year).append("-").append("0").append(eMonth)
						.append(getEndDateTime(Integer.parseInt(eMonth.toString()), year));
			}
			vo.setPeid_proid(quarter + 1);
			// 周期类型
			vo.setPeid_name(PeriodType.QUARTER.name());
			// 开始时间
			vo.setPeid_sdate(sdf.parse(sdate.toString()));
			// 结束时间
			vo.setPeid_edate(sdf.parse(endDate.toString()));
			// 财务周期名称
			vo.setPeid_fina_name(
					year + quarterPeriodStr.replace("%Q", "0" + (quarter + 1)).replace("%q", "0" + (quarter + 1)));
			// 日历周期名称
			vo.setPeid_cale_name(
					year + quarterPeriodStr.replace("%Q", "0" + (quarter + 1)).replace("%q", "0" + (quarter + 1)));
			quarterEntityList.add(vo);
			sdate.setLength(0);
			endDate.setLength(0);
			sMonth.setLength(0);
			eMonth.setLength(0);
		}
	}

	/**
	 * 获取周期结束时间
	 * 
	 * @param month
	 *            月份
	 * @param year
	 *            年份
	 * @return
	 */
	@Deprecated
	private String getEndDateTime(int month, int year) {
		if (month > 12) {
			month -= 12;
		}
		if (year / 4 == 0) {
			return "-29 23:59:59";
		}
		switch (month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			return "-31 23:59:59";
		case 4:
		case 6:
		case 9:
		case 11:
			return "-30 23:59:59";
		default:
			return "-28 23:59:59";
		}
	}

	/**
	 *
	 * @param initDate
	 *            初始时间
	 * @param yearPeriodStr
	 *            财年模式串
	 * @param yearEntityList
	 *            周期集合——暂时存放—财年—类型周期
	 * @param sdate
	 *            开始时间
	 * @param endDate
	 *            结束时间
	 * @param sdf
	 *            时间格式转换
	 * @param year
	 *            当前自然年
	 * @throws ParseException
	 */
	@Deprecated
	private void initPeriodYear(Integer initDate, String yearPeriodStr, SimpleDateFormat sdf,
			List<PeriodEntity> yearEntityList, StringBuilder sdate, StringBuilder endDate, int year, String creUserId)
			throws ParseException {
		PeriodEntity vo = new PeriodEntity();
		vo.setEdmd_class("period");
		vo.setCreuser(creUserId);
		vo.setPeid_enable("1");
		vo.setPeid_fyr(String.valueOf(year));
		// 周期类型
		vo.setPeid_name(PeriodType.YEAR.name());
		// 替换%y——>为yy，%Y——>为yyyy
		vo.setPeid_fina_name(
				yearPeriodStr.replace("%y", String.valueOf(year).substring(2)).replace("%Y", String.valueOf(year)));
		vo.setPeid_cale_name(
				yearPeriodStr.replace("%y", String.valueOf(year).substring(2)).replace("%Y", String.valueOf(year)));
		// 周期类型为Y时，期次默认为1
		vo.setPeid_proid(1);

		if (initDate.equals(PeriodInitDateEnum.JANUARY.getValue())) {
			sdate.append(year).append("-").append(PeriodConstant.JANUARY_YEAR_SDATE);
			endDate.append(year).append("-").append(PeriodConstant.JANUARY_YEAR_EDATE);
		} else if (initDate.equals(PeriodInitDateEnum.APRIL.getValue())) {
			sdate.append(year).append("-").append(PeriodConstant.APRIL_YEAR_SDATE);
			endDate.append(year + 1).append("-").append(PeriodConstant.APRIL_YEAR_EDATE);
		} else if (initDate.equals(PeriodInitDateEnum.JULY.getValue())) {
			sdate.append(year).append("-").append(PeriodConstant.JULY_YEAR_SDATE);
			endDate.append(year + 1).append("-").append(PeriodConstant.JULY_YEAR_EDATE);
		} else {
			sdate.append(year).append("-").append(PeriodConstant.OCTOBER_YEAR_SDATE);
			endDate.append(year + 1).append("-").append(PeriodConstant.OCTOBER_YEAR_EDATE);
		}
		vo.setPeid_sdate(sdf.parse(sdate.toString()));
		vo.setPeid_edate(sdf.parse(endDate.toString()));
		yearEntityList.add(vo);
		sdate.setLength(0);
		endDate.setLength(0);
	}
}
