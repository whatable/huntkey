package com.huntkey.rx.sceo.provider.school.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.school.vo.SchoolVO;
import com.huntkey.rx.sceo.provider.school.service.SchoolService;
import com.huntkey.rx.sceo.provider.utils.Utils;

/**
 * 学校
 * 
 * @author liucs
 * @date 2018-3-28 13:47:20
 */
@RestController
@RequestMapping(value = "/school")
public class SchoolController {
	private static Logger log = LoggerFactory.getLogger(SchoolController.class);

	@Autowired
	private SchoolService schoolService;

	/**
	 * 新增学校
	 * 
	 * @param entity
	 *            新增学校对象
	 * @return 返回新增对象id
	 */
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public Result insert(@RequestParam("authorization") String authorization, @RequestBody SchoolVO entity) {
		String currentUserId = Utils.getCurentUserId(authorization);
		entity.setCreuser(currentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.insert(entity));
		} catch (Exception e) {
			log.debug("Provider::SchoolController::insert data{}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 删除
	 * 
	 * @param id
	 *            对象id
	 * @return 返回删除条数
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public Result delete(@RequestParam("authorization") String authorization, @RequestParam("id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.delete(authorization, id));
		} catch (Exception e) {
			log.debug("Provider::SchoolController::delete data{}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 学校信息修改
	 * 
	 * @param entity
	 *            学校对象
	 * @return 返回修改条数
	 */
	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public Result update(@RequestParam("authorization") String authorization, @RequestBody SchoolVO entity) {
		String currentUserId = Utils.getCurentUserId(authorization);
		entity.setModuser(currentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.update(entity));
		} catch (Exception e) {
			log.debug("Provider::SchoolController::update data{}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 根据id查询学校
	 * 
	 * @param id
	 *            对象id
	 * @return 返回对象
	 */
	@RequestMapping(value = "/queryById/{id}", method = RequestMethod.GET)
	public Result queryById(@PathVariable("id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.queryById(id));
		} catch (Exception e) {
			log.debug("Provider::SchoolController::queryById data{}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 分页、模糊查询学校列表
	 * 
	 * @param rschName
	 *            查询条件
	 * @param rschCode
	 *            查询条件
	 * @param rschCity
	 *            学下所在地
	 * @param rschEnable
	 *            启用/禁用
	 * @param pageSize
	 *            每页大小
	 * @param pageNum
	 *            当前页数
	 * @return
	 */
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public Result list(@RequestParam(required = false, value = "rschName") String rschName,
			@RequestParam(required = false, value = "rschCode") String rschCode,
			@RequestParam(required = false, value = "rschCity") String rschCity,
			@RequestParam(required = false, value = "rschEnable") String rschEnable,
			@RequestParam(required = false, value = "pageSize", defaultValue = "10") Integer pageSize,
			@RequestParam(required = false, value = "pageNum", defaultValue = "1") Integer pageNum) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.list(rschName, rschCode, rschCity, rschEnable, pageSize, pageNum));
		} catch (Exception e) {
			log.debug("Provider::SchoolController::list data{}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 按名称模糊查询学校
	 * 
	 * @param name
	 * @return
	 */
	@RequestMapping(value = "/v1/objectsByName", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "shcool",methodDesc = "按名称模糊查询学校",methodCate =
	// "表单通用方法",getReqParamsNameNoPathVariable = {"name"})
	@Deprecated
	public Result objectsByName(@RequestParam(value = "name") String name) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.objectsByName(name));
		} catch (Exception e) {
			log.debug("Provider::SchoolController::objectsByName data{}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 读取指定区域内所有学校
	 * 
	 * @param area
	 * @return
	 */
	@RequestMapping(value = "/v1/objectsByArea/{area}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "school", methodDesc = "读取指定区域内所有学校", methodCate =
	// "表单通用方法", getReqParamsNameNoPathVariable = {
	// "enable" })
	@Deprecated
	public Result objectsByArea(@PathVariable(value = "area") String area,
			@RequestParam(value = "enable") String enable) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.objectsByArea(area, enable));
		} catch (Exception e) {
			log.debug("school//v1/objectsByArea/{area}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 读取某个学校的信息
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/v1/objects/{id}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "school", methodDesc = "读取某个学校的信息", methodCate =
	// "表单通用方法")
	@Deprecated
	public Result qeuryObjectById(@PathVariable(value = "id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(schoolService.qeuryObjectById(id));
		} catch (Exception e) {
			log.debug("school//v1/objects/{id}", e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}
}
