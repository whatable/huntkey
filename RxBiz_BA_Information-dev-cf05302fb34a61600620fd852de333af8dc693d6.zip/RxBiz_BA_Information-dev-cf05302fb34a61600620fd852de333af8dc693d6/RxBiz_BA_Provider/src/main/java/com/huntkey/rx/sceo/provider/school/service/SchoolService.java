package com.huntkey.rx.sceo.provider.school.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.SchoolEntity;
import com.huntkey.rx.sceo.common.model.school.vo.SchoolVO;

import java.util.List;

/**
 * @author liucs
 * @date 2018-3-28 13:46:49
 */
public interface SchoolService {

    /**
     * 新增学校
     * @param entity 学校对象
     * @return 返回对象id
     */
    String insert(SchoolVO entity)throws Exception;

    /**
     * 删除学校
     * @param id 对象id
     * @return 返回删除记录条数
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 学校信息修改
     * @param entity 学校对象
     * @return 返回修改条数
     * @throws Exception 抛出异常
     */
    int update(SchoolVO entity)throws Exception;

    /**
     * 根据id查询学校信息
     * @param id 对象id
     * @return 返回对象
     * @throws Exception 抛出异常
     */
    SchoolVO queryById(String id)throws Exception;

    /**
     * 分页、模糊查询学校列表
     * @param rschName 查询参数
     * @param rschCode 查询参数
     * @param rschCity 学校所在地
     * @param pageSize 每页大小
     * @param pageNum 当前页数
     * @return 返回SchoolEntity集合
     * @throws Exception 抛出异常
     */
    Pagination<SchoolVO> list(String rschName,String rschCode,String rschCity,String rschEnable,Integer pageSize,Integer pageNum)throws Exception;

    /**
     * 根据学校名称模糊查询
     * @param name
     * @return
     * @throws Exception
     */
    List<SchoolVO> objectsByName(String name)throws Exception;

    /**
     * 读取指定区域内所有学校
     * @param area
     * @return
     * @throws Exception
     */
    List<SchoolVO> objectsByArea(String area,String enable) throws Exception;

    /**
     * 读取某个学校的信息
     * @param id
     * @return
     * @throws Exception
     */
    SchoolVO qeuryObjectById(String id)throws Exception;
}
