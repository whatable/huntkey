package com.huntkey.rx.sceo.provider.school.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.base.BaseEntity;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.AreaProperty;
import com.huntkey.rx.edm.entity.AreaEntity;
import com.huntkey.rx.edm.entity.SchoolEntity;
import com.huntkey.rx.edm.entity.WordlistEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.school.SchoolConstant;
import com.huntkey.rx.sceo.common.model.school.vo.SchoolVO;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.school.service.SchoolService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.formula.functions.Roman;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class SchoolServiceImpl implements SchoolService {
    @Autowired
    private OrmService ormService;
    @Autowired
    private ParameterService parameterService;
    @Override
    @Transactional(rollbackFor = Exception.class)
    public String insert(SchoolVO entity) throws Exception{
        // 判断是否标准系统
        boolean isStandardSystem = parameterService.isStandardSystem();
        if (!isStandardSystem) {
            entity.setRschIsStandard(Constants.NOT_STANDARD);
        }
        if(StringUtil.isNullOrEmpty(entity.getRschName().trim())){
            throw new RuntimeException("学校名称为空！");
        }
        if(isExistSchoolCode(entity)){
            throw new RuntimeException("学校编号重复!");
        }
        if(isExistSchoolName(entity)){
            throw new RuntimeException("学校名称重复!");
        }
        SchoolEntity schoolEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),SchoolEntity.class);
        return ormService.insertSelective(schoolEntity).toString();
    }

    @Override
    public int delete(String authorization,String id) throws Exception {
        String currentUserId = Utils.getCurentUserId(authorization);
        SchoolEntity entity = new SchoolEntity();
        entity.setId(id);
        entity.setModuser(currentUserId);
        entity.setModtime(new Date());
        ormService.updateSelective(entity);
        return ormService.delete(SchoolEntity.class, id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(SchoolVO entity) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(SchoolConstant.RSCH_CODE,entity.getRschCode().trim()));
        List<SchoolEntity> entities = ormService.selectBeanList(SchoolEntity.class,ormParam);
        if(entities != null && entities.size() >= 1 && !entities.get(0).getId().equals(entity.getId())){
            throw new RuntimeException("学校代码重复!");
        }
        ormParam.setWhereExp(ormParam.getEqualXML(SchoolConstant.RSCH_NAME,entity.getRschName().trim()));
        entities = ormService.selectBeanList(SchoolEntity.class, ormParam);
        if(entities != null && entities.size() >= 1 && !entities.get(0).getId().equals(entity.getId())){
            throw new RuntimeException("学校名称重复!");
        }
        SchoolEntity schoolEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),SchoolEntity.class);

        return ormService.updateSelective(schoolEntity);
    }

    @Override
    public SchoolVO queryById(String id) throws Exception {
        SchoolEntity entity = ormService.load(SchoolEntity.class,id);
        if(entity == null){
            return null;
        }
        SchoolVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity),SchoolVO.class);
        AreaEntity areaEntity = ormService.load(AreaEntity.class,vo.getRschCity());
        if(areaEntity != null){
            vo.setRschCityName(areaEntity.getArea_name());
        }
        vo.setCreUserName(Utils.getUserNameByUserId(entity.getCreuser(),ormService));
        vo.setModUserName(Utils.getUserNameByUserId(entity.getModuser(),ormService));
        return vo;
    }

    @Override
    public Pagination<SchoolVO> list(String rschName,String rschCode,String rschCity,String rschEnable,Integer pageSize,Integer pageNum) throws Exception {
        //封装查询条件，并按创建时间倒序排序
        OrmParam ormParam = setQuerydition(rschName,rschCode,rschCity,rschEnable);

        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);
        Pagination<SchoolEntity> pagination = ormService.selectPagedBeanList(SchoolEntity.class,ormParam);
        if(pagination == null || pagination.getTotal() == 0){
            return null;
        }
       List<SchoolVO> voList = JSONObject.parseArray(JSONObject.toJSONString(pagination.getList()),SchoolVO.class);
//        AreaEntity city;
        WordlistEntity wordlistEntity = null;
        for (SchoolVO schoolVO : voList) {
            if(StringUtils.isNotEmpty(schoolVO.getRschRanking())){
                wordlistEntity = ormService.load(WordlistEntity.class,schoolVO.getRschRanking());
            }
            if(wordlistEntity != null){
                schoolVO.setRschRankingName(wordlistEntity.getWord_name());
            }
            AreaEntity areaEntity = ormService.load(AreaEntity.class,schoolVO.getRschCity());
            if(areaEntity != null){
                schoolVO.setRschCityName(areaEntity.getArea_name());
                schoolVO.setRschProv(areaEntity.getArea_parent_area());
            }

            schoolVO.setModUserName(Utils.getUserNameByUserId(schoolVO.getModuser(),ormService));
            schoolVO.setCreUserName(Utils.getUserNameByUserId(schoolVO.getCreuser(),ormService));
//            city = ormService.load(AreaEntity.class,schoolVO.getRschCity());
//            if(city != null){
//                schoolVO.setRschProv(city.getArea_parent_area());
//            }
        }
        return new Pagination<SchoolVO>(voList,pageNum,pageSize,pagination.getTotal());
    }

    @Override
    public List<SchoolVO> objectsByName(String name) throws Exception {
        OrmParam ormParam = setQuerydition(name,null,null,null);
        return entity2vo(ormParam);
    }

    @Override
    public List<SchoolVO> objectsByArea(String area,String enable) throws Exception {
        OrmParam ormParam = setQuerydition(null,null,area,enable);
        return entity2vo(ormParam);
    }

    @Override
    public SchoolVO qeuryObjectById(String id) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(BasicConst.ID,id)));
        return entity2vo(ormParam).get(0);
    }

    /**
     * 封装查询条件，并按创建时间倒序排序
     * @param rschName 查询参数
     * @param rschCode 查询参数
     * @param rschCity 学校所在区域
     * @return
     */
    private OrmParam setQuerydition(String rschName,String rschCode,String rschCity,String rschEnable){
        OrmParam ormParam = new OrmParam();
        List<String> columnList = new ArrayList<>(Arrays.asList(SchoolConstant.RSCH_CITY,SchoolConstant.RSCH_ENABLE,SchoolConstant.RSCH_NAME,
                SchoolConstant.RSCH_CODE,SchoolConstant.RSCH_RANKING,SchoolConstant.RSCH_WEBSITE,SchoolConstant.RSCH_IS_STANDARD));
        Utils.setBaseQueryColums(columnList);
        columnList.remove(columnList.indexOf("pid"));
        ormParam.setColumns(columnList);
        String whereExp = "";
        if(StringUtils.isNotEmpty(rschName) && StringUtils.isNotEmpty(rschName.trim())){
           whereExp = OrmParam.and(ormParam.getMatchMiddleXML(SchoolConstant.RSCH_NAME,rschName.trim()));
        }
        if(StringUtils.isNotEmpty(rschCode) && StringUtils.isNotEmpty(rschCode.trim())){
            whereExp = OrmParam.and(ormParam.getEqualXML(SchoolConstant.RSCH_CODE,rschCode.trim()));
        }
        if(StringUtils.isNotEmpty(rschCity)){
            whereExp = OrmParam.and(ormParam.getEqualXML(SchoolConstant.RSCH_CITY,rschCity),whereExp);
        }
        if(StringUtils.isNotEmpty(rschEnable)){
            whereExp = OrmParam.and(ormParam.getEqualXML(SchoolConstant.RSCH_ENABLE,rschEnable),whereExp);
        }
        ormParam.setWhereExp(whereExp);
        //设置排序方式
        ormParam.addOrderExpElement(SQLSortEnum.DESC, BasicConst.CRETIME);
        return ormParam;
    }

    private List<SchoolVO> entity2vo(OrmParam ormParam)throws Exception{
        List<SchoolEntity> entities = ormService.selectBeanList(SchoolEntity.class,ormParam);
        List<SchoolVO> voList = new ArrayList<>();
       if(entities != null && entities.size() > 0){
           voList = JSONObject.parseArray(JSONObject.toJSONString(entities),SchoolVO.class);
           for (SchoolVO schoolVO : voList) {
               schoolVO.setModUserName(Utils.getUserNameByUserId(schoolVO.getModuser(),ormService));
               schoolVO.setCreUserName(Utils.getUserNameByUserId(schoolVO.getCreuser(),ormService));
           }
       }
        return voList;
    }

    /**
     * 学校编号重复校验
     * @param vo
     * @return
     * @throws Exception
     */
    private boolean isExistSchoolCode(SchoolVO vo) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(SchoolConstant.RSCH_CODE,vo.getRschCode().trim()));
        long count = ormService.count(SchoolEntity.class,ormParam);
        return count > 0;
    }

    private boolean isExistSchoolName(SchoolVO vo) throws Exception {
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(SchoolConstant.RSCH_NAME,vo.getRschName().trim()));
        long count = ormService.count(SchoolEntity.class,ormParam);
        return count > 0;
    }

    //通用——设置查询条件
//    private static  void setCondition(OrmParam ormParam, String queryCondition, Class clazz)throws Exception{
//        Field[] fields = clazz.getDeclaredFields();
//        String whereAnd = ormParam.getWhereExp();
//        String whereOr = "";
//        for (Field field : fields) {
//            if(whereAnd.contains(field.getName().toLowerCase())){
//                continue;
//            }
//            whereOr = OrmParam.or(ormParam.getEqualXML(field.getName().toLowerCase(),queryCondition),whereOr);
//        }
//        String whereExp = OrmParam.and(whereOr,whereAnd);
//        ormParam.setWhereExp(whereExp);
//    }
}
