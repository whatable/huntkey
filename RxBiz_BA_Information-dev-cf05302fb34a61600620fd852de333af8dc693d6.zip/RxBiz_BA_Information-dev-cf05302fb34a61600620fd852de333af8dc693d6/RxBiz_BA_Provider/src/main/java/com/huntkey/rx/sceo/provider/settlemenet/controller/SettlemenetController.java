package com.huntkey.rx.sceo.provider.settlemenet.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.SettlemenetEntity;
import com.huntkey.rx.sceo.provider.settlemenet.service.SettlemenetService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author liucs
 * @date 2018-4-2 11:19:54
 */
@RestController
@RequestMapping("/settlemenet")
public class SettlemenetController {
    @Autowired
    private SettlemenetService settlemenetService;

    /**
     * 新增
     * @param authorization 用户登录认证
     * @param entity 对象
     * @return 返回对象id
     */
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(@RequestParam("authorization")String authorization, SettlemenetEntity entity){
        String currentUserId = Utils.getCurentUserId(authorization);
        entity.setCreuser(currentUserId);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(settlemenetService.insert(entity));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 删除
     * @param id 对象id
     * @return 返回删除条数
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(@RequestParam("authorization") String authorization,@RequestParam("id") String id){
        String currentUserId = Utils.getCurentUserId(authorization);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(settlemenetService.delete(currentUserId,id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 信息修改
     * @param entity 对象
     * @return 返回修改条数
     */
    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    public Result update(@RequestParam("authorization")String authorization,@RequestBody SettlemenetEntity entity){
        String currentUserId = Utils.getCurentUserId(authorization);
        entity.setModuser(currentUserId);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(settlemenetService.update(entity));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     */
    @RequestMapping(value = "/queryById",method = RequestMethod.GET)
    public Result queryById(@RequestParam("id")String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(settlemenetService.queryById(id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 分页、模糊查询结算方式列表
     * @param settType 结算类型
     * @param settOdays 出货天数
     * @param settIdays 货到天数
     * @param settWay 结算方式
     * @param pageSize 每页大小
     * @param pageNum 当前页数
     * @return
     */
    @RequestMapping(value = "/list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "sett_type")String settType,
                       @RequestParam(required = false,value = "sett_odays")Integer settOdays,
                       @RequestParam(required = false,value = "sett_idays")Integer settIdays,
                       @RequestParam(required = false,value = "sett_way")String settWay,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum){
        SettlemenetEntity entity = new SettlemenetEntity();
        entity.setSett_type(settType);
        entity.setSett_odays(settOdays);
        entity.setSett_idays(settIdays);
        entity.setSett_way(settWay);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(settlemenetService.list(entity,pageSize,pageNum));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }
}
