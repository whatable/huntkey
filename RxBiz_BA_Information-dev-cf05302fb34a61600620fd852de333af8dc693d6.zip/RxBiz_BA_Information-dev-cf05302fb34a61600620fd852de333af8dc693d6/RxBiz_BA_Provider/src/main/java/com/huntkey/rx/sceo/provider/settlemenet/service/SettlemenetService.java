package com.huntkey.rx.sceo.provider.settlemenet.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.SettlemenetEntity;

/**
 * @author liucs
 * @date 2018-4-2 11:22:41
 */
public interface SettlemenetService {

        /**
         * 新增
         * @param entity 结算方式对象
         * @return 返回对象id
         * @throws Exception 抛出异常
         */
        String insert(SettlemenetEntity entity)throws Exception;

        /**
         * 删除
         * @param id 对象id
         * @param currentUserId 当前登录用户id
         * @return 返回删除数量
         * @throws Exception 抛出异常
         */
        int delete(String currentUserId,String id)throws Exception;

        /**
         * 修改
         * @param entity 结算方式对象
         * @return 返回修改数量
         * @throws Exception 抛出异常
         */
        int update(SettlemenetEntity entity)throws Exception;

        /**
         * 根据id查询
         * @param id 对象id
         * @return 返回区域对象
         * @throws Exception 抛出异常
         */
        SettlemenetEntity queryById(String id)throws Exception;

        /**
         * 分页模糊查询区域列表
         * @param entity 区域对象——封装查询参数
         * @param pageSize 每页大小
         * @param pageNum 当前页
         * @return 返回区域列表
         * @throws Exception 抛出异常
         */
        Pagination<SettlemenetEntity> list(SettlemenetEntity entity, Integer pageSize, Integer pageNum)throws Exception;
}
