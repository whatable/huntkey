package com.huntkey.rx.sceo.provider.settlemenet.service.impl;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.SettlemenetEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.settlemenet.SettlemenetConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.settlemenet.service.SettlemenetService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author liucs
 * @date 2018-4-2 11:22:24
 */
@Service
@Transactional(readOnly = true, rollbackFor = Exception.class)
public class SettlemenetServiceImpl implements SettlemenetService {
    @Autowired
    private OrmService ormService;

    @Override
    public String insert(SettlemenetEntity entity) throws Exception {
        return ormService.insert(entity).toString();
    }

    @Override
    public int delete(String currentUserId, String id) throws Exception {
        SettlemenetEntity entity = new SettlemenetEntity();
        entity.setModuser(currentUserId);
        entity.setId(id);
        ormService.updateSelective(entity);
        return ormService.delete(SettlemenetEntity.class,id);
    }

    @Override
    public int update(SettlemenetEntity entity) throws Exception {
        return ormService.updateSelective(entity);
    }

    @Override
    public SettlemenetEntity queryById(String id) throws Exception {
        return ormService.load(SettlemenetEntity.class,id);
    }

    @Override
    public Pagination<SettlemenetEntity> list(SettlemenetEntity entity, Integer pageSize, Integer pageNum) throws Exception {
        OrmParam ormParam = setQueryCondition(entity);
        List<String> list = Arrays.asList(SettlemenetConstant.SETT_DESC,SettlemenetConstant.SETT_WAY,SettlemenetConstant.SETT_MDAYS,
                SettlemenetConstant.SETT_MDATE,SettlemenetConstant.SETT_DATYS,SettlemenetConstant.SETT_RATE,SettlemenetConstant.SETT_IDAYS,
                SettlemenetConstant.SETT_ODAYS,SettlemenetConstant.SETT_TYPE);
        List<String> columns = new ArrayList<>(list);
        Utils.setBaseQueryColums(columns);
        columns.remove("pid");
        ormParam.setColumns(columns);
        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);
        return ormService.selectPagedBeanList(SettlemenetEntity.class,ormParam);
    }

    private OrmParam setQueryCondition(SettlemenetEntity entity){
        OrmParam ormParam = new OrmParam();
        if(null == entity){
            return ormParam;
        }
        String whereExp = "";
        if(StringUtils.isNotEmpty(entity.getSett_type())){
            whereExp = OrmParam.and(ormParam.getEqualXML(SettlemenetConstant.SETT_TYPE,entity.getSett_type()));
        }
        if(null != entity.getSett_odays()){
            whereExp = OrmParam.and(ormParam.getEqualXML(SettlemenetConstant.SETT_ODAYS,entity.getSett_odays()),whereExp);
        }
        if(null != entity.getSett_idays()){
            whereExp = OrmParam.and(ormParam.getEqualXML(SettlemenetConstant.SETT_IDAYS,entity.getSett_idays()),whereExp);
        }
        if(StringUtils.isNotEmpty(entity.getSett_way())){
            whereExp = OrmParam.and(ormParam.getEqualXML(SettlemenetConstant.SETT_WAY,entity.getSett_way()),whereExp);
        }
        ormParam.setWhereExp(whereExp);
        ormParam.setOrderExp(SQLSortEnum.DESC, BasicConst.MODTIME);
        return ormParam;
    }
}
