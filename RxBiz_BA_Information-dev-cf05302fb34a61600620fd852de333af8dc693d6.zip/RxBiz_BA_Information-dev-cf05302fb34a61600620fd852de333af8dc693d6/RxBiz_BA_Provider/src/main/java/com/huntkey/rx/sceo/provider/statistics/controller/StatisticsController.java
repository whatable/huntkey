package com.huntkey.rx.sceo.provider.statistics.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.edm.entity.StatisticsEntity;
import com.huntkey.rx.sceo.provider.statistics.service.StatisticService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * 统计
 * @author liucs
 * @date 2018-3-29 13:59:33
 */
@RestController
@RequestMapping("/statistics")
public class StatisticsController {
    @Autowired
    private StatisticService statisticService;

    /**
     * 新增
     * @param authorization 登录用户认证
     * @param entity 统计对象
     * @return 返回对象id
     */
    @RequestMapping(value = "/insert",method = RequestMethod.POST)
    public Result insert(@RequestParam("authorization")String authorization,@RequestBody StatisticsEntity entity){
        String currentUserid = Utils.getCurentUserId(authorization);
        entity.setCreuser(currentUserid);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(statisticService.insert(entity));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 删除
     * @param id 对象id
     * @return 返回删除记录条数
     */
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    public Result delete(@RequestParam("authorization")String authorization,@RequestParam("id")String id){
        String currentUserId = Utils.getCurentUserId(authorization);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(statisticService.delete(currentUserId,id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 修改
     * @param authorization 登录用户认证
     * @param entity 统计对象
     * @return 返回修改记录条数
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public Result update(@RequestParam("authorization")String authorization,@RequestBody StatisticsEntity entity){
        String currentUserId = Utils.getCurentUserId(authorization);
        entity.setModuser(currentUserId);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(statisticService.update(entity));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     */
    @RequestMapping(value = "/queryById",method = RequestMethod.GET)
    public Result queryById(@RequestParam("id")String id){
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(statisticService.queryById(id));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }

    /**
     * 分页、模糊查询统计列表
     * @param statMoniclass 所属类
     * @param statFyear 财年
     * @param statBeg 起始时间
     * @param statEnd 结束时间
     * @param pageSize 每页数据量
     * @param pageNum 当前页数
     * @return
     */
    @RequestMapping(value = "list",method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "stat_moniclass")String statMoniclass,
                       @RequestParam(required = false,value = "stat_fyear")String statFyear,
                       @RequestParam(required = false,value = "stat_beg")Date statBeg,
                       @RequestParam(required = false,value = "stat_end")Date statEnd,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "10")Integer pageSize,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1")Integer pageNum){
        StatisticsEntity entity = new StatisticsEntity();
        entity.setStat_moniclass(statMoniclass);
        entity.setStat_fyear(statFyear);
        entity.setStat_beg(statBeg);
        entity.setStat_end(statEnd);
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        try {
            result.setData(statisticService.list(entity,pageSize,pageNum));
        }catch (Exception e){
            result.setRetCode(Result.RECODE_ERROR);
            result.setErrMsg(e.getMessage());
        }
        return result;
    }
}
