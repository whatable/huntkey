package com.huntkey.rx.sceo.provider.statistics.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.StatisticsEntity;

/**
 * @author liucs
 * @date 2018-3-29 14:06:09
 */
public interface StatisticService {

    /**
     *新增
     * @param entity 统计对象
     * @return 返回id
     * @throws Exception 抛出异常
     */
    String insert(StatisticsEntity entity) throws Exception;

    /**
     * 删除
     * @param id 对象id
     * @return 返回删除记录条数
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 修改
     * @param entity 统计对象
     * @return 返回修改记录条数
     * @throws Exception 抛出异常
     */
    int update(StatisticsEntity entity)throws Exception;

    /**
     * 根据id查询
     * @param id 对象id
     * @return 返回对象
     * @throws Exception 抛出异常
     */
    StatisticsEntity queryById(String id)throws Exception;

    /**
     * 分页模糊查询统计列表
     * @param entity 统计对象——封装查询参数
     * @param pageSize 每页数据量
     * @param pageNum 当前页数
     * @return 返回集合
     * @throws Exception 抛出异常
     */
    Pagination<StatisticsEntity> list(StatisticsEntity entity,Integer pageSize,Integer pageNum)throws Exception;
}
