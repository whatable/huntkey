package com.huntkey.rx.sceo.provider.statistics.service.impl;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.StatisticsEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.statistics.StatisticsConstant;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.statistics.service.StatisticService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Service
@Transactional(readOnly = true,rollbackFor = Exception.class)
public class StatisticServiceImpl implements StatisticService{
    @Autowired
    private OrmService ormService;

    @Override
    public String insert(StatisticsEntity entity) throws Exception {
        return ormService.insertSelective(entity).toString();
    }

    @Override
    public int delete(String currentUserId,String id) throws Exception {
        StatisticsEntity entity = new StatisticsEntity();
        entity.setId(id);
        entity.setModuser(currentUserId);
        //修改维护人信息
        ormService.updateSelective(entity);
        return ormService.delete(StatisticsEntity.class, id);
    }

    @Override
    public int update(StatisticsEntity entity) throws Exception {
        return ormService.updateSelective(entity);
    }

    @Override
    public StatisticsEntity queryById(String id) throws Exception {
        return ormService.load(StatisticsEntity.class,id);
    }

    @Override
    public Pagination<StatisticsEntity> list(StatisticsEntity entity, Integer pageSize, Integer pageNum) throws Exception {
        //封装查询条件，并按创建时间倒序排序
        OrmParam ormParam = setQueryCondition(entity);
        List<String> list = Arrays.asList(StatisticsConstant.STAT_PRIDOBJ,StatisticsConstant.STAT_MONICLASS,
                StatisticsConstant.STAT_MONIOBJ,StatisticsConstant.STAT_MONIATTR,StatisticsConstant.STAT_ISCOMPARE,
                StatisticsConstant.STAT_FYEAR,StatisticsConstant.STAT_PERIORNAME,StatisticsConstant.STAT_PERIOD,
                StatisticsConstant.STAT_BEG,StatisticsConstant.STAT_END,StatisticsConstant.STAT_PERAMT,
                StatisticsConstant.STAT_CURAMT,StatisticsConstant.STAT_CURSUM);
        List<String> columns = new ArrayList<>(list);
        //设置基础查询列
        Utils.setBaseQueryColums(columns);
        columns.remove(columns.indexOf("pid"));
        ormParam.setColumns(columns);
        ormParam.setPageSize(pageSize);
        ormParam.setPageNo(pageNum);
        return ormService.selectPagedBeanList(StatisticsEntity.class,ormParam);
    }

    /**
     * 封装查询条件，并按创建时间倒序排序
     * @param entity 查询参数
     * @return
     */
    private OrmParam setQueryCondition(StatisticsEntity entity){
        OrmParam ormParam = new OrmParam();
        if(null == entity){
            return ormParam;
        }
        String whereExp = "";
        if(StringUtils.isNotEmpty(entity.getStat_moniclass())){
            whereExp = OrmParam.and(ormParam.getMatchMiddleXML(StatisticsConstant.STAT_MONICLASS,entity.getStat_moniclass()));
        }
        if(StringUtils.isNotEmpty(entity.getStat_fyear())){
            whereExp = OrmParam.and(ormParam.getEqualXML(StatisticsConstant.STAT_FYEAR,entity.getStat_fyear()),whereExp);
        }
        if(null != entity.getStat_beg()){
            whereExp = OrmParam.and(ormParam.getGreaterThanAndEqualXML(StatisticsConstant.STAT_BEG,entity.getStat_beg()),whereExp);
        }
        if(null != entity.getStat_end()){
            whereExp = OrmParam.and(ormParam.getLessThanAndEqualXML(StatisticsConstant.STAT_END,entity.getStat_end()),whereExp);
        }
        ormParam.setWhereExp(whereExp);
        ormParam.setOrderExp(SQLSortEnum.DESC, BasicConst.CRETIME);
        return ormParam;
    }
}
