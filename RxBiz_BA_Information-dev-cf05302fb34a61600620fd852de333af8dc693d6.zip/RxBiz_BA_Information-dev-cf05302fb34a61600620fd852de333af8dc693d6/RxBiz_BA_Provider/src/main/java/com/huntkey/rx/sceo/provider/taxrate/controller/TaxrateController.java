package com.huntkey.rx.sceo.provider.taxrate.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.taxrate.vo.TaxrateVO;
import com.huntkey.rx.sceo.provider.taxrate.service.TaxrateService;
import com.huntkey.rx.sceo.provider.utils.Utils;

/**
 * 税率
 * 
 * @author liucs
 * @date 2018-3-29 17:43:54
 */
@RestController
@RequestMapping("/taxrate")
public class TaxrateController {
	private static Logger logger = LoggerFactory.getLogger(TaxrateController.class);

	@Autowired
	private TaxrateService taxrateService;

	/**
	 * 新增
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param entity
	 *            税率对象
	 * @return 返回对象id
	 */
	@RequestMapping(value = "/insert", method = RequestMethod.POST)
	public Result insert(@RequestParam("authorization") String authorization, @RequestBody TaxrateVO entity) {
		String currentUserId = Utils.getCurentUserId(authorization);
		entity.setCreuser(currentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(taxrateService.insert(entity));
		} catch (Exception e) {
			logger.error("taxrate/insert:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 删除
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param id
	 *            对象id
	 * @return 返回删除数量
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.DELETE)
	public Result delete(@RequestParam("authorization") String authorization, @RequestParam("id") String id) {
		String currentUserId = Utils.getCurentUserId(authorization);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(taxrateService.delete(currentUserId, id));
		} catch (Exception e) {
			logger.error("taxrate/delete:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 修改
	 * 
	 * @param authorization
	 *            登录用户认证
	 * @param entity
	 *            统计对象
	 * @return 返回修改记录条数
	 */
	@RequestMapping(value = "/update", method = RequestMethod.PUT)
	public Result update(@RequestParam("authorization") String authorization, @RequestBody TaxrateVO entity) {
		String currentUserId = Utils.getCurentUserId(authorization);
		entity.setModuser(currentUserId);
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(taxrateService.update(entity));
		} catch (Exception e) {
			logger.error("taxrate/update:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 根据id查询
	 * 
	 * @param id
	 *            对象id
	 * @return 返回对象
	 */
	@RequestMapping(value = "/queryById/{id}", method = RequestMethod.GET)
	public Result queryById(@PathVariable("id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(taxrateService.queryById(id));
		} catch (Exception e) {
			logger.error("taxrate/queryById:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 分页、模糊查询税率列表
	 * 
	 * @param taxrName
	 *            税率名
	 * @param taxrEnable
	 *            启用禁用
	 * @param taxrCode
	 *            税率编码
	 * @param taxrIsdeduct
	 *            是否抵扣
	 * @return
	 */
	@RequestMapping(value = "list", method = RequestMethod.GET)
	public Result list(@RequestParam(required = false, value = "taxrName") String taxrName,
			@RequestParam(required = false, value = "taxrEnable") String taxrEnable,
			@RequestParam(required = false, value = "taxrCode") String taxrCode,
			@RequestParam(required = false, value = "taxrIsdeduct") Integer taxrIsdeduct) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(taxrateService.list(taxrName, taxrCode, taxrEnable, taxrIsdeduct));
		} catch (Exception e) {
			logger.error("taxrate/list:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 根据id查询某条税率信息
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/v1/objects/{id}", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "taxrate", methodDesc = "根据id查询某条税率信息", methodCate
	// = "表单通用方法")
	@Deprecated
	public Result queryObjectById(@PathVariable(value = "id") String id) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(taxrateService.queryById(id));
		} catch (Exception e) {
			logger.error("taxrate/v1/objects/{id}:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}

	/**
	 * 【注】----------------------------------------------------------------------------------------------
	 * 移除了@MethodRegister注解，EDM注册方法统一在api.controller包中的开放接口中实现（除了api.controller包，其他包的方法原则上不要设置@MethodRegister）。
	 * 本类的方法仅供基础资料后台维护界面使用，本方法已经设置了@Deprecated，如果不被界面调用，则后续建议彻底删除该方法，如果确定会被界面使用，则请删除@Deprecated注解
	 * 【by jiangshaoh @ 2018-7-3 】
	 * 
	 * 综合查询税率信息
	 * 
	 * @param code
	 *            系统编码
	 * @param isdeduct
	 *            是否抵扣
	 * @param name
	 *            税率名称
	 * @param enable
	 *            1、启用，0、禁用
	 * @return
	 */
	@RequestMapping(value = "/v1/objects", method = RequestMethod.GET)
	// @MethodRegister(edmClass = "taxrate",methodDesc = "综合查询税率信息",methodCate =
	// "表单通用方法",
	// getReqParamsNameNoPathVariable = {"code","isdeduct","name","enable"})
	@Deprecated
	public Result queryObjects(@RequestParam(value = "code", required = false) String code,
			@RequestParam(value = "isdeduct", required = false) Integer isdeduct,
			@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "enable", required = false) String enable) {
		Result result = new Result();
		result.setRetCode(Result.RECODE_SUCCESS);
		try {
			result.setData(taxrateService.queryObjects(code, isdeduct, name, enable));
		} catch (Exception e) {
			logger.error("taxrate/v1/objects:" + e.getMessage());
			result.setRetCode(Result.RECODE_ERROR);
			result.setErrMsg(e.getMessage());
		}
		return result;
	}
}
