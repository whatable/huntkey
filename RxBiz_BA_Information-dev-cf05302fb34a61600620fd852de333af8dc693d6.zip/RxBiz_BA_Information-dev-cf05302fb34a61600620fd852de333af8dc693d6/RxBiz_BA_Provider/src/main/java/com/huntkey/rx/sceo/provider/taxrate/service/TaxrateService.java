package com.huntkey.rx.sceo.provider.taxrate.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.common.model.taxrate.vo.TaxrateVO;

import java.util.List;

/**
 * @author liucs
 * @date 2018-3-29 17:45:13
 */
public interface TaxrateService {
    /**
     * 新增
     * @param entity 税率对象
     * @return 返回对象id
     * @throws Exception 抛出异常
     */
    String insert(TaxrateVO entity)throws Exception;

    /**
     * 删除
     * @param currentUserId 登录用户id
     * @param id 税率id
     * @return 反水删除数量
     * @throws Exception 抛出异常
     */
    int delete(String currentUserId,String id)throws Exception;

    /**
     * 修改
     * @param entity 税率对象
     * @return 返回修改数量
     * @throws Exception 抛出异常
     */
    int update(TaxrateVO entity)throws Exception;

    /**
     * 根据id查询
     * @param id 税率id
     * @return 返回税率对象
     * @throws Exception 抛出异常
     */
    TaxrateVO queryById(String id)throws Exception;

    /**
     * 分页模糊查询
     * @param taxrName
     * @param taxrCode
     * @param taxrIsdeduct
     * @param taxrEnable
     * @return
     * @throws Exception
     */
    List<TaxrateVO> list(String taxrName,String taxrCode,String taxrEnable,Integer taxrIsdeduct) throws Exception;

    /**
     * 综合查询税率信息
     * @param code 系统编码
     * @param isdeduct 是否抵扣
     * @param name 税率名称
     * @return
     */
    List<TaxrateVO> queryObjects(String code,Integer isdeduct,String name,String enable)throws Exception;
}
