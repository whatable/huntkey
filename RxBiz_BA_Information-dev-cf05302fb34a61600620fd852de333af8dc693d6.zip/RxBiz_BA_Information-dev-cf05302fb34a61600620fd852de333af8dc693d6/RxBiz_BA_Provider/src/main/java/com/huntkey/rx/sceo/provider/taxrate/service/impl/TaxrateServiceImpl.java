package com.huntkey.rx.sceo.provider.taxrate.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.TaxrateEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.common.model.taxrate.TaxrateConstant;
import com.huntkey.rx.sceo.common.model.taxrate.vo.TaxrateVO;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.feign.OrmClient;
import com.huntkey.rx.sceo.provider.taxrate.service.TaxrateService;
import com.huntkey.rx.sceo.provider.utils.Utils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author liucs
 * @date 2018-3-29 17:45:37
 */
@Service
@Transactional(readOnly = true,rollbackFor = Exception.class)
public class TaxrateServiceImpl implements TaxrateService {
    @Autowired
    private OrmService ormService;
    @Autowired
    private ParameterService parameterService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public String insert(TaxrateVO entity) throws Exception {
        // 判断是否标准系统
        boolean isStandardSystem = parameterService.isStandardSystem();
        if (!isStandardSystem) {
            entity.setTaxrIsStandard(Constants.NOT_STANDARD);
        }
        if(StringUtil.isNullOrEmpty(entity.getTaxrCode().trim())){
            throw new RuntimeException("系统编码为空");
        }
        if(StringUtil.isNullOrEmpty(StringUtil.isNullOrEmpty(entity.getTaxrDetail()))){
            throw new RuntimeException("税率为空");
        }
        if(StringUtil.isNullOrEmpty(entity.getTaxrName().trim())){
            throw new RuntimeException("税率名称为空");
        }
        if(isExistTaxrateCode(entity)){
            throw new RuntimeException("系统编码重复!");
        }
        if(isExistTaxrateName(entity)){
            throw new RuntimeException("税率名称重复!");
        }
        TaxrateEntity taxrateEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),TaxrateEntity.class);
        return ormService.insertSelective(taxrateEntity).toString();
    }

    @Override
    public int delete(String currentUserId, String id) throws Exception {
        TaxrateEntity entity = new TaxrateEntity();
        entity.setId(id);
        entity.setCreuser(currentUserId);
        //修改带删除数据的维护人信息
        ormService.updateSelective(entity);
        return ormService.delete(TaxrateEntity.class,id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(TaxrateVO entity) throws Exception {
        if(StringUtil.isNullOrEmpty(entity.getTaxrCode().trim())){
            throw new RuntimeException("系统编码为空");
        }
        if(StringUtil.isNullOrEmpty(StringUtil.isNullOrEmpty(entity.getTaxrDetail()))){
            throw new RuntimeException("税率为空");
        }
        if(StringUtil.isNullOrEmpty(entity.getTaxrName().trim())){
            throw new RuntimeException("税率名称为空");
        }
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(TaxrateConstant.TAXR_NAME,entity.getTaxrName().trim()));
        List<TaxrateEntity> entityList = ormService.selectBeanList(TaxrateEntity.class,ormParam);
        if(entityList != null && entityList.size() > 0){
            if(entityList.size() > 1 || !entityList.get(0).getId().equals(entity.getId())){
                throw new RuntimeException("税率名称重复!");
            }
        }
        // 税率代码重复检验
        ormParam.reset();
        ormParam.setWhereExp(ormParam.getEqualXML(TaxrateConstant.TAXR_CODE,entity.getTaxrCode().trim()));
        entityList = ormService.selectBeanList(TaxrateEntity.class,ormParam);
        if(entityList != null && entityList.size() > 0 ){
            if(entityList.size()> 1 || !entityList.get(0).getId().equals(entity.getId())){
                throw new RuntimeException("系统编码重复!");
            }
        }
        TaxrateEntity taxrateEntity = JSONObject.parseObject(JSONObject.toJSONString(entity),TaxrateEntity.class);
        return ormService.updateSelective(taxrateEntity);
    }

    @Override
    public TaxrateVO queryById(String id) throws Exception {
        TaxrateEntity entity = ormService.load(TaxrateEntity.class, id);
        if(entity == null){
            return null;
        }
        TaxrateVO vo = JSONObject.parseObject(JSONObject.toJSONString(entity),TaxrateVO.class);
        vo.setModUserName(Utils.getUserNameByUserId(vo.getModuser(),ormService));
        vo.setCreUserName(Utils.getUserNameByUserId(vo.getCreuser(),ormService));
        return vo;
    }

    @Override
    public List<TaxrateVO> list(String taxrName,String taxrCode,String taxrEnable,Integer taxrIsdeduct) throws Exception {
        OrmParam ormParam = setQueryCondition(taxrName,taxrCode,taxrEnable,taxrIsdeduct);

        List<TaxrateEntity> entityList = ormService.selectBeanList(TaxrateEntity.class,ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        List<TaxrateVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),TaxrateVO.class);
        for (TaxrateVO taxrateVO : voList) {
            taxrateVO.setCreUserName(Utils.getUserNameByUserId(taxrateVO.getCreuser(),ormService));
            taxrateVO.setModUserName(Utils.getUserNameByUserId(taxrateVO.getModuser(),ormService));
        }
        return voList;
    }

    @Override
    public List<TaxrateVO> queryObjects(String code, Integer isdeduct, String name,String enable) throws Exception {
        List<String> columns = new ArrayList<>(Arrays.asList(TaxrateConstant.TAXR_NAME,TaxrateConstant.TAXR_ISDEDUCT,TaxrateConstant.TAXR_DETAIL,TaxrateConstant.TAXR_CODE,TaxrateConstant.TAXR_ENABLE,TaxrateConstant.TAXR_IS_STANDARD));
        Utils.setBaseQueryColums(columns);
        OrmParam ormParam = setQueryCondition(name,code,enable,isdeduct);
        List<TaxrateEntity> entityList = ormService.selectBeanList(TaxrateEntity.class,ormParam);
        if(entityList == null || entityList.size() == 0){
            return null;
        }
        List<TaxrateVO> voList = JSONObject.parseArray(JSONObject.toJSONString(entityList),TaxrateVO.class);
        for (TaxrateVO taxrateVO : voList) {
            taxrateVO.setCreUserName(Utils.getUserNameByUserId(taxrateVO.getCreuser(),ormService));
            taxrateVO.setModUserName(Utils.getUserNameByUserId(taxrateVO.getModuser(),ormService));
        }
        return voList;
    }


    private OrmParam setQueryCondition(String taxrName,String taxrCode,String taxrEnable,Integer taxrIsdeduct){
        List<String> columns = new ArrayList<>(Arrays.asList(TaxrateConstant.TAXR_NAME,TaxrateConstant.TAXR_ISDEDUCT,TaxrateConstant.TAXR_DETAIL,TaxrateConstant.TAXR_IS_STANDARD,TaxrateConstant.TAXR_ENABLE,TaxrateConstant.TAXR_CODE));
        Utils.setBaseQueryColums(columns);
        columns.remove("pid");
        OrmParam ormParam = new OrmParam();
        ormParam.setColumns(columns);
        String whereExp = "";
        if(StringUtils.isNotEmpty(taxrName) && StringUtils.isNotEmpty(taxrName.trim())){
            whereExp = OrmParam.and(ormParam.getMatchMiddleXML(TaxrateConstant.TAXR_NAME,taxrName.trim()));
        }
        if(StringUtils.isNotEmpty(taxrCode) && StringUtils.isNotEmpty(taxrCode.trim())){
            whereExp = OrmParam.and(ormParam.getMatchMiddleXML(TaxrateConstant.TAXR_CODE,taxrCode.trim()));
        }
        if(StringUtils.isNotEmpty(taxrEnable)){
            whereExp = OrmParam.and(ormParam.getEqualXML(TaxrateConstant.TAXR_ENABLE,taxrEnable));
        }
        if(null != taxrIsdeduct){
            whereExp = OrmParam.and(ormParam.getEqualXML(TaxrateConstant.TAXR_ISDEDUCT,taxrIsdeduct),whereExp);
        }
        ormParam.setWhereExp(whereExp);
        ormParam.setOrderExp(SQLSortEnum.DESC, BasicConst.CRETIME);
        return ormParam;
    }

    /**
     * 汇率名称重复检验
     * @param vo
     * @return
     * @throws Exception
     */
    private boolean isExistTaxrateName(TaxrateVO vo)throws Exception{
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(TaxrateConstant.TAXR_NAME,vo.getTaxrName().trim()));
        long count = ormService.count(TaxrateEntity.class,ormParam);
        return count > 0;
    }
    /**
     * 汇率编码重复检验
     * @param vo
     * @return
     * @throws Exception
     */
    private boolean isExistTaxrateCode(TaxrateVO vo)throws Exception{
        OrmParam ormParam = new OrmParam();
        ormParam.setWhereExp(ormParam.getEqualXML(TaxrateConstant.TAXR_CODE,vo.getTaxrCode().trim()));
        long count = ormService.count(TaxrateEntity.class,ormParam);
        return count > 0;
    }
}
