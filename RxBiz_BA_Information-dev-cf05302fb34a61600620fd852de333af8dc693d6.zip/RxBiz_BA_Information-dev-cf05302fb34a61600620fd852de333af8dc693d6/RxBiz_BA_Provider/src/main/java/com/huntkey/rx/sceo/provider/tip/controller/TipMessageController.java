package com.huntkey.rx.sceo.provider.tip.controller;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.sceo.common.model.tip.TipMessage;
import com.huntkey.rx.sceo.provider.tip.service.TipMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 *
 * @author yexin
 * @date 2017/10/25
 */
@RestController
@RequestMapping(value = "/tipMessage")
public class TipMessageController {

    private static Logger log = LoggerFactory.getLogger(TipMessageController.class);

    @Autowired
    private TipMessageService tipMessageService;

    /**
     * 获取显示信息
     * @param params
     * @return
     */
    @RequestMapping(value = "/getMessage", method = RequestMethod.POST)
    public Result getMessage(@RequestBody String params) throws Exception {
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(tipMessageService.getMessage(params));
        return result;
    }

    /**
     * 分页查询信息提示数据，支持模糊查询
     * @param pageCode
     * @param msgCode
     * @param msgType
     * @param pageNum
     * @param pageSize
     * @return
     */
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public Result list(@RequestParam(required = false,value = "pageCode") String pageCode,
                       @RequestParam(required = false,value = "msgCode") String msgCode,
                       @RequestParam(required = false,value = "msgType") String msgType,
                       @RequestParam(required = false,value = "pageNum",defaultValue = "1") int pageNum,
                       @RequestParam(required = false,value = "pageSize",defaultValue = "15") int pageSize) throws Exception {
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(tipMessageService.list(pageCode,msgCode,msgType,pageNum,pageSize));
        return result;
    }

    /**
     * 获取提示信息
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public Result queryTip(@PathVariable(value = "id") String id) throws Exception {
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(tipMessageService.queryTip(id));
        return result;
    }

    /**
     * 更新提示信息
     * @param tipMessage
     * @return
     */
    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public Result updateMessage(@RequestBody TipMessage tipMessage) throws Exception {
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(tipMessageService.updateMessage(tipMessage));
        return result;
    }

    /**
     * 删除提示信息
     * @param id
     * @return
     */
    @RequestMapping(value = "/{id}/delete", method = RequestMethod.DELETE)
    public Result delete(@PathVariable(value = "id") String id) throws Exception {
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(tipMessageService.deleteMessage(id));
        return result;
    }

    /**
     * 根据pageCode查询同一个页面下所有的提示信息
     * @param pageCode
     * @return
     */
    @RequestMapping(value = "/{pageCode}/loadMsgs", method = RequestMethod.GET)
    public Result loadMsgs(@PathVariable(value = "pageCode") String pageCode) throws Exception {
        Result result = new Result();
        result.setRetCode(Result.RECODE_SUCCESS);
        result.setData(tipMessageService.loadMsgs(pageCode));
        return result;

    }


}
