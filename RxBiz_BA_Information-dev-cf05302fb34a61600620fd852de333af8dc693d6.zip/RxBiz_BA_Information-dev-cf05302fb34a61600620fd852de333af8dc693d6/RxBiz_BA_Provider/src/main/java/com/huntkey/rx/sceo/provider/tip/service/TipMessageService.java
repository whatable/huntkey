package com.huntkey.rx.sceo.provider.tip.service;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.sceo.common.model.tip.TipData;
import com.huntkey.rx.sceo.common.model.tip.TipMessage;

import java.util.List;

/**
 *
 * @author yexin
 * @date 2017/10/25
 */
public interface TipMessageService {

    /**
     * 获取显示信息
     * @param params
     * @return
     */
    TipData getMessage(String params) throws Exception;

    /**
     * 更新提示信息
     * @param tipMessage
     * @return
     */
    int updateMessage(TipMessage tipMessage) throws Exception;

    /**
     * 删除提示信息
     * @param id
     * @return
     */
    int deleteMessage(String id) throws Exception;

    /**
     * 获取提示信息
     * @param id
     * @return
     */
    TipMessage queryTip(String id) throws Exception;

    /**
     * 根据pageCode查询同一个页面下所有的提示信息
     * @param pageCode
     * @return
     */
    List<TipMessage> loadMsgs(String pageCode) throws Exception;

    /**
     * 分页查询信息提示数据，支持模糊查询
     * @param pageCode
     * @param msgCode
     * @param msgType
     * @param pageNum
     * @param pageSize
     * @return
     */
    Pagination<TipMessage> list(String pageCode, String msgCode, String msgType, int pageNum, int pageSize) throws Exception;
}
