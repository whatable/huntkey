package com.huntkey.rx.sceo.provider.tip.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.datetime.DateUtil;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.TipmessageEntity;
import com.huntkey.rx.sceo.common.model.tip.TipData;
import com.huntkey.rx.sceo.common.model.tip.TipMessage;
import com.huntkey.rx.sceo.common.model.tip.TipMessageConst;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.tip.service.TipMessageService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author yexin
 * @date 2017/10/25
 */
@Service
public class TipMessageServiceImpl implements TipMessageService {
    @Autowired
    private OrmService ormService;

    private final static Logger log = LoggerFactory.getLogger(TipMessageServiceImpl.class);

    @Override
    public TipData getMessage(String params) throws Exception {
        TipData data = new TipData();
        //解析json字符串，取得对应参数
        JSONObject json = JSONObject.parseObject(params);
        System.out.println("json:  " + json);
        String pageCode = json.getString("pageCode");
        String msgCode = json.getString("msgCode");
        String msgType = json.getString("msgType");
        String baseMsg = json.getString("baseMsg");
        int showTime = json.getInteger("showTime") == null ? -1 : json.getInteger("showTime");
        String parm1 = json.getString("parm1") == null ? "{1}" : json.getString("parm1");
        String parm2 = json.getString("parm2") == null ? "{2}" : json.getString("parm2");
        String parm3 = json.getString("parm3") == null ? "{2}" : json.getString("parm3");

        OrmParam ormParam = new OrmParam();
        String exp = OrmParam.and(ormParam.getEqualXML(TipMessageConst.TIPM_PAGE_CODE, pageCode)
                ,ormParam.getEqualXML(TipMessageConst.TIPM_MSG_CODE, msgCode));
        ormParam.setWhereExp(exp);
        List<TipmessageEntity> tipmessageEntities = ormService.selectBeanList(TipmessageEntity.class, ormParam);

        //查询是否存在，存在直接返回数据,不存在插入数据
        String msg;
        if (tipmessageEntities != null && tipmessageEntities.size() > 0) {
            TipMessage tipMessage = tipmessageEntityToTipMessage(tipmessageEntities.get(0));
            data.setMsgType(tipMessage.getTipMsgType());
            data.setShowTime(tipMessage.getTipShowTime());
            String showMsg = tipMessage.getTipShowMsg();

            log.info("showMsg:" + showMsg);

            if(showMsg != null){
                showMsg = showMsg.contains("{1}") ? showMsg.replace("{1}",parm1) : showMsg;
                showMsg = showMsg.contains("{2}") ? showMsg.replace("{2}",parm2) : showMsg;
                msg = showMsg.contains("{3}") ? showMsg.replace("{3}",parm3) : showMsg;
                data.setMsgDesc(msg);
            } else {
                data.setMsgDesc(baseMsg);
            }
        } else {
            //第一查询时，插入信息系统中
            TipMessage tipMessage = new TipMessage();
            tipMessage.setTipPageCode(pageCode);
            tipMessage.setTipMsgCode(msgCode);
            tipMessage.setTipShowMsg(baseMsg);
            tipMessage.setTipBaseMsg(baseMsg);
            //提示类别初始化为提示
            tipMessage.setTipMsgType((msgType!=null) && (!"".equals(msgType)) ? msgType : "1");
            //显示时间初始化
            tipMessage.setTipShowTime(showTime);

            baseMsg = baseMsg.contains("{1}") ? baseMsg.replace("{1}",parm1) : baseMsg;
            baseMsg = baseMsg.contains("{2}") ? baseMsg.replace("{2}",parm2) : baseMsg;
            msg = baseMsg.contains("{3}") ? baseMsg.replace("{3}",parm3) : baseMsg;

            insertSelective(tipMessage);

            data.setMsgDesc(msg);
            data.setMsgType(tipMessage.getTipMsgType());
            data.setShowTime(tipMessage.getTipShowTime());
        }

        return data;
    }

    /**
     * 更新提示信息
     * @param tipMessage
     * @return
     */
    @Override
    public int updateMessage(TipMessage tipMessage) throws Exception {
        TipmessageEntity tipmessageEntity = tipMessageToTipmessageEntity(tipMessage);
        tipmessageEntity.setModtime(new Date());

        return ormService.updateSelective(tipmessageEntity);
    }

    /**
     * 删除提示信息
     * @param id
     * @return
     */
    @Override
    public int deleteMessage(String id) throws Exception {
        return ormService.delete(TipmessageEntity.class, id);
    }

    /**
     * 通过id查询信息提示
     * @param id
     * @return
     */
    @Override
    public TipMessage queryTip(String id) throws Exception {
        TipmessageEntity tipmessageEntity = ormService.load(TipmessageEntity.class, id);
        return tipmessageEntityToTipMessage(tipmessageEntity);
    }


    /**
     * 根据页面编码加载所有对应的页面提示信息
     * @param pageCode
     * @return
     */
    @Override
    public List<TipMessage> loadMsgs(String pageCode) throws Exception {
        OrmParam ormParam = new OrmParam();

        String exp = ormParam.getEqualXML(TipMessageConst.TIPM_PAGE_CODE, pageCode);
        ormParam.setWhereExp(exp);
        List<TipmessageEntity> tipmessageEntities = ormService.selectBeanList(TipmessageEntity.class, ormParam);

        List<TipMessage> list = null;
        if (tipmessageEntities == null || tipmessageEntities.size() <= 0) {
            list = null;
        } else {
            list = new ArrayList<>();
            for (TipmessageEntity o : tipmessageEntities) {
                list.add(tipmessageEntityToTipMessage(o));
            }
        }

        return list;
    }

    /**
     * 分页查询信息提示数据，支持模糊查询
     * @param pageCode
     * @param msgCode
     * @param msgType
     * @param pageNum
     * @param pageSize
     * @return
     */
    @Override
    public Pagination<TipMessage> list(String pageCode, String msgCode, String msgType, int pageNum, int pageSize) throws Exception {
        OrmParam ormParam = new OrmParam();
        StringBuilder exp = new StringBuilder();
        if(!StringUtil.isNullOrEmpty(pageCode)){
            if(pageCode.contains("_")){
                pageCode = pageCode.replaceAll("_","\\\\_");
            }
            exp.append(ormParam.getMatchMiddleXML(TipMessageConst.TIPM_PAGE_CODE, pageCode));
        }
        if(!StringUtil.isNullOrEmpty(msgCode)){
            if(msgCode.contains("_")){
                msgCode = msgCode.replaceAll("_","\\\\_");
            }
            exp.append(" AND ").append(ormParam.getMatchMiddleXML(TipMessageConst.TIPM_MSG_CODE, msgCode));
        }
        if(!StringUtil.isNullOrEmpty(msgType)){
            exp.append(" AND ").append(ormParam.getEqualXML(TipMessageConst.TIPM_MSG_TYPE, msgType));
        }

        log.info(exp.toString());
        ormParam.setWhereExp(exp.toString());
        ormParam.setOrderExp(SQLSortEnum.ASC, TipMessageConst.TIPM_PAGE_CODE, TipMessageConst.TIPM_MSG_CODE
                ,TipMessageConst.TIPM_MSG_TYPE);
        ormParam.setPageNo(pageNum);
        ormParam.setPageSize(pageSize);

        Pagination<TipmessageEntity> pagedBeanList = ormService.selectPagedBeanList(TipmessageEntity.class, ormParam);

        Pagination<TipMessage> pagination = null;
        if (pagedBeanList.getList() == null || pagedBeanList.getList().size() <= 0) {
            pagination = new Pagination<>(null, pageNum, pageSize, 0);
        } else {
            List<TipMessage> list = new ArrayList<>();
            for (TipmessageEntity o : pagedBeanList.getList()) {
                list.add(tipmessageEntityToTipMessage(o));
            }
            pagination = new Pagination<>(list, pageNum, pageSize, pagedBeanList.getTotal());
        }

        return pagination;
    }

    private TipMessage tipmessageEntityToTipMessage(TipmessageEntity o) {
        TipMessage tipMessage = new TipMessage();
        tipMessage.setId(o.getId());
        tipMessage.setTipBaseMsg(o.getTipm_base_msg());
        tipMessage.setTipModifyTime(DateUtil.formatDate(o.getModtime()));
        tipMessage.setTipModifyUser(o.getModuser());
        tipMessage.setTipMsgCode(o.getTipm_msg_code());
        tipMessage.setTipMsgType(o.getTipm_msg_type());
        tipMessage.setTipPageCode(o.getTipm_page_code());
        tipMessage.setTipShowMsg(o.getTipm_show_msg());
        tipMessage.setTipShowTime(o.getTipm_show_time());
        return tipMessage;
    }

    private TipmessageEntity tipMessageToTipmessageEntity(TipMessage o) {
        TipmessageEntity tipmessageEntity = new TipmessageEntity();
        tipmessageEntity.setId(o.getId());
        tipmessageEntity.setTipm_base_msg(o.getTipBaseMsg());
        tipmessageEntity.setTipm_msg_code(o.getTipMsgCode());
        tipmessageEntity.setTipm_page_code(o.getTipPageCode());
        tipmessageEntity.setTipm_msg_type(o.getTipMsgType());
        tipmessageEntity.setTipm_show_msg(o.getTipShowMsg());
        tipmessageEntity.setTipm_show_time(o.getTipShowTime());

        return tipmessageEntity;
    }


    private void insertSelective(TipMessage tipMessage) throws Exception {
        TipmessageEntity tipmessageEntity = tipMessageToTipmessageEntity(tipMessage);

        Date date = new Date();
        tipmessageEntity.setCretime(date);
        tipmessageEntity.setModtime(date);

        ormService.insert(tipmessageEntity);
    }
}
