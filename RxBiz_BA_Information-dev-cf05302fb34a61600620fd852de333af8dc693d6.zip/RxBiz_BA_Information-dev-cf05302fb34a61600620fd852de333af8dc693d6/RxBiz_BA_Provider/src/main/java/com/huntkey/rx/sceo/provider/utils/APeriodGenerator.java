package com.huntkey.rx.sceo.provider.utils;

import java.util.Calendar;
import java.util.Date;

public abstract class APeriodGenerator {
	private final int FISCAL_START_MONTH;
	private final Calendar start;
	private final int quitYear;

	/**
	 * 批量生成若干年的周、月、季、年等周期数据
	 * 
	 * @param s
	 *            财年的起始（一年中的某一天，目前只可四选一），输入null则取Q1
	 * @param yearStart
	 *            生成数据的起始年（年份数，4位数，默认2000）
	 * @param yearEnd
	 *            生成数据的结束年（年份数，在起始年基础上的年数，默认100）
	 */
	protected APeriodGenerator(Inception s, Integer yearStart, Integer yearEnd) {
		if (s == null) {
			s = Inception.Q1;
		}
		FISCAL_START_MONTH = s.value * 3;
		start = Calendar.getInstance();
		start.set(Calendar.YEAR, yearStart == null ? 2000 : yearStart);
		start.set(Calendar.MONTH, FISCAL_START_MONTH);
		start.set(Calendar.DAY_OF_MONTH, 0);
		start.set(Calendar.HOUR_OF_DAY, 0);
		start.set(Calendar.MINUTE, 0);
		start.set(Calendar.SECOND, 0);
		start.set(Calendar.MILLISECOND, 0);
		quitYear = start.get(Calendar.YEAR) + (yearEnd == null ? 100 : yearEnd);
	}

	/**
	 * 开始生成
	 */
	public final void go() {
		Calendar __c = (Calendar) start.clone();
		Calendar __p = (Calendar) start.clone();// __c的上一毫秒，也就是前一天的最后一毫秒
		__p.add(Calendar.MILLISECOND, -1);

		Calendar weekHead = null, yearHead = null, monthHead = null, quarterHead = null;
		int __w = 1, __y = __c.get(Calendar.YEAR), __m = 1, __q = 1;
		int __wseq = 1, __wseq2 = 1;
		int __qseq = 1;
		int __mseq = 1;
		int __yseq = 1;
		while (true) {
			boolean isFirstDayOfCalendarWeek = 1 == __c.get(Calendar.DAY_OF_WEEK);
			boolean isFirstDayOfCalendarMonth = 1 == __c.get(Calendar.DAY_OF_MONTH);
			boolean isFirstDayOfFiscalYear = isFirstDayOfCalendarMonth && FISCAL_START_MONTH == __c.get(Calendar.MONTH);
			// 周
			if (isFirstDayOfCalendarWeek || isFirstDayOfFiscalYear) {
				if (weekHead != null) {
					Calendar weekTail = (Calendar) __p.clone();
					week(weekHead.getTime(), weekTail.getTime(), __y, __w++, weekTail.get(Calendar.YEAR),
							weekHead.get(Calendar.WEEK_OF_YEAR), __wseq++);
					if (isFirstDayOfCalendarWeek) {
						Calendar h = (Calendar) __c.clone();
						h.add(Calendar.DAY_OF_WEEK, -7);
						week(h.getTime(), weekTail.getTime(), __y, weekTail.get(Calendar.YEAR),
								weekHead.get(Calendar.WEEK_OF_YEAR), __wseq2++);
					}
				}
				weekHead = (Calendar) __c.clone();
			}
			// 月
			if (isFirstDayOfCalendarMonth) {
				if (monthHead != null) {
					month(monthHead.getTime(), __p.getTime(), __y, __m++, monthHead.get(Calendar.YEAR),
							monthHead.get(Calendar.MONTH) + 1, __mseq++);
				}
				monthHead = (Calendar) __c.clone();

				// 季
				if (0 == __c.get(Calendar.MONTH) % 3) {
					if (quarterHead != null) {
						quarter(quarterHead.getTime(), __p.getTime(), __y, __q++, quarterHead.get(Calendar.YEAR),
								quarterHead.get(Calendar.MONTH) / 3 + 1, __qseq++);
					}
					quarterHead = (Calendar) __c.clone();
				}
			}
			// 年
			if (isFirstDayOfFiscalYear) {
				__w = 1;
				__m = 1;
				__q = 1;
				if (yearHead != null) {
					year(yearHead.getTime(), __p.getTime(), __y++, __yseq++);
				}
				yearHead = (Calendar) __c.clone();
			}
			__c.add(Calendar.DAY_OF_YEAR, 1);
			__p.add(Calendar.DAY_OF_YEAR, 1);
			if (__c.get(Calendar.YEAR) >= quitYear)
				break;
		}
	}

	/**
	 * 财年结束时调用的函数，会提供财年年份、总期次以及详细的日历日期的起止等信息，供进一步处理使用
	 * 
	 * @param head
	 *            财年起始日期
	 * @param tail
	 *            财年结束日期
	 * @param fy
	 *            财年年份
	 * @param seq
	 *            期次，从生成数据那一年开始逐年累加的序列值
	 */
	protected abstract void year(Date head, Date tail, int fy, int seq);

	/**
	 * 财季结束时调用的函数，会提供财年和对应的日历年年份、财季和对应的日历季序数、总期次以及详细的日历日期的起止等信息，供进一步处理使用
	 * 
	 * @param head
	 * @param tail
	 * @param fy
	 * @param fq
	 * @param y
	 * @param q
	 * @param seq
	 */
	protected abstract void quarter(Date head, Date tail, int fy, int fq, int y, int q, int seq);

	/**
	 * 财月结束时调用的函数，会提供财年和对应的日历年年份、财月和对应的日历月序数、总期次以及详细的日历日期的起止等信息，供进一步处理使用
	 * 
	 * @param head
	 * @param tail
	 * @param fy
	 * @param fm
	 * @param y
	 * @param m
	 * @param seq
	 */
	protected abstract void month(Date head, Date tail, int fy, int fm, int y, int m, int seq);

	/**
	 * 财周结束时调用的函数，会提供财年和对应的日历年年份、财周和对应的日历周序数、总期次以及详细的日历日期的起止等信息，供进一步处理使用
	 * 
	 * @param head
	 * @param tail
	 * @param fy
	 * @param fw
	 * @param y
	 * @param w
	 * @param seq
	 */
	protected abstract void week(Date head, Date tail, int fy, int fw, int y, int w, int seq);

	protected abstract void week(Date head, Date tail, int fy, int y, int w, int seq);

	/**
	 * 财年起点，按照国际惯例，考虑系统的逻辑可控，可选择的财年起点不是任意一天，而是只有每季度的第一天
	 * 
	 * @author jiangshaoh
	 */
	public static enum Inception {
		/**
		 * 第一季度为起点，即1月1日
		 */
		Q1(0),
		/**
		 * 第二季度为起点，即4月1日
		 */
		Q2(1),
		/**
		 * 第三季度为起点，即7月1日
		 */
		Q3(2),
		/**
		 * 第四季度为起点，即10月1日
		 */
		Q4(3);
		private int value;

		private Inception(int value) {
			this.value = value;
		}
	}// [END] enum Start
}
