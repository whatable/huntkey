package com.huntkey.rx.sceo.provider.utils;

import java.util.Calendar;
import java.util.Date;

/**
 * 两个日期对象的相等性比较，先实例化一个本类对象，然后调用对象上的各个方法来判断
 * 
 * @author jiangshaoh
 *
 */
public class DateEquality {

	private boolean year = false;
	private boolean month = false;
	private boolean day = false;
	private boolean hour = false;
	private boolean minute = false;
	private boolean second = false;
	private boolean millisecond = false;
	private boolean week = false;
	private boolean date = false;
	private boolean season = false;

	/**
	 * 输入一个日期对象，和当前日期时间对象作比较
	 * 
	 * @param d
	 *            输入的日期对象
	 */
	public DateEquality(Date d) {
		this(d, new Date());
	}

	/**
	 * 输入两个日期对象，互相比较
	 * 
	 * @param d1
	 * @param d2
	 */
	public DateEquality(Date d1, Date d2) {
		if (d1 != null && d2 != null) {
			Calendar c1 = Calendar.getInstance();
			Calendar c2 = Calendar.getInstance();
			c1.setTime(d1);
			c2.setTime(d2);

			year = c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR);
			month = c1.get(Calendar.MONTH) == c2.get(Calendar.MONTH);
			day = c1.get(Calendar.DAY_OF_MONTH) == c2.get(Calendar.DAY_OF_MONTH);
			hour = c1.get(Calendar.HOUR) == c2.get(Calendar.HOUR);
			minute = c1.get(Calendar.MINUTE) == c2.get(Calendar.MINUTE);
			second = c1.get(Calendar.SECOND) == c2.get(Calendar.SECOND);
			millisecond = c1.get(Calendar.MILLISECOND) == c2.get(Calendar.MILLISECOND);
			season = (c1.get(Calendar.MONTH) / 3) == (c2.get(Calendar.MONTH) / 3);
			week = c1.get(Calendar.WEEK_OF_YEAR) == c2.get(Calendar.WEEK_OF_YEAR);
			date = c1.get(Calendar.DAY_OF_WEEK) == c2.get(Calendar.DAY_OF_WEEK);
		}
	}

	/**
	 * 年是否相等
	 * 
	 * @return
	 */
	public boolean year() {
		return year;
	}

	/**
	 * 月是否相等
	 * 
	 * @return
	 */
	public boolean month() {
		return month;
	}

	/**
	 * 日是否相等，注意与星期几的方法date()区分
	 * 
	 * @return
	 */
	public boolean day() {
		return day;
	}

	/**
	 * 年月是否相等
	 * 
	 * @return
	 */
	public boolean yearMonth() {
		return year && month;
	}

	/**
	 * 年月日是否相等
	 * 
	 * @return
	 */
	public boolean yearMonthDay() {
		return year && month && day;
	}

	/**
	 * 小时（24时制）是否相等
	 * 
	 * @return
	 */
	public boolean hour() {
		return hour;
	}

	/**
	 * 分钟是否相等
	 * 
	 * @return
	 */
	public boolean minute() {
		return minute;
	}

	/**
	 * 秒是否相等
	 * 
	 * @return
	 */
	public boolean second() {
		return second;
	}

	/**
	 * 毫秒是否相等
	 * 
	 * @return
	 */
	public boolean millisecond() {
		return millisecond;
	}

	/**
	 * 周（一年中的第几周）是否相等
	 * 
	 * @return
	 */
	public boolean week() {
		return week;
	}

	/**
	 * 年和周（一年中的第几周）是否相等
	 * 
	 * @return
	 */
	public boolean yearWeek() {
		return year && week;
	}

	/**
	 * 星期几是否相等，年月日的日请参阅day()方法
	 * 
	 * @return
	 */
	public boolean date() {
		return date;
	}

	/**
	 * 季节是否相等
	 * 
	 * @return
	 */
	public boolean season() {
		return season;
	}

	/**
	 * 年和季是否相等
	 * 
	 * @return
	 */
	public boolean yearSeason() {
		return year && season;
	}

}
