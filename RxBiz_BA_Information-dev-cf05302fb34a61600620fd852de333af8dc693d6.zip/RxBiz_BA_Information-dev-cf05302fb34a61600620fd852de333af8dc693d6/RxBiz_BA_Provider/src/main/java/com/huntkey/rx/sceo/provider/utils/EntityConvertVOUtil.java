package com.huntkey.rx.sceo.provider.utils;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;

/**
 * 实体类转过度类
 * @author zoulj
 * @create 2017/12/18 16:04
 **/
public abstract class EntityConvertVOUtil {

    /**
     * 相同属性字段赋值(entity属性值赋值到vo) vo转entity交换参数就行
     * @param entity
     * @param vo
     * @throws Exception
     */
    public static void assignmentOfTheSameField(Object entity, Object vo) throws Exception{
        // 获取属性
        BeanInfo sourceBean = Introspector.getBeanInfo(entity.getClass(),Object.class);
        PropertyDescriptor[] sourceProperty = sourceBean.getPropertyDescriptors();

        BeanInfo destBean = Introspector.getBeanInfo(vo.getClass(),Object.class);
        PropertyDescriptor[] destProperty = destBean.getPropertyDescriptors();

        try {
            for (int i = 0; i < sourceProperty.length; i++) {

                for (int j = 0; j < destProperty.length; j++) {

                    if (sourceProperty[i].getName().equals(destProperty[j].getName())  && sourceProperty[i].getPropertyType() == destProperty[j].getPropertyType()) {
                        // 调用source的getter方法和dest的setter方法
                        destProperty[j].getWriteMethod().invoke(vo,sourceProperty[i].getReadMethod().invoke(entity));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            throw new Exception("属性复制失败:" + e.getMessage());
        }
    }

    /**
     * 相同属性字段赋值(entity属性值赋值到vo,entity的creuser值从id转成用户名) vo转entity交换参数就行
     * @param entity
     * @param vo
     * @param authorization 获取方式：request.getHeaders().get("Authorization").get(0)
     * @throws Exception
     */
    public static void assignmentOfTheSameField(Object entity, Object vo,String authorization) throws Exception{
        // 获取属性
        BeanInfo sourceBean = Introspector.getBeanInfo(entity.getClass(),Object.class);
        PropertyDescriptor[] sourceProperty = sourceBean.getPropertyDescriptors();

        BeanInfo destBean = Introspector.getBeanInfo(vo.getClass(),Object.class);
        PropertyDescriptor[] destProperty = destBean.getPropertyDescriptors();

        try {
            for (int i = 0; i < sourceProperty.length; i++) {

                for (int j = 0; j < destProperty.length; j++) {

                    if (sourceProperty[i].getName().equals(destProperty[j].getName())  && sourceProperty[i].getPropertyType() == destProperty[j].getPropertyType()) {
                        // 调用source的getter方法和dest的setter方法
                        if(sourceProperty[i].getName().equals("creuser") || sourceProperty[i].getName().equals("moduser")){
                            String username = Utils.getUserNameByUserId(authorization,(String)sourceProperty[i].getReadMethod().invoke(entity));
                            destProperty[j].getWriteMethod().invoke(vo,username);
                        }
                        destProperty[j].getWriteMethod().invoke(vo,sourceProperty[i].getReadMethod().invoke(entity));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            throw new Exception("属性复制失败:" + e.getMessage());
        }
    }
}
