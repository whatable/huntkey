package com.huntkey.rx.sceo.provider.utils;

import java.util.Calendar;
import java.util.Date;

import com.huntkey.rx.sceo.profile.common.service.PeriodService.PeriodType;

public class PeriodGenerator extends APeriodGenerator {
	private String fiscalYearPattern = "%YFYR";
	private String yearPattern = "%Y";
	private String fiscalQuarterPattern = "%YFQ%q";
	private String quarterPattern = "%YQ%q";
	private String fiscalMonthPattern = "%YF%M";
	private String monthPattern = "%YM%M";
	private String fiscalWeekPattern = "%YFW%W";
	private String weekPattern = "%YW%W";

	public PeriodGenerator(Inception s, Integer yearStart, Integer yearEnd) {
		super(s, yearStart, yearEnd);
	}

	public final void setFiscalYearPattern(String fiscalYearPattern) {
		this.fiscalYearPattern = fiscalYearPattern;
	}

	public final void setYearPattern(String yearPattern) {
		this.yearPattern = yearPattern;
	}

	public final void setFiscalQuaterPattern(String fiscalQuaterPattern) {
		this.fiscalQuarterPattern = fiscalQuaterPattern;
	}

	public final void setQuarterPattern(String quarterPattern) {
		this.quarterPattern = quarterPattern;
	}

	public final void setFiscalMonthPattern(String fiscalMonthPattern) {
		this.fiscalMonthPattern = fiscalMonthPattern;
	}

	public final void setMonthPattern(String monthPattern) {
		this.monthPattern = monthPattern;
	}

	public final void setFiscalWeekPattern(String fiscalWeekPattern) {
		this.fiscalWeekPattern = fiscalWeekPattern;
	}

	public final void setWeekPattern(String weekPattern) {
		this.weekPattern = weekPattern;
	}

	@Override
	protected final void year(Date head, Date tail, int fy, int seq) {
		String name = fiscalYearPattern.replaceAll("%Y", Integer.toString(fy)).replaceAll("%y",
				Integer.toString(fy % 100));
		String calendarName = yearPattern.replaceAll("%Y", Integer.toString(fy)).replaceAll("%y",
				Integer.toString(fy % 100));
		item(head, tail, PeriodType.FISCAL_YEAR, fy, name, calendarName, seq);

		Calendar chead = (Calendar) ZERO.clone();
		chead.set(Calendar.YEAR, fy);
		Calendar ctail = (Calendar) chead.clone();
		ctail.add(Calendar.YEAR, 1);
		ctail.add(Calendar.MILLISECOND, -1);
		item(chead.getTime(), ctail.getTime(), PeriodType.YEAR, fy, calendarName, calendarName, seq);
	}

	@Override
	protected final void quarter(Date head, Date tail, int fy, int fq, int y, int q, int seq) {
		String name = fiscalQuarterPattern.replaceAll("%Y", Integer.toString(fy))
				.replaceAll("%y", Integer.toString(fy % 100)).replaceAll("%Q", String.format("%02d", fq))
				.replaceAll("%q", Integer.toString(fq));
		String calendarName = quarterPattern.replaceAll("%Y", Integer.toString(y))
				.replaceAll("%y", Integer.toString(y % 100)).replaceAll("%Q", String.format("%02d", q))
				.replaceAll("%q", Integer.toString(q));
		item(head, tail, PeriodType.FISCAL_QUARTER, fy, name, calendarName, seq);
		item(head, tail, PeriodType.QUARTER, fy, calendarName, calendarName, seq);

	}

	@Override
	protected final void month(Date head, Date tail, int fy, int fm, int y, int m, int seq) {
		String name = fiscalMonthPattern.replaceAll("%Y", Integer.toString(fy))
				.replaceAll("%y", Integer.toString(fy % 100)).replaceAll("%M", String.format("%02d", fm))
				.replaceAll("%m", Integer.toString(fm));
		String calendarName = monthPattern.replaceAll("%Y", Integer.toString(y))
				.replaceAll("%y", Integer.toString(y % 100)).replaceAll("%M", String.format("%02d", m))
				.replaceAll("%m", Integer.toString(m));
		item(head, tail, PeriodType.FISCAL_MONTH, fy, name, calendarName, seq);
		item(head, tail, PeriodType.MONTH, fy, calendarName, calendarName, seq);
	}

	@Override
	protected final void week(Date head, Date tail, int fy, int fw, int y, int w, int seq) {
		String name = fiscalWeekPattern.replaceAll("%Y", Integer.toString(fy))
				.replaceAll("%y", Integer.toString(fy % 100)).replaceAll("%W", String.format("%02d", fw))
				.replaceAll("%w", Integer.toString(fw));
		String calendarName = weekPattern.replaceAll("%Y", Integer.toString(y))
				.replaceAll("%y", Integer.toString(y % 100)).replaceAll("%W", String.format("%02d", w))
				.replaceAll("%w", Integer.toString(w));
		item(head, tail, PeriodType.FISCAL_WEEK, fy, name, calendarName, seq);
	}

	@Override
	protected void week(Date head, Date tail, int fy, int y, int w, int seq) {
		String calendarName = weekPattern.replaceAll("%Y", Integer.toString(y))
				.replaceAll("%y", Integer.toString(y % 100)).replaceAll("%W", String.format("%02d", w))
				.replaceAll("%w", Integer.toString(w));
		item(head, tail, PeriodType.WEEK, fy, calendarName, calendarName, seq);
	}

	/**
	 * @param head
	 *            起始
	 * @param tail
	 *            结束
	 * @param type
	 *            周期类型
	 * @param fy
	 *            财年
	 * @param name
	 *            周期名
	 * @param calendarName
	 *            日历周期
	 * @param seq
	 *            期次
	 */
	protected void item(Date head, Date tail, PeriodType type, int fy, String name, String calendarName, int seq) {
	}

	private static final Calendar ZERO;
	static {
		ZERO = Calendar.getInstance();
		ZERO.set(Calendar.DAY_OF_YEAR, 1);
		ZERO.set(Calendar.HOUR_OF_DAY, 0);
		ZERO.set(Calendar.MINUTE, 0);
		ZERO.set(Calendar.SECOND, 0);
		ZERO.set(Calendar.MILLISECOND, 0);
	}

}
