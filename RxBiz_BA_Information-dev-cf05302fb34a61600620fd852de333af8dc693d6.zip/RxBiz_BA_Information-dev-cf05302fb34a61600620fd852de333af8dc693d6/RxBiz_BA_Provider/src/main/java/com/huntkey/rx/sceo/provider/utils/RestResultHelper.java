package com.huntkey.rx.sceo.provider.utils;

import com.huntkey.rx.commons.utils.rest.Result;

/**
 * 快速生成并填充{@link Result}对象的工厂类
 * 
 * @author jiangshaoh
 */
public class RestResultHelper {
	private RestResultHelper() {
	}

	public static Result success(Object data) {
		Result r = new Result();
		r.setRetCode(Result.RECODE_SUCCESS);
		r.setData(data);
		return r;
	}

	public static Result error(String message) {
		Result r = new Result();
		r.setRetCode(Result.RECODE_ERROR);
		r.setErrMsg(message);
		return r;
	}

	/**
	 * 根据条件决定生成不同的{@link Result}对象，条件为true则取data作为数据，条件false则取errorMessage作为出错消息
	 * 
	 * @param success
	 *            条件是否成立
	 * @param data
	 *            数据对象
	 * @param errorMessage
	 *            出错消息对象
	 * @return
	 */
	public static Result adopt(boolean success, Object data, String errorMessage) {
		Result r = new Result();
		if (success) {
			r.setRetCode(Result.RECODE_SUCCESS);
			r.setData(data);
		} else {
			r.setRetCode(Result.RECODE_ERROR);
			r.setErrMsg(errorMessage);
		}
		return r;
	}
}
