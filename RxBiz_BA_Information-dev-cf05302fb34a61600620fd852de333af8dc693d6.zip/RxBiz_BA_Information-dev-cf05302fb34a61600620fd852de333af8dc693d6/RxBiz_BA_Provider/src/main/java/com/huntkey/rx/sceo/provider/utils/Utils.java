package com.huntkey.rx.sceo.provider.utils;

import com.huntkey.rx.base.PropertyBaseEntity;
import com.huntkey.rx.commons.utils.json.JsonUtils;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.constant.EmployeeProperty;
import com.huntkey.rx.edm.entity.EmployeeEntity;
import com.huntkey.rx.edm.entity.PeopleEntity;
import com.huntkey.rx.sceo.common.model.code.Const.BasicConst;
import com.huntkey.rx.sceo.method.register.plugin.entity.ParamsVo;
import com.huntkey.rx.sceo.method.register.plugin.util.ExecUtil;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.config.DynamicDataSourceContextHolder;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.code.controller.NbrlManualNumberSetController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Utils {

	private static Logger log = LoggerFactory.getLogger(Utils.class);
	private static String Symbol[] = { "=", ">", "<", ">=", "<=", "(", ")", "&", "|", " " };

	/**
	 * @param str
	 * @param firstNum
	 * @param endNum
	 * @return
	 */
	public static String subStr(String str, int firstNum, int endNum) {
		String param = str.substring(firstNum, endNum);
		return param;
	}

	public static String analysis(String formula) {
		formula = formula.replace("AND", "&&");
		formula = formula.replace("OR", "||");

		return formula;
	}

	;

	/**
	 * 获取当前登录用户
	 *
	 * @return
	 */
	public static String getCurentUserId(String authorization) {
		String id = "admin";
		try {
			ParamsVo params = new ParamsVo();
			params.setClassName("people");
			params.setMethodName("getEcosystemSession");
			params.setAuthorization(authorization);
			Result result = ExecUtil.exec(params);
			if (result.getRetCode() == 1) {
				@SuppressWarnings("unchecked")
				Map<String, Object> map = (Map<String, Object>) result.getData();
				@SuppressWarnings("unchecked")
				Map<String, Object> people = (Map<String, Object>) map.get("people");
				id = (String) people.get("id");
			}
		} catch (Exception e) {
			log.debug("Provider::Utils::getCurentUserId data{}", e.getMessage());
		}
		return id;

	}

	/**
	 * 获取当前登录用户
	 *
	 * @return
	 */
	public static String getCurentUserName(String authorization) {
		String username = "未知";
		try {
			ParamsVo params = new ParamsVo();
			params.setClassName("people");
			params.setMethodName("getEcosystemSession");
			params.setAuthorization(authorization);
			Result result = ExecUtil.exec(params);
			if (result.getRetCode() == 1) {
				Map<String, Object> map = (Map<String, Object>) result.getData();
				Map<String, Object> people = (Map<String, Object>) map.get("people");
				String firstName = (String) people.get("epeo_fist_name");
				String lastName = (String) people.get("epeo_last_name");
				username = ((firstName == null ? "" : firstName) + (lastName == null ? "" : lastName));
				username = username.equals("") ? (String) people.get("epeo_tel") : username;
			}
		} catch (Exception e) {
			log.debug("Provider::Utils::getCurentUserId data{}", e.getMessage());
		} finally {
			return username;
		}
	}

	/**
	 * 替换整个list中userId转换username并赋值到指定指定字段中
	 *
	 * @param objectList
	 * @param voName
	 */
	public static <T extends PropertyBaseEntity> void getUserNameByUserId(OrmService ormService, List<T> objectList,
			String voName) throws Exception {
		Map<String, String> map = new HashMap<>();
		for (T o : objectList) {
			map.put(o.getModuser(), "未知");
		}
		getUsersNameByUserIds(map, ormService);
		try {
			BeanInfo sourceBean = Introspector.getBeanInfo(PropertyBaseEntity.class, Object.class);
			PropertyDescriptor[] sourceProperty = sourceBean.getPropertyDescriptors();
			for (Object o : objectList) {
				String userId = null;
				for (int i = 0; i < sourceProperty.length; i++) {
					if (sourceProperty[i].getName().equals("moduser")) {
						userId = String.valueOf(sourceProperty[i].getReadMethod().invoke(o));
						break;
					}
				}

				for (int i = 0; i < sourceProperty.length; i++) {
					if (sourceProperty[i].getName().equals(voName)) {
						sourceProperty[i].getWriteMethod().invoke(o, map.get(userId));
						break;
					}
				}
			}
		} catch (Exception e) {
			// throw new Exception("属性复制失败:" + e.getMessage());
		}
	}

	public static void getUsersNameByUserIds(Map<String, String> map, OrmService ormService) throws Exception {
		String ids = "";
		for (Object id : map.keySet().toArray()) {
			if (ids.equals("")) {
				ids += "'" + id + "'";
			}
			ids += "," + "'" + id + "'";
		}
		if (StringUtil.isNullOrEmpty(ids)) {
			return;
		}
		List<Map<String, Object>> list = ormService
				.getDataBySql("select id,epeo_fist_name,epeo_last_name from ecodb.people  where id in(" + ids + ")");
		for (Map<String, Object> entity : list) {
			String firstName = StringUtils.isEmpty(entity.get("epeo_fist_name")) ? ""
					: (String) entity.get("epeo_fist_name");
			String lastName = StringUtils.isEmpty(entity.get("epeo_last_name")) ? ""
					: (String) entity.get("epeo_last_name");
			String username = (firstName + lastName).equals("") ? "未知" : (firstName + lastName);
			map.put((String) entity.get("id"), username);
		}
	}

	/**
	 * 根据用户Id查询用户名称
	 *
	 * @return
	 */
	public static String getUserNameByUserId(String authorization, String userId) {
		String username = userId;
		if (StringUtil.isNullOrEmpty(userId)) {
			return userId;
		}
		try {
			ParamsVo params = new ParamsVo();
			params.setClassName("people");
			params.setMethodName("getEcosystemSession");
			params.setAuthorization(authorization);
			Map<String, Object> temp = new HashMap<String, Object>();
			temp.put("userId", userId);
			params.setParamObj(temp);
			Result result = ExecUtil.exec(params);
			if (result.getRetCode() == 1) {
				Map<String, Object> map = (Map<String, Object>) result.getData();
				Map<String, Object> people = (Map<String, Object>) map.get("people");
				String firstName = (String) people.get("epeo_fist_name");
				String lastName = (String) people.get("epeo_last_name");
				username = (firstName == null ? "" : firstName + lastName == null ? "" : lastName).equals("")
						? (String) people.get("epeo_tel")
						: (firstName == null ? "" : firstName + lastName == null ? "" : lastName);
			}
		} catch (Exception e) {
			log.debug("Provider::Utils::getUserNameByUserId data{}", e.getMessage());
		} finally {
			return username;
		}
	}

	/**
	 * 根据用户Id查询用户名称
	 *
	 * @return
	 */
	public static String getUserNameByUserId(String userId, OrmService ormService) throws Exception {
		String username = "未知";
		String id = userId;
		List<Map<String, Object>> list = ormService
				.getDataBySql("select epeo_fist_name,epeo_last_name from ecodb.people  where id='" + userId + "'");
		if (list != null && list.size() != 0) {
			String firstName = StringUtils.isEmpty(list.get(0).get("epeo_fist_name")) ? ""
					: (String) list.get(0).get("epeo_fist_name");
			String lastName = StringUtils.isEmpty(list.get(0).get("epeo_last_name")) ? ""
					: (String) list.get(0).get("epeo_last_name");
			username = (firstName + lastName).equals("") ? "未知" : (firstName + lastName);
		}
		return username;
	}

	public static Map<String, Object> userIdConveruserNameInEntity(Object entity, String authorization) {
		if (entity == null) {
			return null;
		}
		String entity_json = JsonUtils.objectToJson(entity);
		Map<String, Object> map = JsonUtils.parseJSONMap(entity_json);
		pase(map, authorization);
		return map;
	}

	private static void pase(Map<String, Object> map, String authorization) {
		for (String key : map.keySet()) {
			if (key.equals("creuser") || key.equals("moduser")) {
				String username = getUserNameByUserId(authorization, (String) map.get(key));
				map.put(key, username);
			}
			if (map.get(key) instanceof ArrayList) {
				if (map.get(key) == null) {
					continue;
				}
				for (Object Object : (ArrayList) map.get(key)) {
					pase((Map<String, Object>) Object, authorization);
				}
			}
			if (key.equals("cretime") || key.equals("modtime") || key.equals("nbrl_takeno_date")) {
				if (map.get(key) == null) {
					continue;
				}
				Map<String, Object> map2 = JsonUtils.parseJSONMap(JsonUtils.objectToJson(map.get(key)));
				map.put(key, map2.get("time"));
			}
		}

	}

	/**
	 * 数据格式转换
	 */
	public static String getFormula(String formula) {
		if (StringUtil.isNullOrEmpty(formula)) {
			return "";
		}
		formula = analysis(formula);
		StringBuilder newFormula = new StringBuilder();
		int firstIndex = 0;
		int endIndex = -1;
		String temp = "";
		for (int i = 0; i < formula.length(); i++) {
			char a = formula.charAt(i);
			if (isIn(String.valueOf(a))) {
				if (firstIndex < endIndex + 1) {
					newFormula.append("'");
					newFormula.append(formula.substring(firstIndex + 1, endIndex + 1));
					newFormula.append("'");
				}
				newFormula.append(a);
				firstIndex = i;
			} else {
				endIndex = i;
			}
		}

		return newFormula.toString();
	}

	/**
	 * 判断是否为字符
	 *
	 * @param ch
	 * @return
	 */
	private static boolean isChar(char ch) {
		return ('a' <= ch && ch <= 'z') || ('A' <= ch && ch <= 'Z');
	}

	public static boolean isIn(String a) {
		for (String param : Symbol) {
			if (param.equals(a)) {
				return true;
			}
		}
		return false;
	}

	/*
	 * public static void main(String args[]){
	 * System.out.println(getFormula("(aa=bb)&&(c01>=c02)"));
	 * 
	 * }
	 */

	/**
	 * 公式转换
	 *
	 * @param formaul
	 * @return
	 */
	public static String analytical(String formaul) {
		formaul = analysis(formaul);
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < formaul.length(); i++) {
			if (!Character.isAlphabetic(formaul.charAt(i))) {
				sb.append(formaul.charAt(i));
			} else {
				sb.append("\'").append(formaul.charAt(i));
				i++;
				while (i < formaul.length() && !isWhiteSpqceAndOperator(formaul.charAt(i))) {
					sb.append(formaul.charAt(i));
					i++;
				}
				if (i < formaul.length()) {
					sb.append("\'");
					sb.append(formaul.charAt(i));
				} else {
					sb.append("\'");
				}

			}
		}

		return sb.toString();
	}

	/**
	 * 判断是否是运算符和空格
	 */
	public static boolean isWhiteSpqceAndOperator(char c) {
		return Character.isWhitespace(c) || '=' == c || '!' == c || '>' == c || '<' == c || '(' == c || ')' == c;
	}

	/**
	 * 驼峰转下划线
	 *
	 * @param tf
	 * @param xhx
	 */
	public static void tfToxhx(Object tf, Object xhx) throws Exception {
		// 获取属性
		BeanInfo sourceBean = Introspector.getBeanInfo(tf.getClass(), Object.class);
		PropertyDescriptor[] sourceProperty = sourceBean.getPropertyDescriptors();

		BeanInfo destBean = Introspector.getBeanInfo(xhx.getClass(), Object.class);
		PropertyDescriptor[] destProperty = destBean.getPropertyDescriptors();
		try {
			for (int i = 0; i < sourceProperty.length; i++) {
				for (int j = 0; j < destProperty.length; j++) {
					if (camel2Underline(sourceProperty[i].getName()).equals(destProperty[j].getName())
							&& sourceProperty[i].getPropertyType() == destProperty[j].getPropertyType()) {
						// 调用source的getter方法和dest的setter方法
						destProperty[j].getWriteMethod().invoke(xhx, sourceProperty[i].getReadMethod().invoke(tf));
						break;
					}
				}
			}
		} catch (Exception e) {
			throw new Exception("属性复制失败:" + e.getMessage());
		}
	}

	/**
	 * 下划线转驼峰
	 *
	 * @param tf
	 * @param xhx
	 */
	public static void xhxTotf(Object xhx, Object tf) throws Exception {
		// 获取属性
		BeanInfo sourceBean = Introspector.getBeanInfo(xhx.getClass(), Object.class);
		PropertyDescriptor[] sourceProperty = sourceBean.getPropertyDescriptors();

		BeanInfo destBean = Introspector.getBeanInfo(tf.getClass(), Object.class);
		PropertyDescriptor[] destProperty = destBean.getPropertyDescriptors();
		try {
			for (int i = 0; i < sourceProperty.length; i++) {
				for (int j = 0; j < destProperty.length; j++) {
					if (sourceProperty[i].getName().equals(camel2Underline(destProperty[j].getName()))
							&& sourceProperty[i].getPropertyType() == destProperty[j].getPropertyType()) {
						// 调用source的getter方法和dest的setter方法
						destProperty[j].getWriteMethod().invoke(xhx, sourceProperty[i].getReadMethod().invoke(tf));
						break;
					}
				}
			}
		} catch (Exception e) {
			throw new Exception("属性复制失败:" + e.getMessage());
		}
	}

	/**
	 * 字符串驼峰转下划线
	 * 
	 * @param line
	 * @return
	 */
	public static String camel2Underline(String line) {
		if (line == null || "".equals(line)) {
			return "";
		}
		line = String.valueOf(line.charAt(0)).toUpperCase().concat(line.substring(1));
		StringBuffer sb = new StringBuffer();
		Pattern pattern = Pattern.compile("[A-Z]([a-z\\d]+)?");
		Matcher matcher = pattern.matcher(line);
		while (matcher.find()) {
			String word = matcher.group();
			sb.append(word.toUpperCase());
			sb.append(matcher.end() == line.length() ? "" : "_");
		}
		return sb.toString().toLowerCase();
	}

	public static String underline2Camel(String line, boolean smallCamel) {
		if (line == null || "".equals(line)) {
			return "";
		}
		StringBuffer sb = new StringBuffer();
		Pattern pattern = Pattern.compile("([A-Za-z\\d]+)(_)?");
		Matcher matcher = pattern.matcher(line);
		while (matcher.find()) {
			String word = matcher.group();
			sb.append(smallCamel && matcher.start() == 0 ? Character.toLowerCase(word.charAt(0))
					: Character.toUpperCase(word.charAt(0)));
			int index = word.lastIndexOf('_');
			if (index > 0) {
				sb.append(word.substring(1, index).toLowerCase());
			} else {
				sb.append(word.substring(1).toLowerCase());
			}
		}
		return sb.toString();
	}

	public static void setBaseQueryColums(List<String> columnList) {
		columnList.add(BasicConst.ID);
		columnList.add(BasicConst.PID);
		columnList.add(BasicConst.CRETIME);
		columnList.add(BasicConst.MODTIME);
		columnList.add(BasicConst.CREUSER);
		columnList.add(BasicConst.MODUSER);
	}
}
