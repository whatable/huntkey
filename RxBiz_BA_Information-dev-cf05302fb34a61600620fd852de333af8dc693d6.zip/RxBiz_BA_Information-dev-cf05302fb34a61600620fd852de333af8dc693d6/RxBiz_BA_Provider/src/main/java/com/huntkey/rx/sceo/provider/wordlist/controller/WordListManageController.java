package com.huntkey.rx.sceo.provider.wordlist.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.WordlistEntity;
import com.huntkey.rx.sceo.common.model.wordlist.WordList;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.wordlist.service.WordListManageService;

/**
 *
 * @author zhoucj
 * @date 2017/11/20
 */
@RestController
@RequestMapping(value = "/wordList")
public class WordListManageController {
	@Autowired
	private WordListManageService wordListManageService;
	@Autowired
	private OrmService ormService;

	/**
	 * 枚举查询
	 * 
	 * @param infoCode
	 *            枚举编码，模糊过滤条件。不要同时设置infoCode和className两个条件。
	 * @param wordName
	 *            枚举名称
	 * @param className
	 *            使用类名，是类的中文名，如“检验单类”、“分类属性类”等，多个用逗号隔开，这个名称会通过modeler转换为infoCode来作为查询条件，因此不允许用户同时设置infoCode和className两个条件。
	 * @param wordEnable
	 *            是否可用
	 * @param pageNum
	 *            起始页
	 * @param pageSize
	 *            每页条数
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.GET)
	public Result select(@RequestParam(required = false, value = "infoCode") String infoCode,
			@RequestParam(required = false, value = "wordName") String wordName,
			@RequestParam(required = false, value = "className") String className,
			@RequestParam(required = false, value = "wordEnable") Integer wordEnable,
			@RequestParam(required = false, value = "pageNum", defaultValue = "1") int pageNum,
			@RequestParam(required = false, value = "pageSize", defaultValue = "15") int pageSize) throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.select(infoCode, wordName, className, wordEnable, pageNum, pageSize));
		return result;
	}

	/**
	 * 插入
	 * 
	 * @param wordList
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.POST)
	public Result insert(@RequestBody WordList wordList) throws Exception {
		Result result = new Result();

		// 枚举编码、名称唯一性验证
		String retStr = wordListManageService.checkInfoCode(wordList.getInfoCode(), wordList.getWordParent());
		if (!"".equals(retStr)) {
			result.setRetCode(Result.RECODE_VALIDATE_ERROR);
			result.setErrMsg(retStr);
			return result;
		}
		retStr = wordListManageService.checkName(wordList.getWordName(), wordList.getWordParent());
		if (!"".equals(retStr)) {
			result.setRetCode(Result.RECODE_VALIDATE_ERROR);
			result.setErrMsg(retStr);
			return result;
		}

		result.setData(wordListManageService.insert(wordList));
		return result;
	}

	/**
	 * 更新
	 * 
	 * @param wordList
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.PUT)
	public Result update(@RequestBody WordList wordList) throws Exception {
		Result result = new Result();

		// 枚举编码、名称唯一性验证
		WordlistEntity entity = ormService.load(WordlistEntity.class, wordList.getId());
		if (!wordList.getInfoCode().equals(entity.getInfo_code())) {
			String retStr = wordListManageService.checkInfoCode(wordList.getInfoCode(), wordList.getWordParent());
			if (!"".equals(retStr)) {
				result.setRetCode(Result.RECODE_VALIDATE_ERROR);
				result.setData(retStr);
				return result;
			}
		}
		if (!wordList.getWordName().equals(entity.getWord_name())) {
			String retStr = wordListManageService.checkName(wordList.getWordName(), wordList.getWordParent());
			if (!"".equals(retStr)) {
				result.setRetCode(Result.RECODE_VALIDATE_ERROR);
				result.setData(retStr);
				return result;
			}
		}

		result.setData(wordListManageService.update(wordList));
		return result;
	}

	/**
	 * 删除
	 * 
	 * @param ids
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(method = RequestMethod.DELETE)
	public Result delete(@RequestParam(value = "ids") String ids) throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.delete(ids));
		return result;
	}

	/**
	 * 获取完整枚举树
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/wordListTree", method = RequestMethod.GET)
	public Result getWordListTree() throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.getWordListTree());
		return result;
	}

	/**
	 * 获取指定id为根的枚举子树
	 * 
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/wordListTree/{id}", method = RequestMethod.GET)
	public Result getWordListTree(@PathVariable(value = "id") String id) throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.getWordListTree(id));
		return result;
	}

	/**
	 * 根据枚举编码获取枚举数据
	 * 
	 * @return
	 */
	@RequestMapping(value = "/selectByInfoCodes", method = RequestMethod.GET)
	public Result selectByInfoCodes(@RequestParam(value = "infoCodes", required = false) List<String> infoCodes)
			throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.selectByInfoCodes(infoCodes));
		return result;
	}

	/**
	 * 根据枚举编码获取子枚举
	 * 
	 * @return
	 */
	@RequestMapping(value = "/selectChildByInfoCode", method = RequestMethod.GET)
	public Result selectChildByInfoCode(@RequestParam(value = "infoCode", required = false) String infoCode)
			throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.selectChildByInfoCode(infoCode));
		return result;
	}

	/**
	 * 根据枚举编码获取子枚举
	 * 
	 * @return
	 */
	@RequestMapping(value = "/selectChildByInfoCodes", method = RequestMethod.GET)
	public Result selectChildByInfoCodes(@RequestParam(value = "infoCodes", required = false) List<String> infoCodes)
			throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.selectChildByInfoCodes(infoCodes));
		return result;
	}

	/**
	 * 获取枚举列表
	 * 
	 * @return
	 */
	@RequestMapping(value = "/selectWordlists", method = RequestMethod.GET)
	public Result selectWordlists(@RequestParam(value = "wordName", required = false) String wordName,
			@RequestParam(required = false, defaultValue = "1") int pageNum,
			@RequestParam(required = false, defaultValue = "15") int pageSize) throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.selectWordlists(wordName, pageNum, pageSize));
		return result;
	}

	/**
	 * 校验枚举编码和名称
	 * 
	 * @param infoCode
	 * @param wordName
	 * @param wordParent
	 * @return
	 */
	@RequestMapping(value = "/check", method = RequestMethod.GET)
	public Result checkInfoCodeAndName(@RequestParam(value = "infoCode") String infoCode,
			@RequestParam(value = "wordName") String wordName, @RequestParam(value = "wordParent") String wordParent)
			throws Exception {
		Result result = new Result();
		String retStr = "";

		if (!StringUtil.isNullOrEmpty(infoCode)) {
			retStr = wordListManageService.checkInfoCode(infoCode, wordParent);
		}
		if (!StringUtil.isNullOrEmpty(wordName)) {
			retStr = wordListManageService.checkName(wordName, wordParent);
		}
		result.setData(retStr);
		return result;
	}

	/**
	 * 上移、下移
	 * 
	 * @param ids
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/move", method = RequestMethod.PUT)
	public Result move(@RequestParam(value = "ids") String ids) throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.move(ids));
		return result;
	}

	/**
	 * 根据根枚举名称获取枚举编码
	 * 
	 * @param wordName
	 *            根枚举名称
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/wordName", method = RequestMethod.GET)
	public Result getInfoCodeByWordName(@RequestParam(value = "wordName") String wordName) throws Exception {
		Result result = new Result();
		result.setData(wordListManageService.getInfoCodeByWordName(wordName));
		return result;
	}
}