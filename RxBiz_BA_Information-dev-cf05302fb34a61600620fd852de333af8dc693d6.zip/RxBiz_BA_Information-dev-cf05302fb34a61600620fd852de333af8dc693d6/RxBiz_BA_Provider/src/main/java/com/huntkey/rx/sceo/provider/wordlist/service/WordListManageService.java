package com.huntkey.rx.sceo.provider.wordlist.service;

import java.util.List;
import java.util.Map;

import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.sceo.common.model.wordlist.WordList;
import com.huntkey.rx.sceo.common.model.wordlist.WordListExtend;

/**
 *
 * @author zhoucj
 * @date 2017/11/20
 */
public interface WordListManageService {
	String insert(WordList wordList) throws Exception;

	String update(WordList wordList) throws Exception;

	/**
	 * 根据指定的id（逗号分隔多个），实现必须是逻辑删除数据（全系统不允许物理删除数据）
	 * 
	 * @param ids
	 * @return
	 * @throws Exception
	 */
	int delete(String ids) throws Exception;

	/**
	 * 给定一个枚举id，返回以其为根的枚举树
	 * 
	 * @param id
	 * @return
	 * @throws Exception
	 */
	WordListExtend getWordListTree(String id) throws Exception;

	/**
	 * 读取系统中完整的枚举树，数据量极大，慎用
	 * 
	 * @return
	 * @throws Exception
	 */
	List<WordListExtend> getWordListTree() throws Exception;

	Pagination<WordList> select(String infoCode, String wordName, String className, Integer state, int pageNum,
			int pageSize) throws Exception;

	/**
	 * 根据给定的不定量infoCode，获取其对应的枚举名称，并一起构成map返回（返回的是infoCode:wordName的map）
	 * 
	 * @param infoCodes
	 * @return "infoCod-wordName"的map
	 * @throws Exception
	 */
	Map<String, String> selectByInfoCodes(List<String> infoCodes) throws Exception;

	List<Map<String, Object>> selectChildByInfoCode(String infoCode) throws Exception;

	Pagination<Map<String, String>> selectWordlists(String wordName, int pageNum, int pageSize) throws Exception;

	String checkInfoCode(String infoCode, String flag) throws Exception;

	String checkName(String wordName, String flag) throws Exception;

	String move(String ids) throws Exception;

	String getInfoCodeByWordName(String wordName) throws Exception;

	Map<String, List<Map<String, Object>>> selectChildByInfoCodes(List<String> infoCodes) throws Exception;
}
