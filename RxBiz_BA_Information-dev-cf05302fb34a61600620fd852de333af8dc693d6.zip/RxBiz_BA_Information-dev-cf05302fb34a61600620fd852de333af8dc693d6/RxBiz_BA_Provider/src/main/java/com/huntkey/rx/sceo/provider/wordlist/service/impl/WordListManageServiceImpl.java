package com.huntkey.rx.sceo.provider.wordlist.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.huntkey.rx.edm.constant.WordlistProperty;
import com.huntkey.rx.sceo.profile.common.service.ParameterService;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import kafka.security.auth.All;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.huntkey.rx.commons.utils.rest.Pagination;
import com.huntkey.rx.commons.utils.rest.Result;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.WordlistEntity;
import com.huntkey.rx.sceo.common.model.wordlist.WordList;
import com.huntkey.rx.sceo.common.model.wordlist.WordListExtend;
import com.huntkey.rx.sceo.orm.common.model.OrmParam;
import com.huntkey.rx.sceo.orm.common.type.SQLSortEnum;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.feign.ModelerProvider;
import com.huntkey.rx.sceo.provider.wordlist.service.WordListManageService;

/**
 * 枚举列表管理实现
 * 
 * @author zhoucj
 * @date 2017/11/20
 */
@Service
public class WordListManageServiceImpl implements WordListManageService {

	private static final String ID = "id";
	private static final String DEL = "is_del";
	private static final String WORD_PAR = "word_par";
	private static final String WORD_NAME = "word_name";
	private static final String WORD_ENABLE = "word_enable";
	private static final String INFO_CODE = "info_code";
	@Autowired
	private ModelerProvider modeler;

	@Autowired
	private ParameterService parameterService;

	@Autowired
	private OrmService orm;

	private final Logger LOG = LoggerFactory.getLogger(this.getClass());

	/**
	 * 查询枚举列表
	 * 
	 * @param infoCode
	 *            枚举编码
	 * @param wordName
	 *            枚举名称
	 * @param className
	 *            使用类名
	 * @param state
	 *            是否禁用
	 * @param pageNum
	 *            初始页
	 * @param pageSize
	 *            每页条数
	 * @return
	 * @throws Exception
	 */
	@Override
	public Pagination<WordList> select(String infoCode, String wordName, String className, Integer state, int pageNum,
			int pageSize) throws Exception {

		OrmParam param = new OrmParam();

		String where = OrmParam.and(param.getIsNull(WORD_PAR), param.getMatchMiddleXML(INFO_CODE, infoCode),
				param.getMatchMiddleXML(WORD_NAME, wordName), param.getEqualXML(WORD_ENABLE, state));

		if (!StringUtil.isNullOrEmpty(infoCode)) {
			where = OrmParam.and(where, param.getMatchMiddleXML(INFO_CODE, infoCode));
		}
		if (!StringUtil.isNullOrEmpty(className)) {
			Result result = modeler.getInfoCodes(className);
			if (result != null) {
				String codes = (String) JSONObject.toJSON(result.getData());
				if (!StringUtil.isNullOrEmpty(codes)) {
					where = OrmParam.and(where, param.getInXML(INFO_CODE, codes.split(",")));
				}
			}
		}

		param.setWhereExp(where);
		param.setPageNo(pageNum);
		param.setPageSize(pageSize);
		Pagination<WordlistEntity> entities = orm.selectPagedBeanList(WordlistEntity.class, param);

		if (entities == null || entities.getList() == null || entities.getList().size() <= 0) {
			return new Pagination<>(new LinkedList<>(), pageNum, pageSize, 0);
		} else {
			List<WordList> list = new ArrayList<>(entities.getList().size());
			for (WordlistEntity e : entities.getList()) {
				WordList wordList = new WordList(e);
				setClassIdsAndNames(wordList);// <<<<<<<<<<<<<<<<<<<<<<<< 这里亟待优化！！！！！
				list.add(wordList);
			}
			return new Pagination<>(list, pageNum, pageSize, entities.getTotal());
		}
	}

	@Override
	public String insert(WordList wordList) throws Exception {
		WordlistEntity e = wordList.toEntity();
		// 判断是否标准系统
		boolean isStandardSystem = parameterService.isStandardSystem();
		if (!isStandardSystem) {
			e.setWord_issta(Integer.valueOf(Constants.NOT_STANDARD));
		}
		Date date = new Date();
		e.setCretime(date);
		e.setModtime(date);
		e.setWord_enable(1);
		e.setCreuser("admin");
		e.setModuser("admin");

		// 排序处理
		e.setWord_seq(getChildrensMaxSeq(wordList.getWordParent()) + 1);

		return orm.insert(e).toString();
	}

	@Override
	public String update(WordList wordList) throws Exception {
		// 判断是否标准系统
		boolean isStandardSystem = parameterService.isStandardSystem();
		WordlistEntity updateBefore = orm.load(WordlistEntity.class, wordList.getId());
		/**
		 * 	1、标准系统下，任意节点由标准—>非标，则其所有子节点—>非标
		 * 	2、任意节点由启用—>禁用，则其所有子节点—>禁用
		 */
		// 启用改为禁用
		boolean enable2unenable = updateBefore.getWord_enable() == 1 && wordList.getWordEnable() == 0;
		if(isStandardSystem || enable2unenable){
			// 标准改为非标准
			boolean stand2unstand = updateBefore.getWord_issta() == 1 && wordList.getWordIsStandard() == 0;
			if(stand2unstand || enable2unenable){
				//所有后代节点
				List<WordlistEntity> descendants = new LinkedList<>();
				updateChildList(descendants, new String[]{wordList.getId()}, wordList);
				for (WordlistEntity descendant : descendants) {
					orm.updateSelective(descendant);
				}
			}
		}
		WordlistEntity e = wordList.toEntity();
		e.setModtime(new Date());
		e.setModuser("admin");
		if(!StringUtil.isNullOrEmpty(e.getWord_par())){
			e.setWord_par(wordList.getWordParent().split(",")[wordList.getWordParent().split(",").length-1]);
		}
		return String.valueOf(orm.updateSelective(e));
	}

	/**
	 * 修改所有后代子节点为非标
	 * @param descendants 后代节点
	 * @param ids id集合
	 * @throws Exception
	 */
	private void updateChildList(List<WordlistEntity> descendants,Object[] ids, WordList wordList) throws Exception {
		List<String> childIds = new LinkedList<>();
		// 查询所有有子节点
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(ormParam.getInXML(WordlistProperty.WORD_PAR, ids));
		List<WordlistEntity> childList = orm.selectBeanList(WordlistEntity.class, ormParam);
		if(childList != null && childList.size()>0) {
			for (WordlistEntity wordlistEntity : childList) {
				wordlistEntity.setWord_issta(wordList.getWordIsStandard());
				wordlistEntity.setWord_enable(wordList.getWordEnable());
				childIds.add(wordlistEntity.getId());
			}
			descendants.addAll(childList);
			updateChildList(descendants, childIds.toArray(), wordList);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.huntkey.rx.sceo.provider.wordlist.service.WordListManageService#
	 * physicalDelete(java.lang.String)
	 */
	@Override
	public int delete(String ids) throws Exception {
		if (StringUtil.isNullOrEmpty(ids)) {
			return 0;
		}

		// 因为要关联删除所有子代节点，所以先遍历出所有子代，把整个“家族”的id收集到family列表中以后批量删
		String[] arr = ids.split(",");
		final List<String> family = new LinkedList<>(Arrays.asList(arr));
		while (arr != null && arr.length > 0) {
			OrmParam ormParam = new OrmParam();
			String exp = ormParam.getInXML(WORD_PAR, arr);
			ormParam.setWhereExp(exp);
			List<WordlistEntity> entities = orm.selectBeanList(WordlistEntity.class, ormParam);
			if (entities != null && entities.size() > 0) {
				arr = new String[entities.size()];
				for (int i = 0; i < entities.size(); i++) {
					arr[i] = entities.get(i).getId();// 作为下一趟的pid
				}
			} else {
				arr = null;// 没有更多子代了，退出迭代
			}
		}

		// 最终根据整个家族的id把所有的节点做删除（orm.delete是逻辑删除）
		OrmParam ormParam = new OrmParam();
		String exp = ormParam.getInXML(ID, family.toArray());
		ormParam.setWhereExp(exp);
		return orm.delete(WordlistEntity.class, ormParam);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.huntkey.rx.sceo.provider.wordlist.service.WordListManageService#
	 * getWordListTree(java.lang.String)
	 */
	@Override
	public WordListExtend getWordListTree(String id) throws Exception {
		if (id == null || id.isEmpty()) {
			return null;
		}
		return new WTree().pick(id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.huntkey.rx.sceo.provider.wordlist.service.WordListManageService#
	 * getWordListTree()
	 */
	@Override
	public List<WordListExtend> getWordListTree() throws Exception {
		return new WTree().pick();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.huntkey.rx.sceo.provider.wordlist.service.WordListManageService#
	 * selectByInfoCodes(java.util.List)
	 */
	@Override
	public Map<String, String> selectByInfoCodes(List<String> infoCodes) throws Exception {
		if (null == infoCodes || infoCodes.isEmpty()) {
			return null;
		}
		OrmParam ormParam = new OrmParam();
		String whereCondition = OrmParam.and(ormParam.getInXML(INFO_CODE, infoCodes.toArray()),
				ormParam.getEqualXML(WORD_ENABLE, 1));
		ormParam.addColumn("id").addColumn(INFO_CODE).addColumn(WORD_NAME);
		ormParam.setWhereExp(whereCondition);
		List<Map<String, Object>> list = orm.selectMapList(WordlistEntity.class, ormParam);
		Map<String, String> infoMap = new HashMap<>();
		if (list != null && list.size() > 0) {
			for (Map<String, Object> map : list) {
				String infoCode = (String) map.get(INFO_CODE);
				if (!StringUtil.isNullOrEmpty(infoCode)) {
					infoMap.put(infoCode, (String) map.get(WORD_NAME));
				}
			}
		}
		return infoMap;
	}

	@Override
	public List<Map<String, Object>> selectChildByInfoCode(String infoCode) throws Exception {
		List<Map<String, Object>> list = new ArrayList<>();
		if (infoCode == null || infoCode.isEmpty()) {
			return list;
		}

		OrmParam ormParam = new OrmParam();
		String whereCondition = OrmParam.and(ormParam.getEqualXML(INFO_CODE, infoCode),
				ormParam.getEqualXML(WORD_ENABLE, 1));// <<<<<<<<
		// 这里不需要word_par
		// is
		// null吗？？
		ormParam.addColumn("id").addColumn(INFO_CODE).addColumn(WORD_NAME).addColumn(WORD_PAR).addColumn("word_seq");
		ormParam.setWhereExp(whereCondition);
		List<Map<String, Object>> maps = orm.selectMapList(WordlistEntity.class, ormParam);
		if (maps != null && maps.size() > 0) {
			String wordPar = (String) maps.get(0).get("id");
			list = getEnableWordListChild(wordPar);
		}

		return buildMapListTree(list);
	}

	@Override
	public Map<String, List<Map<String, Object>>> selectChildByInfoCodes(List<String> infoCodes) throws Exception {
		Map<String, List<Map<String, Object>>> maps = new HashMap<>();
		for (String infoCode : infoCodes) {
			maps.put(infoCode, selectChildByInfoCode(infoCode));
		}

		return maps;
	}

	@Override
	public Pagination<Map<String, String>> selectWordlists(String wordName, int pageNum, int pageSize)
			throws Exception {
		OrmParam param = new OrmParam();

		StringBuilder exp = new StringBuilder("1=1 and word_par is null");
		if (!StringUtil.isNullOrEmpty(wordName)) {
			exp.append(" and (info_code like '%").append(wordName).append("%' or word_name like '%").append(wordName)
					.append("%')");
		}
		param.setWhereExp(exp.toString());
		long totalSize = orm.count(WordlistEntity.class, param);
		param.setPageNo(pageNum);
		param.setPageSize(pageSize);
		param.addColumn("id").addColumn(INFO_CODE).addColumn(WORD_NAME);
		List<Map<String, Object>> mapList = orm.selectMapList(WordlistEntity.class, param);
		Pagination<Map<String, String>> pagination = new Pagination(mapList, pageNum, pageSize, totalSize);
		return pagination;
	}

	@Override
	public String checkInfoCode(String infoCode, String wordParent) throws Exception {
		if (StringUtil.isNullOrEmpty(infoCode)) {
			return "枚举编码不可为空";
		}

		String retStr = "";
		String exp = "";
		OrmParam ormParam = new OrmParam();
		exp = OrmParam.and(ormParam.getEqualXML(INFO_CODE, infoCode),
				StringUtil.isNullOrEmpty(wordParent) ? ormParam.getIsNull(WORD_PAR)
						: ormParam.getEqualXML(WORD_PAR, wordParent));
		ormParam.setWhereExp(exp);
		long count = orm.count(WordlistEntity.class, ormParam);
		if (count > 0) {
			retStr = "枚举编码重复";
		}

		return retStr;
	}

	@Override
	public String checkName(String wordName, String wordParent) throws Exception {
		if (StringUtil.isNullOrEmpty(wordName)) {
			return "枚举名称不可为空";
		}

		String retStr = "";
		String exp = "";
		OrmParam ormParam = new OrmParam();
		if (StringUtil.isNullOrEmpty(wordParent)) {
			exp = exp.concat(ormParam.getEqualXML(WORD_NAME, wordName)).concat(" AND ")
					.concat(ormParam.getIsNull(WORD_PAR));
		} else {
			exp = exp.concat(ormParam.getEqualXML(WORD_NAME, wordName)).concat(" AND ")
					.concat(ormParam.getEqualXML(WORD_PAR, wordParent));
		}
		ormParam.setWhereExp(exp);
		long count = orm.count(WordlistEntity.class, ormParam);
		if (count > 0) {
			retStr = "枚举名称重复";
		}

		return retStr;
	}

	@Override
	public String move(String ids) throws Exception {
		if (StringUtil.isNullOrEmpty(ids)) {
			return "0";
		}
		String[] idArr = ids.split(",");
		int i = 1;
		for (String id : idArr) {
			WordlistEntity wordlistEntity = new WordlistEntity();
			wordlistEntity.setWord_seq(i++);
			wordlistEntity.setId(id);
			orm.updateSelective(wordlistEntity);
		}
		return String.valueOf(i);
	}

	/**
	 * 设置枚举列表的使用类id和类名
	 * 
	 * @param wordList
	 */
	private void setClassIdsAndNames(WordList wordList) {
		if (wordList == null) {
			return;
		}
		Result result = modeler.getEdmcIdsByDataType(wordList.getInfoCode());
		JSONArray jsonArray = (JSONArray) JSONObject.toJSON(result.getData());
		if (jsonArray == null || jsonArray.size() <= 0) {
			return;
		}

		StringBuilder sb = new StringBuilder();
		for (Object o : jsonArray) {
			sb.append(o).append(",");
		}
		if (!StringUtil.isNullOrEmpty(sb)) {
			sb.delete(sb.length() - 1, sb.length());
		}

		wordList.setClassIds(sb.toString());
		result = modeler.getClassNamesByIds(wordList.getClassIds());
		wordList.setClassNames((String) result.getData());
	}

	private List<Map<String, Object>> buildMapListTree(List<Map<String, Object>> mapList) {
		List<Map<String, Object>> wordListTree = new ArrayList<>();
		for (Map<String, Object> child : mapList) {
			boolean hasNoParent = true;
			for (Map<String, Object> parent : mapList) {
				if (!StringUtil.isNullOrEmpty(parent.get("id")) && parent.get("id").equals(child.get(WORD_PAR))) {
					hasNoParent = false;
					List<Map<String, Object>> temp = new ArrayList<>();
					if (parent.get("children") == null) {
						parent.put("children", temp);
					} else {
						temp = (List<Map<String, Object>>) parent.get("children");
					}
					temp.add(child);
				}
			}
			if (hasNoParent) {
				wordListTree.add(child);
			}
		}

		return wordListTree;
	}

	/**
	 * 根据id获取启用的子枚举列表集合
	 * 
	 * @param id
	 * @return
	 */
	private List<Map<String, Object>> getEnableWordListChild(String id) throws Exception {
		OrmParam ormParam = new OrmParam();
		ormParam.setWhereExp(OrmParam.and(ormParam.getEqualXML(WORD_PAR, id), ormParam.getEqualXML(WORD_ENABLE, 1)));
		ormParam.addColumn("id").addColumn(INFO_CODE).addColumn(WORD_NAME).addColumn(WORD_PAR).addColumn("word_seq");
		List<Map<String, Object>> mapList = orm.selectMapList(WordlistEntity.class, ormParam);

		List<Map<String, Object>> list = new ArrayList<>();
		if (mapList != null && mapList.size() > 0) {
			for (Map<String, Object> map : mapList) {
				list.add(map);
				list.addAll(getEnableWordListChild(map.get("id").toString()));
			}
		}

		return list;
	}

	/**
	 * 根据枚举id，获取其所有直接子节点的最大排序值（若全为null则自动取0）
	 * 
	 * @param wordParent
	 *            父枚举id
	 * @return
	 * @throws Exception
	 */
	private int getChildrensMaxSeq(String id) throws Exception {
		String sql = "SELECT MAX(word_seq) AS max FROM edmdb.wordlist WHERE word_par";// 注意，这里并不排除IS_DEL=1的数据，也即是删除的数据也参与排序，这样在恢复数据的时候不需处理排序
		sql += (id == null || id.isEmpty()) ? " IS NULL" : ("='" + id + "'");
		List<Map<String, Object>> list = orm.getDataBySql(sql);
		return (list != null && list.size() > 0 && list.get(0) != null && list.get(0).get("max") != null)
				? ((int) list.get(0).get("max"))
				: 0;
	}

	// /**
	// * 获取根枚举
	// *
	// * @param id
	// * 枚举id
	// * @return
	// */
	// private WordlistEntity getRootWordList(String id) throws Exception {
	// WordlistEntity wordlistEntity = orm.load(WordlistEntity.class, id);
	//
	// if (wordlistEntity != null) {
	// if (StringUtil.isNullOrEmpty(wordlistEntity.getWord_par())) {
	// wordlistEntity = getRootWordList(wordlistEntity.getWord_par());
	// }
	// }
	//
	// return wordlistEntity;
	// }

	@Override
	public String getInfoCodeByWordName(String wordName) throws Exception {
		String infoCode = "";
		OrmParam ormParam = new OrmParam();

		ormParam.setWhereExp(ormParam.getEqualXML(WORD_NAME, wordName));
		List<WordlistEntity> wordlistEntitys = orm.selectBeanList(WordlistEntity.class, ormParam);
		if (wordlistEntitys != null && wordlistEntitys.size() > 0) {
			infoCode = wordlistEntitys.get(0).getInfo_code();
		}

		return infoCode;
	}

	private class WTree {
		private final List<WordListExtend> ALL_AS_TREE = new LinkedList<>();
		private final Map<String, WordListExtend> ALL_AS_MAP = new HashMap<>();

		public WTree() throws Exception {
			final List<String> dirtyIds = new LinkedList<>();
			OrmParam ormParam = new OrmParam();
			String exp = ormParam.getEqualXML(DEL, 0);
			ormParam.setWhereExp(exp);
			ormParam.setOrderExp(SQLSortEnum.ASC, "word_seq");
			List<WordlistEntity> entities = orm.selectBeanList(WordlistEntity.class, ormParam);

			if (entities != null && entities.size() > 0) {
				List<WordListExtend> list = new ArrayList<>();// 临时的list，用于按顺序装入所有entity，后面再遍历一次，把树构造起来
				for (WordlistEntity e : entities) {
					WordListExtend w = new WordListExtend(e);
					ALL_AS_MAP.put(w.getId(), w);// 所有entity装入一个快速索引的map中
					list.add(w); // 所有entity同时也装入一个便于遍历的list中
				}

				// 遍历所有entity，构建树形结构
				for (WordListExtend w : list) {
					String pid = w.getWordParent();
					System.out.println("pid==>"+pid);
					if (pid == null) {
						// 顶级区域，直接放入tree顶层
						ALL_AS_TREE.add(w);
					} else {
						// 非顶级区域，先检查其pid是否合法，若pid指向有问题的数据，直接丢弃（打印日志提醒）；若pid合法，则拼接到其父节点
//						if (!ALL_AS_MAP.containsKey(pid)) {
//							dirtyIds.add(w.getId());
//						} else {
//							WordListExtend parent = ALL_AS_MAP.get(pid);
//							parent.getChildList().add(w);// 拼接到父节点
//						}
						List<String> grandPids = new ArrayList<>();
						splicingWordparent(w,grandPids);
						if(grandPids.size() > 0){
							StringBuilder splicingPid = new StringBuilder();
							for (int i=grandPids.size()-1; i >= 0; i--){
								splicingPid.append(grandPids.get(i)).append(",");
							}
							w.setWordParent(splicingPid.toString());
						}
						String[] pids = pid.split(",");
						if (!ALL_AS_MAP.containsKey(pids[pids.length-1])) {
							dirtyIds.add(w.getId());
						} else {
							WordListExtend parent = ALL_AS_MAP.get(pids[pids.length-1]);
							parent.getChildList().add(w);// 拼接到父节点
						}
					}
					System.out.println("////////");
				}
			}
			if (dirtyIds.size() > 0) {
				LOG.warn("系统中发现枚举脏数据，建议修复，数据编号：{}", dirtyIds);
			}
		}

		void splicingWordparent(WordListExtend wordListExtend, List<String> grandPids) {
			String[] pids = new String[20];
			if (!StringUtil.isNullOrEmpty(wordListExtend.getWordParent())){
				pids = wordListExtend.getWordParent().split(",");
			}
			String pid = null;
			if(pids.length > 0){
				pid = pids[pids.length-1];
			}
			if(!StringUtil.isNullOrEmpty(pid) && ALL_AS_MAP.containsKey(pid)){
				WordListExtend parent = ALL_AS_MAP.get(pid);
				grandPids.add(pid);
				splicingWordparent(parent, grandPids);
			}
		}

		/**
		 * 获取所有枚举，每类构成一棵树。数据量偏大，慎用
		 * 
		 * @return
		 * @throws Exception
		 */
		List<WordListExtend> pick() throws Exception {
			return ALL_AS_TREE;
		}

		/**
		 * 以给定id的节点为根，获取一棵枚举子树
		 * 
		 * @param id
		 * @return
		 * @throws Exception
		 */
		WordListExtend pick(String id) throws Exception {
			if(!ALL_AS_MAP.containsKey(id)){
				return null;
			}
			WordListExtend root = ALL_AS_MAP.get(id);

			return root;
		}
	}
}
