package com.huntkey.rx.sceo.provider;

import com.huntkey.rx.sceo.common.model.tip.TipMessage;
import com.huntkey.rx.sceo.provider.tip.service.TipMessageService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by zhoucj on 2017/11/14.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class TipMessageServiceImplTest {
    @Autowired
    private TipMessageService tipMessageService;

    @Test
    public void testSelectByPrimaryKey() throws Exception {
        TipMessage tipMessage = tipMessageService.queryTip("111");
        System.out.println(tipMessage.toString());
    }
}
