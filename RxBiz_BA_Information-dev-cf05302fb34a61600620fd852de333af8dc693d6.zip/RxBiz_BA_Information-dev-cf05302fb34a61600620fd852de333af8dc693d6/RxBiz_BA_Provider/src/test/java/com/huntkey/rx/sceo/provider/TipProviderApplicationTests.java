package com.huntkey.rx.sceo.provider;


import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.huntkey.rx.commons.utils.string.StringUtil;
import com.huntkey.rx.edm.entity.*;
import com.huntkey.rx.sceo.common.model.area.vo.AreaVO;
import com.huntkey.rx.sceo.common.model.code.NumberRules;
import com.huntkey.rx.sceo.common.model.code.VO.NumberRulesVO;
import com.huntkey.rx.sceo.common.model.order.vo.CurrRateSetOrderVO;
import com.huntkey.rx.sceo.common.model.paramter.ParamterDto;
import com.huntkey.rx.sceo.common.model.paramter.VO.ParameterVO;
import com.huntkey.rx.sceo.common.model.paramter.constant.ParameterConstant;
import com.huntkey.rx.sceo.common.model.period.PeriodEnum;
import com.huntkey.rx.sceo.common.model.school.vo.SchoolVO;
import com.huntkey.rx.sceo.method.register.plugin.entity.ParamsVo;
import com.huntkey.rx.sceo.orm.service.OrmService;
import com.huntkey.rx.sceo.provider.area.service.impl.AreaServiceImpl;
import com.huntkey.rx.sceo.provider.code.constants.Constants;
import com.huntkey.rx.sceo.provider.code.service.Impl.NumberRulesSereviceImpl;
import com.huntkey.rx.sceo.provider.utils.Utils;
import com.netflix.util.HashCode;
import kafka.utils.Json;
import org.apache.catalina.core.ApplicationContext;
import org.apache.catalina.core.StandardContext;
import org.apache.commons.collections.buffer.BoundedBuffer;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.aspectj.lang.ProceedingJoinPoint;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.RootBeanDefinition;
import org.springframework.beans.factory.xml.DefaultBeanDefinitionDocumentReader;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.boot.autoconfigure.security.AuthenticationManagerConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.test.context.ContextLoader;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.servlet.DispatcherServlet;
import org.yaml.snakeyaml.constructor.Constructor;
import scala.Char;
import sun.reflect.Reflection;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.http.HttpServletRequest;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;
import java.awt.*;
import java.beans.BeanInfo;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.*;
import java.lang.reflect.*;
import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.sql.*;
import java.text.Collator;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import java.util.logging.Logger;


@RunWith(SpringRunner.class)
@SpringBootTest
public class TipProviderApplicationTests {
@Autowired
private NumberRulesSereviceImpl numberRulesSerevice;
@Autowired
private OrmService ormService;
@Autowired
	AreaServiceImpl areaService;
	@Test
	public void contextLoads() {
		String[] ids = {"00000000000000000000000000110000"};
		try {
			areaService.setChildrenDisable(ids);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
//	private static ConcurrentHashMap<Integer, Integer> map = new ConcurrentHashMap<Integer, Integer>();

	public static void main(String[] args) throws Exception{
		String st = "001,002,003,";
		System.out.println(st.lastIndexOf(","));
		System.out.println(st.length());
	}
	private static List<AreaEntity> sorListByChineseName(List<AreaEntity> entityList){
		Collections.sort(entityList,(AreaEntity o1,AreaEntity o2)->Collator.getInstance(Locale.CHINESE).compare(o1.getArea_name(),o2.getArea_name()));
		return entityList;
	}
	public static Date getFrontDay(Date date) {
		//指定时间的时间戳
		long targetTime = date.getTime();
		//指定时间往前推一天的时间戳
		long frontTime = targetTime + 24*60*60*1000;
		return new Date(frontTime);
	}
}
class School{
	private String rsch_code;

	public String getRsch_code() {
		return rsch_code;
	}

	public void setRsch_code(String rsch_code) {
		this.rsch_code = rsch_code;
	}
}

class ThreadDraw implements Runnable{
	private int money = 500;  //总金额
	public void run() {
		for (int i = 0; i < 5; i++) {  //循环次数
			money1();          //调用money1方法
		}
	}
	public  void money1() { //同步方法
		synchronized (this) {
			if(money>0) {
				System.out.println(Thread.currentThread().getName()+"准备取款！");
				System.out.println(Thread.currentThread().getName()+"完成取款！");
				try {
					Thread.sleep(500);                          //延时500秒
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				money-=100;

			}else {
				System.out.println(Thread.currentThread().getName()+"的取款，余额为0");
			}
		}
	}

	public static void main(String[] args) {


	}
}
class Mylock {
	private Integer num = 0;
	ReadWriteLock rwl = new ReentrantReadWriteLock();
	public void get(){
		rwl.readLock().lock();
		try {
			System.out.println(Thread.currentThread().getName()+"读取数据："+num);
		}catch (Exception e){
			e.printStackTrace();
		}finally {
			rwl.readLock().unlock();
		}
	}

	public void set(Integer data){
		rwl.writeLock().lock();
		try {
			this.num += data;
			System.out.println(Thread.currentThread().getName()+"设置数据："+num);
		}catch (Exception e){
			e.printStackTrace();
		}finally {
			rwl.writeLock().unlock();
		}

	}
}





