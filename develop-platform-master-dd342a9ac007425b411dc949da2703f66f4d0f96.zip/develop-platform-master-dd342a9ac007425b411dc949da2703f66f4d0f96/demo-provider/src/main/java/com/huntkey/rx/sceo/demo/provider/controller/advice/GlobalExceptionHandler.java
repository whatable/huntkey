package com.huntkey.rx.sceo.demo.provider.controller.advice;

import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 * Created by zhaomj on 2017/4/13.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

}
