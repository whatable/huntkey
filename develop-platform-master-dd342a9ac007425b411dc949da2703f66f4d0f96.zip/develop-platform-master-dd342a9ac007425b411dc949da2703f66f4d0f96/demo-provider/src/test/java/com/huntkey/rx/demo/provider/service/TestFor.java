package com.huntkey.rx.demo.provider.service;

import org.junit.Assert;
import org.junit.Test;

/***********************************************************************
 * @author chenxj												      
 * 																	  
 * @email: kaleson@163.com											  
 * 																	  
 * @date : 2017年5月11日 下午1:58:21											 
 *																	  															 
 **********************************************************************/
public class TestFor {
	
	@Test
	public void testOne(){
		Assert.assertEquals(1,2);
	}
}
