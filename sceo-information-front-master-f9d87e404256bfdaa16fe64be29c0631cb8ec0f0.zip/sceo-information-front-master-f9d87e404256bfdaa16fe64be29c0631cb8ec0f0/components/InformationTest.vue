<template>
  <div class="information-test">
    information-test 
  </div>
</template>
<script>
  export default {
  }
</script>
<style scoped>
</style>
