const router = {
  path: '/information',
  name: 'information',
  component: () => import('@information/App'),
  children: [{
    path: 'information-test',
    name: 'information-test',
    component: () => import('@information/components/InformationTest')
  }]
}
export default router
