module.exports = {
  host: '10.3.98.21:8999',
  group: 'sceo-main-front',
  user: '',
  password: ''
}
