<template>
  <div id="app">
    <router-view></router-view>
    <dialog-pool></dialog-pool>
    <!-- <rx-window v-model="isShow" title="测试" v-if="isShow"></rx-window> -->
    <rx-taskbar></rx-taskbar>
  </div>
</template>

<script>
import dialogPool from '@/components/common/DialogPool'
import RxWindow from '@/components/common/RxWindow'
import RxTaskbar from '@/components/common/RxTaskbar'

export default {
  name: 'app',
  components: {
    dialogPool, RxWindow, RxTaskbar
  },
  created () {
    this.$nextTick(() => {
      this.isShow = true
    })
  },
  data () {
    return {
      isShow: false
    }
  }
}
</script>

<style scoped>
  #app{
    height: 100%;
    overflow: auto;
  }
</style>
