import utils from '@/utils'

export const demoService = {
  /**
   * 获得所有部门
   * @param  {String} relationId 伙伴对象ID
   * @return {List}   所有部门对象
   */
  getAllDept (relationId) {
    // 获得所有部门
    return utils.execUtil('depttree', 'getAllDept', {
      relationId
    })
  }
}
