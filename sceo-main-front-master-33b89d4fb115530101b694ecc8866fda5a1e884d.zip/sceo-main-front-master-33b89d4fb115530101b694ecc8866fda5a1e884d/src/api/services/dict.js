import axios from 'axios'
import util from '@/utils'

export const dictService = {
  getDictByCodes (codes) {
    return axios.get(util.getConfig('commonApiHost') + 'dict/code', {
      params: {
        'codes[]': codes.join(',')
      }
    })
  },
  // 根据code获得树
  getDictTreeByCode (code) {
    return axios.get(util.getConfig('commonApiHost') + 'dict/tree', {
      params: {
        code
      }
    })
  }
}
