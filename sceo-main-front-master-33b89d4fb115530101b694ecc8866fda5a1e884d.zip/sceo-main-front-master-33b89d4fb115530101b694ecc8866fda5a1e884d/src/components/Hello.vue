<template>
  <div class="hello">
    <div v-for="item in list" :key="item.name">
      <el-button type="text" @click="go(item.router)">{{item.name}}</el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'hello-main',
  data () {
    return {
      list: [{
        name: '部门列表',
        router: 'departmentList'
      }, {
        name: '新增部门',
        router: 'departmentAdd'
      }, {
        name: '岗位列表',
        router: 'deptPostList'
      }, {
        name: '职位列表',
        router: 'positionList'
      }, {
        name: '部门员工列表',
        router: 'departStaffList'
      }, {
        name: '转正申请查询列表',
        router: 'turnPositiveApplication'
      }, {
        name: '转正申请单',
        router: 'turnPositiveForm'
      }, {
        name: '离职申请查询',
        router: 'resignation'
      }, {
        name: '离职申请单',
        router: 'resignationForm'
      }, {
        name: '离职手续列表',
        router: 'resignationProcess'
      }, {
        name: '合同到期查询',
        router: 'ContractInquiry'
      }]
    }
  },
  methods: {
    go (name) {
      this.$router.push({
        name
      })
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}
</style>
