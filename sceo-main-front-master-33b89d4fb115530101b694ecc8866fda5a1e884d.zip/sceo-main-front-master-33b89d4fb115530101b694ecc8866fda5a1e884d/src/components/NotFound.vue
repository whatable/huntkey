<template>
  <div id="notFound" class="not-found">
    <!--<el-alert-->
    <!--title="找不到页面"-->
    <!--type="error"-->
    <!--description="你访问的页面被张坤偷吃了！！"-->
    <!--close-text="返回首页"-->
    <!--show-icon-->
    <!--@close="onClose"-->
    <!--&gt;-->
    <!--</el-alert>-->
    <h1>404</h1>
    <strong>哎呀，您要查看的页面似乎被吃了！</strong>
    <div class="button-group">
      <el-button @click="goHome">回到首页</el-button>
      <el-button @click="goBack" type="primary">返回上一级页面</el-button>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'not-found',
    methods: {
      goHome () {
        this.$router.push('/')
      },
      goBack () {
        this.$router.go(-1)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .not-found {
    box-sizing: border-box;
    color: #373C4F;
    width: 100%;
    height: 100%;
    background: url("../assets/images/not_found.png") no-repeat bottom center;
    text-align: center;
    padding-top: 100px;
    h1 {
      margin: 30px;
      font-size: 80px;
    }
    strong {
      font-size: 24px;
      font-weight: 100;
      margin-bottom: 25px;
      display: block;
    }
  }
</style>
