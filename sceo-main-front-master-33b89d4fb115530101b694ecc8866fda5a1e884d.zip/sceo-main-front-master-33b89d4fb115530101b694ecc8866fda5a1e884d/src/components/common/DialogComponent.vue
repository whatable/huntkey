<script>
  export default {
    name: 'dialog-component',
    props: ['component', 'props', 'customEvent', 'resolve'],
    mounted () {
      this.resolve(this.$refs.comp)
    },
    render (h) {
      return h(this.component, {
        ref: 'comp',
        props: this.props,
        on: this.customEvent
      })
    }
  }
</script>
