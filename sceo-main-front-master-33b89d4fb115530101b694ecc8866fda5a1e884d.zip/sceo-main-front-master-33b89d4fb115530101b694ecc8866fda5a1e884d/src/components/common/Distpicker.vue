<template>
  <div class="dist-picker">
    <el-cascader
      ref="cascader"
      :options="options"
      v-model="val"
      :placeholder="placeholder"
      :props="{label:settings.label,value:settings.value}"
      @active-item-change="itemChange"
      @change="handleChange">
    </el-cascader>
  </div>
</template>

<script>
  import _ from 'lodash'

  export default {
    name: 'distpicker',
    props: {
      type: {
        type: String,
        default: 'auto'
      },
      value: {
        required: true,
        type: Object | String
//        default () {
//          return {}
//        }
      },
      props: {
        type: Object,
        default () {
          return {}
        }
      },
      filterable: {
        type: Boolean,
        default: false
      },
      placeholder: {
        type: String,
        default: '请选择'
      }
    },
    created () {
      Object.assign(this.settings, this.props)
    },
    mounted () {
      this.cascader = this.$refs['cascader']
      this.loadProvinces()
    },
    methods: {
      init () {
        if (this.watchValue.length > 0) {
          this.setValue(this.watchValue)
        }
      },
      handleChange (val) {
        let rs = null
        if (this.type === 'text') {
          rs = JSON.stringify(this.val)
        } else if (this.type === 'array') {
          rs = this.val
        } else {
          rs = this.value
          this.$set(rs, this.settings.province, val[0])
          this.$set(rs, this.settings.city, val[1])
          this.$set(rs, this.settings.area, val[2])
        }
        this.$emit('input', rs)
      },
      itemChange (val) {
        let obj = {children: this.options}
        for (let i of val) {
          obj = _.find(obj.children, {'id': i})
        }
        if (obj.children.length < 1) {
          this.loadCity(obj).then(len => {
            if (len < 1) {
              this.val = val
              this.cascader.handlePick(val, true)
            }
          })
        }
      },
      loadProvinces () {
        this.$store.dispatch('dictStore/getProvinces')
          .then((data) => {
            this.options = data
            this.init()
          })
      },
      loadCity (obj) {
        return this.$store.dispatch('dictStore/getChildDeep', obj)
      },
      setValue (arr) {
        let province = _.find(this.options, {'id': arr[0]})
        if (arr[1] && province.children.length < 1) {
          this.loadCity(province).then(len => {
            let city = _.find(province.children, {'id': arr[1]})
            if (arr[2]) {
              this.loadCity(city)
            }
          })
        } else if (arr[2]) {
          let city = _.find(province.children, {'id': arr[1]})
          this.loadCity(city)
        }
        this.val = arr
      }
    },
    watch: {
      watchValue (val) {
        if (this.UTILS.arrContrast(val, this.val)) return false
        if (val.length < 1) {
          this.val = []
        } else {
          this.setValue(val)
        }
      }
    },
    computed: {
      watchValue () {
        let val = []
        if (this.type === 'text') {
          try {
            val = JSON.parse(this.value)
          } catch (e) {}
        } else if (this.type === 'array') {
          val = this.value
        } else {
          this.value[this.settings.province] && val.push(this.value[this.settings.province])
          this.value[this.settings.city] && val.push(this.value[this.settings.city])
          this.value[this.settings.area] && val.push(this.value[this.settings.area])
        }
        if (val === null) val = []
        return val
      }
    },
    data () {
      return {
        settings: {
          province: 'province',
          city: 'city',
          area: 'area',
          label: 'gare_name',
          value: 'id'
        },
        cascader: null,
        val: [],
        options: []
      }
    }
  }
</script>

<style scoped>
  .dist-picker {
    display: inline-block;
  }

  .el-cascader {
    width: 100%;
  }
</style>
