<template>
  <div class="rx-taskbar">
    <div class="rx-task" v-for="item in tasks" :key="item.id" :ref="item.id" @click="showTask(item.id)">
      <i v-if="item.icon" :class="`el-icon-${item.icon}`"></i>
      {{item.title}}
      <i class="rx-task-close el-icon-rx-close2" @click.stop="closeTask(item.id)"></i>
    </div>
  </div>  
</template>
<script>
  import Vue from 'vue'

  export default {
    created () {
      // 在全局注册任务栏
      if (!Vue.prototype.$taskBar) {
        Vue.prototype.$taskBar = this
      }
    },
    data () {
      return {
        tasks: []
      }
    },
    methods: {
      addTask ({icon, title, onShow, onClose}) {
        const id = new Date().getTime()
        this.tasks.push({
          id, title, onShow, onClose, icon
        })
        return id
      },
      // 关闭任务
      closeTask (id) {
        let onClose
        for (let index = 0; index < this.tasks.length; index++) {
          if (this.tasks[index].id === id) {
            this.$refs[id][0].style.opacity = 0
            onClose = this.tasks[index].onClose
            setTimeout(() => {
              this.tasks.splice(index, 1)
            }, 300)
            break
          }
        }
        if (onClose && typeof onClose === 'function') {
          onClose()
        }
      },
      // 切换任务
      showTask (id) {
        let onShow
        for (let index = 0; index < this.tasks.length; index++) {
          if (this.tasks[index].id === id) {
            this.$refs[id][0].style.opacity = 0
            onShow = this.tasks[index].onShow
            setTimeout(() => {
              this.tasks.splice(index, 1)
            }, 300)
            break
          }
        }
        if (onShow && typeof onShow === 'function') {
          onShow()
        }
      }
    }
  }
</script>
