<template>
  <div class="rx-window" :style="windowStyle" v-show="visible">
    <div class="rx-window-head" ref="header" @mousedown.prevent="dragStart" @dblclick="dblclickHeader">
      <div class="rx-window-title">
        <i v-if="icon" :class="`el-icon-${icon}`"></i>
        {{title}}
      </div>
      <div class="rx-window-operate">
        <div class="rx-window-operate-item" title="刷新">
          <i class="el-icon-rx-refresh"></i>
        </div>
        <!-- 有全局任务栏的时候才显示最小化 -->
        <div class="rx-window-operate-item" title="最小化" @click="minsizeWindow" v-if="$taskBar">
          <i class="el-icon-rx-window-minimize"></i>
        </div>
        <div class="rx-window-operate-item" title="最大化" v-show="state === 'normal'" @click="state = 'max'">
          <i class="el-icon-rx-window-maximize"></i>
        </div>
        <div class="rx-window-operate-item" title="还原" v-show="state === 'max'" @click="state = 'normal'">
          <i class="el-icon-rx-window-restore"></i>
        </div>
        <div class="rx-window-operate-item" title="关闭" @click="closeWindow">
          <i class="el-icon-rx-close2"></i>
        </div>
      </div>
    </div>
    <div class="rx-window-content" ref="content">
      <slot></slot>
    </div>
    <div class="rx-resize-button" @mousedown.prevent="resizeStart" v-show="state === 'normal'" v-if="resizeable"></div>
  </div>
</template>
<script>
  import Vue from 'vue'
  import _ from 'lodash'

  export default {
    name: 'rx-window',
    props: {
      // 窗口宽度
      width: Number,
      // 内容区高度
      height: Number,
      // 窗口位置，距离左边
      left: Number,
      // 窗口位置，距离顶部
      top: Number,
      // 窗口的标题
      title: String,
      // 窗口显示，隐藏
      value: Boolean,
      // 窗口的图标
      icon: String,
      // 是否可拖拽移动
      moveable: {
        type: Boolean,
        default: true
      },
      // 是否可改变大小
      resizeable: {
        type: Boolean,
        default: true
      }
    },
    created () {
      // 设置当前窗口的z-index
      if (!this.$windowStore) {
        Vue.prototype.$windowStore = {
          zIndex: this.zIndex,
          count: 1
        }
      } else {
        this.zIndex = ++this.$windowStore.zIndex
        this.$windowStore.count++
      }
      // 窗口是否展示
      this.visible = this.value
      // 根据参数设置窗口大小
      this.setWindowByProps()
      if (this.moveable) {
        // 拖拽事件定义
        window.document.addEventListener('mouseup', this.dragEnd)
        window.document.addEventListener('mousemove', this.dragMoving)
      }
      if (this.resizeable) {
        // 更改窗口大小事件定义
        window.document.addEventListener('mouseup', this.resizeEnd)
        window.document.addEventListener('mousemove', this.resizeMoving)
      }
    },
    mounted () {
      window.document.body.appendChild(this.$el)
      // 未设置高度，窗口高度自适应
      if (!this.height) {
        this.windowSize.height = this.$refs.content.clientHeight + this.$refs.header.clientHeight
      }
      // 适应当前窗口大小
      this.fixedSize()
    },
    computed: {
      windowStyle () {
        if (this.state === 'normal') {
          return {
            left: this.windowPosition.left + 'px',
            top: this.windowPosition.top + 'px',
            width: this.windowSize.width + 'px',
            height: this.windowSize.height + 'px',
            zIndex: this.zIndex
          }
        } else if (this.state === 'max') {
          return {
            left: '1px',
            right: '1px',
            top: '1px',
            bottom: '1px',
            zIndex: this.zIndex
          }
        }
      }
    },
    data () {
      return {
        // 窗口z-index默认是10000
        zIndex: 10000,
        id: '',
        // 是否展示
        visible: true,
        // 是否正在拖动
        draging: false,
        // 是否正在改变大小
        resizing: false,
        // 当前窗口大小, 默认500, 高度根据内容自适应
        windowSize: {
          width: 500
        },
        // 当前窗口位置，默认居中
        windowPosition: {
          left: window.innerWidth / 2 - 500 / 2,
          top: window.innerHeight * 0.2
        },
        // 当前窗口状态 normal, max, min 三种状态, 默认normal
        state: 'normal'
      }
    },
    watch: {
      value (value) {
        if (this.state === 'normal' || this.state === 'max') {
          this.visible = value
        } else if (this.state === 'min') {
          if (value) {
            this.state = 'normal'
            this.visible = value
          } else {
            // this.$taskBar.closeTask(this.id)
          }
        }
      }
    },
    methods: {
      setWindowByProps () {
        if (this.width) {
          this.windowSize.width = this.width
          this.windowPosition.left = window.innerWidth / 2 - this.width / 2
        }
        if (this.height) {
          this.windowSize.height = this.height
        }
        if (this.left) {
          this.windowPosition.left = this.left
        }
        if (this.top) {
          this.windowPosition.top = this.top
        }
      },
      // 拖动开始
      dragStart (event) {
        // 置顶
        if (this.zIndex < this.$windowStore.zIndex) {
          this.zIndex = ++this.$windowStore.zIndex
        }
        if (this.moveable && !this.draging && this.state === 'normal') {
          this.draging = true
          // 记录初始位置
          this.drarStartPosition = _.clone(this.windowPosition)
          // 记录初始鼠标触发事件位置
          this.eventPosition = {
            x: event.clientX,
            y: event.clientY
          }
        }
      },
      // 拖动中
      dragMoving (event) {
        if (!this.draging) return
        event.preventDefault()
        // 计算偏移量
        const offset = {
          x: event.clientX - this.eventPosition.x,
          y: event.clientY - this.eventPosition.y
        }
        this.windowPosition.left = this.drarStartPosition.left + offset.x
        this.windowPosition.top = this.drarStartPosition.top + offset.y
        // 适应窗口
        this.fixedPosition()
      },
      // 拖动结束
      dragEnd (event) {
        if (!this.draging) return
        event.preventDefault()
        this.draging = false
      },
      resizeStart (event) {
        if (this.resizeable && !this.resizing) {
          this.resizing = true
          window.document.body.style.cursor = 'se-resize'
          // 记录初始位置
          this.resizeStartSize = _.clone(this.windowSize)
          // 记录初始鼠标触发事件位置
          this.eventPosition = {
            x: event.clientX,
            y: event.clientY
          }
        }
      },
      resizeMoving (event) {
        if (!this.resizing) return
        event.preventDefault()
        const offset = {
          x: event.clientX - this.eventPosition.x,
          y: event.clientY - this.eventPosition.y
        }
        this.windowSize.width = this.resizeStartSize.width + offset.x
        this.windowSize.height = this.resizeStartSize.height + offset.y
        // 适应窗口
        this.fixedSize()
      },
      resizeEnd (event) {
        if (!this.resizing) return
        event.preventDefault()
        window.document.body.style.cursor = 'default'
        this.resizing = false
      },
      // 适应窗口位置，限定在window范围内
      fixedPosition () {
        if (this.windowPosition.left < 1) {
          this.windowPosition.left = 1
        }
        if (this.windowPosition.top < 1) {
          this.windowPosition.top = 1
        }
        if (this.windowPosition.left + this.windowSize.width > window.innerWidth - 1) {
          this.windowPosition.left = window.innerWidth - 1 - this.windowSize.width
        }
        if (this.windowPosition.top + this.windowSize.height > window.innerHeight - 1) {
          this.windowPosition.top = window.innerHeight - 1 - this.windowSize.height
        }
      },
      // 适应窗口大小
      fixedSize () {
        if (this.windowSize.width < 200) {
          this.windowSize.width = 200
        }
        if (this.windowSize.width > window.innerWidth - this.windowPosition.left - 1) {
          this.windowSize.width = window.innerWidth - this.windowPosition.left - 1
        }
        if (this.windowSize.height < 100) {
          this.windowSize.height = 100
        }
        if (this.windowSize.height > window.innerHeight - this.windowPosition.top - 1) {
          this.windowSize.height = window.innerHeight - this.windowPosition.top - 1
        }
        this.$refs.content.style.width = this.windowSize.width - 20 + 'px'
        this.$refs.content.style.height = this.windowSize.height - this.$refs.header.clientHeight - 20 + 'px'
      },
      // 关闭窗口
      closeWindow () {
        this.visible = false
        this.$emit('close')
        this.$emit('input', false)
      },
      dblclickHeader () {
        if (this.state === 'normal') {
          this.state = 'max'
        } else {
          this.state = 'normal'
        }
      },
      // 最小化窗口
      minsizeWindow () {
        const currentState = this.state
        this.state = 'min'
        this.visible = false
        this.id = this.$taskBar.addTask({
          title: this.title,
          icon: this.icon,
          onShow: () => {
            this.state = currentState
            this.visible = true
          },
          onClose: () => {
            this.closeWindow()
          }
        })
      }
    },
    beforeDestroy () {
      // 清除全局事件
      window.document.removeEventListener('mouseup', this.dragEnd)
      window.document.removeEventListener('mousemove', this.dragMoving)
      window.document.removeEventListener('mouseup', this.resizeEnd)
      window.document.removeEventListener('mousemove', this.resizeMoving)
    }
  }
</script>
<style scoped>
  
</style>
