<template>
  <div class="order-header">
    <div class="button-area" v-if="orderStatus !== '2'">
      <el-button type="primary" v-if="orderStatus === '1'" :disabled="editing" 
        @click="edit">编辑</el-button>
      <el-button type="primary" :disabled="!editing"
        @click="save" :loading="saveLoading">保存</el-button>
      <el-button type="primary" :disabled="!editing"
        @click="submit" :loading="saveLoading">提交</el-button>
      <el-button type="danger" v-if="orderStatus === '1'" :disabled="!editing"
        @click="remove" :loading="deleteLoading">删除</el-button>
    </div>
    <div class="header-info">
      <el-form inline label label-width="85px">
        <el-form-item label="申请单号">
          <el-input class="input" :disabled="true" :value="currentData.orderNumber"></el-input>
        </el-form-item>
        <el-form-item  label="申请人">
          <el-input class="input" :disabled="true" :value="currentData.name"></el-input>
        </el-form-item>
        <el-form-item label="申请部门/岗位" label-width="100px">
          <el-input class="input" :disabled="true" :value="currentData.deptPost"></el-input>
        </el-form-item>
        <el-form-item label="申请时间">
          <el-input class="input" :disabled="true" :value="currentData.date"></el-input>
        </el-form-item>
      </el-form>
    </div>
    <!-- <slot></slot> -->
  </div>
</template>
<script>
  import { mapGetters } from 'vuex'
  import moment from 'moment'

  export default {
    name: 'orderCreate',
    props: {
      // 单据状态
      orderStatus: {
        type: String,
        default: '0'
      },
      // 单据编号, orderState = 1,2的时候传
      orderNumber: String,
      // 单据ID, orderState = 1,2的时候传
      orderId: String,
      // 单据类名, orderState = 1的时候传
      orderClassName: String,
      // 申请人姓名, orderState = 1,2的时候传
      name: String,
      // 申请人部门, orderState = 1,2的时候传
      deptName: String,
      // 申请人岗位, orderState = 1,2的时候传
      postName: String,
      // 申请时间, orderState = 1,2的时候传
      orderDate: Number
    },
    computed: {
      ...mapGetters({
        currentUser: 'userInfoStore/getCurrentUser',
        currentDept: 'userInfoStore/getCurrentDept',
        currentPost: 'userInfoStore/getCurrentPost'
      }),
      currentData () {
        if (!this.orderStatus || this.orderStatus === '0') {
          return {
            orderNumber: this.orderNumber,
            name: `${this.currentUser.remp_name}/${this.currentUser.remp_no}`,
            deptPost: `${this.currentDept.mdep_name}/${this.currentPost.rpos_name}`,
            date: moment().format('YYYY-MM-DD')
          }
        } else {
          return {
            orderNumber: this.orderNumber,
            name: this.name,
            deptPost: `${this.deptName}/${this.postName}`,
            date: moment(this.orderDate).format('YYYY-MM-DD')
          }
        }
      }
    },
    created () {
      if (!this.orderStatus || this.orderStatus === '0') {
        this.editing = true
      } else {
        this.editing = false
      }
    },
    data () {
      return {
        editing: false,
        saveLoading: false,
        deleteLoading: false
      }
    },
    methods: {
      edit () {
        this.editing = true
        this.$emit('edit')
      },
      save () {
        this.saveLoading = true
        this.$emit('save', () => {
          this.saveLoading = false
        })
      },
      submit () {
        this.saveLoading = true
        this.$emit('submit', () => {
          this.saveLoading = false
        })
      },
      // 删除单据
      remove () {
        this.$confirm('确定删除此临时单？', '提示').then(() => {
          this.deleteLoading = true
          this.UTILS.execUtil('order', 'deleteOrder', {
            orderTable: this.orderClassName,
            orderId: this.orderId
          }).then(() => {
            this.$emit('remove')
            this.deleteLoading = false
          }).catch(() => {
            this.deleteLoading = false
          })
        })
      },
      // 设置编辑状态
      setEditState (state) {
        this.editing = state
      }
    }
  }
</script>
<style scoped lang="scss">
  .order-header{
    .button-area{
      height: 40px;
      line-height: 40px;
      margin-left: 20px;
    }
    .header-info{
      margin-top: 10px;
    }
    .input {
      width: 130px;
    }
  }
</style>
