<template>
  <div class="z-tree" ref="zTree">
    <el-popover
      v-model="popoverShow"
      @show="computeWidth"
      :disabled="disabled"
      popper-class="z-tree-popper"
      ref="popoverTree"
      placement="bottom"
      :width="width"
      :visible-arrow="false"
      trigger="click">
      <el-input v-show="filter" v-model="filterInput" icon="search"></el-input>
      <div class="z-tree-box" @drop="onDrop" @dragover="onDragOver">
        <span v-show="dragLine.show" class="drag-line" :class="{inner:dragLine.pos===0}"
              :style="{top:dragLine.Y+'px',width:dragLine.W+'px'}"></span>
        <z-tree-node v-for="(child,index) in data" :node="child" :index="index" :parent="node"
                     :key="child[nodeKey] || child[defaultProps.label]"
                     v-model="currentValue" :defaultProps="defaultProps"
                     :tree="tree" @autoPopover="autoPopover" @accordion="onAccordion"></z-tree-node>
      </div>
    </el-popover>
    <div class="z-tree-select" v-popover:popoverTree :class="{'is-disabled':disabled}" @mouseenter="mouseOver=true"
         @mouseleave="mouseOver=false">
      <el-tag type="primary" v-for="item in selectNode" :key="item[nodeKey]">{{item[defaultProps.label]}}</el-tag>
      <i v-show="!mouseOver || currentValue===''" class="icon el-icon-edit"></i>
      <i v-show="mouseOver && currentValue!==''" class="icon el-icon-circle-cross" @click.stop="cleanSelect"></i>
    </div>
  </div>
</template>

<script>
  import emitter from './emitter'
  import ZTreeNode from './ZTreeNode.vue'
  export default {
    components: {ZTreeNode},
    mixins: [emitter],
    name: 'ZTree',
    props: {
      // 按层级默认展开
      extendLevel: {
        type: Number,
        default: -1
      },
      // 按值默认展开
      extendValue: {
        type: Array,
        default () {
          return []
        }
      },
      accordion: {
        type: Boolean,
        default: false
      },
      // 按层级禁止
      disableLevel: {
        type: Number,
        default: -1
      },
      // 按值禁止
      disableValue: {
        type: Array,
        default () {
          return []
        }
      },
      // 自动关闭
      autoClose: {
        type: Boolean,
        default: false
      },
      // 是否禁用
      disabled: {
        type: Boolean,
        default: false
      },
      // 是否开启过滤
      filter: {
        type: Boolean,
        default: false
      },
      // 是否可选父节点
      noParent: {
        type: Boolean,
        default: false
      },
      // 此属性为真不可选择
      dChoose: {
        type: String,
        default: 'dChoose'
      },
      // 是否多选
      isCheck: {
        type: Boolean,
        default: false
      },
      // 父节点是否同时操作子节点
      checkAll: {
        type: Boolean,
        checkAll: false
      },
      // 值的KEY
      nodeKey: {
        type: String,
        default: 'id'
      },
      // 属性映射
      defaultProps: {
        type: Object,
        default () {
          return {
            children: 'children',
            label: 'label',
            value: 'value'
          }
        }
      },
      // 默认值
      value: {
        default: ''
      },
      // 树的数据
      data: {
        type: Array,
        default: []
      },
      // 自定义渲染内容
      renderContent: {
        type: Function,
        default: null
      }
    },
    created () {
      if (this.isCheck) {
        if (!(this.value instanceof Array)) {
          this.checked = [this.value]
        } else {
          this.checked = this.value
        }
      }
      if (this.value) this.currentValue = this.value
    },
    mounted () {},
    watch: {
      value (val) {
        this.currentValue = val
      },
      currentValue (val) {
        this.refreshSelectNode(val)
        this.dispatch('ElFormItem', 'el.form.change', val)
      },
      data () {
        if (this.currentValue) this.refreshSelectNode(this.currentValue)
      },
      isCheck () {
        this.selectNode = []
        this.currentValue = ''
      },
      checked (val) {
        this.$emit('input', val)
      },
      // 过滤方法
      filterInput (v) {
        const t = this
        const filterNodeMethod = function (node, val) {
          return node[t.defaultProps.label].indexOf(val) > -1
        }
        const traverse = function (node) {
          let ch = node[t.defaultProps.children]
          ch.forEach(nd => {
            nd.visible = filterNodeMethod(nd, v)
            traverse(nd)
          })
          if (!node.visible && ch.length) {
            let allHidden = true
            ch.forEach(child => {
              if (child.visible) allHidden = false
            })
            node.visible = allHidden === false
          }
        }
        traverse(this.node)
      }
    },
    data () {
      return {
        popoverShow: false,
        mouseOver: false,
        width: 100,
        node: {
          [this.defaultProps.children]: this.data,
          [this.defaultProps.label]: 'root',
          [this.defaultProps.value]: 'root',
          index: -1
        }, // root节点
        nodeAll: [],
        selectNode: [],
        filterInput: '', // 过滤内容
        checked: [], // 选中对象值
        tree: this, // 树组件对象
        currentValue: '',
        dragNodes: {
          Node: null,
          parent: null,
          index: -1
        },
        dragLine: {
          show: false,
          Y: 0,
          W: 0,
          pos: 1 // 位置 0 内, 1上 2 下
        }
      }
    },
    methods: {
      /**
       * 按值选中
       * @param val
       */
      selectByVal (val) {
        if (this.isCheck) {
          if (!(val instanceof Array)) {
            val = val ? [val] : []
          }
          this.nodeAll.forEach(it => {
            if (val.indexOf(it[this.defaultProps.value]) > -1) {
              it.checked = true
              it.onChange()
            } else {
              it.checked = false
              it.onChange()
            }
          })
        }
        this.currentValue = val
      },
      computeWidth () {
        this.width = this.$refs.zTree.clientWidth
      },
      /**
       * 刷新选中内容显示
       * @param val
       */
      refreshSelectNode (val) {
        if (!val || val === '' || val.length < 1 || this.nodeAll.length < 1) {
          this.selectNode = []
        } else {
          let nodes = []
          if (val instanceof Array) {
            val.forEach(it => {
              let v = this.find(this.nodeAll, this.defaultProps.value, it)
              if (v) nodes.push(v)
            })
          } else {
            let v = this.find(this.nodeAll, this.defaultProps.value, val)
            if (v) nodes.push(v)
          }
          this.selectNode = nodes
        }
        this.$emit('input', val)
      },
      find (Array, key, val) {
//        let r = null
//        Array.forEach(it => {
//          if (it[key] === val) {
//            r = it
//            return false
//          }
//        })
//        return r
        for (let i = 0; i < Array.length; i++) {
          if (Array[i][key] === val) return Array[i]
        }
      },
      /**
       * 清理选中
       */
      cleanSelect () {
        this.selectByVal('')
      },
      /**
       * 自动关闭
       */
      autoPopover () {
        if (!this.autoClose) return
        this.popoverShow = false
      },
      /**
       * 手风琴监听
       * @param node
       */
      onAccordion (node) {
        this.accordionFilter(this.node[this.defaultProps.children], node)
      },
      /**
       * 手风琴过滤
       * @param nodes
       * @param node
       */
      accordionFilter (nodes, node) {
        nodes.forEach(it => {
          if (it !== node) {
            it.childrenShow = false
          }
        })
      },
      /**
       * 拖拽过程
       * @param ev
       * @returns {boolean}
       */
      onDragOver (ev) {
        if (this.dragNodes.Node === null) return false
        let el = this.dragCheck(ev)
        if (el === false) return true
        this.dragLine.W = el.clientWidth - parseInt(el.style.paddingLeft) + 10
        if (ev.offsetY < 10) {
          this.dragLine.Y = el.offsetTop
          this.dragLine.pos = 1
        } else if (ev.offsetY > 25) {
          this.dragLine.Y = el.offsetTop + el.offsetHeight
          this.dragLine.pos = 2
        } else {
          this.dragLine.Y = el.offsetTop + el.offsetHeight
          this.dragLine.W -= 25
          this.dragLine.pos = 0
        }
        ev.preventDefault()
      },
      /**
       * 拖拽放置
       * @param ev
       * @returns {boolean}
       */
      onDrop (ev) {
        let el = this.dragCheck(ev)
        if (el === false) return true
        let targetIndex = parseInt(el.getAttribute('data-index')) // 目标节点针对 父节点 索引
        const targetParentIndex = parseInt(el.getAttribute('data-parent')) // 目标父节点针对 nodeAll 索引
        let targetParent = targetParentIndex === -1 ? this.node : this.nodeAll[targetParentIndex]
        if (this.dragLine.pos === 0) {
          // 如果为0 则表示放入目标对象内，父对象改变，索引默认设置为0
          targetParent = targetParent[this.defaultProps.children][targetIndex]
          targetIndex = 0
        } else if (targetParent === this.dragNodes.parent && this.dragLine.pos === 1 && this.dragNodes.index < targetIndex) {
          // 如果为1 表示 放置于目标对象上方，若拖动对象与目标对象同父对象且在其之上，则目标对象索引需-1
          targetIndex--
        } else if (this.dragLine.pos === 2 && (this.dragNodes.index > targetIndex || targetParent !== this.dragNodes.parent)) {
          // 如果为2 表示 放置于目标对象之下，若拖动对象与目标对象不同父对象，或者同对象在其之下，则目标对象索引需+1
          targetIndex++
        }
        this.dragNodes.parent[this.defaultProps.children].splice(this.dragNodes.index, 1)
        targetParent[this.defaultProps.children].splice(targetIndex, 0, this.dragNodes.Node)
      },
      /**
       * 拖拽检查
       * @param ev
       * @returns {boolean}
       */
      dragCheck (ev) {
        let el = ev.target
        if (el.className === 'drag-line') return false
        if (el.className === 'z-tree-node__content is-drag' || el.className === 'z-tree-node is-drag') return false
        if (el.className === 'z-tree-node') el = el.childNodes[0]
        if (el.className.indexOf('z-tree-node__content') === -1) el = this.getParentsNode(el.parentNode, 'z-tree-node__content')
        if (el === false) return false
        if (this.getParentsNode(el.parentNode, 'z-tree-node is-drag') !== false) return false
        return el
      },
      /**
       * 根据完整className获取父节点
       * @param el
       * @param className
       * @returns {*}
       */
      getParentsNode (el, className) {
        if (!el) return false
        return el.className && el.className.indexOf(className) > -1 ? el : this.getParentsNode(el.parentNode, className)
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
  .z-tree {
    user-select: none;
    position: relative;
  }

  .z-tree-select {
    background-color: #fff;
    cursor: pointer;
    position: relative;
    border-radius: 4px;
    border: 1px solid #bfcbd9;
    box-sizing: border-box;
    padding: 3px 23px 3px 10px;
    min-height: 32px;
    line-height: 22px;
  }

  .z-tree-select.is-disabled {
    background-color: #eef1f6;
    border-color: #d1dbe5;
    color: #bbb;
    cursor: not-allowed;
  }

  .z-tree-select:hover {
    border-color: #8391a5;
  }

  .z-tree-select .icon {
    position: absolute;
    right: 8px;
    top: 8px;
  }

  .z-tree-select .el-tag {
    margin-right: 2px;
    margin-bottom: 2px;
  }

  .z-tree-popper {
    user-select: none;
    box-sizing: border-box;
    padding: 10px 0;
    /*width: 100%;*/

  }

  .z-tree-popper[x-placement^=bottom] {
    margin-top: 5px;
  }

  .z-tree-box {
    cursor: default;
    background: #fff;
    max-height: 300px;
    overflow: auto;
    position: relative;
    /*border: 1px solid #d1dbe5;*/
  }

  .z-tree-node {
    /*border: 1px dashed #fff;*/
  }

  .z-tree-node .is-disabled {
    /*color: #ccc;*/
  }

  .z-tree-node .z-tree-node__content {
    line-height: 36px;
    height: 36px;
    cursor: pointer;
    padding: 0 10px;
  }

  .z-tree-node .z-tree-node__content:hover, .z-tree-node__content.is-drag {
    background: #e4e8f1;
  }

  .z-tree-node .z-tree-node__content.is-select {
    color: #fff;
    background: #20a0ff;
  }

  /*.z-tree-node > .z-tree-node__children {*/
  /*padding-left: 15px;*/
  /*}*/

  .z-tree-node .z-tree-node__icon {
    transition: all 0.3s;
  }

  .z-tree-node .z-tree-node__icon.is-extend {
    transform: rotate(90deg);
  }

  .z-tree-node .z-tree-node__icon.is-hidden {
    visibility: hidden;
  }

  .drag-line {
    display: block;
    position: absolute;
    border: 1px solid #666;
    right: 0;
    transition: all .1s;
    /*width: 100%;*/
  }

  .drag-line.inner {
    border-style: dashed;
  }
</style>
