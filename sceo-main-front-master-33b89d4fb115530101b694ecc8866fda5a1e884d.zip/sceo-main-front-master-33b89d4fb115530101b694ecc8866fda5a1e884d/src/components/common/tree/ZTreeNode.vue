<template>
  <div class="z-tree-node"
       :class="{'is-drag':tree.dragNodes.Node === node}"
       v-show="tree.filter===false || tree.filterInput==='' || node.visible"
       draggable="true"
       @dragstart.stop="onDragStart" @dragend.stop="onDragEnd">
    <div class="z-tree-node__content"
         :class="{'is-select':isSelect,'is-disabled':isDisable,'is-drag':tree.dragNodes.Node === node}"
         :style="{'padding-left':(depth*15+10)+'px'}"
         @click.stop="onClick" :data-index="index" :data-parent="parent?parent.index:-1">
      <span class="z-tree-node__icon el-icon-caret-right"
            :class="{'is-extend':node.childrenShow,'is-hidden':!node[defaultProps.children] || node[defaultProps.children].length<1}"></span>
      <el-checkbox v-if="tree.isCheck" v-model="node.checked" :label="node" :indeterminate="isIndeterminate"
                   @click.native.stop="" @change="onChange" :disabled="isDisable">&nbsp;
      </el-checkbox>
      <!--<label class="z-tree-node__label">{{node[defaultProps.label]}}</label>-->
      <node-content :tree="tree" :node="node"></node-content>
    </div>
    <el-collapse-transition>
      <div class="z-tree-node__children" v-show="node.childrenShow" v-if="node[defaultProps.children]">
        <z-tree-node v-for="(child,cIndex) in node[defaultProps.children]" :node="child" :index="cIndex" :parent="node"
                     :key="child.key || child[defaultProps.label]"
                     v-model="currentValue" :depth="depth+1" :tree="tree"
                     @childrenChecked="childrenChecked" @accordion="onAccordion"
                     :defaultProps="defaultProps"></z-tree-node>
      </div>
    </el-collapse-transition>
  </div>
</template>

<script>
  export default {
    name: 'ZTreeNode',
    props: {
      index: {
        type: Number,
        default: -1
      },
      // 默认值
      value: {},
      // 父节点数据
      parent: {
        type: Object,
        default: null
      },
      // 自身节点数据
      node: {
        type: Object,
        default: {}
      },
      // 深度
      depth: {
        type: Number,
        default: 0
      },
      // 树组件对象
      tree: {
        type: Object,
        default: null
      },
      // 属性映射
      defaultProps: {
        type: Object,
        default () {
          return {
            children: 'children',
            label: 'label',
            value: 'value'
          }
        }
      }
    },
    components: {
      NodeContent: {
        props: {
          tree: {
            required: true
          },
          node: {
            required: true
          }
        },
        render (h) {
          if (this.tree.renderContent) {
            return this.tree.renderContent(h, {tree: this.tree, node: this.node})
          } else {
            return h('label', {
              'class': 'z-tree-node__label'
            }, [this.node[this.tree.defaultProps.label]])
          }
        }
      }
    },
    created () {
      if (typeof this.node.checked === 'undefined' && this.tree.isCheck) {
        this.$set(this.node, 'checked', this.currentValue.indexOf(this.node[this.defaultProps.value]) > -1)
      }
      if (typeof this.node.isIndeterminate === 'undefined') {
        this.$set(this.node, 'isIndeterminate', false)
      }
      if (typeof this.node.childrenShow === 'undefined') {
        this.$set(this.node, 'childrenShow', false)
      }
      if (typeof this.node[this.defaultProps.children] === 'undefined' || this.node[this.defaultProps.children] === null) {
        this.$set(this.node, this.defaultProps.children, [])
      }
      if (typeof this.node[this.defaultProps.label] === 'undefined') {
        this.$set(this.node, this.defaultProps.label, this.node.label)
      }
      this.node.onChange = this.onChange
      this.node.index = this.tree.nodeAll.length
      this.tree.nodeAll.push(this.node)
    },
    mounted () {
      if (!this.tree.accordion) {
        if (this.depth <= this.tree.extendLevel) this.node.childrenShow = true
        if (this.tree.extendValue.indexOf(this.node[this.defaultProps.value]) > -1) this.node.childrenShow = true
      }
      this.childrenChecked()
    },
    computed: {
      isSelect () {
        return this.node[this.defaultProps.value] === this.currentValue
      },
      isDisable () {
        return this.depth <= this.tree.disableLevel || this.tree.disableValue.indexOf(this.node[this.defaultProps.value]) > -1
      }
    },
    data () {
      return {
        currentValue: this.value,
        isIndeterminate: false
      }
    },
    watch: {
      currentValue () {
        this.$emit('input', this.currentValue)
        this.$emit('autoPopover')
      },
      value () {
        this.currentValue = this.value
      },
      'node.checked' (val) {
        let i = this.tree.checked.indexOf(this.node[this.defaultProps.value])
        if (val) {
          if (i < 0) {
            this.tree.checked.push(this.node[this.defaultProps.value])
          }
        } else {
          if (i > -1) {
            this.tree.checked.splice(this.tree.checked.indexOf(this.node[this.defaultProps.value]), 1)
          }
        }
      },
      'tree.filterInput' (val) {
        this.node.childrenShow = true
      },
      'tree.isCheck' () {
        this.node.checked = false
      }
    },
    methods: {
      /**
       * 点击节点事件
       */
      onClick () {
        this.node.childrenShow = !this.node.childrenShow
        if (this.tree.accordion && this.node[this.defaultProps.children].length > 0) {
          this.$emit('accordion', this.node)
        }
        if (this.tree.isCheck) return
        if (this.node[this.tree.dChoose]) return
        if (this.isDisable) return
        if (this.tree.noParent && this.node[this.defaultProps.children].length > 0) return
        this.currentValue = this.node[this.defaultProps.value]
      },
      /**
       * 选择框改变事件
       */
      onChange () {
        if (!this.tree.checkAll) return
        this.childrenChange(this.node, this.node.checked)
        this.childrenChecked()
        this.$emit('childrenChecked')
      },
      /**
       * 批量子节点选中状态变更
       * @param node 根节点
       * @param val 选中状态
       */
      childrenChange (node, val) {
        node[this.defaultProps.children].forEach(nd => {
          nd.checked = val
          this.childrenChange(nd, val)
        })
      },
      /**
       * 子节点选中状态检查
       */
      childrenChecked () {
        if (this.node[this.defaultProps.children].length < 1) return
        let n = 0
        this.node[this.defaultProps.children].forEach(nd => {
          if (nd.checked) n++
          else if (nd.isIndeterminate) n += 0.1
        })
        let l = this.node[this.defaultProps.children].length
        this.node.checked = n === l
        this.node.isIndeterminate = this.isIndeterminate = n > 0 && n < l

        this.$emit('childrenChecked')
      },
      /**
       * 手风琴监听
       * @param node
       */
      onAccordion (node) {
        this.tree.accordionFilter(this.node[this.defaultProps.children], node)
      },
      /**
       * 拖拽开始
       */
      onDragStart () {
        this.tree.dragNodes.parent = this.parent
        this.tree.dragNodes.index = this.index
        this.tree.dragNodes.Node = this.node
        this.tree.dragLine.show = true
      },
      /**
       * 拖拽结束
       * @param ev
       */
      onDragEnd (ev) {
        this.tree.dragNodes.parent = null
        this.tree.dragNodes.index = -1
        this.tree.dragNodes.Node = null
        this.tree.dragLine.show = false
        ev.preventDefault()
      }
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style>
</style>
