import locale from 'element-ui/lib/locale/lang/en'
import home from './home.json'

export default {
  // elementUI 国际化
  ...locale,
  // title
  FORM_DESIGNER_TITLE: 'form desinger demo',
  message: 'This is a message',
  FROM_OPERATIONS: 'Form Operations:',
  // // 首页
  home
}
