import locale from 'element-ui/lib/locale/lang/zh-CN'
import home from './home.json'

export default {
  // elementUI 国际化
  ...locale,
  // title
  FORM_DESIGNER_TITLE: '表单设计器DEMO',
  message: '这是一条消息',
  FROM_OPERATIONS: '表单操作',
  // 首页
  home
}
