import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
// elementUI样式
// import 'element-ui/lib/theme-chalk/index.css'
import './assets/theme-editor/theme/index.css'
// 自定义样式
import './assets/fonts/icon.css'
import './assets/themes/default/css/style.scss'
import utils from './utils'
import axios from 'axios'
// 国际化
import VueI18n from 'vue-i18n'
import I18nMessages from './i18n'
import ElementLocale from 'element-ui/lib/locale'

Vue.config.productionTip = false

// 工具方法，全局配置
Vue.prototype.UTILS = utils
// 事件池
Vue.prototype.$eventBus = new Vue()

Vue.use(ElementUI)
Vue.use(VueI18n)
const i18n = new VueI18n({
  locale: 'zh-CN', // set locale
  messages: I18nMessages // set locale messages
})
// document.getElementsByTagName('title')[0].innerText = i18n.t('title')
ElementLocale.i18n((key, value) => i18n.t(key, value))
// window窗口变化，记录窗口大小
window.onresize = () => {
  store.commit('windowStore/refresh')
}

// 注册页面接收函数
window.onmessage = function (message) {
  if (message.source === window) return
  if (message.data.eventType) {
    const callback = store.state.windowStore.eventBus[message.data.eventType]
    callback(message.data)
  }
}
//  function getRequest (url) {
//    var theRequest = {}
//    if (url.indexOf('?') !== -1) {
//      var str = url.substr(url.indexOf('?') + 1)
//      const strs = str.split('&')
//      for (var i = 0; i < strs.length; i++) {
//        theRequest[strs[i].split('=')[0]] = (strs[i].split('=')[1])
//      }
//    }
//    return theRequest
//  }
// 获取全局配置文件，初始化vue组件
axios.create().get('/static/config/project-config.json?_=' + new Date().getTime()).then(data => {
  // 获取配置文件
  Vue.prototype.CONFIG = data.data
  store.commit('windowStore/initConfig', data.data)
//  console.log(1)
//  loadVue()
  store.dispatch('userInfoStore/init').then(data => {
    loadVue()
  })
  // 从URL中获得token
//  const urlObject = getRequest(window.location.href)
//  if (urlObject.jwt) {
//    const jwt = urlObject.jwt
//    // 保存token数据到sessionStorage中
//    sessionStorage.setItem('JWT', jwt)
//    // 设置headers
//    axios.defaults.headers.common['Authorization'] = jwt
//    // 保存到vuex
//    store.commit('userInfoStore/setJwt', jwt)
//    // 删除URL中的jwt
//    window.location.href = window.location.href.substr(0, window.location.href.indexOf('?'))
//    // 获取用信息
//    getUserInfo().then(data => {
//      store.commit('userInfoStore/setUserInfo', data)
//      loadVue()
//    })
//  } else {
//    const jwt = sessionStorage.getItem('JWT') || '1234'
//    if (jwt) {
//      // 设置headers
//      axios.defaults.headers.common['Authorization'] = jwt
//      // 保存到vuex
//      store.commit('userInfoStore/setJwt', jwt)
//      getUserInfo().then(data => {
//        store.commit('userInfoStore/setUserInfo', data)
//        loadVue()
//      })
//    } else {
//      // 未登录
//      // loadVue()
//      // 跳转到登录页
//      window.location.href = `${utils.getConfig('loginHost')}`
//    }
//  }
})

// 加载页面
function loadVue () {
  /* eslint-disable no-new */
  new Vue({
    el: '#app',
    i18n,
    router,
    store,
    template: '<App/>',
    components: {App}
  })
}

window.parseString = function (string) {
  if (string === null) return ''
  return string
}
// function getUserInfo () {
//   return utils.execUtil('people', 'getEcosystemSession', {})
// }
