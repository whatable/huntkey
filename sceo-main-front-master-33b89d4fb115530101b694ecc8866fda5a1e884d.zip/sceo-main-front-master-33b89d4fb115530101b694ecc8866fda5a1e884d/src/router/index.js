import Vue from 'vue'
import Router from 'vue-router'
import * as projectRouter from './project-router'
import store from '../store'

Vue.use(Router)

let projectRouterList = []

for (let index in projectRouter) {
  projectRouterList.push(projectRouter[index])
}

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      // component: () => import('@/components/Hello')
      redirect: '/id/mine'
    },
    ...projectRouterList,
    {path: '*', component: () => import('../components/NotFound')}
  ]
})
const except = [
  'Login',
  'Register',
  'ForgetPassword'
]
router.beforeEach((to, from, next) => {
  if (store.getters['userInfoStore/logout'] && except.indexOf(to.name) === -1) {
    next('/login')
  } else {
    next()
  }
})
export default router
