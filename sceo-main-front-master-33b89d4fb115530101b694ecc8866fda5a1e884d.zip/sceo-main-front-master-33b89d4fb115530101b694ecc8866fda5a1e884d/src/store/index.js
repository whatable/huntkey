import Vuex from 'vuex'
import Vue from 'vue'
import * as projectStore from './project-store'
import windowStore from './modules/window-store'
import dictStore from './modules/dict-store'
import userInfoStore from './modules/userInfo-store'

Vue.use(Vuex)

// 强制使用命名空间
for (var key in projectStore) {
  projectStore[key].namespaced = true
}

const _opt = {
  modules: {
    ...projectStore,
    windowStore,
    dictStore,
    userInfoStore
  },
  // 严格模式
  strict: process.env.NODE_ENV === 'development'
}

export default new Vuex.Store(_opt)
