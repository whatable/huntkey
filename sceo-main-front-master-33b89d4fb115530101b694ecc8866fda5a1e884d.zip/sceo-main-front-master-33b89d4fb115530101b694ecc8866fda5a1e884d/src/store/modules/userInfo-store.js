import axios from 'axios'
import utils from '../../utils'

const Base64 = require('js-base64').Base64
const addrFormat = function (addr) {
  if (addr === null || addr === '') {
    return {
      province: '',
      city: '',
      addr: ''
    }
  }
  return JSON.parse(addr)
}
const userInfoFormat = function (data) {
  let addr = addrFormat(data.epeo_home_addr)
  return {
    sceoNumber: '', // SCEO号码
    epeo_name_ni: data.epeo_name_ni, // 昵称
    epeo_fist_name: data.epeo_fist_name, // 姓
    epeo_last_name: data.epeo_last_name, // 名
    fullName: window.parseString(data.epeo_fist_name) + window.parseString(data.epeo_last_name),
    certificateType: 1,
    epeo_card_no: data.epeo_card_no,
    epeo_tel: data.epeo_tel,
    epeo_mail: data.epeo_mail,
    epeo_gender: data.epeo_gender || 'M',
    epeo_nation: data.epeo_nation,
    epeo_nationality: data.epeo_nationality,
    province: addr.province,
    provinceText: '',
    city: addr.city,
    cityText: '',
    addr: addr.addr,
    epeo_self_eval: data.epeo_self_eval,
    epeo_photourl: data.epeo_photourl
  }
}

const state = {
  jwt: null,
  jwtExp: 0,
  userId: null,
  userInfo: {},
  user: null
}

const getters = {
  getCurrentUser: state => state.userInfo.currentStatus.currentStaff,
  getCurrentDept: state => state.userInfo.currentStatus.depttreeEntity,
  getCurrentEnterprise: state => state.userInfo.currentStatus.currentEnterprise,
  getCurrentPost: state => state.userInfo.currentStatus.currentPosition,
  getUser: state => state.user || {},
  getJWT: state => state.jwt,
  logout (state) {
    return state.user === null
  }
}

const mutations = {
  setJwt (state, jwt) {
    state.jwt = jwt
  },
  setJwtExp (state, jwtExp) {
    state.jwtExp = jwtExp
  },
  setUserId (state, userId) {
    state.userId = userId
  },
  setUserInfo (state, userInfo) {
    state.userInfo = userInfo
  },
  setUser (state, user) {
    state.user = user
  },
  setProvinceText (state, provinceText) {
    state.user.provinceText = provinceText
  },
  setCityText (state, cityText) {
    state.user.cityText = cityText
  }
}
const actions = {
  init ({commit, dispatch}) {
    let JWT = window.sessionStorage.getItem('JWT')
    let userId = null
    let exp = 0
    if (JWT) {
      axios.defaults.headers.common['Authorization'] = JWT
      let jwts = JWT.split('.')
      let tmp = Base64.decode(jwts[1])
      if (tmp) {
        tmp = JSON.parse(tmp)
        exp = tmp.exp
        userId = tmp.sub.id
      }
    }
    commit('setJwt', JWT)
    commit('setJwtExp', exp)
    commit('setUserId', userId)
    return dispatch('loadUser')
  },
  loadUser ({commit, dispatch, state}) {
    return new Promise((resolve, reject) => {
      if (state.jwt === null) {
        commit('setUser', null)
        commit('setUserInfo', null)
        return resolve('none')
      }
      utils.execUtil('people', 'queryPeopleInfo', null)
        .then(data => {
          data = data.peopleEntity
          data = userInfoFormat(data)
          commit('setUser', data)
          dispatch('dictStore/showProvince', data.province, {root: true}).then(provinceText => {
            // 回显用户信息
            commit('setProvinceText', provinceText)
            dispatch('dictStore/showCity', {
              provinceId: data.province,
              cityId: data.city
            }, {root: true}).then(cityText => {
              // 回显用户信息
              commit('setCityText', cityText)
              resolve(data)
            })
          })
//          resolve(data)
        })
        .catch(err => {
          console.log(err)
          reject(err)
        })
    })
  },
  logout ({commit}, router) {
    utils.execUtil('people', 'loginOut', null)
      .then(data => {
        window.sessionStorage.removeItem('JWT')
//        commit('taskClear')
        this.dispatch('userInfoStore/init')
        router.push('id/login')
      })
    // Lockr.set('jwt', null)
  }
}
export default {
  namespaced: true,
  state,
  mutations,
  getters,
  actions
}
