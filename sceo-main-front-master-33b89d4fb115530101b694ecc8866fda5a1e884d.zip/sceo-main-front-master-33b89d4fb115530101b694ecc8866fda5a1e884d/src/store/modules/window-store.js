import _ from 'lodash'

const state = {
  windowHeight: window.innerHeight,
  windowWidth: window.innerWidth,
  eventBus: {
  },
  config: {
  }
}

const getters = {
  windowSize: state => {
    return {
      width: state.windowWidth,
      height: state.windowHeight
    }
  }
}

const mutations = {
  refresh (state) {
    state.windowHeight = window.innerHeight
    state.windowWidth = window.innerWidth
  },
  addEvent (state, {type, callback}) {
    state.eventBus[type] = callback
  },
  initConfig (state, config) {
    _.assign(state.config, config)
  }
}

export default {
  namespaced: true,
  state,
  getters,
  mutations
}
