import validate from './validate'
import store from '@/store'
import axios from 'axios'
import utils from '@/utils'

export default {
  validate,
  /**
   * 对象复制数据，不会增加目标对象字段数量
   * @return {[type]} [description]
   */
  setDataFromOther (target, src) {
    for (let index in target) {
      target[index] = src[index]
    }
  },
  // 根据字典code和value获得字典名称
  getDictName (code, value) {
    const dicts = store.state.dictStore.dicts[code]
    const dict = dicts.find(item => item.value === value)
    if (dict) {
      return dict.label
    } else {
      return ''
    }
  },
  getEnumName (code, value) {
    const dicts = store.state.dictStore.dicts[code]
    const dict = dicts.find(item => item.info_code.trim() === value.trim())
    if (dict) {
      return dict.word_name
    } else {
      return ''
    }
  },
  // 获得配置文件信息
  getConfig (key) {
    if (key) {
      return store.state.windowStore.config[key]
    } else {
      return store.state.windowStore.config
    }
  },
  /**
   * 执行对象执行器方法
   * @param  {String} className  类编码
   * @param  {String} methodName 方法名称
   * @param  {Obj} paramObj 参数
   * @return {Obj} 返回值
   */
  execUtil (className, methodName, paramObj) {
    // 连接bizDriver调用对象执行器
    return axios.post(`${utils.getConfig('execHost')}`, {
      className, methodName, paramObj
    })
  },
  /**
   * 执行对象执行器上传方法
   * @param  {String} className  类编码
   * @param  {String} methodName 方法名称
   * @param  {Obj} paramObj 参数
   * @return {Obj} 返回值
   */
  execUpload (className, methodName, paramObj, file) {
    let params = new FormData()
    params.append('className', className)
    params.append('methodName', methodName)
    params.append('paramObj', paramObj)
    params.append('file', file, file.name)
    return axios.create().post(`${utils.getConfig('execHost')}4Upload`, params, {
      headers: {'Content-Type': 'multipart/form-data'}
    })
  },
  // 转换字段
  // 示例 convertObj(obj, {
  //  a: '_a',
  //  b: '_b'
  // })
  // a,b是转换后的字段，_a,_b是转换前的字段，不转换的字段保留
  convertObj (obj, fieldMap) {
  },
  /**
   * 数组比较
   * @param arr1
   * @param arr2
   * @returns {boolean}
   */
  arrContrast (arr1, arr2) {
    for (let i = 0; i < arr1.length; i++) {
      if (arr1 !== arr2) {
        return false
      }
    }
    return true
  }
}
