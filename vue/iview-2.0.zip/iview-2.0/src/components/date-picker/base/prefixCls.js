
export default 'ivu-date-picker-cells';