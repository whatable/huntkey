import MenuGroup from '../menu/menu-group.vue';

export default MenuGroup;