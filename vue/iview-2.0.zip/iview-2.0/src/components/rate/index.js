import Rate from './rate.vue';
export default Rate;