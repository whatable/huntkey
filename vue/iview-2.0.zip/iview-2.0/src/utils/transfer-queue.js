let transferIndex = 0;

function transferIncrease() {
    transferIndex++;
}

export {transferIndex, transferIncrease};